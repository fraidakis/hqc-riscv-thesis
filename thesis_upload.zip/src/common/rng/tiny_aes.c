/* src/common/rng/tiny_aes.c
 *
 * Compact AES-256 implementation sufficient for the KAT AES-CTR DRBG.
 *
 * Based on the public-domain TinyAES by kokke:
 *   https://github.com/kokke/tiny-AES-c  (commit a793a1ea)
 * Stripped to ECB-encrypt-only, AES-256 key only.
 *
 * This is explicitly NOT a constant-time implementation and MUST NOT be
 * used outside KAT seed generation.  For production entropy on bare metal,
 * use the processor's hardware entropy source or a constant-time AES-NI
 * equivalent.
 *
 * Public domain — no copyright assertion.
 */

#include "tiny_aes.h"
#include <stdint.h>
#include <string.h>

/* ── AES constants ─────────────────────────────────────────────────────────── */
#define Nb   4   /* columns (32-bit words) in the state  = 4  */
#define Nk   8   /* key length in 32-bit words for AES-256    */
#define Nr  14   /* number of rounds for AES-256              */

static const uint8_t sbox[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

static const uint8_t rcon[11] = {
    0x8d,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36
};

static uint8_t xtime(uint8_t x) {
    return (uint8_t)((x << 1) ^ (((x >> 7) & 1) * 0x1b));
}

static uint8_t gmul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        uint8_t hi = a & 0x80;
        a = (uint8_t)(a << 1);
        if (hi) a ^= 0x1b;
        b >>= 1;
    }
    return p;
}

/* ── Key expansion ─────────────────────────────────────────────────────────── */
void aes256_key_expansion(const uint8_t key[32], uint8_t round_key[240])
{
    memcpy(round_key, key, 32);
    for (int i = Nk; i < Nb * (Nr + 1); i++) {
        uint8_t tmp[4];
        memcpy(tmp, round_key + (size_t)(i - 1) * 4, 4);
        if (i % Nk == 0) {
            /* RotWord */
            uint8_t t = tmp[0];
            tmp[0] = tmp[1]; tmp[1] = tmp[2]; tmp[2] = tmp[3]; tmp[3] = t;
            /* SubWord */
            for (int j = 0; j < 4; j++) tmp[j] = sbox[tmp[j]];
            tmp[0] ^= rcon[i / Nk];
        } else if (Nk > 6 && i % Nk == 4) {
            for (int j = 0; j < 4; j++) tmp[j] = sbox[tmp[j]];
        }
        for (int j = 0; j < 4; j++)
            round_key[(size_t)i * 4 + j] = round_key[(size_t)(i - Nk) * 4 + j] ^ tmp[j];
    }
}

/* ── AES-256 ECB encryption of one block ──────────────────────────────────── */

/* State is a 4×4 byte matrix stored column-major. */
typedef uint8_t state_t[4][4];

static void sub_bytes(state_t s)
{
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 4; c++)
            s[r][c] = sbox[s[r][c]];
}

static void shift_rows(state_t s)
{
    uint8_t tmp;
    /* Row 1: shift left 1 */
    tmp = s[1][0]; s[1][0] = s[1][1]; s[1][1] = s[1][2]; s[1][2] = s[1][3]; s[1][3] = tmp;
    /* Row 2: shift left 2 */
    tmp = s[2][0]; s[2][0] = s[2][2]; s[2][2] = tmp;
    tmp = s[2][1]; s[2][1] = s[2][3]; s[2][3] = tmp;
    /* Row 3: shift left 3 */
    tmp = s[3][3]; s[3][3] = s[3][2]; s[3][2] = s[3][1]; s[3][1] = s[3][0]; s[3][0] = tmp;
}

static void mix_columns(state_t s)
{
    for (int c = 0; c < 4; c++) {
        uint8_t a = s[0][c], b = s[1][c], d = s[2][c], e = s[3][c];
        s[0][c] = gmul(a,2)^gmul(b,3)^d^e;
        s[1][c] = a^gmul(b,2)^gmul(d,3)^e;
        s[2][c] = a^b^gmul(d,2)^gmul(e,3);
        s[3][c] = gmul(a,3)^b^d^gmul(e,2);
        (void)xtime; /* suppress unused warning — gmul covers all cases */
    }
}

static void add_round_key(state_t s, const uint8_t *rk)
{
    for (int c = 0; c < 4; c++)
        for (int r = 0; r < 4; r++)
            s[r][c] ^= rk[(size_t)c * 4 + r];
}

void aes256_ecb_encrypt(const uint8_t round_key[240],
                        const uint8_t in[16],
                        uint8_t       out[16])
{
    state_t s;
    /* Load input into column-major state */
    for (int c = 0; c < 4; c++)
        for (int r = 0; r < 4; r++)
            s[r][c] = in[c * 4 + r];

    add_round_key(s, round_key);

    for (int round = 1; round < Nr; round++) {
        sub_bytes(s);
        shift_rows(s);
        mix_columns(s);
        add_round_key(s, round_key + (size_t)round * 16);
    }
    /* Final round: no MixColumns */
    sub_bytes(s);
    shift_rows(s);
    add_round_key(s, round_key + (size_t)Nr * 16);

    /* Store state back to bytes */
    for (int c = 0; c < 4; c++)
        for (int r = 0; r < 4; r++)
            out[c * 4 + r] = s[r][c];
}
