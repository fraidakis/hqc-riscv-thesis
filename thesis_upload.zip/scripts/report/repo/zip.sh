#!/usr/bin/env bash
# Goal: include everything needed to EDIT .tex/TikZ + writing context, exclude binaries/data bloat.
# NOTE: the produced zip is for EDITING, not for compiling (logos/PDFs are excluded on purpose).

set -euo pipefail

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "${REPO_ROOT}" || ! -d "${REPO_ROOT}" ]]; then
  echo "ERROR: not inside a git repository." >&2
  exit 1
fi
cd "${REPO_ROOT}"

WITH_SRC=1
for arg in "$@"; do
  case "${arg}" in
    --no-src) WITH_SRC=0 ;;
    --with-src) WITH_SRC=1 ;;
    *) echo "Unknown option: ${arg}" >&2; exit 2 ;;
  esac
done

OUTPUT="${REPO_ROOT}/thesis_upload.zip"
rm -f "${OUTPUT}"

# --- Paths to include (only those that exist are added) ---
CANDIDATES=(
  "docs/thesis/"
  "docs/thesis-helper/"
  "docs/references/markdown/"
  "docs/references/notes/"
  "docs/proposals/"
  "results/reports/summaries/"
  "results/reports/variants/"
  "scripts/report/repo/"          # round-trip helper scripts (zip/unzip/make-edits-zip)
)
if [[ "${WITH_SRC}" -eq 1 ]]; then
  CANDIDATES+=( "src/" "include/" )
fi

INCLUDE=()
for p in "${CANDIDATES[@]}"; do
  if [[ -e "${p}" ]]; then
    INCLUDE+=( "${p}" )
  else
    echo "WARN: skipping missing path: ${p}" >&2
  fi
done
[[ "${#INCLUDE[@]}" -gt 0 ]] || { echo "ERROR: nothing to include." >&2; exit 1; }

# --- Exclusions: binaries, data, VCS, caches, editor junk, LaTeX intermediates ---
EXCLUDE=(
  "*.csv" "*.pdf" "*.png" "*.jpg" "*.jpeg" "*.gif" "*.eps" "*.svg"
  "*.zip" "*.o" "*.elf" "*.bin" "*.so" "*.a"
  "*/.git/*" ".git/*"
  "*/__pycache__/*" "*.pyc"
  "*/vendor/*" "*/build/*" "docs/thesis/build/*" "docs/thesis/code/*"
  "*.bak" "*.orig" "*~" "*.swp" ".DS_Store"
  "*.aux" "*.log" "*.out" "*.toc" "*.fls" "*.fdb_latexmk" "*.synctex.gz"
  "*.bbl" "*.blg" "*.bcf" "*.run.xml" "*.xdv"
  "*.glo" "*.gls" "*.glg" "*.acn" "*.acr" "*.alg" "*.ist"
  "*.lof" "*.lot" "*.nav" "*.snm" "*.vrb"
  "compile_commands.json" "thesis_upload.zip" "MANIFEST.txt"
  "scoreboard.md"
)

# --- Sanity: warn about CRLF in .tex (can break patches later) ---
if CRLF=$(grep -rlIU --include='*.tex' $'\r' "${INCLUDE[@]}" 2>/dev/null); then
  if [[ -n "${CRLF}" ]]; then
    echo "WARN: CRLF line endings detected in:" >&2
    echo "${CRLF}" | sed 's/^/  /' >&2
  fi
fi

# --- Build the zip ---
zip -rX "${OUTPUT}" "${INCLUDE[@]}" -x "${EXCLUDE[@]}" >/dev/null

# --- Manifest with per-file sha256 (for byte-level verification of round-trips) ---
MANIFEST="${REPO_ROOT}/MANIFEST.txt"
{
  echo "# Thesis upload manifest"
  echo "# generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "# repo:      ${REPO_ROOT}"
  echo "# with_src:  ${WITH_SRC}"
  echo "# format: <sha256>  <path>"
  echo
  while IFS= read -r f; do
    [[ -f "${f}" ]] && sha256sum "${f}"
  done < <(unzip -Z1 "${OUTPUT}" | sort)
} > "${MANIFEST}"
zip -qX "${OUTPUT}" "MANIFEST.txt"
rm -f "${MANIFEST}"

COUNT="$(unzip -Z1 "${OUTPUT}" | wc -l | tr -d ' ')"
SIZE="$(du -sh "${OUTPUT}" | cut -f1)"
echo "OK: ${OUTPUT}"
echo "  files: ${COUNT}"
echo "  size:  ${SIZE}"
echo "  (MANIFEST.txt inside lists every file + sha256)"
