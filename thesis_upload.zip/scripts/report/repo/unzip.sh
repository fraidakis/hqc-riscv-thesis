#!/usr/bin/env bash
# =============================================================================
# apply-edits.sh — (LOCAL side) Apply a "changed files" zip from the agent into
#                  THIS repo, safely, leaving changes UNSTAGED for VSCode review.
#
# Run from inside your repo (it uses the current git repo).
#
# Workflow:
#   1. Commit your current work (clean tree = baseline).
#   2. Download the edits zip (defaults to ~/Downloads/thesis-edits.zip).
#   3. Run this script -> overwrites only the changed files, then deletes the zip.
#   4. Review the diff in VSCode (Source Control); revert hunks you dislike.
#   5. Commit the accepted result. Repeat.
#
# Usage:
#   ./scripts/apply-edits.sh                     # uses ~/Downloads/thesis-edits.zip
#   ./scripts/apply-edits.sh path/to/other.zip   # explicit zip
#   ./scripts/apply-edits.sh [--branch <name>] [--allow-dirty] [--dry-run] [--keep-zip]
# =============================================================================

set -euo pipefail

# ---- Defaults --------------------------------------------------------------
ZIP="$HOME/Downloads/thesis-edits.zip"
BRANCH=""
ALLOW_DIRTY=0
DRY_RUN=0
KEEP_ZIP=0

# ---- Colors (plain if not a TTY) -------------------------------------------
if [ -t 1 ]; then
  BOLD=$'\033[1m'; RED=$'\033[31m'; GRN=$'\033[32m'; YEL=$'\033[33m'; RST=$'\033[0m'
else
  BOLD=""; RED=""; GRN=""; YEL=""; RST=""
fi
info() { printf '%s==>%s %s\n' "$GRN" "$RST" "$*"; }
warn() { printf '%s[!]%s %s\n' "$YEL" "$RST" "$*"; }
die()  { printf '%s[x]%s %s\n' "$RED" "$RST" "$*" >&2; exit 1; }

# ---- Parse arguments -------------------------------------------------------
ZIP_SET=0
while [ $# -gt 0 ]; do
  case "$1" in
    --branch)      BRANCH="${2:-}"; shift 2 ;;
    --allow-dirty) ALLOW_DIRTY=1;   shift ;;
    --dry-run)     DRY_RUN=1;       shift ;;
    --keep-zip)    KEEP_ZIP=1;      shift ;;
    -h|--help)     grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*)            die "Unknown option: $1" ;;
    *)             [ "$ZIP_SET" -eq 0 ] && { ZIP="$1"; ZIP_SET=1; } || die "Unexpected arg: $1"; shift ;;
  esac
done

[ -f "$ZIP" ]    || die "Zip not found: $ZIP  (download it or pass a path)"
command -v git   >/dev/null || die "git is required but not found."
command -v unzip >/dev/null || die "unzip is required but not found."

# ---- Resolve repo root (must run from inside the repo) ---------------------
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" \
  || die "Not inside a git repository. cd into your repo and re-run."
ZIP="$(cd "$(dirname "$ZIP")" && pwd)/$(basename "$ZIP")"   # absolutize
cd "$REPO_ROOT"
info "Repository:  ${BOLD}$REPO_ROOT${RST}"
info "Edits zip:   ${BOLD}$ZIP${RST}"

# ---- Safety: require a clean working tree ----------------------------------
if [ -n "$(git status --porcelain)" ]; then
  if [ "$ALLOW_DIRTY" -eq 1 ]; then
    warn "Working tree is DIRTY but --allow-dirty set; uncommitted edits may be overwritten."
  else
    git status --short
    die "Working tree is not clean. Commit or stash first, or re-run with --allow-dirty."
  fi
fi

# ---- Safety net: tag a restore point --------------------------------------
RESTORE_TAG="pre-edits-$(date +%Y%m%d-%H%M%S)"
git tag "$RESTORE_TAG" >/dev/null 2>&1 || true
info "Restore point: ${BOLD}$RESTORE_TAG${RST}  (undo round with: git reset --hard $RESTORE_TAG)"

# ---- Optional review branch ------------------------------------------------
if [ -n "$BRANCH" ]; then
  git show-ref --verify --quiet "refs/heads/$BRANCH" && git checkout "$BRANCH" || git checkout -b "$BRANCH"
  info "On review branch: ${BOLD}$BRANCH${RST}"
fi

# ---- Inspect the zip before touching anything ------------------------------
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$ZIP" -d "$TMP" || die "Failed to unzip $ZIP"

mapfile -t FILES < <(cd "$TMP" && find . -type f | sed 's|^\./||' | sort)
[ "${#FILES[@]}" -gt 0 ] || die "Zip contains no files."

echo
info "${BOLD}${#FILES[@]} file(s) will be written:${RST}"
for f in "${FILES[@]}"; do
  if [ -e "$REPO_ROOT/$f" ]; then printf '   %sM%s %s\n' "$YEL" "$RST" "$f"
  else                            printf '   %sA%s %s\n' "$GRN" "$RST" "$f"; fi
done
echo

# ---- Dry run stops here (zip NOT deleted) ----------------------------------
if [ "$DRY_RUN" -eq 1 ]; then
  warn "Dry run — no files written, zip left in place. Re-run without --dry-run to apply."
  exit 0
fi

# ---- Confirm ---------------------------------------------------------------
printf '%sProceed and overwrite these files?%s [y/N] ' "$BOLD" "$RST"
read -r reply
case "$reply" in y|Y|yes|YES) ;; *) die "Aborted by user (zip kept)." ;; esac

# ---- Copy files in, preserving directory structure ------------------------
for f in "${FILES[@]}"; do
  mkdir -p "$REPO_ROOT/$(dirname "$f")"
  cp -f "$TMP/$f" "$REPO_ROOT/$f"
done
info "Files written."

# ---- Delete the downloaded zip (keeps next download named cleanly) --------
if [ "$KEEP_ZIP" -eq 1 ]; then
  warn "Kept zip at $ZIP (--keep-zip)."
else
  rm -f "$ZIP" && info "Deleted $ZIP (so the next download stays 'thesis-edits.zip')."
fi

# ---- Show the result for review -------------------------------------------
echo
info "${BOLD}Change summary (unstaged):${RST}"
git --no-pager diff --stat || true
echo
info "Next steps:"
cat <<EOF
   1. VSCode -> Source Control: review every hunk; discard the ones you don't want.
   2. When happy:  git add -A && git commit -m \"Apply round of edits\"
   3. Undo the whole round:  git reset --hard $RESTORE_TAG
EOF
