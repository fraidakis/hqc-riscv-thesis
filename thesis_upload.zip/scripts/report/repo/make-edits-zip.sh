#!/usr/bin/env bash
# =============================================================================
# make-edits-zip.sh — (SANDBOX side) Package changed files into thesis-edits.zip
#
# Run from anywhere inside the repo, AFTER editing. It determines which files
# changed (via the baseline git commit made right after extracting the upload)
# and zips exactly those, preserving repo-relative paths so that
# apply-edits.sh can drop them straight in with `unzip -o`.
#
# Usage:
#   bash scripts/make-edits-zip.sh                  # auto-detect via git
#   bash scripts/make-edits-zip.sh f1 f2 ...         # explicit file list
#   OUT=/data/thesis-edits.zip bash scripts/make-edits-zip.sh
#
# Note: this flow ADDS/OVERWRITES files. Deletions are NOT propagated by the
# zip — handle file removals manually/separately if ever needed.
# =============================================================================

set -euo pipefail

OUT="${OUT:-/data/thesis-edits.zip}"

command -v zip >/dev/null || { echo "zip is required" >&2; exit 1; }

# Move to repo root so zipped paths are repo-relative
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"

# ---- Collect changed files -------------------------------------------------
declare -a FILES=()
if [ "$#" -gt 0 ]; then
  FILES=("$@")
elif git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  while IFS= read -r f; do [ -n "$f" ] && FILES+=("$f"); done < <(
    { git diff --name-only;                    # unstaged modifications
      git diff --name-only --cached;           # staged
      git ls-files --others --exclude-standard; # new untracked
    } | sort -u
  )
else
  echo "Not a git repo and no files given. Pass changed files explicitly." >&2
  exit 1
fi

# Keep only existing files (skip deletions / typos)
declare -a EXIST=()
for f in "${FILES[@]}"; do
  if [ -f "$f" ]; then EXIST+=("$f"); else echo "  skip (missing/deleted): $f" >&2; fi
done
[ "${#EXIST[@]}" -gt 0 ] || { echo "No changed files to package." >&2; exit 1; }

# ---- Build the zip ---------------------------------------------------------
rm -f "$OUT"
mkdir -p "$(dirname "$OUT")"
printf '%s\n' "${EXIST[@]}" | zip -q "$OUT" -@

echo "Packaged ${#EXIST[@]} file(s) -> $OUT"
printf '  %s\n' "${EXIST[@]}"
command -v sha256sum >/dev/null && echo "sha256: $(sha256sum "$OUT" | cut -d' ' -f1)"
