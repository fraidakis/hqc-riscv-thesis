---
source_pdf: docs/references/pdf/other-platforms/A High Efficiency Hardware Design for the Post-Quantum KEM HQC.pdf
converted_at: 2026-05-29 22:40
conversion_time: 10.2s
tool: pymupdf4llm
---

**POLITECNICO DI MILANO** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

_Francesco Antognazza1_ , Alessandro Barenghi1, Gerardo Pelosi1, Ruggero Susella2 

- 1 Department of Electonics, Information, and Bioengineering (DEIB), Politecnico di Milano, Milano, Italy 2 STMicrolectronics S.r.l., Agrate Brianza, Italy 

_HOST 2024 · Washington D.C., USA · May 8, 2024_ 

**2** 

## **The quantum threat** 

**==> picture [210 x 66] intentionally omitted <==**

**----- Start of picture text -----**<br>
1) Keygen<br>Private keyB<br>2) Encapsulation 3) Decapsulation Public keyB<br>Public keyB Private keyB<br>A B<br>**----- End of picture text -----**<br>


- Today we assist to continuous advancements in the computational capabilities of quantum computers: _>_ 1000 of qubits in 2023 

- Shor’s algorithm speeds up part of the cryptanalysis of **all** currently deployed asymmetric algorithms 

- In 2016 NIST started the Post-Quantum standardization process 

   - CRYSTALS-Kyber (FIPS 203), CRYSTALS-Dilithium (FIPS 204), SPHINCS+ (FIPS 205), FALCON (WIP) 

   - Portfolio variety: standardize also a code-based scheme among Classic McEliece, BIKE, **HQC** , and a new call for digital signatures 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**3** 

## **Our contribution** 

We focused on HQC due to its strong security properties, providing a full RTL hardware accelerator: 

- having a flexible architecture for the binary polynomial arithmetics 

- proposing new approach for the modulo operation during the sample of polynomials: no use of DSP while providing low latency 

- ■ using the state-of-the-art algebraic encoders and decoders and adapting them for the HQC public error correction code 

- suggesting an optimization to the HQC algorithm improving the overall performance of the scheme 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number 

_a_ = _a_ 0 + _a_ 1 _x_ + _. . ._ + _ap−_ 1 _x[p][−]_[1] _∈_ **R** stored as vector **a** =[ _a_ 0 _, a_ 1 _, . . . , ap−_ 1] 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) 

_a_ = _a_ 0 + _a_ 1 _x_ + _. . ._ + _ap−_ 1 _x[p][−]_[1] _∈_ **R** stored as vector **a** =[ _a_ 0 _, a_ 1 _, . . . , ap−_ 1] 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

_a_ = _a_ 0 + _a_ 1 _x_ + _. . ._ + _ap−_ 1 _x[p][−]_[1] _∈_ **R** stored as vector **a** =[ _a_ 0 _, a_ 1 _, . . . , ap−_ 1] Moderate Density Parity Check code = _⇒ w ≈[√] p_ Since _ai ∈_ F2, an element _a ∈_ **R** _w_ stored as vector of the non-zero _i_ 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

## **polynomial addition (** + **)** 

**==> picture [318 x 5] intentionally omitted <==**

Coefficient-wise addition: XOR ( _⊕_ ) boolean operator as coefficients in F2 

**==> picture [232 x 34] intentionally omitted <==**

**==> picture [136 x 10] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

## _−_ **polynomial subtraction ( )** 

**==> picture [318 x 5] intentionally omitted <==**

Coefficient-wise subtraction: XOR ( _⊕_ ) boolean operator as coefficients in F2 

**==> picture [232 x 34] intentionally omitted <==**

**==> picture [136 x 10] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

## _·_ **polynomial multiplication ( )** 

**==> picture [318 x 5] intentionally omitted <==**

Cyclic convolution: _ci_ =[�] _j_ + _k ≡i_ mod _p_[(] _[a][j][⊗][b][k]_[)] _[,][i][,][ j][,][ k][∈{]_[0] _[,]_[ 1] _[, . . . ,][ p][ −]_[1] _[}]_ 

**==> picture [234 x 35] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

## _·_ **polynomial multiplication ( )** 

**==> picture [318 x 5] intentionally omitted <==**

Cyclic convolution: _ci_ =[�] _j_ + _k ≡i_ mod _p_[(] _[a][j][⊗][b][k]_[)] _[,][i][,][ j][,][ k][∈{]_[0] _[,]_[ 1] _[, . . . ,][ p][ −]_[1] _[}]_ 

**==> picture [300 x 46] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

## _·_ **polynomial multiplication ( )** 

**==> picture [318 x 5] intentionally omitted <==**

Cyclic convolution: _ci_ =[�] _j_ + _k ≡i_ mod _p_[(] _[a][j][⊗][b][k]_[)] _[,][i][,][ j][,][ k][∈{]_[0] _[,]_[ 1] _[, . . . ,][ p][ −]_[1] _[}]_ 

**==> picture [234 x 46] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

## _·_ **polynomial multiplication ( )** 

**==> picture [318 x 5] intentionally omitted <==**

Cyclic convolution: _ci_ =[�] _j_ + _k ≡i_ mod _p_[(] _[a][j][⊗][b][k]_[)] _[,][i][,][ j][,][ k][∈{]_[0] _[,]_[ 1] _[, . . . ,][ p][ −]_[1] _[}]_ 

**==> picture [234 x 76] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**4** 

## **Background** 

## **Algebraic structure: binary polynomial ring** 

**==> picture [318 x 5] intentionally omitted <==**

■ **R** : polynomial ring F2[ _x_ ] _/⟨x[p] −_ 1 _⟩_ , where _p_ is a prime number ■ _ω_ ( _a_ ): Hamming weight of _a ∈_ **R** (number of non-zero binary coefficients) ■ **R** _w_ : set containing all polynomials in **R** with Hamming weight _w_ 

## _·_ **polynomial multiplication ( )** 

**==> picture [318 x 5] intentionally omitted <==**

Cyclic convolution: _ci_ =[�] _j_ + _k ≡i_ mod _p_[(] _[a][j][⊗][b][k]_[)] _[,][i][,][ j][,][ k][∈{]_[0] _[,]_[ 1] _[, . . . ,][ p][ −]_[1] _[}]_ 

**==> picture [234 x 76] intentionally omitted <==**

if _a ∈_ **R** _w_ and _b ∈_ **R** , has asymptotic complexity _Θ_ ( _pw_ ) = _Θ_ ( _p_ ~~_[√]_~~ _p_ ) = _Θ_ ( _p_[1] _[.]_[5] ) 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**5** 

## **Background** 

## **Error correction code** 

**==> picture [318 x 5] intentionally omitted <==**

■ quasi-cyclic random [2 _p, p, d_ ] code with a public parity-check matrix **H** = [ **I** _p |_ **rot** ( _h_ )] 

**==> picture [250 x 68] intentionally omitted <==**

## _h_ is a random vector generated from the public key seed 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**5** 

## **Background** 

## **Error correction code(s)** 

**==> picture [318 x 5] intentionally omitted <==**

■ quasi-cyclic random [2 _p, p, d_ ] code with a public parity-check matrix **H** = [ **I** _p |_ **rot** ( _h_ )] 

■ public [ _neni , keki , dedi_ ] fixed code generated by a shortened Reed-Solomon (RS) [ _ne, ke, de_ ] (external) code with a duplicated Reed-Muller (RM) [ _ni , ki , di_ ] (internal) code such that _neni ≈ p_ . 

**==> picture [234 x 57] intentionally omitted <==**

**----- Start of picture text -----**<br>
Encapsulation<br>information<br>word<br>MSG<br>**----- End of picture text -----**<br>


Decapsulation 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**5** 

## **Background** 

## **Error correction code(s)** 

**==> picture [318 x 5] intentionally omitted <==**

■ quasi-cyclic random [2 _p, p, d_ ] code with a public parity-check matrix **H** = [ **I** _p |_ **rot** ( _h_ )] 

■ public [ _neni , keki , dedi_ ] fixed code generated by a shortened Reed-Solomon (RS) [ _ne, ke, de_ ] (external) code with a duplicated Reed-Muller (RM) [ _ni , ki , di_ ] (internal) code such that _neni ≈ p_ . 

**==> picture [234 x 57] intentionally omitted <==**

**----- Start of picture text -----**<br>
Encapsulation<br>information<br>codeword<br>word<br>encode<br>MSG M S G<br>**----- End of picture text -----**<br>


Decapsulation 

**HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**5** 

## **Background** 

## **Error correction code(s)** 

**==> picture [318 x 5] intentionally omitted <==**

■ quasi-cyclic random [2 _p, p, d_ ] code with a public parity-check matrix **H** = [ **I** _p |_ **rot** ( _h_ )] 

■ public [ _neni , keki , dedi_ ] fixed code generated by a shortened Reed-Solomon (RS) [ _ne, ke, de_ ] (external) code with a duplicated Reed-Muller (RM) [ _ni , ki , di_ ] (internal) code such that _neni ≈ p_ . 

**==> picture [234 x 115] intentionally omitted <==**

**----- Start of picture text -----**<br>
Encapsulation random materialpublic key +<br>information uncorrectable<br>codeword<br>word codeword<br>encode<br>MSG M S G<br>Decapsulation<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**5** 

## **Background** 

## **Error correction code(s)** 

**==> picture [318 x 5] intentionally omitted <==**

■ quasi-cyclic random [2 _p, p, d_ ] code with a public parity-check matrix **H** = [ **I** _p |_ **rot** ( _h_ )] 

■ public [ _neni , keki , dedi_ ] fixed code generated by a shortened Reed-Solomon (RS) [ _ne, ke, de_ ] (external) code with a duplicated Reed-Muller (RM) [ _ni , ki , di_ ] (internal) code such that _neni ≈ p_ . 

**==> picture [234 x 115] intentionally omitted <==**

**----- Start of picture text -----**<br>
Encapsulation random materialpublic key +<br>information uncorrectable<br>codeword<br>word codeword<br>encode<br>MSG M S G<br>Decapsulation<br>uncorrectable<br>codeword<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**5** 

## **Background** 

## **Error correction code(s)** 

**==> picture [318 x 5] intentionally omitted <==**

■ quasi-cyclic random [2 _p, p, d_ ] code with a public parity-check matrix **H** = [ **I** _p |_ **rot** ( _h_ )] 

■ public [ _neni , keki , dedi_ ] fixed code generated by a shortened Reed-Solomon (RS) [ _ne, ke, de_ ] (external) code with a duplicated Reed-Muller (RM) [ _ni , ki , di_ ] (internal) code such that _neni ≈ p_ . 

**==> picture [234 x 115] intentionally omitted <==**

**----- Start of picture text -----**<br>
Encapsulation random materialpublic key +<br>information uncorrectable<br>codeword<br>word codeword<br>encode<br>MSG M S G<br>private key material Decapsulation<br>uncorrectable corrupted<br>codeword codeword<br>M S G<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**5** 

## **Background** 

## **Error correction code(s)** 

**==> picture [318 x 5] intentionally omitted <==**

■ quasi-cyclic random [2 _p, p, d_ ] code with a public parity-check matrix **H** = [ **I** _p |_ **rot** ( _h_ )] 

■ public [ _neni , keki , dedi_ ] fixed code generated by a shortened Reed-Solomon (RS) [ _ne, ke, de_ ] (external) code with a duplicated Reed-Muller (RM) [ _ni , ki , di_ ] (internal) code such that _neni ≈ p_ . 

**==> picture [234 x 115] intentionally omitted <==**

**----- Start of picture text -----**<br>
Encapsulation random materialpublic key +<br>information uncorrectable<br>codeword<br>word codeword<br>encode<br>MSG M S G<br>private key material Decapsulation<br>uncorrectable corrupted information<br>codeword codeword word<br>decode<br>M S G MSG<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**6** 

## **Background** 

NIST provided a security level classification to match the security margin of AES symmetric key encryption algorithm: 

Table: Security level classification by NIST 

|**Security level**|**AES parameter**|**HQC parameter**|
|---|---|---|
|1<br>AES-128<br>hqc-128<br>3<br>AES-192<br>hqc-192<br>5<br>AES-256<br>hqc-256|||



Each HQC parameter set specifies a different algebraic structure and public error correction code. 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Polynomial adder** Addition/subtraction **R** _×_ **R** _�→_ **R** 

**7** 

## In case both operands are in **R** : 

operand1 

operand2 

result 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**7** 

**Polynomial adder** Addition/subtraction **R** _×_ **R** _�→_ **R** 

## In case both operands are in **R** : ■ access data in blocks of _B_ = 128 bits 

operand1 0 1 2 3 4 5 6 7 8 9 10 11 

operand2 0 1 2 3 4 5 6 7 8 9 10 11 result 0 1 2 3 4 5 6 7 8 9 10 11 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Polynomial adder** Addition/subtraction **R** _×_ **R** _�→_ **R** 

**7** 

## In case both operands are in **R** : 

## ■ access data in blocks of _B_ = 128 bits 

## ■ perform the XOR operation block-wise 

operand1 0 1 2 3 4 5 6 7 8 9 10 11 operand2 0 1 2 3 4 5 6 7 8 9 10 11 result 0 1 2 3 4 5 6 7 8 9 10 11 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Polynomial adder** Addition/subtraction **R** _×_ **R** _�→_ **R** 

**7** 

## In case both operands are in **R** : 

## ■ access data in blocks of _B_ = 128 bits 

■ perform the XOR operation block-wise 

operand1 0 1 2 3 4 5 6 7 8 9 10 11 operand2 0 1 2 3 4 5 6 7 8 9 10 11 result 0 1 2 3 4 5 6 7 8 9 10 11 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Polynomial adder** Addition **R** _w ×_ **R** _�→_ **R** 

**7** 

In case operand1 in **R** _w_ and operand2 is in **R** : For each index _i_ in the vector of operand1: 

operand1 

544 284 302 1402 239 819 265 1053 

operand2/result 0 1 2 3 4 5 6 7 8 9 10 11 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**7** 

**Polynomial adder** Addition **R** _w ×_ **R** _�→_ **R** 

In case operand1 in **R** _w_ and operand2 is in **R** : For each index _i_ in the vector of operand1: ■ determine the operand2 block index as _⌊i/B⌋_ 

operand1 

544 284 302 1402 239 819 265 1053 

operand2/result 0 1 2 3 4 5 6 7 8 9 10 11 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Polynomial adder** Addition **R** _w ×_ **R** _�→_ **R** 

**7** 

In case operand1 in **R** _w_ and operand2 is in **R** : For each index _i_ in the vector of operand1: 

■ determine the operand2 block index as _⌊i/B⌋_ ■ flip a single bit of that block by generating _T_ = 1 _≪_ ( _i_ mod _B_ ) 

operand1 

544 284 302 1402 239 819 265 1053 

**==> picture [310 x 48] intentionally omitted <==**

**----- Start of picture text -----**<br>
operand2/result<br>0 1 2 3 4 5 6 7 8 9 10 11<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**7** 

**Polynomial adder** Addition **R** _w ×_ **R** _�→_ **R** 

In case operand1 in **R** _w_ and operand2 is in **R** : For each index _i_ in the vector of operand1: 

■ determine the operand2 block index as _⌊i/B⌋_ ■ flip a single bit of that block by generating _T_ = 1 _≪_ ( _i_ mod _B_ ) 

operand1 

544 284 302 1402 239 819 265 1053 

operand2/result 0 1 2 3 4 5 6 7 8 9 10 11 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**7** 

**Polynomial adder** Addition **R** _w ×_ **R** _�→_ **R** 

In case operand1 in **R** _w_ and operand2 is in **R** : For each index _i_ in the vector of operand1: 

■ determine the operand2 block index as _⌊i/B⌋_ ■ flip a single bit of that block by generating _T_ = 1 _≪_ ( _i_ mod _B_ ) ■ cannot be easily pipelined due to read-after-write dependency! 

operand1 

544 284 302 1402 239 819 265 1053 

operand2/result 0 1 2 3 4 5 6 7 8 9 10 11 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

## **Polynomial multiplier: R** _×_ **R** _w_ 

- One operand is always in **R** _w_ 

- The low weight of polynomial ( _≈[√] p_ ) makes the schoolbook shift-and-add approach interesting: _Θ_ ( _p_[1] _[.]_[5] ) asymptotic complexity 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

## **Polynomial multiplier: R** _×_ **R** _w_ 

- One operand is always in **R** _w_ 

- The low weight of polynomial ( _≈[√] p_ ) makes the schoolbook shift-and-add approach interesting: _Θ_ ( _p_[1] _[.]_[5] ) asymptotic complexity 

- There are faster algorithms based on the NTT with better asymptotic complexity, but: 

   - the polynomial ring is not compatible with any NTT algorithm 

   - memory access pattern is challenging to optimize 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

**Polynomial multiplier: R** _×_ **R** _w_ Single index processed 

start block = _⌊_ ( _p − i_ ) _/B⌋_ shift amount = _⌊_ ( _p − i_ ) mod _B⌋_ 

operand1 862 302 1402 239 819 265 1053 operand2 0 1 2 3 4 5 6 7 8 9 10 11 barrel shifter 1 

## 1332 862 302 1402 239 819 265 1053 

accumulator 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

**Polynomial multiplier: R** _×_ **R** _w_ Single index processed 

start block = _⌊_ ( _p − i_ ) _/B⌋_ shift amount = _⌊_ ( _p − i_ ) mod _B⌋_ 

operand1 862 302 1402 239 819 265 1053 operand2 0 1 2 3 4 5 6 7 8 9 10 11 barrel shifter 2 1 accumulator 0 

## 1332 862 302 1402 239 819 265 1053 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

**Polynomial multiplier: R** _×_ **R** _w_ Single index processed 

start block = _⌊_ ( _p − i_ ) _/B⌋_ shift amount = _⌊_ ( _p − i_ ) mod _B⌋_ 

**==> picture [302 x 164] intentionally omitted <==**

**----- Start of picture text -----**<br>
operand1<br>1332 862 302 1402 239 819 265 1053<br>operand2<br>0 1 2 3 4 5 6 7 8 9 10 11<br>barrel shifter<br>3 2<br>accumulator<br>1<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

**Polynomial multiplier: R** _×_ **R** _w_ Single index processed 

start block = _⌊_ ( _p − i_ ) _/B⌋_ shift amount = _⌊_ ( _p − i_ ) mod _B⌋_ 

operand1 

## 1332 862 302 1402 239 819 265 1053 

**==> picture [302 x 128] intentionally omitted <==**

**----- Start of picture text -----**<br>
operand2<br>0 1 2 3 4 5 6 7 8 9 10 11<br>barrel shifter<br>4 3<br>accumulator<br>2<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

**Polynomial multiplier: R** _×_ **R** _w_ Multiple indexes processed 

start block = _⌊_ ( _p − i_ ) _/B⌋_ shift amount = _⌊_ ( _p − i_ ) mod _B⌋_ 

**==> picture [302 x 164] intentionally omitted <==**

**----- Start of picture text -----**<br>
operand1<br>1332 862 302 1402 239 819 265 1053<br>operand2<br>0 1 2 3 4 5 6 7 8 9 10 11<br>barrel shifter barrel shifter<br>2 1 6 5<br>accumulator<br>6<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**8** 

**Polynomial multiplier: R** _×_ **R** _w_ Multiple indexes processed 

start block = _⌊_ ( _p − i_ ) _/B⌋_ shift amount = _⌊_ ( _p − i_ ) mod _B⌋_ 

**==> picture [302 x 164] intentionally omitted <==**

**----- Start of picture text -----**<br>
operand1<br>1332 862 302 1402 239 819 265 1053<br>operand2<br>0 1 2 3 4 5 6 7 8 9 10 11<br>barrel shifter barrel shifter<br>3 2 7 6<br>accumulator<br>7<br>**----- End of picture text -----**<br>


**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**9** 

**Sampling polynomials uniformly** Generating polynomials in **R** and **R** _w_ 

The component of the vector **h** _∈_ **R** are generated by the SHAKE-256 algorithm (a SHA-3 eXtensible Output Function) expanding the small 320-bits public seed. 

- The HQC specification uses the constant-time algorithm from [1]: 

■ runs in constant-time 

- uses of an exact amount of randomness (32 _· w_ bits) 

- requires a modulo operations between a 32-bit dividend and a generic 16-bit divisor 

We used a straightforward _shift-and-subtract_ pipelined algorithm, not requiring DSPs to perform the operation. 

At synthesis time the number of pipeline stages can be selected to balance resources usage and timing closure. 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**10** 

## **Public code: Reed Solomon** 

Encoder 

The code treats a block of data as a set of F28 elements (symbols). 

In a systematic encoding procedure the sequence of symbols of the message polynomial _u_ ( _x_ ) are the prefix of the codeword, and the error correcting symbols are the suffix: 

_c_ ( _x_ ) = _x[n][e][−][k][e] u_ ( _x_ ) _−_ � _x[n][e][−][k][e] u_ ( _x_ ) mod _g_ ( _x_ )� 

A simple way to produce such special encoding is through a Linear Feedback Shift Register [2]: 

**==> picture [98 x 46] intentionally omitted <==**

**==> picture [76 x 84] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**10** 

**Public code: Reed Solomon** Decoder 

Consider a valid codeword _c_ ( _x_ ) affected by an unknown error _e_ ( _x_ ) which has up to _t_ terms: 

_r_ ( _x_ ) = _c_ ( _x_ ) + _e_ ( _x_ ) 

## **Decoding algorith overview** 

**==> picture [318 x 5] intentionally omitted <==**

The decoder computes: 

■ the polynomial associated to the syndrome of the received word _r_ ( _x_ ) 

■ both positions and values of the coefficients of _e_ ( _x_ ) 

■ the error-free codeword is derived as _c_ ( _x_ ) = _r_ ( _x_ ) _− e_ ( _x_ ). 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**10** 

**Public code: Reed Solomon** Decoder 

First, the received polynomial _r_ ( _x_ ) is evaluated at each root _α[i]_ of the generator polynomial _g_ ( _x_ ) using the Horner’s method, determining the _syndrome polynomial S_ ( _x_ ) 

**==> picture [45 x 48] intentionally omitted <==**

**==> picture [45 x 48] intentionally omitted <==**

**==> picture [45 x 48] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**10** 

**Public code: Reed Solomon** Decoder 

We employed the design of the Enhanced Parallel Inversionless Berlekamp-Massey Algorithm (ePIBMA) introduced in [3]. 

The _error locator polynomial_ Λ( _x_ ) and the _auxiliary polynomial B_ ( _x_ ) are derived from the syndrome polynomial _S_ ( _x_ ) 

**==> picture [89 x 84] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**10** 

**Public code: Reed Solomon** Decoder 

Similarly, we used the Enhanced Chien Search and Error Evaluator design from [3]. The _error evaluator polynomial_ Ω( _x_ ) is computed from Λ( _x_ ) and _B_ ( _x_ ). 

**==> picture [174 x 175] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**11** 

**Public code: Reed Muller** Encoder 

To derive the 128-bit codewords corresponding to each 8-bit input message, we follow the traditional message vector multiplied by the generator matrix _G_ . 

`aaaaaaaa aaaaaaaa aaaaaaaa aaaaaaaa cccccccc cccccccc cccccccc cccccccc`   `f0f0f0f0 f0f0f0f0 f0f0f0f0 f0f0f0f0 ff00ff00 ff00ff00 ff00ff00 ff00ff00` _G_ = `ffff0000 ffff0000 ffff0000 ffff0000 ffffffff 00000000 ffffffff 00000000 ffffffff ffffffff 00000000 00000000`  `ffffffff ffffffff ffffffff ffffffff`  

Working with 32-bits words, the presence of repeated words in _G_ yields some identical intermediate values during the multiplication. 

Consequently, the size of multiplexers and the number of XOR gates were decreased substantially. 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**11** 

**Public code: Reed Muller** Decoder 

The operation is carried out by a Maximum Likelihood (ML) decoder computing a fast Hadamard transform [4] 

**==> picture [53 x 75] intentionally omitted <==**

**==> picture [53 x 38] intentionally omitted <==**

We find the maximum absolute value with a pipelined comparator tree computing pairwise maxima, acting on a tunable-sized input vector. 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**==> picture [363 x 273] intentionally omitted <==**

**----- Start of picture text -----**<br>
HQC schedule 12<br>HQC specification<br>poly sampler<br>poly sampler<br>expanderseed samplersparse<br>sparse<br>samplersparse denseadderto<br>sparse<br>by<br>seed dense dense<br>expander sampler multiplier<br>HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC<br>**----- End of picture text -----**<br>


**12** 

## **HQC schedule** 

**==> picture [229 x 187] intentionally omitted <==**

**----- Start of picture text -----**<br>
HQC specification proposed order<br>poly sampler poly sampler<br>poly sampler poly sampler<br>expanderseed samplersparse<br>sparse<br>samplersparse denseadderto<br>sparse<br>by<br>seed dense dense<br>expander sampler multiplier<br>**----- End of picture text -----**<br>


Performance gains from 13% to 32% over the entire cryptographic primitive **without any cost or security implications** 

**HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**13** 

## **Experimental results** 

Designed in SystemVerilog, tested with CocoTB following the Universal Verification Methodology (UVM). 

Synthesized on an Artix-7 `xc7a200tfbg484-3` FPGA, and validated it on a Digilent’s Arty A7-100T employing the (modified) official Known Answer Tests (KAT) via a UART module. 

The source code is available on Zenodo: 

**==> picture [86 x 86] intentionally omitted <==**

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Experimental results** Public code encoder/decoder 

**14** 

Table: Performance of the public error correction code decoder. Area-Time product in eSlices _·_ ns 

|**Parameter**<br>**Design**<br>**Resources**<br>**Frequency**<br>**Latency**<br>**Area-Time**<br>**set**<br>**eSlice**<br>**MHz**<br>_µs_<br>**product**|**Parameter**<br>**Design**<br>**Resources**<br>**Frequency**<br>**Latency**<br>**Area-Time**<br>**set**<br>**eSlice**<br>**MHz**<br>_µs_<br>**product**|
|---|---|
|hqc128<br>our<br>1794<br>212<br>**6.10**<br>**10.94**<br>[5]<br>1025<br>205<br>22.49<br>23.06<br>[6]<br>2923<br>-<br>-<br>-|1794<br>212<br>**6.10**<br>**10.94**|
|hqc192<br>our<br>2125<br>219<br>**7.69**<br>**16.35**<br>[5]<br>1135<br>212<br>25.87<br>29.37|2125<br>219<br>**7.69**<br>**16.35**|
|hqc256<br>our<br>[5]|2843<br>225<br>**12.02**<br>**34.18**|
||1240<br>206<br>44.66<br>55.37|



**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Experimental results** Fixed weight polynomial sampler 

**14** 

Table: Performance of fixed-weight polynomial samplers. Area-Time product[1] in eSlices _· µ_ s 

|**Parameter**<br>**Design**<br>**Resources**<br>**Frequency**<br>**Latency**<br>**Area-Time**<br>**set**<br>**DSP**<br>**eSlice**<br>**MHz**<br>_µs_<br>**product**|**Parameter**<br>**Design**<br>**Resources**<br>**Frequency**<br>**Latency**<br>**Area-Time**<br>**set**<br>**DSP**<br>**eSlice**<br>**MHz**<br>_µs_<br>**product**|
|---|---|
|hqc128<br>our<br>0<br>520<br>230<br>**10.15**<br>5.28<br>[5] CWW<br>**4**<br>179<br>201<br>15.23<br>2.73_⋆_<br>[5] FNB<br>0<br>335<br>223<br>6.63<br>2.22<br>[7]<br>0<br>646<br>170<br>5.74<br>3.71|0<br>520<br>230<br>**10.15**<br>5.28|
||**4**<br>179<br>201<br>15.23<br>2.73_⋆_|
|hqc192<br>our<br>0<br>509<br>237<br>**21.97**<br>11.18<br>[5] CWW<br>**5**<br>181<br>200<br>34.08<br>6.17_⋆_<br>[5] FNB<br>0<br>330<br>236<br>9.43<br>3.11<br>[7]<br>0<br>773<br>185<br>8.84<br>6.84|0<br>509<br>237<br>**21.97**<br>11.18|
||**5**<br>181<br>200<br>34.08<br>6.17_⋆_|
|hqc256<br>our<br>[5] CWW<br>[5] FNB<br>[7]|0<br>513<br>225<br>**39.26**<br>20.14|
||**5**<br>182<br>204<br>56.31<br>10.25_⋆_|
||0<br>399<br>242<br>13.42<br>5.36<br>0<br>777<br>181<br>12.53<br>9.74|



1 _⋆_ Contribution of DSP units not present in the AT product 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Experimental results** Top-level: Key Generation 

**14** 

Table: Performance of HQC keygen top-module w/o SHAKE256 (5520 LUTs and 2810 FFs). AT product in eSlices _·_ ns 

|**Parameter**<br>**Design**<br>**set**|**Resources**<br>**Frequency**<br>**Latency**<br>**Area-Time**<br>**eSlice**<br>**MHz**<br>_µs_<br>**product**|
|---|---|
|hqc128<br>[5]<br>1879<br>179<br>88<br>165<br>[6] (HLS, perf.)<br>2849<br>150<br>270<br>768<br>our<br>4267<br>208<br>**30**<br>**127**||
||4267<br>208<br>**30**<br>**127**|
|hqc192<br>[5]<br>1866<br>189<br>222<br>415<br>our<br>4348<br>207<br>**72**<br>**314**||
||4348<br>207<br>**72**<br>**314**|
|hqc256<br>[5]<br>1866<br>188<br>437<br>817<br>our<br>4272<br>201<br>**138**<br>**591**||
||4272<br>201<br>**138**<br>**591**|



**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Experimental results** Top-level: Encapsulation 

**14** 

Table: Performance of HQC encapsulation top-modules w/o SHAKE256 (5520 LUTs and 2810 FFs). AT product in eSlices _·_ ns 

|**Parameter**<br>**Design**<br>**set**|**Resources**<br>**Frequency**<br>**Latency**<br>**Area-Time**<br>**eSlice**<br>**MHz**<br>_µs_<br>**product**|
|---|---|
|hqc128<br>[5] (balanced)<br>2701<br>179<br>186<br>504<br>[5] (high speed)<br>3377<br>179<br>125<br>423<br>[6] (HLS, perf.)<br>4575<br>152<br>586<br>2682<br>our<br>4326<br>168<br>**79**<br>**343**||
||4326<br>168<br>**79**<br>**343**|
|hqc192<br>[5] (balanced)<br>2990<br>182<br>496<br>1484<br>[5] (high speed)<br>3785<br>196<br>292<br>1106<br>our<br>4468<br>175<br>**180**<br>**803**||
||4468<br>175<br>**180**<br>**803**|
|hqc256<br>[5] (balanced)<br>3123<br>182<br>973<br>3039<br>[5] (high speed)<br>3901<br>196<br>553<br>2160<br>our<br>4412<br>187<br>**313**<br>**1382**||
||4412<br>187<br>**313**<br>**1382**|



**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Experimental results** Top-level: Decapsulation 

**14** 

Table: Performance of HQC decapsulation top-modules w/o SHAKE256 (5520 LUTs and 2810 FFs). AT product in eSlices _·_ ns 

|**Parameter**<br>**Design**<br>**set**|**Resources**<br>**Frequency**<br>**Latency**<br>**Area-Time**<br>**eSlice**<br>**MHz**<br>_µs_<br>**product**|
|---|---|
|hqc128<br>[5] (balanced)<br>4806<br>192<br>251<br>1206<br>[5] (high speed)<br>5556<br>179<br>207<br>1154<br>[6] (HLS, perf.)<br>6130<br>152<br>1270<br>7787<br>our<br>5956<br>167<br>**119**<br>**709**||
||5956<br>167<br>**119**<br>**709**|
|hqc192<br>[5] (balanced)<br>5309<br>186<br>676<br>3590<br>[5] (high speed)<br>6051<br>186<br>498<br>3018<br>our<br>7068<br>161<br>**287**<br>**2026**||
||7068<br>161<br>**287**<br>**2026**|
|hqc256<br>[5] (balanced)<br>5549<br>186<br>1335<br>7408<br>[5] (high speed)<br>6289<br>186<br>966<br>6076<br>our<br>8098<br>151<br>**570**<br>**4614**||
||8098<br>151<br>**570**<br>**4614**|



**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**15** 

## **Conclusions** 

## Our work contributes to the current state-of-the-art: 

- improving both latency and efficiency of HQC Key Encapsulation Mechanism RTL designs 

- detailing an efficient implementation for the public error correction code in use by HQC 

- providing an optimization for the HQC algorithm significantly improving the performance of the algorithm 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**Thanks for your attention** 

**16** 

## Francesco Antognazza 

PhD student - Politecnico di Milano email: `francesco.antognazza@polimi.it` website: `https://antognazza.faculty.polimi.it/` 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**17** 

## **References I** 

- [1] Nicolas Sendrier. “Secure Sampling of Constant-Weight Words - Application to BIKE”. In: _IACR Cryptol. ePrint Arch._ (2021), p. 1631. URL: `https://eprint.iacr.org/2021/1631` . 

- [2] Shu Lin and Daniel J. Costello Jr. _Error control coding - fundamentals and applications_ . Prentice Hall computer applications in electrical engineering series. Prentice Hall, 1983. ISBN: 978-0-13-283796-5. 

- [3] Yingquan Wu. “New Scalable Decoder Architectures for Reed-Solomon Codes”. In: _IEEE Trans. Commun._ 63.8 (2015), pp. 2741–2761. DOI: `10.1109/TCOMM.2015.2445759` . URL: `https://doi.org/10.1109/TCOMM.2015.2445759` . 

- [4] Yair Be’ery and Jakov Snyders. “Optimal soft decision block decoders based on fast Hadamard transform”. In: _IEEE Trans. Inf. Theory_ 32.3 (1986), pp. 355–364. DOI: `10.1109/TIT.1986.1057189` . URL: `https://doi.org/10.1109/TIT.1986.1057189` . 

**HOST 2024 · Washington D.C., USA · May 8, 2024** 

**A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

**18** 

## **References II** 

- [5] Sanjay Deshpande et al. “Fast and Efficient Hardware Implementation of HQC”. In: _IACR Cryptol. ePrint Arch._ (2023). URL: `https://eprint.iacr.org/2022/1183` . 

[6] Carlos Aguilar Melchor et al. “Towards Automating Cryptographic Hardware Implementations: A Case Study of HQC”. In: _Code-Based Cryptography - 10th International Workshop, CBCrypto 2022, Trondheim, Norway, May 29-30, 2022, Revised Selected Papers_ . Ed. by Jean-Christophe Deneuville. Vol. 13839. Lecture Notes in Computer Science. Springer, 2022, pp. 62–76. DOI: `10.1007/978-3-031-29689-5\_4` . URL: `https://doi.org/10.1007/978-3-031-29689-5\_4` . 

[7] Pengzhou He, Yazheng Tu, and Jiafeng Xie. “LOCS: LOw-Latency and ConStant-Timing Implementation of Fixed-Weight Sampler for HQC”. In: _2023 IEEE International Symposium on Circuits and Systems (ISCAS)_ (2023), pp. 1–5. URL: `https://api.semanticscholar.org/CorpusID:260004183` . 

**HOST 2024 · Washington D.C., USA · May 8, 2024 A High Efficiency Hardware Design for the Post-Quantum KEM HQC** 

