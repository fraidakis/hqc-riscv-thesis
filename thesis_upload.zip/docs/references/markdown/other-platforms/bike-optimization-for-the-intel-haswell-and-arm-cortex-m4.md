---
source_pdf: docs/references/pdf/other-platforms/!BIKE optimization for the Intel Haswell and ARM Cortex-M4.pdf
converted_at: 2026-05-29 22:39
conversion_time: 6.7s
tool: pymupdf4llm
---

"The FAFFT has already been tested in BIKE" -> this is the paper, look page 17 

IACR Transactions on Cryptographic Hardware and Embedded Systems ISSN 2569-2925, Vol. 2021, No. 3, pp. 97–124. DOI:10.46586/tches.v2021.i3.97-124 

## **Optimizing BIKE for the Intel Haswell and ARM Cortex-M4** 

Ming-Shing Chen[1] , Tung Chou[2] and Markus Krausz[1] 

> 1 Ruhr University Bochum, Bochum, Germany `mschen@crypto.tw` , `markus.krausz@rub.de` 

> 2 Academia Sinica, Taipei, Taiwan `blueprint@crypto.tw` 

**Abstract.** BIKE is a key encapsulation mechanism that entered the third round of the NIST post-quantum cryptography standardization process. This paper presents two constant-time implementations for BIKE, one tailored for the Intel Haswell and one tailored for the ARM Cortex-M4. Our Haswell implementation is much faster than the `avx2` implementation written by the BIKE team: for `bikel1` , the level-1 parameter set, we achieve a 1.39x speedup for decapsulation (which is the slowest operation) and a 1.33x speedup for the sum of all operations. For `bikel3` , the level-3 parameter set, we achieve a 1.5x speedup for decapsulation and a 1.46x speedup for the sum of all operations. Our M4 implementation is more than two times faster than the _non-constant-time_ implementation `portable` written by the BIKE team. The speedups are achieved by both algorithm-level and instruction-level optimizations. **Keywords:** constant-time implementations · NIST PQC standardization · CortexM4 

## **1 Introduction** 

BIKE [ABB[+] 17] is a key encapsulation mechanism (KEM) involved in the NIST postquantum cryptography standardization process. It can be viewed as a variant of the code-based cryptosystem introduced in [MTSB13], which makes use of so-called “quasicyclic moderate-density parity-check” (QC-MDPC) codes. In July 2020, NIST announced that BIKE has been selected as one of 15 schemes that advanced to the third round of the process, making BIKE one of the candidates considered for standardization. 

During the standardization process, BIKE holds a nice security record: unlike many other candidates, the claimed security levels of BIKE haven never been challenged. BIKE also features small public keys: the public key sizes are around 1.5KB, 3KB, and 5KB for the level-1, level-3, and level-5 parameter sets, respectively. These features make BIKE a competitive candidate in the process. In fact, NIST also commented that 

“NIST views BIKE as one of the most promising code-based candidates.” 

in the status report for the second round candidates [AASA[+] 20]. 

Despite the advantages, there are two factors that arguably make BIKE look weaker than some other candidates. The first factor is that, although the BIKE team has identified the conditions on the decoder that would make the scheme CCA-secure, they are not able to prove that the decoder actually satisfies the conditions. On the other hand, BIKE can still be used in applications which require only CPA security. The other factor is the relatively slow speeds of the operations. The speed issue is what this paper aims to deal with. 

Permanent ID of this document: `7ea7ddcc350bc2666b5fb0221161a420` . Date: 2021.04.18. 

Licensed under Creative Commons License CC-BY 4.0. Received: 2020-10-15 Accepted: 2020-12-15 

Published: 2021-07-09 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

98 

## **1.1 Previous Works** 

There have been many previous papers on improving the speed of the cryptosystem introduced in [MTSB13] and its variants. In particular, the QcBits paper [Cho16] was the first one to present a fully constant-time software implementation. Later on, many papers tried to improve the speed of constant-time software implementations. For the purpose of this paper, instead of reviewing all related papers, we list some important optimization techniques adopted by the BIKE team. All the optimization techniques are related to _Rz_ = Z[ _y_ ] _/_ ( _y[r] −_ 1) or _R_ = F2[ _x_ ] _/_ ( _x[r] −_ 1). 

- As pointed out in [Cho16], there are many operations that can be viewed as multiplications in _Rz_ in the decoding algorithm. These multiplications are of the form _g_ ( _y_ ) _f_ ( _y_ ), where each coefficient _gi_ and _fi_ is either 0 or 1, and _g_ ( _y_ ) is a sparse polynomial. [Cho16] proposed to consider _g_ ( _y_ ) as[�] _s[y][−][s]_[and][compute][the][sum][of] all _y[−][s] f_ ( _y_ ) to obtain _g_ ( _y_ ) _f_ ( _y_ ). Each _y[−][s] f_ ( _y_ ) is computed using a circular shift on the coefficients of _f_ by _s_ positions. In order to make sure that the circular shift does not leak information through timing, [Cho16] proposed to make use of the concept of a Barrel shifter to build a “Barrel rotator”. 

- This idea of using a “Barrel rotator” would be very efficient if _r_ was a multiple of the register size. However, as _r_ is always an odd prime in BIKE, performing the circular shift directly will introduce some overhead. In order to reduce the overhead, [DG19] proposed to represent _f_ in a “duplicated form” such that _y[−][s] f_ ( _y_ ) can be obtained by performing a logical shift on the duplicated form. The logical shift is again implemented using the concept of a Barrel shifter. 

- To compute the sum[�] _s_[(] _[y][−][s][f]_[(] _[y]_[)),][[][Cho16][]][proposed][to][perform][the][computation][in] a bitsliced fashion to make use of the fact that each coefficient of _y[−][s] f_ ( _y_ ) is either 0 or 1. 

- There are many multiplications in _R_ in key generation, encapsulation, and decapsulation. In order to compute the product of two elements _f_ =[�] _i[f][i][x][i]_[and] _[g]_[=][ �] _j[g][j][x][j]_ in _R_ , the `clmul` implementation of [Cho16] represents _f_ and _g_ as[�] _i[F][i][z][i]_[and] � _j[G][j][z][j]_[, where] _[ z]_[=] _[ x]_[64][, and uses the] `[ pclmulqdq]`[ instruction to compute every] _[ F][i][G][j]_[.] [DG19] proposed to use Karatsuba recursively, where the bottom level of recursions is handled by `pclmulqdq` . 

- The public key is of the form _h_ 1 _· h[−]_ 0[1] where each _hi ∈R_ . Computation of _h[−]_ 0[1] _∈R_ can be computed using a multiplication chain as shown in [Cho16]. Inside the multiplication chain, it is often required to compute the 2 _[k]_ th power of an element _f ∈R_ for some constant _k_ . [DGK20a] proposed to compute such an exponentiation by permuting the coefficients in _f_ . When _k_ is large, this is much faster than carrying out _k_ squarings sequentially. 

Unfortunately, even with so many optimizations, the latest software speed of BIKE is still not very satisfying: the eBACs website [Be] reports that, on `titan0` , a machine with an Intel Haswell CPU, the level-1 parameter set `bikel1` takes more than 138000 cycles and 2650000 cycles to perform encapsulation and decapsulation, respectively. For comparison, `mceliece348864` , one of the level-1 parameter sets of a third-round code-based candidate Classic McEliece [ABC[+] 17], takes only 44652 and 132360 cycles, respectively, on the same machine. Note that this means that the situation of code-based candidates is quite different from the situation of lattice-based candidates, as structured lattice-based schemes are typically much faster than non-structured ones. 

The BIKE team has some optimized implementations for x86 machines, whose speeds rely heavily on the usage of instructions for carryless multiplications such as `pclmulqdq` . 

Ming-Shing Chen , Tung Chou 

and Markus Krausz 

99 

This raises the question whether BIKE can still run with reasonable speed on embedded systems where such instructions are not available. To our knowledge, there has not been any BIKE implementation tailored for embedded systems yet. 

## **1.2 Our Contribution** 

This paper presents two implementations of BIKE, one optimized for the Intel Haswell and one optimized for the Cortex-M4. Compared to the `avx2` implementation written by the BIKE team, for `bikel1` , we achieve a 1.39x speedup for decapsulation and a 1.33x speedup for the sum of all operations on Haswell. For `bikel3` , we achieve a 1.5x speedup for decapsulation and a 1.46x speedup for the sum of all operations on Haswell. Compared to the non-constant-time `portable` implementation written by the BIKE team, our implementation is more than two times faster for all the three operations on M4. Both of our implementations are constant-time: there is no memory access using secret indices, no branching with secret conditions, and no usage of variable-time instructions. 

We believe that our implementations will make BIKE a more interesting option for standardization. Even though we did not implement the largest parameter set `bikel5` , which was introduced in the 3rd-round specification, we expect that our optimization techniques (see below) will be useful for optimizing `bikel5` as well. We also expect the implementation techniques used for Haswell will be useful for optimizing BIKE for newer microarchitectures, e.g., those supporting AVX512. In addition, our optimization techniques for polynomial multiplications in _R_ can be useful for optimizing HQC [AMAB[+] 17], another third-round code-based candidate. 

## **1.3 Optimization Techniques** 

The speed of our implementations is achieved by using the following optimization techniques. 

- a) When performing a logical shift on the duplicated form of _f ∈Rz_ , we make use of matrix transpositions to change the representation of _f_ , so that a Barrel shifter is no longer required. As far as we can tell, this idea is completely original. This optimization is only used in our Haswell implementation. 

- b) We implement the Barrel shifter for shifting the duplicated form of _f ∈Rz_ using conditional execution and powerful multiply-and-accumulate instructions supported by the M4. We consider this as a purely instruction-level optimization. 

- c) The sum of all _y[−][s] f_ is computed using a sequence of half adders in the BIKE team’s implementation. We follow an algorithm explained by Boyar and Peralta [BP05] to use full adders whenever possible. The algorithm is more complex and requires more 

**Table 1:** Optimization techniques and where they are used: _•_ means that the technique is used for the corresponding operation on the corresponding platform, and _◦_ means that the technique is not used. 

||Haswell implementation|Haswell implementation|Haswell implementation|M4 implementation|M4 implementation|M4 implementation||
|---|---|---|---|---|---|---|---|
|technique|keygen|encap.|decap.|keygen|encap.|decap.|section|
|a)<br>b)<br>c)<br>d)<br>e)|_◦_<br>_◦_<br>_◦_<br>_•_<br>_◦_|_◦_<br>_◦_<br>_◦_<br>_•_<br>_◦_|_•_<br>_◦_<br>_•_<br>_•_<br>_◦_|_◦_<br>_◦_<br>_◦_<br>_◦_<br>_•_|_◦_<br>_◦_<br>_◦_<br>_◦_<br>_•_|_◦_<br>_•_<br>_•_<br>_◦_<br>_•_|3<br>4<br>5<br>6<br>7|



Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

100 

memory, but it reduces the number of logical operations required to compute the sum by a factor of more than 2. 

- d) The BIKE team’s implementations use the Karatsuba algorithm to optimize multiplications in _R_ . The Karatsuba algorithm is used recursively. Instead, we use a five-way recursive algorithm proposed by Bernstein in [Ber09a] for the top level of recursion. This optimization is only applied in our Haswell implementation. 

- e) We use a “Frobenius additive FFT” (FAFFT) to optimize multiplications in _R_ on the M4. We found that FAFFTs fit nicely with bitslicing, such that we are able to carry out multiplications in _R_ efficiently even without instructions for carryless multiplications. 

To summarize, a), b), and c) are used for multiplications in _Rz_ , while d) and e) are used for multiplications in _R_ . Table 1 summarizes where each of these techniques is used in our implementations. 

## **1.4 Availability of Source Code** 

Our implementations are adapted from the BIKE team’s implementation and hence will be distributed under the same Apache 2.0 license of the orignal implementations. We plan to submit our Haswell implementation to the eBACS project [Be] so that the source code can be included in SUPERCOP. The source code of our M4 implementation has been included in the `pqm4` project [KRSS] under the directories `crypto_kem/bikel1/m4f` and `crypto_kem/bikel3/m4f` . We also plan to submit both of our implementations as the artifact of our paper for CHES 2021. 

## **1.5 Organization of the paper** 

Section 2 reviews the latest specification of BIKE and shows why we need to perform multiplications in _Rz_ and multiplications in _R_ . Each of the remaining sections introduces one of our five optimization techniques; See Table 1. Section 8 shows our experimental results for multiplications in _Rz_ , multiplications in _R_ , and the three KEM operations. 

## **2 BIKE** 

This section reviews the third-round specification of BIKE [ABB[+] 17]. For the sake of completeness, we repeat some contents from the specification in this section. 

## **2.1 System Parameters.** 

BIKE uses system parameters _r, w, t,_ and _ℓ_ . The following table shows the values of the system parameters and the security level for each of the three parameter sets of BIKE, which we denote as `bikel1` , `bikel3` , and `bikel5` . 

||_r_|_w_|_t_|_ℓ_|level|
|---|---|---|---|---|---|
|`bikel1`<br>`bikel3`<br>`bikel5`|12323<br>24659<br>40973|142<br>206<br>274|134<br>199<br>264|256<br>256<br>256|1<br>3<br>5|



Ming-Shing Chen , Tung Chou and Markus Krausz 

101 

|**KeyGen**: ()_→_(_h_0_, h_1_, σ_)_, h_<br>Output: (_h_0_, h_1_, σ_)_∈Hw × M, h ∈R_<br>1: _h_0_, h_1<br>$ _←−Hw_<br>2: _h_=_h_1_· h−_1<br>0<br>3: _σ_<br>$ _←−M_|**Encaps**: _h →K, c_<br>Input: _h ∈R_<br>Output: _K ∈K, c ∈R × M_<br>1: _m_<br>$ _←−M_<br>2: _e_0_, e_1 _←_**H**(_m_)<br>3: _c_= (_e_0+_e_1_·h, m⊕_**L**(_e_0_, e_1))<br>4: _K ←_**K**(_m, c_)|
|---|---|
|**Decaps**: (_h_0_, h_1_, σ_)_, c →K_<br>Input: ((_h_0_, h_1)_, σ_)_∈Hw × M, c_= (_c_0_, c_1)_∈R × M_<br>Output: _K ∈K_<br>1: _e′ ←_decoder(_c_0_h_0_, h_0_, h_1)<br>▷_e′ ∈R_2 _∪{⊥}_<br>2: _m′_ =_c_1_⊕_**L**(_e′_)<br>▷with the convention_⊥_= (0_,_0)<br>3: **if** _e′_ =**H**(_m′_) **then** _K ←_**K**(_m′, c_), **else** _K ←_**K**(_σ, c_)||



**Figure 1:** BIKE’s key generation, encapsulation, and decapsulation. 

## **2.2 Hash Functions.** 

The BIKE team defines the hash functions **H** , **K** , **L** to have the following domains and ranges. 

- **H** : _M →Et_ , 

**==> picture [111 x 10] intentionally omitted <==**

- **L** : _R_[2] _→M_ , 

where the spaces _M_ , _K_ , and _Et_ are defined as follows. 

- _M_ = _{_ 0 _,_ 1 _}[ℓ]_ . 

- _K_ = _{_ 0 _,_ 1 _}[ℓ]_ . 

- _Et_ = _{_ ( _e_ 0 _, e_ 1) _∈R_[2] _| |e_ 0 _|_ + _|e_ 1 _|_ = _t}_ , where _|ei|_ means the number of nonzero coefficients in _ei_ . 

The concrete instantiation of **H** , **K** , **L** can be found in the specification and is beyond the scope of this paper. 

## **2.3 Key Generation, Encapsulation, and Decapsulation.** 

BIKE’s key generation, encapsulation, and decapsulation algorithms are depicted in Figure 1. As shown in the figure, the key generation algorithm generates a secret key ( _h_ 0 _, h_ 1 _, σ_ ) and a public key _h_ . ( _h_ 0 _, h_ 1) is in _Hw_ , which is defined as 

**==> picture [155 x 13] intentionally omitted <==**

**==> picture [4 x 3] intentionally omitted <==**

The encapsulation algorithm, on input a public key _h_ , generates a session key _K_ and a ciphertext _c_ encapsulating the session key. The decapsulation algorithm, on input a secret key ( _h_ 0 _, h_ 1 _, σ_ ) and a ciphertext _c_ , outputs a session key _K_ or _⊥_ . There are many multiplications in _R_ as one can see from the KEM operations and the decoding algorithm `decoder` defined in the next subsection, 

## **2.4 The Black-Gray Decoder** 

The decoding algorithm specified in the third-round specification is the black-gray decoder, which was introduced in [DGK20b]. The algorithm is shown in Algorithm 1 of the 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

102 

specification. The BIKE team described it as an algorithm that can be used for any code with a low-weight parity-check matrix. However, as shown in Figure 1, BIKE is a scheme with a ring structure. To facilitate our discussion in the following sections, we rephrased the algorithm so that operations in rings are explicitly shown. We emphasize that “rephrased” means that we do not create a new algorithm but merely write the original algorithm in a different way. Our version of the black-gray decoder uses the following notations. 

- Lift( _·_ ), which lifts an element from _R_ to _Rz_ . 

- Tr( _·_ ), which converts an element[�] _[r] i_ =0 _[−]_[1] _[f][i][x][i][∈R]_[,][into][Lift(] _[f]_[0][ +][ �] _[r] i_ =1 _[−]_[1] _[f][r][−][i][x][i]_[).] 

The black-gray decoder is summarized in Algorithm 1. It should be easy to see where the operations in _R_ are from with respect to the specification. Note that the multiplications of the form Tr( _hi_ ) _·_ Lift( _s_ ) are in _Rz_ , and _|_ Tr( _hi_ ) _|_ is always _w/_ 2. These multiplications are used to compute the numbers of unsatified parity-check equations. It has been explained in [Cho16] why computation of the numbers of unsatified parity-check equations can be viewed as multiplications in _Rz_ . For completeness, we note that the black-gray decoder uses (in addition to _r, w, t_ ) two integers `NbIter` _, τ_ and a function `threshold` as its parameters. The third-round specification defines `NbIter` = 5 for all parameter sets. How _τ_ and `threshold` are defined is irrelevant to the purpose of this paper. 

## **3 Circular Shifts with Matrix Transposition** 

As mentioned in the Introduction, in order to compute _g · f_ where _g, f ∈Rz_ , _gi, fi ∈{_ 0 _,_ 1 _}_ for all _i_ , we may write _g_ as[�] _s[y][−][s]_[with 0] _[ ≤][s < r]_[and compute] _[ gf]_[as][ �] _s_[(] _[y][−][s][f]_[).][For each] _s_ , _y[−][s] f_ can be computed by carrying out a circular shift on ( _f_ 0 _, . . . , fr−_ 1) by _s_ positions due to the structure of _Rz_ . Below we review how such a circular shift can be implemented using a Barrel shifter and propose a way to avoid the Barrel shifter. 

## **3.1 The Duplicated Form and the Barrel Shifter** 

In order to compute _y[−][s] f_ , the BIKE team follows [Cho16] to use a Barrel shifter and follows [DG19] to use a duplicated form for _f_ . The idea is to 

1. lift _f_ to Z[ _y_ ] and represent it as _f[′]_ = _f_ + ( _f_ mod _y[r][−]_[1] ) _y[r]_[1] and 

2. compute _y[−][s] f_ as (( _f[′] −_ ( _f[′]_ mod _y[s]_ )) _/y[s]_ ) mod _y[r]_ . 

The second step might look complicated, but computationally it simply means performing a logical shift (toward the direction of _f_ 0 _[′]_[)][of] _[s]_[positions][on][the][vector][of][2] _[r][ −]_[1][coefficients] of _f[′]_ and taking the first _r_ coefficients. Note that making _f[′]_ a longer polynomial will lead to the same result, as long as _fi[′]_[=] _[ f]_[(] _[i]_[mod] _[r]_[)][for] _[i][ ∈{]_[0] _[, . . . ,]_[ 2] _[r][ −]_[2] _[}]_[.] Let _b_ be a power of 2. To implement this idea, _f[′]_ is stored as an array of _b_ -bit words, where the values of the words are[�] _i[b]_ =0 _[−]_[1] _[f] i[ ′]_[2] _[i]_[,][�] _i[b]_ =0 _[−]_[1] _[f] i[ ′]_ + _b_[2] _[i]_[,][and][so][on.][Then,] _[f][ ′]_[is][first] shifted by _s_[(1)] = _s −_ ( _s_ mod _b_ ) positions and then by _s_[(0)] = _s_ mod _b_ positions. As _s_[(1)] is a multiple of _b_ , the shift by _s_[(1)] =[�] _j[s]_[(1)] _j_[2] _[j]_[positions][is][carried][out][as][a][sequence][of] conditional moves from word _i_ + 2 _[j] /b_ to word _i_ for each _j_ . The shift by _s_[(0)] positions can be carried out by a sequence of logical shifts and ORs on the words, assuming that corresponding instructions exist. 

The `avx2` implementation follows the strategy above, where _b_ is set to 256 to fit the size of YMM registers. Note that there is no general shift instruction for YMM registers, so the `avx2` implementation follows [GAB19] to use AVX intrinsics to carry out the shift by _s_[(0)] positions. 

> 1[DG19] actually uses (1 + _yr_ ) _f_ , which has one more coefficient than _f_ + ( _f_ mod _yr−_ 1) _yr_ . 

Ming-Shing Chen , Tung Chou 

and Markus Krausz 

103 

**Algorithm 1** The Black-Gray Decoder (rephrased) 

**Parameters** : _r, w, t, d_ = _w/_ 2, NbIter, _τ_ , threshold 

1: **procedure** decoder( _s, h_ 0 _, h_ 1) 2: ( _e_ 0 _, e_ 1) _←_ (0 _,_ 0) _∈R_[2] 3: **for** _i_ = 1 _, . . . ,_ NbIter **do** 4: _T ←_ threshold( _|s_ + _e_ 0 _h_ 0 + _e_ 1 _h_ 1 _|, i_ ) 5: _e_ 0 _, e_ 1 _, b_ 0 _, b_ 1 _, g_ 0 _, g_ 1 _←_ BFIter( _s_ + _e_ 0 _h_ 0 + _e_ 1 _h_ 1 _, e_ 0 _, e_ 1 _, T, h_ 0 _, h_ 1) 6: **if** _i_ = 1 **then** 7: _e_ 0 _, e_ 1 _←_ BFMaskedIter( _s_ + _e_ 0 _h_ 0 + _e_ 1 _h_ 1 _, e_ 0 _, e_ 1 _, b_ 0 _, b_ 1 _,_ ( _d_ + 1) _/_ 2 + 1 _, h_ 0 _, h_ 1) 8: _e_ 0 _, e_ 1 _←_ BFMaskedIter( _s_ + _e_ 0 _h_ 0 + _e_ 1 _h_ 1 _, e_ 0 _, e_ 1 _, g_ 0 _, g_ 1 _,_ ( _d_ + 1) _/_ 2 + 1 _, h_ 0 _, h_ 1) 9: **end if** 10: **end for** 11: **if** _s_ = _e_ 0 _h_ 0 + _e_ 1 _h_ 1 **then** 12: **return** ( _e_ 0 _, e_ 1) 13: **else** 14: **return** _⊥_ 15: **end if** 16: **end procedure** 17: **procedure** BFIter( _s, e, T, h_ 0 _, h_ 1) 18: ( _c_ 0 _, c_ 1) _←_ (Tr( _h_ 0) _·_ Lift( _s_ ) _,_ Tr( _h_ 1) _·_ Lift( _s_ )) 19: ( _b_ 0 _, b_ 1) _←_ (0 _,_ 0) _∈R_[2] 20: ( _g_ 0 _, g_ 1) _←_ (0 _,_ 0) _∈R_[2] 21: **for** _i_ = 0 _,_ 1 **do** 22: **for** _j_ = 0 _, . . . , r −_ 1 **do** 23: **if** _cij ≥ T_ **then** 24: _eij ← eij_ + 1 25: _bij ←_ 1 26: **else if** _cij ≥ τ_ **then** 27: _gij ←_ 1 28: **end if** 29: **end for** 30: **end for** 31: **return** _e_ 0 _, e_ 1 _, b_ 0 _, b_ 1 _, g_ 0 _, g_ 1 32: **end procedure** 33: **procedure** BFMaskedIter( _s, e, m_ 0 _, m_ 1 _, T, h_ 0 _, h_ 1) 34: ( _c_ 0 _, c_ 1) _←_ (Tr( _h_ 0) _·_ Lift( _s_ ) _,_ Tr( _h_ 1) _·_ Lift( _s_ )) 35: **for** _i_ = 0 _,_ 1 **do** 36: **for** _j_ = 0 _, . . . , r −_ 1 **do** 37: **if** _cij ≥ T_ **then** 38: _eij ← eij_ + _mij_ 39: **end if** 40: **end for** 41: **end for** 42: **return** _e_ 0 _, e_ 1 43: **end procedure** 

## **3.2 Avoiding the Barrel Shifter with Matrix Transposition** 

We do better than the `avx` implementation by making use of a simple observation. In short, we observed that shifting _f[′]_ by _s_[(1)] positions can be carried out by shifting a set of 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

104 

1 `_INLINE_ void` 2 `rotate256_big(OUT syndrome_t *out, IN __m256i *in, IN size_t ymm_num)` 3 `{` 4 `int i;` 5 6 `for (i = 0; i < 64; i++)` 7 `STORE(&out->qw[4*i], SRLI_I64(in[i], ymm_num) |` 8 `SLLI_I64(in[i+64], 64-ymm_num));` 9 10 `transpose_64x256_sp_asm(out->qw);` 11 `}` 

**Figure 2:** The source code for computing _M_[(1)] from _N_[(0)] for `bikel1` . 

_b_ vectors by _s_[(1)] _/b_ positions, if _f[′]_ is represented in a different format. The observation is explained via the following example. 

Let _r_ = _b_[2] _/_ 2. For a concrete number, one can imagine that _b_ = 64. We choose _f[′]_ to have a length of 2 _r_ = _b_[2] instead of 2 _r −_ 1. Consider _f[′]_ as a _b × b_ matrix _M_[(0)] , where the entry at row _i_ and column _j_ contains the bit _fb[′] ·i_ + _j_[.][The][matrix][is][illustrated][below.] 

**==> picture [151 x 43] intentionally omitted <==**

Our main observation is that shifting _f[′]_ by _s_[(1)] positions, in the matrix view, simply means updating row _i_ by row _i_ + _s_[(1)] _/b_ (and if row _i_ + _s_[(1)] _/b_ is undefined, row _i_ is set to 0). If we can somehow make each column of _M_[(0)] lie in one _b_ -bit word, this can be carried out easily via _b_ shift operations by _s_[(1)] _/b_ positions on the columns. 

In order to make use of this observation, given _f_ and _s_ , we perform the following steps to compute _y[−][s] f_ . 

1. Compute _f[′]_ , which can be viewed as the matrix _M_[(0)] , from _f_ . 

2. Compute _N_[(0)] = ( _M_[(0)] ) _[T]_ . How to perform such a matrix transposition efficiently given _b_ = 64 has been explained in, say, [Cho17]. 

3. Perform a shift of _s_[(1)] _/b_ positions on each row of _N_[(0)] to obtain _N_[(1)] . 

4. Compute _M_[(1)] = ( _N_[(1)] ) _[T]_ . Note that we only need _⌈_ ( _r_ + _b −_ 1) _/b⌉_ rows of _M_[(1)] for the next step. 

5. Shift the vector of length _r_ + _b −_ 1 represented by the first _⌈_ ( _r_ + _b −_ 1) _/b⌉_ rows of _M_[(1)] , by _s_[(0)] positions. Then, the first _r_ entries will be _y[−][s] f_ . 

Recall that what we actually want to compute is[�] _s[y][−][s][f]_[.][In fact, the first two steps above] do not depend on _s_ , so _N_[(0)] is the same for any _s_ . Therefore, one can save operations by computing _N_[(0)] with the first two steps, and then for each _s_ perform the last three steps. 

## **3.3 The Haswell Implementation for** **`bikel1`** 

For ease of discussion, we define the following operators that can be applied to any matrix. 

- _⇐j_ ( _·_ ), meaning replacing column _i_ by column _i_ + _j_ for all _i_ . 

- _⇒j_ ( _·_ ), meaning replacing column _i_ by column _i − j_ for all _i_ . 

Ming-Shing Chen 

, Tung Chou 

and Markus Krausz 

105 

- _⇑j_ ( _·_ ), meaning replacing row _i_ by row _i_ + _j_ for all _i_ . 

- _⇓j_ ( _·_ ), meaning replacing row _i_ by row _i − j_ for all _i_ . 

For each operator, the destination row or column is set to 0 if the source is not well-defined. The parentheses will be omitted whenever it is convenient. 

Our Haswell implementation for `bikel1` uses _b_ = 256 because it mainly works on YMM registers. `bikel1` has _r_ = 12323, so _f[′]_ consists of at least _⌈_ (2 _r −_ 1) _/_ 256 _⌉_ = 97 words and _s_[(1)] _/b ≤_ 48. For ease of implementation, we let _f[′]_ be of length 32768, so _M_[(0)] is a matrix with 128 rows: 

**==> picture [205 x 25] intentionally omitted <==**

where each _Mij_ is a 64 _×_ 64 matrix. Following the discussion in Section 3.2, we only need the first _⌈_ (12323 + 255) _/_ 256 _⌉_ = 50 rows of _⇑s_ (1) _/b_ ( _M_[(0)] ) to perform the final shift of _s_[(0)] positions. Let _s[′]_ = _s_[(1)] _/b_ , for ease of implementation, we compute the first 64 rows of _⇑s′_ ( _M_[(0)] ), which is simply 

**==> picture [323 x 37] intentionally omitted <==**

Let _Nij_ = _Mij[T]_[.][Our][implementation][stores] _[f][ ′]_[in][a][way][that][the][corresponding][matrix][is] 

**==> picture [193 x 25] intentionally omitted <==**

instead of _M_[(0)] . And then for each _s_ , we compute 

**==> picture [327 x 37] intentionally omitted <==**

and transpose each of the 4 64 _×_ 64 submatrices in _N_[(1)] to obtain _M_[(1)] . 

We chose the implementation strategy above, because it can be implemented easily using AVX2 intrinsics/instructions. Our source code for computing _M_[(1)] from _N_[(0)] is given in Figure 2. The variable `in` is a pointer to _N_[(0)] . The variable `ymm_num` is set to _s[′]_ . `SRLI_I64` is defined (by the BIKE team) as `_mm256_srli_epi64` , and we use it to perform _⇐s′_ . `SLLI_I64` is defined (by the BIKE team) as `_mm256_slli_epi64` , and we use it to perform _⇒_ 64 _−s′_ . The discussion above suggests that we need to compute XOR of the results of `SRLI_I64` and `SLLI_I64` , but the source code uses OR because it has the same effect. The function `transpose_64x256_sp_asm` is an assembly function that computes the “64 _×_ 64-block-wise” matrix transposition for obtaining _M_[(1)] from _N_[(1)] . The assembly function performs a vectorized version of the 64 _×_ 64 matrix transposition mentioned in Section 3.2. We note that the assembly function is included in the source code of Classic McEliece. The source code of Classic McEliece, including the function, is in the public domain. In fact, we also compute _N_[(0)] from _M_[(0)] by calling the assembly function twice. 

## **3.4 The Haswell Implementation for** **`bikel3`** 

`bikel3` has _r_ = 24659, so _f[′]_ consists of at least _⌈_ (2 _r −_ 1) _/_ 256 _⌉_ = 193 words and _s[′]_ = _s_[(1)] _/b ≤_ 96. For ease of implementation, we let _f[′]_ be of lenght 65536, which means _M_[(0)] is a matrix with 256 rows: 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

106 

**==> picture [207 x 49] intentionally omitted <==**

where each _Mij_ is a 64 _×_ 64 matrix. Following the dicussion in Section 3.2, we only need the first _⌈_ (24659 + 255) _/_ 256 _⌉_ = 98 rows of _⇑s′_ ( _M_[(0)] ) to perform the final shift of _s_[(0)] positions. For ease of implementation, we instead compute 128 rows of _⇑s′_ ( _M_[(0)] ). Let _M_[(0] _[k]_[)] _∈_ F[128] 2 _[×]_[256] be the first 128 rows of _⇑_ 64 _k M_[(0)] . We observed that there are two cases for the first 128 rows of _⇑s′_ ( _M_[(0)] ), which we denote as _M_[(1)] : 

**==> picture [266 x 31] intentionally omitted <==**

Let _Nij_ = _Mij[T]_[.][Our][implementation][stores] _[f][ ′]_[in][a][way][that][the][corresponding][matrix][is] 

**==> picture [195 x 49] intentionally omitted <==**

If 0 _≤ s[′] <_ 64, we compute 

**==> picture [389 x 61] intentionally omitted <==**

Otherwise, we compute 

**==> picture [385 x 57] intentionally omitted <==**

In either case, each of the 8 64 _×_ 64 submatrices in _N_[(1)] is transposed to obtain _M_[(1)] . 

It might seem that the implementation strategy above will result in branching on _s[′]_ , and branching on _s[′]_ is not allowed for constant-time implementations. However, this can be avoided with the ability of AVX intrinsics. Our source code for computing _M_[(1)] from _N_[(0)] is given in Figure 3. The variable `in` , again, is a pointer for _N_[(0)] . The variable `ymm_num` , again, is set to _s[′]_ . When 0 _≤ s[′] <_ 64, the `SRLI_I64` and `SLLI_I64` in line 12 and 13 will give all-zero results because their shift amounts are out-of-range. Similarly, when 64 _≤ s[′] <_ 128, the `SRLI_I64` and `SLLI_I64` in line 10 and 11 will give all-zero results because their shift amounts are out-of-range. In this way, we are able to avoid branching on _s[′]_ . Finally, we compute _M_[(1)] from _N_[(1)] . by calling the assembly function `transpose_64x256_sp_asm` twice. We also compute _N_[(0)] from _M_[(0)] by calling the assembly function four times. 

## **4 Circular Shifts with Conditional Moves** 

Following the discussion in Section 3.1, our M4 implementation uses a Barrel shifter to shift the duplicated form of _f_ by _s_ bits. In the setting of M4, we have _s_ = _s_[(1)] + _s_[(0)] where _s_[(0)] = _s_ mod 32, and the duplicated form of _f_ is stored as an array of 32-bit words. Our M4 implementation first performs the shift by _s_[(1)] bits and then the shift by _s_[(0)] bits. 

Ming-Shing Chen , Tung Chou and Markus Krausz 

107 

1 `_INLINE_ void` 2 `rotate256_big(OUT syndrome_t *out, IN __m256i *in, IN size_t ymm_num)` 3 `{` 4 `int j;` 5 6 `__m256i tmp;` 7 8 `for (j = 0; j < 128; j++)` 9 `{` 10 `tmp = SRLI_I64(in[j], ymm_num)` 11 `| SLLI_I64(in[j+64], 64 - ymm_num)` 12 `| SRLI_I64(in[j+64], ymm_num - 64)` 13 `| SLLI_I64(in[j+128], 128 - ymm_num);` 14 15 `STORE(&out->qw[4*j], tmp);` 16 `}` 17 18 `transpose_64x256_sp_asm(&out->qw[0]);` 19 `transpose_64x256_sp_asm(&out->qw[64*4]);` 20 `}` 

**Figure 3:** The function for computing _M_[(1)] from _N_[(0)] for `bikel3` . 

## **4.1 The Shift by** _**s**_ **[(1)] Bits** 

In the first phase of the Barrel shifter, each word _i_ is conditionally replaced by word _i_ +2 _[j] /_ 32 for several _j_ ’s with _j ≥_ 5 to carry out the shift by _s_[(1)] bits. Note that _j ∈{_ 13 _,_ 12 _, . . . ,_ 5 _}_ for `bikel1` and _j ∈{_ 14 _,_ 13 _, . . . ,_ 5 _}_ for `bikel3` . To complete the computation for each _j_ , we can first create a 32-bit `mask` which is set to `0xFFFFFFFF` if the shift of 2 _[j] /_ 32 words needs to be carried out or `0x0` otherwise. Then, for `i` = 0 _,_ 1 _,_ 2 _, . . ._ , the `portable` implementation does 

## `w[i] = (w[i] & ~mask) | (w[i+idx] & mask)` _,_ 

where `idx` holds the value of 2 _[j] /_ 32. This is essentially the code of the `portable` implementation, except that it actually works on 64-bit words. 

In our implementation, for each _k_ in the first phase, the words are partitioned into 2 _[j] /_ 32 sets: each word _i_ with _k_ = _i_ mod 2 _[j] /_ 32 is in the _k_ th set. For each set, we use two general-purpose registers `Rx` and `Ry` , where `Rx` is initialized with word _k_ . Then, we set _i_ to _k_ and perform the following loop. 

1. Load word _i_ + 2 _[j] /_ 32 to `Ry` . 

2. Conditionally move `Ry` to `Rx` . 

3. Store `Rx` to word _i_ . 

4. If _i <_ min( _⌈_ ( _r_ + 2 _[j] −_ 1) _/_ 32 _⌉_ and _i_ + 2 _[j] /_ 32 _< ⌈_ (2 _r −_ 1) _/_ 32 _⌉_ , increase _i_ by 2 _[j] /_ 32. Otherwise, break the loop. 

5. Load word _i_ + 2 _[j] /_ 32 to `Rx` . 

6. Conditionally move `Rx` to `Ry` . 

7. Store `Ry` to word _i_ . 

8. If _i <_ min( _⌈_ ( _r_ + 2 _[j] −_ 1) _/_ 32 _⌉_ and _i_ + 2 _[j] /_ 32 _< ⌈_ (2 _r −_ 1) _/_ 32 _⌉_ , increase _i_ by 2 _[j] /_ 32 and go back to Step 1. Otherwise, break the loop. 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

108 

In Step 4 and 8, we check if _i <_ min( _⌈_ ( _r_ + 2 _[j] −_ 1) _/_ 32 _⌉_ because we only need 

**==> picture [162 x 31] intentionally omitted <==**

words for the remaining conditional shifts of 2 _[j][−]_[1] _,_ 2 _[j][−]_[2] _, . . . ,_ 32 _, s_[(0)] bits. We check if _i_ +2 _[j] /_ 32 _< ⌈_ (2 _r−_ 1) _/_ 32 _⌉_ because there are only _⌈_ (2 _r−_ 1) _/_ 32 _⌉_ words. In our implementation, the if statements are simplified to “If _i < i_ max, _. . ._ ”, where _i_ max is a precomputed value that depends on _k_ and _j_ . 

To carry out the conditional moves, our M4 implementation uses the instruction `SEL` . As suggested by the name, `SEL` can move one of its two source registers into its destination register. Which source register is chosen is determined by the “GE” flags[2] . We note that the `SEL` instruction always takes 1 cycle. 

In order to reduce the average cost of each conditional move, our implementation actually processes _n_ = min(2 _[j] /_ 32 _,_ 4) words in one iteration of the loop: we first load _n_ words to `Ry1` , _. . ._ , `Ryn` , use the `SEL` instruction _n_ times to conditionally move `Ry1` , _. . ._ , `Ryn` to the corresponding `Rx1` , _. . ._ , `Rxn` , store `Ry1` , _. . ._ , `Ryn` to the memory of _n_ words. We also partially unroll the loop so that Step 4 is omitted. A piece of code for a loop of _j_ = 12 is given in Appendix A. 

## **4.2 The Shift by** _**s**_ **[(0)] Bits** 

In the second phase, the Barret shifter performs the shift of _f_ by _s_[(0)] _<_ 32 bits. Suppose _f_ is stored as an array of 32-bits words `w[n]` . In the `portable` implementation of BIKE team, the shift is carried out by doing 

**==> picture [210 x 9] intentionally omitted <==**

for _i_ = 1 _,_ 2 _, . . . ,_ and so on. This approach takes 2 logic shits and 1 logic `OR` operations for each 32-bits word. We note that `portable` actually works on 64-bit words, but the idea is the same. In fact, we can also deal with the 32-bit words in the reversed order: 

**==> picture [137 x 80] intentionally omitted <==**

Note that the logical OR can be replaced by an addition. Now consider the following C function. 

**==> picture [169 x 69] intentionally omitted <==**

The shift by _s_[(0)] bits can then be carried out by doing simply 

> 2Actually the selection is done on a byte per byte basis. For example, with the right values in the GE flags, one can write the lower 8 bits of the first source register to the corresponding bits of the destination register, and write the upper 24 bits of the second source register to corresponding bits of the destination register. 

Ming-Shing Chen , Tung Chou and Markus Krausz 

109 

**==> picture [137 x 32] intentionally omitted <==**

The interesting thing is that `F` can be replaced by a single instruction `UMLAL` . The instruction operates as 

## `UMLAL Rdlo, Rdhi, Rm, Rn` 

where `Rdlo` and `Rdhi` are the 2 destination registers and `Rm` and `Rn` are the 2 source registers. The instruction multiplies `Rm` and `Rn` and adds the 64-bit result into the 64-bit integer represented by `Rdhi` (the top 32 bits) and `Rdlo` (the bottom 32 bits). To carry out `F(w[i], &v, s0)` with the `UMLAL` , the 4 registers `Rdlo` , `Rdhi` , `Rm` , and `Rn` are set to `w[i]` , `v` , `(1 « s0)-1` , and `w[i]` respectively. Note that we set `Rdlo` to `w[i]` and `Rm` to `(1 « (32-s0))-1` instead of setting `Rdlo` to 0 and `Rm` to `1 « (32-s0)` to avoid the overflow of `Rm` when _s_[(0)] = 0. In this way, we are able to replace the 2 logical shifts and 1 logical OR with only 1 `UMAAL` . 

A previous version of our M4 implementation actually used `IT` blocks instead of `SEL` to carry out conditional moves and use the same way as the `portable` implementation to perform the shift by _s_[(0)] bits. The ideas of using `SEL` and replacing shift instructions by multiplication instructions was suggested by an anonymous reviewer of this paper. In the current version of our M4 implementation, which uses the ideas, one circular shift is about 5% faster than in the previous version. 

## **5 Hamming Weight Computation with Full Adders** 

The implementations of the BIKE team follows [Cho16] to compute the sum[�] _s_[(] _[y][−][s][f]_[)][in] a bitsliced fashion to obtain _gf_ . As the result, a sequence of bitwise logical operations are performed to obtain the sum. Let _n_ be the cardinality for the set of _s_ , and let _b_ 1 be the constant term of the first _y[−][s] f_ , _b_ 2 be the constant term of the second _y[−][s] f_ , and so on. It is easy to see that the problem of computing[�] _s_[(] _[y][−][s][f]_[)][boils][down][to][computing][the] Hamming weight of ( _b_ 1 _, b_ 2 _, . . . , bn_ ) _∈{_ 0 _,_ 1 _}[n]_ using a sequence of gates. This sections shows how previous implementations and our implementation compute the Hamming weight. 

## **5.1 Simple Algorithms for Computing the Hamming Weight** 

The `avx2` implementation of BIKE, following [Cho16], first prepares a counter of _⌊_ log2 _n⌋_ +1 zero bits. The counter is used to store the Hamming weight. Then, for each _i ∈{_ 1 _, . . . , n}_ , _bi_ is added to the counter. For each addition, if _n_ is a power of 2, each of the least significant _⌊_ log2 _n⌋_ bits can be updated using one half adder, and the most significant bit can be set to the carry-out bit of the last half adder. If _n_ is not a power of 2, each of the least significant _⌊_ log2 _n⌋_ bits can be updated using one half adder, and the most significant bit can be updated using 1 `XOR` . Let _T_ ( _n_ ) be the number of bit operations it takes to compute the Hamming weight of _n_ bits. We have 

**==> picture [228 x 31] intentionally omitted <==**

In [GAB19], the authors suggested a simple way to improve the approach above. The idea is that, since adding _bi_ only affects the first _⌊_ log2 _i⌋_ + 1 bits of the counter, there is no need to update the remaining bits. In fact, adding _bi_ takes 2 _⌊_ log2 _i⌋_ + 1 bit operations if _i_ is not a power of 2, and adding _bi_ takes 2 _⌊_ log2 _i⌋_ bit operations if _i_ is a power of 2. Therefore, we have 

**==> picture [296 x 31] intentionally omitted <==**

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

110 

## **5.2 The Boyar–Peralta Algorithm** 

Our implementation uses a much faster algorithm which makes use of full adders. The algorithm was explained by Boyar and Peralta in [BP05]. We note that the technique is probably much older: [FS71] presents an algorithm that seems equivalent. However, as we are not able to tell who was the first to propose the algorithm, we simply call the algorithm the Boyar–Peralta Algorithm. Boyar and Peralta focused on proving that the algorithm gives the minimal number of `AND` s required to compute the Hamming weight. In the following discussion, we consider the number of `XOR` s as well as the space requirement of the algorithm. 

To explain the idea, consider the case when _n_ = 2 _[k] −_ 1. Boyar and Peralta described the following recursive algorithm: apply the algorithm recursively to compute the Hamming weight _x_ 1 of the first 2 _[k][−]_[1] _−_ 1 bits, apply the algorithm recursively to compute the Hamming weight _x_ 2 of the next 2 _[k][−]_[1] _−_ 1 bits, and use a standard adder to compute the sum _x_ 1 + _x_ 2 + _bn_ , where _bn_ serves as the carry-in bit. Then the sum _x_ 1 + _x_ 2 + _bn−_ 1 can be computed using _k −_ 1 full adders, resulting in 5( _k −_ 1) bit operations. Therefore, we have 

**==> picture [161 x 12] intentionally omitted <==**

for _k >_ 1, and obviously _T_ (0) = _T_ (1) = 0. 

In order to handle general _n_ , the Boyar–Peralta algorithm computes _k, n_ 1 _, n_ 2 such that _n_ = 2 _[k][−]_[1] + _n_ 2 = _n_ 1 + _n_ 2 + 1, where 0 _≤ n_ 2 _<_ 2 _[k][−]_[1] . Then, the algorithm is applied recursively to compute the Hamming weight _x_ 1 of the first _n_ 1 bits, and the Hamming weight _x_ 2 of the next _n_ 2 bits, and finally a standard adder is used to compute the sum _x_ 1 + _x_ 2 + _bn−_ 1. Let _k[′]_ = _⌊_ log2 _n_ 2 _⌋_ + 1 if _n_ 2 _>_ 0, i.e., _k[′]_ is the number of bits required to represent _n_ 2. _k[′]_ is set to 0 if _n_ 2 = 0. Then, the sum _x_ 1 + _x_ 2 + _bn−_ 1 can be computed using _k[′]_ full adders and _k −_ 1 _− k[′]_ half adders, resulting in 5 _k[′]_ + 2( _k −_ 1 _− k[′]_ ) bit operations. Therefore, we have 

**==> picture [219 x 13] intentionally omitted <==**

for _n ≥_ 2, and _T_ (0) = _T_ (1) = 0. 

The reason why we need to perform multiplications of the form _gf_ =[�] _s_[(] _[y][−][s][f]_[)][in] the first place is because there are multiplications between Tr( _hi_ ) and Lift( _s_ ) in the decoder (see Section 2.4). As each Tr( _hi_ ) is always of weight _w/_ 2, our goal is actually to compute the Hamming weight of _w/_ 2 bits. Now we can easily compute _T_ ( _w/_ 2) for the Boyar–Peralta algorithm and the simple algorithms in the previous subsection. The numbers are summarized in Table 2. 

## **5.3 Code Generation for the Boyar–Peralta Algorithm** 

To implement the Boyar–Peralta algorithm, we wrote a code generator to generate the sequence of additions in the Boyar–Peralta algorithm. The code generator is included in Appendix B. It assumes that there is a buffer consisting of infinitely many bits that can be used for storing the results of the additions and the Hamming weight. 

Our code generator is written as a Python function named `bp` . One can simply call `bp(n, 0)` to to generate operations for _n_ input bits. Its the second argument, the variable `off` in its signature, indicates the index of the first bit in the buffer of the computation. The function, on input _n >_ 1, computes _k, n_ 1 _, n_ 2 such that _n_ = 2 _[k]_ + _n_ 2 = _n_ 1 + _n_ 2 + 1. Then, the function first recursively calls 

```
bp(n1,off);
bp(n2,off+nbits(n1));
```

to generate operations for computing _x_ 1 and _x_ 2, where `nbits(n1)` means the number of bits required to represent _n_ 1. Note _x_ 1 will be stored in the first `nbits(n1)` bits starting 

Ming-Shing Chen , Tung Chou 

and Markus Krausz 

111 

**Table 2:** The numbers of gates required to compute the Hamming weight for the three methods. 

||_n_=_w/_2|[Cho16]|[GAB19]|[BP05]|
|---|---|---|---|---|
|`bikel1`<br>`bikel3`<br>`bikel5`|71<br>103<br>137|923<br>1339<br>2055|676<br>1092<br>1553|326<br>484<br>655|



from the buffer bit of index `off` after the operations generated by the first recursive call are carried out, and _x_ 2 will be stored in the next `nbits(n2)` bits after the operations generated by the second recursive call are arried out. 

After the recursive calls, the function first outputs 

```
"rotate_right(bn,f,s[{0}]);".format(count)
```

which means a new _s_ is used to compute _y[−][s] f_ , so that the bit `bn` is generated. Here `count` is a global variable which is always increased by 1 after printing the line of `rotate_right` . Then, the function outputs 

- `"adder_size_eq(buf, bn, {0}, {1});".format(off, nbits(n1))` 

if `nbits(n1)` is equal to `nbits(n2)` or 

- `"adder_size_neq(buf, bn, {0}, {1}, {2});".format(off, nbits(n1), nbits(n2))` 

if they are different. In either case, this means that a standard adder is used to compute _x_ 1 + _x_ 2 + _bn_ . The variable `buf` is a pointer to the buffer, and the offset of _x_ 1 is indicated by `off` . The difference between the two cases is that `adder_size_eq` only requires one argument to indicate the bit length of _x_ 1 or _x_ 2, while `adder_size_neq` requires two arguments. If _n_ = 1, the function outputs the line of `rotate_right` , increases `count` by 1, and outputs 

- `"adder_size_eq(buf, bn, {0}, 0);".format(off)` 

where the last argument 0 indicates that _bn_ is simply copied into the buffer bit of index `off` . If _n_ = 0, the function returns immediately. The only remaining task is to implement the C functions `adder_size_eq` and `adder_size_neq` . 

By analysing the output of the function, we found that a buffer of 16, 17, and 22 bits are required for _n_ = 71, _n_ = 103, and _n_ = 137. Note that the simple algorithms requires a buffer of only 7, 7, and 8 bits respectively. In other words, using the Boyar– Peralta algorithm to compute the sum[�] _s_[(] _[y][−][s][f]_[)][in][a][bitsliced][fashion][takes][at][least] _⌈_ 16 _·_ 12323 _/_ 8 _⌉_ = 24646, _⌈_ 17 _·_ 24659 _/_ 8 _⌉_ = 52401, and _⌈_ 22 _·_ 40973 _/_ 8 _⌉_ = 112676 bytes for `bikel1` , `bikel3` , and `bikel5` , respectively. 

## **6 Multiplications in** F **2[** _**x**_ **] with Bernstein’s 5-way Recursive Algorithm** 

The implementations of the BIKE team use Karatsuba for multiplying polynomials in F2[ _x_ ]: given two polynomials _F_ = _F_ 0 + _F_ 1 _x[n]_ and _G_ = _G_ 0 + _G_ 1 _x[n]_ where _F_ 0 _, F_ 1 _, G_ 0 _, G_ 1 are of degree smaller than _n_ , the algorithm computes _FG_ as 

**==> picture [265 x 12] intentionally omitted <==**

This means that Karatsuba is a 3-way recursive algorithm: it reduces the multiplication into 3 smaller ones, where the smaller multiplications can be handled recursively. The complexity of Karatsuba is _O_ ( _n_[log][2][ 3] ). 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

112 

Recall that `bikel1` has _r_ = 12323 and `bikel3` has _r_ = 24659. The BIKE team always picks _n_ to be the smallest possible power of 2, which means at the top level of recursion, we have _n_ = 8192 for `bikel1` and _n_ = 16384 for `bikel3` . They then apply Karatsuba recursively. At the bottom level of recursion, the `avx2` implementation uses `pclmulqdq` , and the `portable` implementation uses a non-constant-time function to handle multiplications of polynomials of degree smaller than 64. 

As _r_ seems to be large enough to make use of algorithms with lower complexities, our Haswell implementation uses a 5-way recursive algorithm by Bernstein. 

## **6.1 Bernstein’s 5-way Recursive Algorithm** 

In [Ber09a], Bernstein proposed a 5-way recursive algorithm for multiplying two polynomials in F2[ _x_ ] with five multiplications. The complexity of Bernstein’s algorithm is _O_ ( _n_[log][3][ 5] ). Given two polynomials _F_ 0 + _F_ 1 _z_ + _F_ 2 _z_[2] and _G_ 0 + _G_ 1 _z_ + _G_ 2 _z_[2] in F2[ _x_ ], where _Fi_ ’s and _Gi_ ’s are polynomials of degree smaller than _n_ and _z_ = _x[n]_ . The algorithm reduces the multiplication into five polynomial multiplications of polynomials of length about _n_ : 

**==> picture [69 x 11] intentionally omitted <==**

_H_ (1) = ( _F_ 0 + _F_ 1 + _F_ 2) _·_ ( _G_ 0 + _G_ 1 + _G_ 2) _,_ 

**==> picture [212 x 12] intentionally omitted <==**

**==> picture [340 x 28] intentionally omitted <==**

Bernstein showed that _H_ = _F · G_ can be constructed by the following formula 

**==> picture [323 x 23] intentionally omitted <==**

where 

**==> picture [324 x 11] intentionally omitted <==**

## **6.2 Implementing Bernstein’s algorithm** 

Our Haswell implementation uses Bernstein’s algorithm at the top level of the recursion and Karatsuba for other levels. At the top level, we pick _n_ = 4096 for `bikel1` and _n_ = 8192 for `bikel3` . Note that 12323 _−_ 4096 _·_ 3 = 35 and 24659 _−_ 8192 _·_ 3 = 83. These “leftover bits” are handle separately, and the costs of handling them is very small. In order to make the operands of the 5 multiplications fit into _n_ = 4096 or _n_ = 8192 bits, we also handle the top 2 bits of _F_ 2 and _G_ 2 and the top bit of _F_ 1 and _G_ 1 separately, together with the “leftover bits”. At the bottom level of recursion, we also use `pclmulqdq` to handle multiplications for polynomials of degree smaller than 64. 

Let _h_ ( _x_ ) =[�] _[ℓ] i_ =0 _[−]_[1] _[h][i][x][i]_[=][(] _[U]_[+] _[ V]_[+] _[ H]_[(] _[∞]_[)(] _[x]_[4][ +] _[ x]_[)).][While][most][of][the][operations][in] Bernstein’s algorithm are either multiplications or additions, there is one division between _h_ ( _x_ ) and ( _x_[2] + _x_ ) in Eq. 1. We carry out the division by computing 

**==> picture [209 x 13] intentionally omitted <==**

Note that instead of computing the coefficients sequentially, the computation can be easily parallelized: let _h[′]_ be ( _h −_ ( _h_ mod _x_[2] )) _/x_[2] , we update _h[′]_ to _h[′]_ + ( _h[′] −_ ( _h[′]_ mod _x_ )) _/x_ , update _h[′]_ to _h[′]_ + ( _h[′] −_ ( _h[′]_ mod _x_[2] )) _/x_[2] , update _h[′]_ to _h[′]_ + ( _h[′] −_ ( _h[′]_ mod _x_[4] )) _/x_[4] , and so on. This results in a much faster implementation for the division. 

Ming-Shing Chen 

, Tung Chou 

and Markus Krausz 

113 

## **7 Polynomial Multiplications in** F **2[** _**x**_ **] with Frobenius Additive FFTs** 

This section presents how we carry out the polynomial multiplications on the Cortex-M4. Section 7.1 reviews how the Gao-Mateer additive FFT works. Section 7.2 reviews how to perform multiplications in F2[ _x_ ] with the additive FFT in [LCK[+] 18, CCK[+] ]. Section 7.3 shows how we implement the algorithm for the Cortex-M4. 

## **7.1 The Gao–Mateer Additive FFT** 

Below we introduce how the Gao–Mateer additive FFT [GM10], which we denote as AFFT, can be used for polynomials over F2 _m_ , where _m_ is a power of 2. 

**Cantor Basis** An F2-linear basis _{v_ 0 _, v_ 1 _, . . . , vm−_ 1 _}_ of F2 _m_ , where _m_ is a power of 2, is called a Cantor basis [Can89] if _v_ 0 = 1 and _vi−_ 1 = _vi_[2][+] _[ v][i]_[for][all] _[i][>]_[0.][We][define] _Wℓ ⊆_ F2 _[m]_ as the span of _{v_ 0 _, . . . , vℓ−_ 1 _}_ for any 1 _≤ ℓ ≤ m_ and _W_ 0 as _{_ 0 _}_ . When _ℓ_ is a power of 2, _Wℓ_ is the subfield of size 2 _[ℓ]_ . In [Can89], Cantor defined a series of polynomials that are closely related to _vi_ ’s and _Wℓ_ ’s: 

**==> picture [235 x 12] intentionally omitted <==**

In fact, each _si_ satisfies the following properties. 

- _si_ ( _x_ ) is linear in the sense that _si_ ( _α_ + _β_ ) = _si_ ( _α_ ) + _si_ ( _β_ ). 

- _si_ ( _vk_ + _i_ ) = _vk_ for all _i ≥_ 0. 

**Divide and Conquer** Given _f_ ( _x_ ) _∈_ F2 _[m]_ [ _x_ ] of degree smaller than _n_ , where _n_ = 2 _[ℓ]_ , _v ∈_ F2 _m_ , and _ℓ ≤ m_ , the AFFT computes _S_ = _{f_ ( _α_ ) _| α ∈ v_ + _Wℓ}_ . When _ℓ_ = 0, the algorithm simply returns _f_ ( _x_ ) itself. When _ℓ>_ 0, the algorithm first writes _f_ ( _x_ ) as 

**==> picture [123 x 13] intentionally omitted <==**

This is called “radix conversion” in [BC14]: the radix is changed from _x_ to _s_ 1( _x_ ) = _x_[2] + _x_ . Note that the computation _f_[(0)] and _f_[(1)] from _f_ requires only field additions, which are much cheaper than field multiplications, and each _f_[(] _[i]_[)] is of degree smaller than 2 _[ℓ][−]_[1] . If we have _S_[(0)] = _{f_[(0)] ( _s_ 1( _α_ )) _| α ∈ v_ + _Wℓ}_ and _S_[(1)] = _{f_[(1)] ( _s_ 1( _α_ )) _| α ∈ v_ + _Wℓ}_ , then every _f_ ( _α_ ) can be computed as _f_ ( _α_ ) = _f_[(0)] ( _α_ ) + _αf_[(1)] ( _α_ ). 

Observe that _s_ 1( _v_ + _Wℓ_ ) = _s_ 1( _v_ ) + _Wℓ−_ 1, which is of size 2 _[ℓ][−]_[1] . Gao and Mateer make use of this observation to compute _S_[(0)] and _S_[(1)] by recursively evaluating _f_[(0)] and _f_[(1)] at all elements of _s_ 1( _v_ ) + _Wℓ−_ 1. In addition, as 

**==> picture [287 x 11] intentionally omitted <==**

Gao and Mateer suggest to compute _S_ by computing 

**==> picture [291 x 13] intentionally omitted <==**

for all _β ∈ v_ + span _{vℓ −_ 1 _, . . . , v_ 1 _}_ . Computation of _f_ ( _β_ ) and _f_ ( _β_ + 1) is depicted by the following figure. 

**==> picture [235 x 12] intentionally omitted <==**

**==> picture [243 x 25] intentionally omitted <==**

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

114 

**==> picture [332 x 106] intentionally omitted <==**

**----- Start of picture text -----**<br>
+ + +<br>+ + +<br>+ + +<br>+ + +<br>+ + +<br>+ + +<br>+ + +<br>+ + +<br>**----- End of picture text -----**<br>


**Figure 4:** The three stages of butterflies in a size-8 AFFT. Each arrow going upwards is associated with a constant which is not shown, so it actually means “adding the product of the source and the constant to the destination” instead of “adding the source to the destination”. 

This is one “butterfly” in an AFFT. 

To have a clearer picture regarding the pattern of computation in an AFFT, one can “unroll” the recursion. In this way, it can be seen that an AFFT always consists of two phases. The first phase consists of a bunch of field additions from radix conversions in all levels of recursion. The second phase consists of several stages of butterflies, where the last stage consists of the butterflies in level 0 (i.e., the top level) of the recursion, the second last stage consists of the butterflies in level 1 of the recursion, and so on. Figure 4 shows the three stages in the second phase of a size-8 ( _n_ = 8) AFFT. 

## **7.2 Multiplication in** F **2[** _**x**_ **] with FAFFT** 

The AFFT allows us to perform multiplications in F2[ _x_ ]: given polynomials _f, g ∈_ F2[ _x_ ] such that _fg_ is of degree smaller than _n_ = 2 _[ℓ]_ , we can lift _f_ and _g_ to F2 _[m]_ [ _x_ ] such that _m_ is a power of 2 and _ℓ ≤ m_ , perform an AFFT for each of _f_ and _g_ to evaluate them at _Wℓ_ , perform the pointwise multiplication, and perform the inverse AFFT to obtain _fg_ . Such an AFFT-based polynomial multiplication always works, but one can reduce the cost of the AFFT by carefully choosing the evaluation points for _f_ and _g_ . 

**Reducing the Number of Evaluation Points** In [LCK[+] 18], Li et al. suggested to pick the set of evaluation points to be 

**==> picture [81 x 12] intentionally omitted <==**

with 

**==> picture [298 x 19] intentionally omitted <==**

In this way, the function that maps _f_ to _f_ (Σ) will be invertible, which means we can use the AFFT and the inverse AFFT to carry out multiplications in F2[ _x_ ]. As explained by Li et al., it is the property that Σ can reach _n_ elements in F2 _m_ via the Frobenius map which guarantees that the function is invertible. This is why Li et al. call such an AFFT a Frobenius AFFT (FAFFT). With the FAFFT, the number of evaluation points is reduced by a factor of _m_ . 

**FAFFT by Truncating A Size-** _**n**_ **AFFT** Consider Σ[ˆ] = _Wℓ′_ +log2 _m_ + _vℓ′_ + _m/_ 2, such that Σ _⊂_ Σ[ˆ] and _|_ Σ[ˆ] _|_ = _n_ . The way Li et al. evaluate _f_ as Σ is to perform a size- _n_ AFFT to evaluate _f_ at Σ[ˆ] but skip all the redundant operations. In other words, the approach of Li et al. is to carry out a truncated AFFT. The truncated AFFT starts with a usual 

Ming-Shing Chen , Tung Chou 

and Markus Krausz 

115 

**Algorithm 2** FAFFT-based Polynomial Multiplication 

**Parameters** : _n_ : maximum length of output polynomial 

1: **procedure** FAFFT( _f_ ( _x_ ) _∈_ F2[ _x_ ] _<n,_ Σ) 2: ( _f_ 0 _, f_ 1 _, . . . , fn−_ 1) _∈_ F _[n]_ 2 _[←]_ `[RadixConversions]`[(] _[f]_[(] _[x]_[))] 3: ( _f_ 0 _[′][, . . . , f] n[ ′][′] −_ 1[)] _[ ∈]_[F] 2 _[n][m][′][←]_ `[Encode]`[((] _[f]_[0] _[, f]_[1] _[, . . . , f][n][−]_[1][)] _[,]_[ Σ)] 4: ( _f_[ˆ] 0 _, . . . , f_[ˆ] _n′−_ 1) _∈_ F _[n]_ 2 _[m][′][←]_ `[Butterflies]`[((] _[f]_ 0 _[ ′][, . . . , f] n[ ′][′] −_ 1[)] _[,]_[ Σ)] 5: **return** ( _f_[ˆ] 0 _, . . . , f_[ˆ] _n′−_ 1) 6: **end procedure** 7: **procedure** FAFFT _[−]_[1] (( _f_[ˆ] 0 _, . . . , f_[ˆ] _n′−_ 1) _∈_ F _[n]_ 2 _[m][′][,]_[ Σ)] 8: ( _f_ 0 _[′][, . . . , f] n[ ′][′] −_ 1[)] _[ ∈]_[F] 2 _[n][m][′][←]_ `[Butterflies]` _[−]_[1][(( ˆ] _[f]_[0] _[, . . . ,][f]_[ˆ] _[n][′][−]_[1][)] _[,]_[ Σ)] 9: ( _f_ 0 _, . . . , fn′−_ 1) _∈_ F _[n]_ 2 _[←]_ `[Encode]` _[−]_[1][((] _[f]_ 0 _[ ′][, f]_ 1 _[ ′][, . . . , f] n[ ′] −_ 1[)] _[,]_[ Σ)] 10: _f_ ( _x_ ) _∈_ F2[ _x_ ] _<n ←_ `RadixConversions` _[−]_[1] ( _f_ 0 _, f_ 1 _, . . . , fn−_ 1) 11: **return** _f_ ( _x_ ) 12: **end procedure** 13: **procedure** BitPolyMul( _a_ ( _x_ ) _∈_ F2[ _x_ ] _<[n]_ 2 _[, b]_[(] _[x]_[)] _[ ∈]_[F][2][[] _[x]_[]] _[<][n]_ 2[)] 14: (ˆ _a_ 0 _, . . . ,_ ˆ _an′−_ 1) _∈_ F _[n]_ 2 _[m][′][←]_ `[FAFFT]`[(] _[a]_[(] _[x]_[)] _[,]_[ Σ)] 15: ([ˆ] _b_ 0 _, . . . ,_[ˆ] _bn′−_ 1) _∈_ F _[n]_ 2 _[m][′][←]_ `[FAFFT]`[(] _[b]_[(] _[x]_[)] _[,]_[ Σ)] 16: (ˆ _c_ 0 _, . . . ,_ ˆ _cn′−_ 1) _∈_ F _[n]_ 2 _[m][′][←]_[(ˆ] _[a]_[0] _[·]_[ ˆ] _[b]_[0] _[, . . . ,]_[ ˆ] _[a][n][′][−]_[1] _[·]_[ ˆ] _[b][n][′][−]_[1][)] _▷_ pointwise multiplication 17: _c_ ( _x_ ) _∈_ F2[ _x_ ] _<n ←_ `FAFFT` _[−]_[1] ((ˆ _c_ 0 _, . . . ,_ ˆ _cn′−_ 1) _,_ Σ) 18: **return** _c_ ( _x_ ) 19: **end procedure** 

radix conversion phase for a size- _n_ AFFT. The second phase consists of the first log2 _m_ levels of butterflies in the truncated AFFT. This phase is called encoding, in which the operations is defined below. The third phase consists of the last _ℓ[′]_ stages of butterflies in the truncated AFFT. The last stage is identical to the butterfly phase in a usual size- _n[′]_ AFFT for Σ. 

As each of the three phase is invertible, one can carry out the inverse FAFFT by performing the inverses of the three phases in the reverse order. The FAFFT-based polynomial multiplication algorithm is shown in Algorithm 2. 

**Encoding** Encoding performs the first log2 _m_ levels of butterflies in the truncated AFFT. With respect to Σ[ˆ] , it is an invertible linear map which maps radix converted coefficients of _f_ ( _x_ ), e.g., ( _f_ 0 _, f_ 1 _, . . . , fn−_ 1) _∈_ F _[n]_ 2[to][(] _[f]_ 0 _[ ′][, . . . , f] n[ ′][′] −_ 1[)] _[ ∈]_[F] 2 _[n][m][′]_[where][the] _[f] i[ ′]_[is][defined][as] 

**==> picture [297 x 33] intentionally omitted <==**

where ( _j_ 0 _, j_ 1 _, . . . , j_ log2 _m−_ 1) _∈{_ 0 _,_ 1 _}_[log][2] _[ m]_ is the binary representation of the integer _j_ , i.e., _j_ =[�] _k[j][k][ ·]_[ 2] _[k]_[.] 

## **7.3 Implementing the FAFFT-based Polynomial Multiplication** 

Below we show how we implemented the FAFFT-based multiplication for the M4. 

**Parameter Selection** The following table shows our parameters for the algorithm 2. We pick the parameters to minimize _m_ satisfying Eq. (2). The field F232 is constructed as 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

116 

||_r_|_n_|_m_|_n′_|_ℓ′_|Σ|
|---|---|---|---|---|---|---|
|BIKE-1<br>BIKE-3|12323<br>24659|32768<br>65536|32<br>32|1024<br>2048|10<br>11|_v_26+_W_10<br>_v_27 +_W_11|



a tower of extension fields of F2 as in [BC14, LCK[+] 18]: 

F22 = F2[ _x_ 1] _/_ ( _x_[2] 1[+] _[ x]_[1][+ 1)] _[,]_ F24 = F22[ _x_ 2] _/_ ( _x_[2] 2[+] _[ x]_[2][+] _[ x]_[1][)] _[,]_ F28 = F24[ _x_ 4] _/_ ( _x_[2] 4[+] _[ x]_[4][+] _[ x]_[2] _[x]_[1][)] _[,]_ F216 = F28[ _x_ 8] _/_ ( _x_[2] 8[+] _[ x]_[8][+] _[ x]_[4] _[x]_[2] _[x]_[1][)] _[,]_ F232 = F216[ _x_ 16] _/_ ( _x_[2] 16[+] _[ x]_[16][+] _[ x]_[8] _[x]_[4] _[x]_[2] _[x]_[1][)] _[.]_ 

For completeness, we note that our Cantor basis is defined by 

**==> picture [284 x 39] intentionally omitted <==**

**The Pointwise Multiplication** The pointwise multiplication consists of 1024 or 2048 independent multiplications in F232. To carry out these multiplications, we follow [BC14, Cho17] to represent field elements in a bitsliced format. As the M4 is a 32-bit platform, bitslicing means that we always perform 32 multiplications in parallel. 

To multiply _a_ 0 + _a_ 1 _x_ 16 _∈_ F232 and _b_ 0 + _b_ 1 _x_ 16 _∈_ F232 (in parallel with 31 other multiplications), we use the Karatsuba algorithm to reduce the task into 3 multiplications _a_ 0 _b_ 0 _, a_ 1 _b_ 1 _,_ ( _a_ 0 + _b_ 0)( _a_ 1 + _b_ 1) in F216 and apply the Karatsuba recursively as [BC14]. We note that the amount of data for multiplication in F24 fits into the general-purpose registers, so there is no register spilling in the case. For larger fields, we use floating-point registers as a pool for register spilling. 

**The Butterflies** Section 7.1 shows that, at level _i_ of recursion (level 0 represents the top level), multiplications in the butterflies are always of the form _β · f_[(1)] ( _s_ 1( _β_ )), where 

**Table 3:** Cost of multiplying an element in F232 by various field elements. Note that the cycle counts are for carrying out 32 such multiplications. For the environment of benchmarking, see Section 8. 

|8.||||
|---|---|---|---|
|mult. by|ANDs|XORs|cycles|
|F24|12_·_8|18_·_8|465|
|F28|36_·_4|74_·_4|871|
|F216|108_·_2|270_·_2|1652|
|F232|324|930|2849|
|_v_17|0|210|760|
|_v_18|0|211|742|
|_v_19|0|231|800|
|_v_20|0|226|798|
|_v_21|0|231|795|
|_v_22|0|222|795|
|_v_23|0|239|836|
|_v_24|0|249|854|
|_v_25|0|251|881|
|_v_26|0|248|861|
|_v_27|0|243|847|



Ming-Shing Chen , Tung Chou 

and Markus Krausz 

117 

_β ∈ vℓ′−i_ + _m/_ 2 + _Wℓ′−i_ . Following [BC14, Cho17], we pre-compute all _β_ ’s and store them (in the bitsliced format) in a static table. The multiplications can of course be carried out by our function for 32 multiplications in F232. However, our implementation does better by exploiting the fact that _β_ = _v_ + _w_ , where _v ∈ vℓ−i_ + _m/_ 2 and _w ∈ Wℓ[′] −i_ . To carry out a multiplication between _β_ and _γ_ , our implementation multiplies _γ_ by _v_ , multiplies _γ_ by _w_ , and adds the two results to obtain _β · γ_ . 

Observe that _w_ is always in a proper subfield of size 2[2] _[⌈]_[log2(] _[ℓ][′−][i]_[)] _[⌉]_ . Due to the tower field structure, we carry out the multiplication by _w_ as 32 _/_ 2 _[⌈]_[log][2][(] _[ℓ][′][−][i]_[)] _[⌉]_ multiplications in the subfield. To carry out the multiplication by _v_ , we consider the operation as an invertible linear map and use the circuit generator introduced in the ePrint version of [BC14] to generate a sequence of `XOR` s for the multiplication. We note that _m_ = 32 is actually too large for the circuit generator to handle: it stops making progress usually after several tens of iterations. When the circuit generator stops to make progress, we generate another sequence of `XOR` s reaching the state in a naive way. Then, we combine the 2 sequences of `XOR` s to complete the whole invertible linear operation. We’ve considered Paar’s circuit generator [Paa97], but it hard to fit everything into available registers since it does not generate in-place code. We also tried Bernstein’s circuit generator [Ber09b], but the results (in terms of numbers of `XOR` s) are worse than the one from [BC14]. 

We show the costs of various multiplications in Table 3 to evaluate our strategy of performing multiplication by _β_ = _v_ + _w_ . As shown in the table, carrying out 32 multiplications by _v_ takes at most 881 cycles, and carrying out 32 multiplications by 32 _w_ ’s takes at most 1652 cycles. Carrying out 32 multiplications in F232, however, takes 2849 _>_ 881 + 1652 cycles. 

Figure 4 shows the stride of the butterflies decreases by a factor of 2 in each stage. For the first few stages, the strides are always greater than 32, so 32 butterflies can be carried out in parallel with bitslicing. However, in the last 5 stages, there are stride-16 _,_ 8 _,_ 4 _,_ 2 _,_ 1 butterflies, which make it hard to carry out 32 butterflies in parallel. The same issue has appeared in [Cho17] regarding Beneš networks as Beneš networks have a similar structure as the butterflies. The author of [Cho17] solve the issue by carrying out matrix transpositions on the data. We make use of the same idea: one can imagine that our implementation performs a matrix transposition on the data right before the last 5 stages. The matrix transposition turns stride-16 _,_ 8 _,_ 4 _,_ 2 _,_ 1 butterflies into butterflies with strides greater than or equal to 32, so that we are able to carry out 32 butterflies in parallel. At the end of the forward FAFFTs, the order of the field elements is changed because of the matrix transposition, but this does not affect the pointwise multiplication since the multiplication can be carried out in any order. Similarly, in the inverse FAFFT, one can imagine that our implementation performs a matrix transposition on the data right after the first 5 stages. 

We note that instead of carrying out the whole matrix transpositions, we actually carry out only a part of the matrix transposition in each of the 5 stages. The part of the matrix transposition we carry out in a stage is just enough to makes it possible to carry out 32 butterflies in parallel in that stage. This is a different way of implementing the idea in [Cho17]. 

**Encoding** Consider the input _f[′]_ as a matrix _M ∈_ F[32] 2 _[×][n][′]_ where the _Mj,i_ = _cj·n′_ + _i_ . One way to understand the encoding is to consider it as multiplying _M_ by a 32 _×_ 32 invertible matrix (from the left), where the invertible matrix is defined by _vm/_ 2 _, . . . , vm/_ 2 _−_ 4. As multiplying by the invertible matrix is a linear map, we again make use of the circuit generator in [Cho17] to optimize it. We also use the circuit generator to optimize the inverse of encoding, which is used in the inverse FAFFT. 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

118 

**Radix Conversions** Our implementation follows the algorithm presented in [LANH16], which seems to be implicitly shown in [GM10, Section IV]. As the implementation is quite straight-forward, we do not describe how we implemented the algorithm in detail. 

## **8 Experiment Results and Discussions** 

We chose the STM32F407 Discovery board to be the platform for benchmarking. It is a low-cost development board by STMicroelectronics featuring the STM32F407VG microcontroller that can be clocked with up to 168 MHz, and it has 192 KB of SRAM and 1 MB of flash memory. All implementations for M4 are benchmarked in the `pqm4` [KRSS19, KRSS] benchmarking framework on the development board with the compiler `arm-none-eabi-gcc-10.2.1` . Note that `pqm4` always sets the frequency to 24 MHz so that the CPU can be set to have zero wait states when fetching instructions from the flash memory. 

All the Haswell cycle counts in this section, unless specified otherwise, are measured on one core of an Intel Xeon E3-1275 v3 CPU, with Turbo Boost and hyper-threading disabled. 

## **8.1 Multiplications in** _**Rz**_ 

The following table shows the cycle counts for carrying out one circular shift in our Haswell and M4 implementations with the techniques in Section 3 and 4. 

|`bikel1`<br>`bikel3`|Haswell|M4|
|---|---|---|
||1112<br>2547|24856<br>52722|



The following table shows the numbers of cycles on the Haswell core to carry out a multiplication Tr( _hi_ ) _·_ Lift( _s_ ) in _Rz_ . Our code uses the techniques in Section 3 and 5. 

||our code|`avx2`|
|---|---|---|
|`bikel1`<br>`bikel3`|113822<br>369782|202176<br>629952|



The way the `avx2` implementation carries out circular shifts is similar to the approach in Section 4, because it also makes use of conditional moves. The conditional moves are realized by using the intrinsic `_mm256_blendv_epi8` . 

The following table shows the numbers of cycles on the Cortex-M4 to carry out a multiplication Tr( _hi_ ) _·_ Lift( _s_ ) in _Rz_ . Our code uses the techniques in Section 4 and 5. 

||our code|`portable`|
|---|---|---|
|`bikel1`<br>`bikel3`|2195104<br>6746105|4346484<br>13981293|



We actually tried to use the techniques in Section 3 for our M4 implementation but found that the approach in Section 4 is still faster. We believe this is due to the fact that the size 

Ming-Shing Chen , Tung Chou 

and Markus Krausz 

119 

of YMM registers on Haswell is much larger than the size of general-purpose registers on the Cortex-M4, and that there are powerful intrinsics/instructions (as shown in [GAB19]) that can be used to manipulate YMM registers so that even a shift of _s_[(0)] _∈{_ 0 _, . . . ,_ 255 _}_ bits can be carried out efficiently. 

## **8.2 Multiplications in** _**R**_ 

The following table shows the Haswell cycles for a multiplication between two elements in _R_ . Our code uses techniques in Section 6. We actually tried to implement the FAFFTbased multiplication described in Section 7. Instead of bitslicing, our FAFFT-based implementation uses `pclmulqdq` for field multiplications. However, as shown in the last column of the table, this leads to a much slower implementation. 

|||||
|---|---|---|---|
||our code|`avx2`|FAFFT|
|`bikel1`<br>`bikel3`|22856<br>68912|29169<br>91641|66265<br>136194|



The following table shows the M4 cycles for a multiplication between two elements in _R_ with respect to methods in Section 7 and from the BIKE team. 

||our code|`portable`|
|---|---|---|
|`bikel1`<br>`bikel3`|1320940<br>2929293|2897887<br>9606051|



We can further reduce the cost of FAFFT multiplication by reusing the intermediate data while multiplying same elements. As shown in Algorithm 1, there are many multiplications in _R_ of the form _eihi_ in the decoder. Since _h_ 0 and _h_ 1 do not change during decapsulation, our implementation computes two forward FAFFTs, one for _h_ 0 and one for _h_ 1, at the beginning of decapsulation. Then, each time we need to compute _eihi_ , one forward FFT can be saved. In this way, about 30% of the 1320940 cycles and 2929293 cycles can be saved for each _eihi_ . 

It is mentioned in [Cho16, Section 5.1] that one can use circular shifts to carry out each multiplication of _eihi_ : write _hi_ as[�] _s[x][−][s]_[and][compute] _[e][i][h][i]_[as][�] _s_[(] _[x][−][s][e][i]_[).][The][numbers] in the first table of Section 8.1 show that the resulting cycle counts are expected to be 

- 1112 _·_ 71 = 78952 cycles for `bikel1` on Haswell, 

- 2547 _·_ 103 = 262341 cycles for `bikel3` on Haswell, 

- 24856 _·_ 71 = 1764776 cycles for `bikel1` on M4, 

- 52722 _·_ 103 = 5430366 cycle for `bikel3` on M4. 

## **8.3 Key Generation, Encapsulation, and Decapsulation** 

The Haswell cycles for key generation, encapsulation, and decapsulation are shown in the following table. The cycle counts of the `avx` implementation are from [Be], and they are measured on a machine `titan0` with a Haswell CPU. 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

120 

||key gen.|encap.|decap.|imple.|
|---|---|---|---|---|
|`bikel1`|833968<br>688372|131276<br>124892|2636108<br>1900908|`avx2`<br>our code|
|`bikel3`|2515016<br>1857256|313976<br>283932|9040604<br>6010004|`avx2`<br>our code|



The M4 cycles for key generation, encapsulation, and decapsulation are shown in the following table. 

||key gen.|encap.|decap.|imple.|
|---|---|---|---|---|
|`bikel1`|65414337<br>24935033|4824059<br>3253379|114592442<br>49911673|`portable`<br>our code|
|`bikel3`|212999628<br>59820502|15041356<br>8376212|374777003<br>139234176|`portable`<br>our code|



## **Acknowledgements** 

The work of Ming-Shing Chen was funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) under Germany’s Excellence Strategy - EXC 2092 CASA - 390781972. The work of Tung Chou was supported by Taiwan Ministry of Science and Technology (MOST) Grant 109-2222-E-001-001-MY3. The work of Markus Krausz was funded by the German Federal Ministry of Education and Research (BMBF) under the project “QuantumRISC” (ID 16KIS1038) [Qua20] and project “PQC4MED” (ID 16KIS1044). 

## **References** 

- [AASA[+] 20] Gorjan Alagic, Jacob Alperin-Sheriff, Daniel Apon, David Cooper, Quynh Dang, John Kelsey, Yi-Kai Liu, Carl Miller, Dustin Moody, Rene Peralta, Ray Perlner, Angela Robinson, and Daniel Smith-Tone. Status report on the second round of the NIST post-quantum cryptography standardization process, 2020. `https://nvlpubs.nist.gov/nistpubs/ir/2020/NIST.IR. 8309.pdf` . 

- [ABB[+] 17] Nicolas Aragon, Paulo S. L. M. Barreto, Slim Bettaieb, Loïc Bidoux, Olivier Blazy, Jean-Christophe Deneuville, Philippe Gaborit, Santosh Ghosh, Shay Gueron, Tim Güneysu, Carlos Aguilar Melchor, Rafael Misoczki, Edoardo Persichetti, Nicolas Sendrier, Jean-Pierre Tillich, Valentin Vasseur, and Gilles Zémor. BIKE – bit flipping key encapsulation, 2017. `https://bikesuite. org/` . 

- [ABC[+] 17] Martin Albrecht, Daniel J. Bernstein, Tung Chou, Carlos Cid, Jan Gilcher, Tanja Lange, Varun Maram, Ingo von Maurich, Rafael Misoczki, Ruben Niederhagen, Kenneth G. Paterson, Edoardo Persichetti, Christiane Peters, Peter Schwabe, Nicolas Sendrier, Jakub Szefer, Cen Jung Tjhai, Martin Tomlinson, and Wen Wang. Classic McEliece, 2017. `https://classic. mceliece.org/` . 

Ming-Shing Chen , Tung Chou and Markus Krausz 

121 

- [AMAB[+] 17] Carlos Aguilar Melchor, Nicolas Aragon, Slim Bettaieb, Loïc Bidoux, Olivier Blazy, Jurjen Bos, Jean-Christophe Deneuville, Arnaud Dion, Philippe Gaborit, Jérôme Lacan, Edoardo Persichetti, Jean-Marc Robert, Pascal Véron, and Gilles Zémor. Hamming Quasi-Cyclic (HQC), 2017. `https: //pqc-hqc.org/` . 

- [BC14] Daniel J. Bernstein and Tung Chou. Faster binary-field multiplication and faster binary-field MACs. In Antoine Joux and Amr M. Youssef, editors, _Selected Areas in Cryptography - SAC 2014 - 21st International Conference, Montreal, QC, Canada, August 14-15, 2014, Revised Selected Papers_ , volume 8781 of _Lecture Notes in Computer Science_ , pages 92–111. Springer, 2014. `https://doi.org/10.1007/978-3-319-13051-4_6` . 

- [Be] Daniel J. Bernstein and Tanja Lange (editors). eBACS: ECRYPT benchmarking of cryptographic systems. Accessed Dec. 23, 2020. `https://bench. cr.yp.to` . 

- [Ber09a] Daniel J. Bernstein. Batch binary edwards. In Shai Halevi, editor, _Advances in Cryptology - CRYPTO 2009, 29th Annual International Cryptology Conference, Santa Barbara, CA, USA, August 16-20, 2009. Proceedings_ , volume 5677 of _Lecture Notes in Computer Science_ , pages 317–336. Springer, 2009. `http://binary.cr.yp.to/bbe-20090604.pdf` . 

- [Ber09b] Daniel J. Bernstein. Optimizing linear maps modulo 2, 2009. `https:// binary.cr.yp.to/linearmod2-20091005.pdf` . 

- [BP05] Joan Boyar and René Peralta. The exact multiplicative complexity of the hamming weight function. In _Electronic Colloquium on Computational Complexity (ECCC’05),(049)_ , 2005. `https://cpsc.yale.edu/sites/default/ files/files/tr1260.pdf` . 

- [Can89] David G. Cantor. On arithmetical algorithms over finite fields. _Journal of Combinatorial Theory, Series A_ , 50(2):285–300, March 1989. `http://dx. doi.org/10.1016/0097-3165(89)90020-4` . 

- [CCK[+] ] Ming-Shing Chen, Chen-Mou Cheng, Po-Chun Kuo, Wen-Ding Li, and BoYin Yang. Multiplying boolean polynomials with Frobenius partitions in additive fast Fourier transform. `http://arxiv.org/abs/1803.11301` . 

- [Cho16] Tung Chou. QcBits: constant-time small-key code-based cryptography. In _International Conference on Cryptographic Hardware and Embedded Systems_ , pages 280–300. Springer, 2016. `https://eprint.iacr.org/2019/150` . 

- [Cho17] Tung Chou. Mcbits revisited. In Wieland Fischer and Naofumi Homma, editors, _Cryptographic Hardware and Embedded Systems - CHES 2017 - 19th International Conference, Taipei, Taiwan, September 25-28, 2017, Proceedings_ , volume 10529 of _Lecture Notes in Computer Science_ , pages 213–231. Springer, 2017. `https://doi.org/10.1007/978-3-319-66787-4_11` . 

- [DG19] Nir Drucker and Shay Gueron. A toolbox for software optimization of QCMDPC code-based cryptosystems. _Journal of Cryptographic Engineering_ , 9(4):341–357, 2019. `https://eprint.iacr.org/2017/1251.pdf` . 

- [DGK20a] Nir Drucker, Shay Gueron, and Dusan Kostic. Fast polynomial inversion for post quantum QC-MDPC cryptography. _IACR Cryptology ePrint Archive_ , 2020:298, 2020. `https://eprint.iacr.org/2020/298.pdf` . 

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

122 

- [DGK20b] Nir Drucker, Shay Gueron, and Dusan Kostic. QC-MDPC decoders with several shades of gray. In _International Conference on Post-Quantum Cryptography_ , pages 35–50. Springer, 2020. `https://eprint.iacr.org/2019/1423` . 

- [FS71] Caxton C. Foster and Fred D. Stockton. Counting responders in an associative memory. _IEEE Transactions on Computers_ , 100(12):1580–1583, 1971. 

- [GAB19] Antonio Guimarães, Diego F Aranha, and Edson Borin. Optimized implementation of QC-MDPC code-based cryptography. _Concurrency and Computation: Practice and Experience_ , 31(18):e5089, 2019. 

- [GM10] Shuhong Gao and Todd Mateer. Additive fast Fourier transforms over finite fields. _IEEE Transactions on Information Theory_ , 56(12):6265–6272, December 2010. `http://dx.doi.org/10.1109/TIT.2010.2079016` . 

- [KRSS] Matthias J. Kannwischer, Joost Rijneveld, Peter Schwabe, and Ko Stoffelen. PQM4: Post-quantum crypto library for the ARM Cortex-M4. `https: //github.com/mupq/pqm4` . 

- [KRSS19] Matthias J. Kannwischer, Joost Rijneveld, Peter Schwabe, and Ko Stoffelen. pqm4: Testing and benchmarking NIST PQC on ARM Cortex-M4. _IACR Cryptology ePrint Archive_ , 2019:844, 2019. `https://eprint.iacr.org/ 2019/844` . 

- [LANH16] Sian-Jheng Lin, Tareq Y. Al-Naffouri, and Yunghsiang S. Han. FFT algorithm for binary extension finite fields and its application to Reed–Solomon codes. _IEEE Transactions on Information Theory_ , 62(10):5343–5358, October 2016. `https://doi.org/10.1109/TIT.2016.2600417` . 

- [LCK[+] 18] Wen-Ding Li, Ming-Shing Chen, Po-Chun Kuo, Chen-Mou Cheng, and BoYin Yang. Frobenius additive fast fourier transform. In Manuel Kauers, Alexey Ovchinnikov, and Éric Schost, editors, _Proceedings of the 2018 ACM on International Symposium on Symbolic and Algebraic Computation, ISSAC 2018, New York, NY, USA, July 16-19, 2018_ , pages 263–270. ACM, 2018. `https://doi.org/10.1145/3208976.3208998` . 

- [MTSB13] Rafael Misoczki, Jean-Pierre Tillich, Nicolas Sendrier, and Paulo SLM Barreto. MDPC-McEliece: new McEliece variants from moderate density parity-check codes. In _2013 IEEE international symposium on information theory_ , pages 2069–2073. IEEE, 2013. `https://eprint.iacr.org/2012/409.pdf` . 

- [Paa97] Christof Paar. Optimized arithmetic for reed-solomon encoders. In _Proceedings of IEEE International Symposium on Information Theory_ , page 250. IEEE, 1997. `https://www.ei.ruhr-uni-bochum.de/media/crypto/ veroeffentlichungen/2011/01/19/cnst.ps` . 

- [Qua20] QuantumRISC. Quantumrisc — next generation cryptography for embedded systems, 2020. 

## **A A Loop with Conditional Shift in Our M4 Implementation** 

Note that the selection instruction `SEL` depends on the `GE` flag, which is not affected by the `TEQ` instruction that is used to control the loop. 

Ming-Shing Chen , Tung Chou 

and Markus Krausz 

123 

```
lsrRy0,s,#13
andRy0,#1
movRx0,#983040
mulRy0,Rx0
msrAPSR_g,Ry0
addptr,ptr_a,#-16
addptr_end,ptr,#1024
loop256_a:
ldrRx0,[ptr,#16]!
ldrRx1,[ptr,#4]
ldrRx2,[ptr,#8]
ldrRx3,[ptr,#12]
ldrRy0,[ptr,#1024]
ldrRy1,[ptr,#1028]
ldrRy2,[ptr,#1032]
ldrRy3,[ptr,#1036]
selRx0,Ry0,Rx0
selRx1,Ry1,Rx1
selRx2,Ry2,Rx2
selRx3,Ry3,Rx3
strRx0,[ptr,#0]
strRx1,[ptr,#4]
strRx2,[ptr,#8]
strRx3,[ptr,#12]
ldrRx0,[ptr,#2048]
ldrRx1,[ptr,#2052]
ldrRx2,[ptr,#2056]
ldrRx3,[ptr,#2060]
selRy0,Rx0,Ry0
selRy1,Rx1,Ry1
selRy2,Rx2,Ry2
selRy3,Rx3,Ry3
strRy0,[ptr,#1024]
strRy1,[ptr,#1028]
strRy2,[ptr,#1032]
strRy3,[ptr,#1036]
teqptr_end,ptr
bneloop256_a
```

## **B Python Code for the Boyar–Peralta Algorithm** 

```
count=0
index=[]
defnbits(n):
ret=0;
whilen>0:
ret+=1
n>>=1
returnret
```

Optimizing BIKE for the Intel Haswell and ARM Cortex-M4 

124 

```
deffind(n):
```

```
exp=0
whileTrue:
if2**exp-1>n:
break
exp+=1
return2**(exp-1)-1
defbp(n,off):
globalcount
globalindex
ifn==1:
print("rotate_right(&bn,f,s[{0}]);".format(count))
count+=1
print("adder_size_eq(buf,bn,{0},0);".format(off))
index.append(off+0)
return
n1=find(n-1)
n2=n-1-n1
ifn1>=1:bp(n1,off)
ifn2>=1:bp(n2,off+nbits(n1))
print("rotate_right(&bn,f,s[{0}]);".format(count))
count+=1
ifn1==n2:
print("adder_size_eq(buf,bn,{0},{1});".format(off,nbits(n1)))
index.append(off+2*nbits(n1)-1);
else:
print("adder_size_neq(buf,bn,{0},{1},{2});".format(off,nbits(n1),nbits(n2)))
index.append(off+nbits(n1)+nbits(n2)-1);
```

