---
source_pdf: docs/references/pdf/other-platforms/PHOENIX - Crypto-Agile Hardware Sharing.pdf
converted_at: 2026-05-29 22:40
conversion_time: 9.1s
tool: pymupdf4llm
---

## **PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC** 

Antonio Ras[1] , Antoine Loiseau[1] , Mikael Carmona[1] , Simon Pontié[1] _[,]_[3] , Guénaël Renault[3] _[,]_[4] , Benjamin Smith[3] and Emanuele Valea[5] 

> 1 Univ. Grenoble Alpes, CEA-Leti, Grenoble, France `{mikael.carmona,antoine.loiseau,simon.pontie,antonio.ras}@cea.fr` 

> 2 CEA-Leti, Mines Saint-Étienne, Equipe Commune, Gardanne, France 

> 3 LIX, INRIA, CNRS, Ecole Polytechnique, Institut Polytechnique de Paris, France `smith@lix.polytechnique.fr` 

> 4 ANSSI, Paris, France `guenael.renault@ssi.gouv.fr` 

> 5 Univ. Grenoble Alpes, CEA-List, Grenoble, France `emanuele.valea@cea.fr` 

**Abstract.** The transition to quantum-safe public-key cryptography has begun: for key agreement, NIST has standardized ML-KEM and selected HQC for future standardization. The relative immaturity of these schemes encourages crypto-agile implementations, to facilitate easy transitions between them. Intelligent crypto-agility requires efficient sharing strategies to compute operations from different cryptosystems using the same resources. This is particularly challenging for cryptosystems with distinct mathematical foundations, like lattice-based ML-KEM and code-based HQC. We introduce PHOENIX, the first crypto-agile hardware coprocessor for latticeand code-based cryptosystems—specifically, ML-KEM and HQC, at all three NIST security levels—with an effective agile sharing strategy. PHOENIX accelerates polynomial multiplication, which is the main operation in both cryptosystems, and the current bottleneck of HQC. To maximise sharing, we replace HQC’s Karatsubabased polynomial multiplication with the Frobenius Additive FFT (FAFFT), which is similar on an abstract level to ML-KEM’s Number Theoretic Transform (NTT). We show that the FAFFT already brings substantial performance improvements in software. In hardware, our sharing strategy for the FAFFT and NTT is based on a new SuperButterfly unit that seamlessly switches between these two FFT variants over completely different rings. This is, to our knowledge, the first FAFFT hardware accelerator of any kind. We have integrated PHOENIX in a real Systemon-Chip FPGA scenario, where our performance measurements show that efficient crypto-agility for lattice- and code-based KEMs can be achieved with low overhead. **Keywords:** Post-Quantum Cryptography · Crypto-Agility · SW-HW FPGA codesign · Polynomial Multiplication sharing strategy · ML-KEM · NTT · HQC · FAFFT 

## **1 Introduction** 

The transition to quantum-safe cryptography has begun [DRA[+] 24], with the first international standards for post-quantum key encapsulation mechanisms (KEMs) and digital signatures appearing in 2024. But the relative immaturity—in security analysis and in implementation techniques—of schemes such as ML-KEM [Nat24b] (the first NIST standard post-quantum KEM) and HQC [AMAB[+] 24] (selected by NIST for future standardization [AG25]) makes _crypto-agility_ an important concern for long-term security [ASW[+] 23]. 

Crypto-agility is promoted by NIST as a best practice to ensure the resilience of cryptographic infrastructure in the face of evolving threats [BCC[+] 25]. Intuitively, cryptoagility means the ability to dynamically switch between different cryptographic algorithms 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

2 

with minimal inconvenience. This switching might mean changing parameters within one system, or moving from one system to another completely different one, to maintain security in the face of advances in cryptanalysis. 

For example: perhaps today we use ML-KEM 512. A significant advance in moduleLWE cryptanalysis might mean revising ML-KEM’s internal parameters to maintain an equivalent security level—or worse, it could force a migration to a KEM based on a different hard problem, such as code-based HQC. 

Cryptographic migration is hard [LGH[+] 24], and even harder when it must be done quickly. Crypto-agility anticipates and mitigates this difficulty starting at the design phase. This is especially challenging when specialized hardware is involved: development cycles are far longer, designed lifetimes of deployed systems are longer, and updates cannot be done by distributing a patch. Efficient hardware agility depends on the ability to execute common operations from different cryptosystems using shared hardware resources. Sometimes, this is trivial: for example, all new NIST standard cryptosystems use the Keccak-based hash functions and XOFs defined in FIPS 202 [Nat15], so a common core implementation of Keccak can serve many different cryptosystems. For another example, many latticebased cryptosystems use the Number-Theoretic Transform (NTT) to perform polynomial multiplication. While different algorithms use different parameters, the nature of the function relies on the same mathematical operations, making it easy to integrate multiple cryptosystems using the same accelerator. But when we consider crypto-agility between cryptosystems from different paradigms—that is, with completely different underlying mathematical problems, different algorithms, and different implementation techniques in software and hardware—then finding ways to share computations is highly nontrivial. 

## **1.1 Prior work** 

Lattice-based cryptosystems have seen plenty of agile hardware designs. Sapphire [BUC19] presented a pioneering configurable and efficient ASIC design for cryptosystems based on the hardness of various Learning With Errors (LWE) problems [Reg09]. Focusing on more recent work targeting the NIST standards ML-KEM [Nat24b] and ML-DSA [Nat24a], we find full hardware ASIC implementations including [KMK[+] 24, AMI[+] 22, KML[+] 24]. Other works follow a hardware-software co-design approach, offloading data to be processed on separate FPGA-based hardware accelerators [NKDNPH24, LZL[+] 24, YSZ[+] 24], RISCV processors [DMSS24, MBB[+] 23, WZZ[+] 24] (which can be directly implemented and integrated as configurable logic in FPGAs), and ASICs [KSFS24]. 

The situation is different for code-based cryptosystems, and HQC in particular. We know of only three full-hardware implementations of HQC [AMDD[+] 22, DXN[+] 23, ABPS24], though other HW/SW co-design proposals accelerate the polynomial multiplication [LST[+] 23, THKX23, HTB[+] 24], the Reed–Muller encoder [THCX24], the Reed– Solomon decoder [LST[+] 23], and constant-time sampling [SFW23, HTX23]. Early reference implementations of HQC used a sparse-dense method for polynomial multiplication; but since the last update [AMAB[+] 24], this has been replaced by 2-way Karatsuba to mitigate side-channel attacks, and this has become the main bottleneck of the algorithm. (The sparse-dense implementations in [ABPS24, HTB[+] 24] were claimed to be constant-time and thus secure, but the shift to 2-way Karatsuba makes this work obsolete.) 

For crypto-agile hardware supporting lattice-based _and_ code-based cryptosystems, we find three full-hardware proposals [ZZL[+] 22, ZZO[+] 24, SKN[+] 24], but none of these has an efficient hardware-sharing strategy. Koleci, Mazzetti, Martina, and Masera [KMMM23] proposed using the NTT to accelerate binary multiplication operations in code-based cryptosystems, but unfortunately this method is incompatible with HQC because of the internal construction of the algorithm. 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

3 

## **1.2 Contributions** 

This article introduces Phoenix, an agile hardware coprocessor to accelerate lattice-based ML-KEM _and_ code-based HQC. Phoenix is a loosely-coupled accelerator:[1] it can be used as a memory-mapped peripheral and integrated in any CPU-based System-on-Chip. 

Phoenix simultaneously tackles the polynomial-multiplication bottlenecks in ML-KEM and HQC. It includes a digital design that speeds up both the Number-Theoretic Transform (NTT) required for ML-KEM and the Frobenius Additive FFT (FAFFT), which we use to implement efficient polynomial multiplication in HQC for the first time in software and in hardware. This also represents first hardware acceleration of HQC mitigating earlier side-channel attacks on its original sparse-dense multiplication algorithm. 

The NTT and FAFFT algorithms are accelerated using an innovative and efficient hardware-sharing strategy—indeed, the first hardware-sharing strategy for simultaneous acceleration of lattice- and code-based cryptosystems. Our strategy is based on a new SuperButterfly circuit which computes various “butterfly” structures (with different arithmetic foundations) that appear in the NTT and FAFFT. The result is competitive hardware acceleration for the three security levels of both ML-KEM and HQC, while reducing the resource consumption that would be required by separate accelerators. 

We have implemented Phoenix and SuperButterfly in a Xilinx Zynq-7020 FPGA SoC, with an efficient memory-access scheme to minimize the impact of slow data transfer on this platform. As a loosely-coupled accelerator, the Phoenix architecture can easily be ported to other platforms, and extended to accelerate other lattice- and code-based cryptosystems such as ML-DSA. 

Our benchmarks on this SoC show important gains in efficiency for ML-KEM and HQC (and also for a new, faster HQC variant where keys are stored in the FFT domain). They also show an encouragingly low overhead for crypto-agility. 

## **2 Preliminaries** 

We begin with a minimal treatment of the KEMs we implemented, ML-KEM and HQC. We give only on the details needed to discuss implementation of the schemes; the underlying theory, hard problems, and security arguments are defined in the specifications. 

Recall that a general KEM comprises three algorithms: Key Generation ( `KeyGen` ), Encapsulation ( `Encaps` ), and Decapsulation ( `Decaps` ). For Alice and Bob to establish a shared secret key SK over a public channel, 

1. Alice runs `KeyGen` , which outputs her **public encapsulation key** EK and her **private decapsulation key** DK. 

2. Bob obtains Alice’s encapsulation key EK. He runs `Encaps` on EK to obtain a **ciphertext** CT and a **shared secret key** SK; he sends CT to Alice. 

3. Alice receives CT from Bob, and runs `Decaps` on CT and DK to obtain SK. 

## **2.1 ML-KEM** 

ML-KEM [Nat24b] is an IND-CCA2-secure lattice-based KEM, selected by NIST as the first PQC KEM standard. Table 1 lists ML-KEM parameter sets targeting NIST security levels I, III, and V. The polynomial length _n_ and prime modulus _q_ (the same in each parameter set) define a ring 

**==> picture [105 x 11] intentionally omitted <==**

> 1 _Loosely-coupled hardware accelerators_ operate independently of the central processing unit (CPU), with a minimum of synchronisation and interdependency, communicating with the CPU and on-chip memory through communication interfaces such as buses. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

4 

where Z _q_ is the finite field of integers modulo _q_ , with values represented in the range [0 _, q_ ). ML-KEM is constructed in two stages. The first defines K-PKE, an IND-CPA-secure public-key encryption scheme whose security relies on the hardness of the Module Learning With Errors problem (M-LWE) [LS15]. The second derives ML-KEM from K-PKE using a tweaked Fujisaki-Okamoto (FO) transform [FO99] to provide IND-CCA2 security. K-PKE consists of three algorithms: key generation, encryption, and decryption. 

- `K-PKE.KeyGen` : A matrix **A** is sampled uniformly from _R[k] q[×][k]_ , and secret vectors **s** _,_ **e** are sampled from binomial distributions on _R[k] q_[.][We][compute] **[t]**[ :=] **[ As]**[ +] **[ e]** _[ ∈R][k] q_[.][The] public key is ( **A** _,_ **t** ), and the private key is **s** _,_ **e** . 

- `K-PKE.Encrypt` : To encrypt a 32-byte message _m_ , we sample **r** _,_ **e** 1 _∈R[k] q_[,] **[e]**[2] _[∈R][q]_ from binomial distributions, then compute **u** := **A** _[T]_ **r** + **e** 1 _∈R[k] q_[and] _[v]_[:=] **[ t]** _[T]_ **[ r]**[ +] _[ e]_[2][+] `Decompress` _q_ ( _m,_ 1) _∈Rq_ (the function `Decompress` _q_ ( _m,_ 1) encodes _m_ as an element in _Rq_ ). The ciphertext is ( **u** _, v_ ). 

- `K-PKE.Decrypt` : To decrypt a ciphertext ( **u** _, v_ ) using the private key **s** , we compute _m_ := `Compress` _q_ ( _v −_ **s** _[T]_ **u** _,_ 1) _,_ where the function `Compress` _q_ inverts `Decompress` _q_ . 

The real computational “work” here is in the sampling (dominated by the cost of hashing with Keccak), and in the costly multiplications in _Rq_ (which is what we will accelerate). 

Table 1: ML-KEM Parameter Sets. 

|KEM|NIST Level|_n_<br>_q_<br>_k_<br>_η_1<br>_η_2<br>(_du, dv_)|
|---|---|---|
||||
|ML-KEM-512<br>ML-KEM-768<br>ML-KEM-1024|1<br>3<br>5|256<br>3329<br>2<br>3<br>2<br>(10, 4)<br>256<br>3329<br>3<br>2<br>2<br>(10, 4)<br>256<br>3329<br>4<br>2<br>2<br>(11, 5)|



## **2.1.1 The Number-Theoretic Transform (NTT)** 

On the surface, multiplication in _Rq_ means multiplying polynomials of degree _< n_ over Z _q_ , then reducing the result modulo _X[n]_ + 1. But _X[n]_ + 1 factors over Z _q_ into a product of 128 irreducible quadratics: 

**==> picture [147 x 30] intentionally omitted <==**

where _ζ_ is a primitive 256-th root of unity in Z _q_ (the ML-KEM standard takes _ζ_ = 17), and `BitRev7(` _i_ `)` is defined to be the integer represented by bit-reversing the unsigned 7-bit value 0 _≤ i <_ 128 (so `BitRev7` (1) = 64, `BitRev7` (2) = 32, `BitRev7` (3) = 96, etc.; note that _{_ 2 `BitRev7` ( _i_ ) + 1 : 0 _≤ i <_ 128 _}_ = _{_ 1 _,_ 3 _,_ 5 _,_ 7 _, . . . ,_ 253 _,_ 255 _}_ ). This gives a ring isomorphism 

**==> picture [285 x 47] intentionally omitted <==**

the product ring _Tq_ is called the _NTT domain_ . 

As we will see, the NTT is a highly efficient way of computing this isomorphism (rather than just as a series of slow mods). The NTT is the key to fast arithmetic in _Rq_ , since 

**==> picture [167 x 14] intentionally omitted <==**

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

5 

the cost of a multiplication in _Tq_ (which is _n_ multiplications modulo quadratics) is much less than a multiplication in _Rq_ (multiplication modulo a polynomial of degree 2 _n_ ), even without parallelization and vectorization. In fact, with this kind of multiplication the cost of `NTT` and `NTT` _[−]_[1] becomes dominant. 

ML-KEM employs an incomplete `NTT` to define the `NTT` domain. That is, 

**==> picture [188 x 13] intentionally omitted <==**

where 

**==> picture [328 x 32] intentionally omitted <==**

Figure 1 illustrates the divide-and-conquer scheme of the NTT operation, and its inverse INTT. The highlighted process elements are called Cooley–Tukey (CT) and Gentleman– Sande (GS) **butterflies** . 

**==> picture [388 x 118] intentionally omitted <==**

**----- Start of picture text -----**<br>
+<br>x -<br>**----- End of picture text -----**<br>


- (a) Incomplete `NTT` CT process using the Cooley–Tukey butterfly 

**==> picture [388 x 110] intentionally omitted <==**

**----- Start of picture text -----**<br>
+ /2<br>- x /2<br>**----- End of picture text -----**<br>


- (b) Incomplete `INTT` GS process using the Gentleman–Sande butterfly 

Figure 1: Examples of NTT and INTT networks with their elementary process elements. The grey boxes represent unnecessary operations in the incomplete NTT-based processes. 

The NTT defines a _Point-Wise Multiplication_ ( `PWM` ) operation, denoted by _h_[ˆ] = _f_[ˆ] _◦ g_ ˆ, with components defined by 

**==> picture [346 x 13] intentionally omitted <==**

This can be computed using five multiplication in Z _q_ , but this can be reduced to four using an optimization based on Karatsuba’s algorithm [XL21]. The calculation is done in two steps, each with two multiplications: 

> `PWM0` computes _s_ 0 := _f_[ˆ] 2 _i_ + _f_[ˆ] 2 _i_ +1, _s_ 1 := _g_ ˆ2 _i_ + ˆ _g_ 2 _i_ +1, _m_ 0 := _f_[ˆ] 2 _i ·_ ˆ _g_ 2 _i_ , _m_ 1 := _f_[ˆ] 2 _i_ +1 _·_ ˆ _g_ 2 _i_ +1; 

`PWM1` computes _s_ 2 = _m_ 0 + _m_ 1, _m_ 2 = _s_ 0 _· s_ 1, _m_ 3 = _m_ 1 _· ζ_[2] `[BitRev7(]` _[i]_ `[)]`[+1] , and then the final result _h_ 2 _i_ = _m_ 0 + _m_ 3, _h_ 2 _i_ +1 = _m_ 2 _− s_ 2. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

6 

## **2.2 HQC** 

Hamming Quasi-Cyclic (HQC) [AMAB[+] 24] is an IND-CCA2-secure _code-based_ KEM, recently selected by NIST as a future standard. HQC uses concatenated Reed–Muller (RM) and Reed–Solomon (RS) codes to add errors to guarantee message confidentiality. Table 2 shows the parameters sets for the three HQC instances. The parameters _n_ and _w_ define a ring 

_R_ := F2[ _X_ ] _/_ ( _X[n]_ + 1) _,_ 

with a special subset _Rw_ = _{v ∈R_ | _ω_ ( _v_ ) = _w}_ where _ω_ ( _·_ ) is the Hamming weight. 

Table 2: HQC Parameter Sets 

|HQC|NIST Level|_n_1<br>_n_2<br>_n_<br>_w_<br>_w_**r** =_w_**e**|
|---|---|---|
||||
|HQC-128<br>HQC-192<br>HQC-256|1<br>3<br>5|46<br>384<br>17,669<br>66<br>75<br>56<br>640<br>35,851<br>100<br>114<br>90<br>640<br>57,637<br>131<br>149|



Like ML-KEM, the KEM is constructed in two stages: first defines `HQC.PKE` , an INDCPA-secure public-key encryption scheme whose security relies on the hardness of the Quasi-Cyclic Syndrome Decoding problem (QCSD) [AMAB[+] 24]. The second applies the Fujisaki–Okamoto-like Hofheinz–H _o_ ¨velmanns–Kiltz (HHK) transform [HHK17] to `HQC.PKE` to derive the IND-CCA2-secure `HQC.KEM` . 

`HQC.PKE` consists of three algorithms: key generation, encryption, and decryption. 

- `HQC.PKE.KeyGen` : We uniformly sample a vector **h** from _R_ , and secret vectors **x** _,_ **y** from _Rw_ . The public key is ( **h** _, s_ := **x** + **h** _·_ **y** ), and the private key is ( **x** _,_ **y** ). 

- `HQC.PKE.Encrypt` : To encrypt a 32-byte message _m_ , we uniformly sample **r** 1 _,_ **r** 2 _∈ Rwr_ , **e** _∈Rwe_ , then compute **u** = **r** 1 + **h** _·_ **r** 2 _∈R_ and **v** = _m_ **G** + **s** _·_ **r** 2 + **h** _∈R_ , where _m_ **G** = _C._ `Encode` ( _m_ ) is the encoding of _m_ in the RMRS concatenated code. The ciphertext is ( **u** _,_ **v** ). 

- `HQC.PKE.Decrypt` : To decrypt a ciphertext ( **u** _,_ **v** ) using the private key **y** , we compute _m_ := _C._ `Decode` ( **v** _−_ **u** _·_ **y** ) _,_ where _C._ `Decode` ( _·_ ) is the decoding process for the RMRS concatenated code. 

Again, the real computational “work” here is in hashing with Keccak for the sampling and in the costly multiplications in _R_ (which is what we will accelerate). 

## **3 Binary Polynomial Multiplications using FAFFT** 

We now present the Frobenius AFFT (FAFFT), a state-of-the-art binary polynomial multiplication. We start by reviewing classic FFT multiplication in §3.1, then Cantor bases in §3.2. In §3.3 we present the Lin–Chung–Han Additive FFT (AFFT) [CCK[+] 17] for binary multiplication, explaining how to improve its efficiency using the Frobenius partition technique of [vDHL17, LCK[+] 18], and analyze the efficiency of the resulting FAFFT multiplication [CCK[+] 18, CCK21]. Finally, in §3.4 we propose the parameters set to properly use this technique in HQC. 

## **3.1 Binary Multiplication using Kronecker Segmentation** 

We briefly recall the now-standard technique of FFT polynomial multiplication using _Kronecker segmentation_ (see [CLRS22, VZGG03] for further detail and background). 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

7 

Suppose we want to compute the product _C_ ( _x_ ) of two polynomials _A_ ( _x_ ) = _a_ 0+ _· · ·_ + _adx[d]_ and _B_ ( _x_ ) = _b_ 0 + _· · ·_ + _bdx[d] ∈_ F2[ _x_ ] _≤d_ , each represented as a bit sequence of length _d_ + 1. Filling high-degree coefficients with 0 as required, we can assume _n_ = 2( _d_ + 1) is a power of 2 (note that the coefficients of _C_ fit into a bit sequence of length _n_ ). Fix a parameter 0 _< w ≤ d_ and set _ℓ_ := _⌈d/w⌉_ . Choose an irreducible polynomial _g_ in F2[ _x_ ] of degree _m_ := 2 _w_ , and let F2 _m_ = F2[ _z_ ] _/g_ ( _z_ ). Now, to compute _C_ we proceed as follows: 

1. Partition the coefficients of _A_ and _B_ into _ℓ_ blocks of _w_ bits: 

**==> picture [345 x 42] intentionally omitted <==**

2. Now, applying the map _x �→ z ∈_ F2 _m_ to each coefficient block, we set 

**==> picture [331 x 29] intentionally omitted <==**

3. Using the FFT, evaluate _A[′]_ ( _y_ ) and _B[′]_ ( _y_ ) at _ℓ_ points _α_ 0 _, . . . , αℓ−_ 1 in F2 _m_ [ _y_ ] _≤ℓ_ to get 

**==> picture [175 x 28] intentionally omitted <==**

4. Perform point-wise multiplication (PWM) on the _ℓ_ evaluations: 

(ˆ _c_ 0 _, . . . ,_ ˆ _cℓ−_ 1) := (ˆ _a_ 0 _·_[ˆ] _b_ 0 _, . . . ,_ ˆ _aℓ−_ 1 _·_[ˆ] _bℓ−_ 1) _._ 

5. Use the IFFT to interpolate the _C[′]_ ( _y_ ) such that _C[′]_ ( _αi_ ) = ˆ _ci_ for 0 _≤ i < ℓ_ . 

6. Map _C[′]_ ( _y_ ) to _C_ ( _x_ ) _∈_ F2[ _x_ ] _≤n_ via _z �→ x_ and _y �→ x[w]_ , collecting terms and coefficients using the _InterleavedCombine_ operation. 

## **3.2 Cantor Basis Representations of Binary Fields** 

The representation of elements of F2 _m_ as vectors in F _[m]_ 2[always][depends][on][a][choice][of] F2-basis ( _β_ 0 _, . . . , βm−_ 1) of F2 _m_ . Cantor [Can89] defined useful bases when _m_ is a power of 2, i.e. _m_ = 2 _[ℓ][m]_ for some _ℓm >_ 0. Gao and Mateer [GM10] give an explicit recursive construction: 

_β_ 0 = 1 and _βi_[2][+] _[ β][i]_[=] _[ β][i][−]_[1] for 0 _< i < m ._ (2) 

(Cantor bases are not unique: there are two choices for _βi_ at each step, differing by 1.) Given a Cantor basis ( _βi_ ) _[m] i_ =0 _[−]_[1] of F2 _m_ , we have a sequence of subspaces 

_Vk_ := _⟨β_ 0 _, β_ 1 _, ..., βk−_ 1 _⟩_ for 0 _≤ k ≤ m ._ 

Note that _V_ 0 = _{_ 0 _}_ , and _Vk_ is the subfield F2 _k ⊂_ F2 _m_ if and only if _k_ is a power of 2. Each of the _Vk_ defines a _subspace vanishing polynomial_ : 

**==> picture [165 x 24] intentionally omitted <==**

These polynomials satisfy three important properties (see [Can89, GM10]): 

- **Linearity** : _sk_ ( _x_ + _y_ ) = _sk_ ( _x_ ) + _sk_ ( _y_ ) for all 0 _≤ k ≤ m_ ; 

- **Two terms** _**for fields**_ : _sk_ ( _x_ ) = _x_[2] _[k]_ + _x ⇐⇒ k_ is a power of 2, i.e., _Vk_ is a field; 

- **Recursivity** : _sk_ +1( _x_ ) = _s_[2] _k_[(] _[x]_[) +] _[s][k]_[(] _[x]_[)][=] _[s]_[1][(] _[s][k]_[(] _[x]_[))][for][0] _[≤][k][<][m]_[,][and][more] generally _sk_ + _i_ ( _x_ ) = _sk_ ( _si_ ( _x_ )) = _si_ ( _sk_ ( _x_ )) for all _k ≥_ 0 and _i ≥_ 0 with _k_ + _i ≤ m_ . 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

8 

**Evaluating** _**si**_ **(** _**x**_ **).** Evaluating _si_ ( _x_ ) is an important operation for us, and the properties above allow us to do this very efficiently. First, by definition, _si_ ( _βj_ ) = 0 for _j < i_ . Then, rewriting (2) as _s_ 1( _βj_ ) = _βj−_ 1 for 0 _< j < m_ , recursivity gives _si_ ( _βj_ ) = _βj−i_ for _i ≤ j < m_ ; then, by linearity, if we identify elements of F2 _[m]_ with their coefficient vectors, we get 

**==> picture [320 x 11] intentionally omitted <==**

That is: evaluating _si_ corresponds to a simple shift of the coefficient vector by _i_ places. This suggests a particularly convenient encoding of elements of F2 _m_ using unsigned _m_ -bit integers: let _ϕβ_ : [0 _,_ 2 _[m]_ ) _→_ F2 _m_ be the bijection defined by 

**==> picture [311 x 21] intentionally omitted <==**

With this encoding, Equation (3) becomes 

**==> picture [99 x 11] intentionally omitted <==**

where _n ≫ i_ means _n_ shifted right by _i_ bits. 

## **3.3 Optimized multiplication in** F **2[** _**x**_ **] using the Frobenius AFFT** 

We can now present a series of optimizations to the general FFT-based binary polynomial multiplication scheme above. 

## **3.3.1 Basis Conversion for Polynomials** 

Evaluation and interpolation of a polynomial _f ∈_ F2[ _x_ ] _<n_ at _n_ = 2 _[l][n]_ points in F2 _[m]_ expressed in a Cantor basis is particularly efficient if _f_ is represented in a particular basis of F2[ _x_ ] called `novelpoly` . 

**Definition 1.** Given a Cantor basis ( _β_ 0 _, . . . , βm−_ 1) for F2 _m_ , the associated `novelpoly` basis [CCK[+] 17] of F2[ _x_ ] is the sequence of polynomials _X_ 0 _, X_ 1 _, . . ._ where 

**==> picture [338 x 18] intentionally omitted <==**

and the _si_ are the vanishing polynomials for the Cantor basis. That is: _Xk_ is the product of all the _si_ ( _x_ ) where the _i_ -th bit of _k_ is set. We will use the variable _x_ for polynomials in the monomial basis, and _X_ for polynomials in the `novelpoly` basis. 

We need to convert a polynomial _f_ ( _x_ ) in the usual monomial basis to and from a polynomial _g_ ( _X_ ) in the `novelpoly` basis. The algorithm proposed in [BC14] converts _f_ ( _x_ ) to _g_ ( _X_ ) recursively by finding the largest _i_ such that 2 _[i] <_ deg( _f_ ), then dividing _fi_ ( _x_ ) by _si_ ( _x_ ) to get _f_ ( _x_ ) = _f_ 0( _x_ ) + _si_ ( _x_ ) _f_ 1( _x_ ); then _f_ 0 and _f_ 1 are divided again, and so on. Division by _si_ ( _x_ ) is performed by `XOR` operations, with the number of `XOR` s depending on the number of _non-zero_ terms in _si_ ( _x_ ). To reduce the number of `XOR` s, [LANH16] finds the largest _i_ such that 2[2] _[i]_ = deg( _f_ ) and then performs variable substitution to express _f_ as a power series in _s_ 2 _i_ . By the **two terms for fields** property of the vanishing polynomials, this optimization selects only the _si_ ( _x_ ) which contains two terms, consequently reducing the cost of each division of the basis conversion. See [CCK[+] 17, §2.4] for more details. 

## **3.3.2 FFT-like Operations and their Butterfly Structures** 

Given _f_ ( _x_ ) _∈_ F2 _m_ [ _x_ ] _<n_ converted to _g_ ( _X_ ) in the `novelpoly` basis, we can efficiently evaluate _f_ at the set _α_ + _Vℓn_ = _{α_ + _u | u ∈ Vℓn}_ for _α ∈_ F2 _[m]_ (where _n_ = 2 _[ℓ][n]_ ) using the `FFT` LCH algorithm [CCK[+] 17, §2.3.2, Alg. 1]. 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

9 

The algorithm follows a typical divide-and-conquer process: we rewrite _f_ ( _x_ ) = _g_ ( _X_ ) = _p_ 0( _X_ ) + _X_ 2 _ln−_ 1( _x_ ) _· p_ 1( _X_ ), with _p_ 0 and _p_ 1 half the length of _g_ . The general idea of evaluating at all points of _Vℓn_ is to divide the subspace in two sets, _Vℓn−_ 1 and _Vℓn/Vℓn−_ 1 = _Vℓn−_ 1 + _βℓn−_ 1 := _{x_ + _βℓn−_ 1 : _x ∈ Vℓn−_ 1 _}_ . Since _si_ ( _x_ ) = _X_ 2 _i_ ( _x_ ) is linear, evaluations at _Vi_ + _βi_ share common computations with the evaluation at _Vi_ . 

In practice, given _α_ + _Vℓn_ as the starting evaluation point set, we first find max( _i_ ) such that 2 _[i] < n_ . Then we divide by _si_ ( _x_ ) to get _g_ ( _X_ ) = _p_ 0( _X_ ) + _si_ ( _x_ ) _· p_ 1( _X_ ). Then, we use the polynomials _pi_ ( _X_ ) to perform an elementary butterfly structure, here called an `FFT` LCH butterfly: 

**==> picture [142 x 25] intentionally omitted <==**

At this point, the algorithm continue recursively its execution of the new half-sized polynomials. To do that, it recalls the `FFT` LCH function passing as scalar input _α_ and _α_ + _βi_ , for the respectively _h_ 0( _X_ ) and _h_ 1( _X_ ) polynomials. 

The inverse process `IFFT` LCH follows a _unit-and-build_ approach: starting from the known _h_ 0( _X_ ) and _h_ 1( _X_ ), it computes the original value _p_ 0( _X_ ), _p_ 1( _X_ ) using the `IFFT` LCH butterfly structure 

**==> picture [142 x 26] intentionally omitted <==**

The whole process is composed of _ℓn_ layers, each of _n/_ 2 butterfly operations. Figure 2 illustrates the `FFT` LCH and an `IFFT` LCH processes, highlighting the butterfly structures above. 

**==> picture [388 x 119] intentionally omitted <==**

**----- Start of picture text -----**<br>
+<br>x<br>+<br>**----- End of picture text -----**<br>


- (a) The HQC `FFT` LCH process and its elementary processing element, the `FFT` LCH butterfly. 

**==> picture [388 x 121] intentionally omitted <==**

**----- Start of picture text -----**<br>
+<br>x<br>+<br>**----- End of picture text -----**<br>


(b) HQC `IFFT` LCH process and its elementary processing element, the `IFFT` LCH butterfly. 

Figure 2: Example of a `FFT` LCH and `IFFT` LCH network with the `FFT` LCH butterfly and the `IFFT` LCH butterfly. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

10 

## **3.3.3 The Frobenius map and the new evaluated points** 

To multiply polynomials _f_ and _g ∈_ F2[ _x_ ] _<d_ such that deg( _f · g_ ) _< n_ = 2 _[ℓ][n]_ = 2( _d_ + 1), we can split _f, g_ into _ℓ_ -bit blocks, apply the `AFFT` to _f_ and _g_ in F2 _m_ [ _x_ ] to evaluate them at _Vℓn_ , perform PWM, and finally apply the inverse `AFFT` to obtain ( _f · g_ )( _x_ ). Here the `AFFT` procedure first performs polynomial basis conversion using a function `BasisCvt` , and uses `FFT` LCH to evaluate polynomials in the `novelpoly` basis; the inverse `AFFT` performs `IFFT` LCH and `iBasisCvt` . This process exactly describes Kronecker segmentation algorithm, in 3.1, using evaluation points in Cantor basis. 

**Definition 2.** We let _ϕ_ 2 denote the Frobenius map (squaring) over F2, mapping _a ∈_ F2 _[m]_ to _ϕ_ 2( _a_ ) := _a_[2] . Note that 

**==> picture [282 x 11] intentionally omitted <==**

which means that the value of _C_ at point _ϕ_ 2( _a_ ) can be derived from the value _C_ ( _a_ ) by computing _ϕ_ 2( _C_ ( _a_ )). 

The _n_ evaluation points can be reduced using to _np_ = _n/m_ using the Frobenius map and, as suggested in [LCK[+] 18], by taking the set of evaluation point to be 

**==> picture [241 x 13] intentionally omitted <==**

where _ℓnp_ = log( _np_ ) _< m/_ 2 and _ℓnp_ + _m/_ 2 _< m_ . Note that #Σ = _np_ = _n/m_ . The _Frobenius AFFT_ (FAFFT) is the `AFFT` with Σ as the evaluation set, and exploiting _ϕ_ 2 for evaluation. 

## **3.3.4 Truncating the FAFFT using the Encoding function** 

As shown in [LCK[+] 18], given _f ∈_ F2[ _x_ ] _<n_ and the point sets Σ[ˆ] = _α_ + _V_ ( _ℓnp_ + _ℓm_ ), where _α_ = _βℓnp_ + _m/_ 2, evaluating _f_ at Σ corresponds to performing a traditional size- _n_ evaluation of _f_ at Σ[ˆ] , avoiding all the redundant operations. This is called the `Truncated FAFFT` , or simply `FAFFT` . 

**Definition 3.** Given Σ[ˆ] , we define the invertible linear map `encode` : F2[ _x_ ] _<n �→_ F _[n]_ 2 _[m][p]_[[] _[x]_[]][by] 

**==> picture [196 x 18] intentionally omitted <==**

where 

**==> picture [335 x 30] intentionally omitted <==**

The function `encode` performs the first _ℓm_ layers of the `FFT` LCH process. The `Truncated FAFFT` therefore starts with the usual `novelpoly` basis conversion for a size- _n_ polynomial. Then, _ℓm_ layers of the size- _n_ `FFT` LCH process is done with `encode` ; finally, the last _ℓnp_ layers are computed with the usual size- _np_ `FFT` LCH process over Σ. 

## **3.4 Overall FAFFT Polynomial Multiplication** 

Algorithm 1 reproduces the binary polynomial-multiplication algorithm of [CCK21]. As noted above, the operation relies on six processes: `BasisCvt` , `Encode` , `FFT` LCH, and their respective inverses `iBasisCvt` , `Decode` , and `IFFT` LCH. 

To evaluate two input polynomials _a_ ( _x_ ) and _b_ ( _x_ ) _∈_ F2[ _x_ ] _<n_ at the _np_ evaluation points in F2 _m_ [ _x_ ], defined by the Frobenius map, we first apply `BasisCvt` to convert them to the 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

11 

## **Algorithm 1:** FAFFT-based Polynomial Multiplication 

||**Input:** _n_: Maximum length of the output polynomial.|
|---|---|
|**1 **|**Procedure** _`FAFFT`(f_(_x_)_∈_F2[_x_]_<d,_Σ_)_|
|**2**|(_f_0_, . . . , fn−_1)_∈_F_n_<br>2 _←_`BasisCvt`(_f_(_x_))|
|**3**|(_f ′_<br>0_, . . . , f ′_<br>_np−_1)_∈_F_np_<br>2_m ←_`Encode`((_f_0_, f_1_, . . . , fn−_1)_,_Σ)|
|**4**|(ˆ_f_0_, . . . ,_ ˆ_fnp−_1)_∈_F_np_<br>2_m ←_`FFT`LCH((_f ′_<br>0_, . . . , f ′_<br>_np−_1)_,_Σ)|
|**5**|**return** (ˆ_f_0_, . . . ,_ ˆ_fnp−_1)|
|**6 **|**Procedure** _`FAFFT`−_1_(_ ˆ_f_(_x_)_∈_F_np_<br>2_m,_Σ_)_|
|**7**|(_f ′_<br>0_, . . . , f ′_<br>_np−_1)_∈_F_np_<br>2_m ←_`IFFT`LCH(( ˆ_f_0_, . . . ,_ ˆ_fnp−_1)_,_Σ)|
|**8**|(_f_0_, . . . , fn−_1)_∈_F_n_<br>2 _←_`Decode`((_f ′_<br>0_, f ′_<br>1_, . . . , f ′_<br>_n−_1)_,_Σ)|
|**9**|_f_(_x_)_∈_F2[_x_]_<n ←_`iBasisCvt`(_f_0_, f_1_, . . . , fn−_1)|
|**10**|**return** _f_(_x_)|
|**11 **|**Procedure** _`BitPolyMult`(a_(_x_)_, b_(_x_)_∈_F2[_x_]_<d)_|
|**12**|(ˆ_a_0_, . . . ,_ˆ_anp−_1)_∈_F_np_<br>2_m ←_`FAFFT`(_a_(_x_)_,_Σ)|
|**13**|(ˆ_b_0_, . . . ,_ˆ_bnp−_1)_∈_F_np_<br>2_m ←_`FAFFT`(_b_(_x_)_,_Σ)|
|**14**|(ˆ_c_0_, . . . ,_ˆ_cnp−_1)_∈_F_np_<br>2_m ←_(ˆ_a_0_·_ˆ_b_0_, . . . ,_ˆ_anp−_1_·_ˆ_bnp−_1) `// PWM`|
|**15**|_c_(_x_)_∈_F2[_x_]_<n ←_`FAFFT`_−_1((ˆ_c_0_, . . . ,_ˆ_cnp−_1)_,_Σ)|
|**16**|**return** _c_(_x_)|



`novelpoly` basis. Then we apply `Encode` to virtually execute the first _ℓm_ layers of `FFT` LCH. The resulting polynomials _a[′]_ ( _X_ ) _, b[′]_ ( _X_ ) _∈_ F _[n]_ 2 _[m][p]_[[] _[x]_[]][are][represented][with] _[n][p]_[coefficients][in] F2 _[m]_ [ _x_ ]. The remaining _ℓnp_ butterfly layers are processed by performing an usual size- _np_ `FFT` LCH process with the evaluation-point set Σ. This yields _a_ ˆ( _X_ ) and[ˆ] _b_ ( _X_ ) _∈_ F _[n]_ 2 _[m][p]_[[] _[x]_[].][To] finalize the polynomial multiplication we first perform a linear point-wise multiplication, `PWM` LCH, which amounts to _ℓnp_ multiplications in F2 _m_ [ _x_ ]; then we interpolate and convert back, using `IFFT` LCH, `Decode` , and `iBasisCvt` to get the final result. 

Table 3 lists the parameters we used to apply Algorithm 1 in HQC. The extension field used throughout is F232 = F2[ _x_ ] _/_ ( _g_ ( _x_ )), where _g_ ( _x_ ) = _x_[32] + _x_[22] + _x_[2] + _x_ + 1. 

Table 3: FAFFT parameter for all HQC levels. Here _nHQC_ is the _n_ -parameter from the HQC specification, and _n_ denotes the next power of 2. 

|FT paramet<br>tion, and _n_|er for all HQC levels. Here _nHQC_ is the _n_-para<br> denotes the next power of 2.|
|---|---|
||_nHQC_<br>_n_<br>_m_<br>_np_<br>_lnp_<br>Σ|
|||
|`HQC-128`<br>`HQC-192`<br>`HQC-256`|17,669<br>65536<br>32<br>2048<br>11<br>_β_27+_V_11<br>35,851<br>131072<br>32<br>4096<br>12<br>_β_28+_V_12<br>57,637<br>131072<br>32<br>4096<br>12<br>_β_28+_V_12|



## **4 Polynomial multiplication sharing strategy** 

We now define our hardware-based sharing strategy for FFT-based polynomial multiplication in ML-KEM and HQC. As we saw above, these polynomial multiplications follow the same operational approach and data handling scheme, but there are critical differences in the butterfly structures: first, the rings _Rq_ (for ML-KEM) and F2 _m_ (for HQC) have completely different arithmetic operations, and second, each butterfly has a different order of dependence of operations. Our goal is to perform all of these different butterflies (and ultimately, both polynomial multiplications) using a single configurable agile hardware design. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

12 

Our solution, SuperButterfly (described in §4.1), varies the execution of arithmetic operations while reducing resource consumption and communication overhead. We present Phoenix, our SuperButterfly-based hardware accelerator, in §4.2, and report experimental results in §5. 

## **4.1 SuperButterfly** 

SuperButterfly is a configurable digital circuit that can perform all the butterfly structures involved in the targeted `NTT` and `FAFFT` polynomial multiplication operations. A SuperButterfly Unit (SBU) (see Figure 3) is a pipelined hardware architecture with a latency of 8 clock cycles that processes 32-bit data. It takes three input data— two for coefficients and one for constants—and provides two outputs. The SBU can be configured to compute 

- _one_ AFFT-based butterfly for HQC, which requires a 32-bit wide data path; or 

- _two_ parallel NTT-based butterflies for ML-KEM, operating on 12-bit coefficients in the higher and lower 16-bit halves of the data path. 

This reduces the data dependency problem that occurs in the `PWM1` configuration in MLKEM, where the calculation of the final result depends on intermediate values computed in another butterfly. 

**==> picture [349 x 214] intentionally omitted <==**

**----- Start of picture text -----**<br>
sel[8:0]<br>{opmode,intt}<br>+<br>COMP1<br>sel5 0 1 sel4<br>0<br>1<br>sel1 sel3<br>+/- 0 x 0 +/- 0<br>COMP2 COMP3 COMP4<br>1 1 1<br>{opmode,addsub,intt} opmode sel2 opmode<br>**----- End of picture text -----**<br>


Figure 3: SuperButterfly hardware architecture. 

The SBU circuit consists of four fundamental arithmetic units, defined in §4.1.1 and §4.1.2: 

- **COMP1** an **agile modular adder** computing modular addition (with or without carries), followed by an optional modular division by 2 (for a GS butterfly); 

**COMP2** an **agile modular arithmetic** unit extending COMP1 with modular subtraction; 

**COMP3** an **agile modular multiplier** supporting carrying and carryless multiplication; 

**COMP4** a second **agile modular arithmetic** unit like COMP2, but omitting divisionby-2. 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

13 

The SBU can be programmed in seven different butterfly configurations: four for NTT multiplication (Figure 4), and three for FAFFT multiplication (Figure 5). We select butterfly configurations using nine control signals: 

- `opmode` ( `sel[8]` ) changes the operation type depending on which polynomial ring we are using; 

- `addsub` ( `sel[7]` ) switches addition and subtraction for NTT butterflies; 

- `intt` ( `sel[6]` ) enables division by 2 in the `INTT` GS butterfly; 

- `pwm` ( `sel[5]` ) selects different data arrangements for `PWM0` and `PWM1` in the NTT; 

- `sel[4:0]` guarantee correct data flow in a given butterfly. 

Table 4 lists the configurations with their control signals and active components. 

Table 4: Configuration signals for programming SuperButterfly 

|Table 4: C|onfguration s|ignals for programming SuperButterfly|
|---|---|---|
|Function|`sel[8:0]`|COMP1<br>COMP2<br>COMP3<br>COMP4|
||||
|`NTT`CT<br>`INTT`GS<br>`PWM0`<br>`PWM1`<br>`MOD_ADD`<br>`FFT`LCH<br>`IFFT`LCH<br>`PWM`LCH|`010010011`<br>`011000100`<br>`000010100`<br>`000110000`<br>`000000000`<br>`100011001`<br>`100001101`<br>`100010100`|✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓<br>✓|



**==> picture [376 x 217] intentionally omitted <==**

**----- Start of picture text -----**<br>
+ +<br>0 1 0 1<br>0 0<br>1 1<br>+/- 0 x 0 +/- 0 +/- 0 x 0 +/- 0<br>1 1 1 1 1 1<br>(a) Cooley-Tukey NTT butterfly (b) Gentlemen-Sande INTT butterfly<br>+ + +<br>+<br>0 1 SWAP +/-<br>0 1 -<br>0 0 +<br>1<br>1<br>+/- 0 x 0 +/- 0 +/- 0 x 0 +/- 0<br>1 1 1 1 1 1<br>(c) PWM0 configuration (d) PWM1 configuration<br>**----- End of picture text -----**<br>


Figure 4: SuperButterfly configuration features for NTT multiplication. CT and GS are used for the NTT and INTT, respectively, while PWM0 and PWM1 which are chained to compute the 2-way Karatsuba PWM. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

14 

_Remark_ 1 _._ The SBU can also be used to compute some other ML-KEM operations in hardware beyond NTT multiplication, such as stand-alone modular addition (MOD_ADD in Table 4). This configuration requires only COMP1 and is not used in NTT-based polynomial multiplication, so it is not shown in Figure 4. 

**==> picture [383 x 241] intentionally omitted <==**

**----- Start of picture text -----**<br>
+ +<br>0 1 0 1<br>0 0<br>1 1<br>+/- 0 x 0 +/- 0 +/- 0 x 0 +/- 0<br>1 1 1 1 1 1<br>(a) FFT LCH butterfly (b) IFFT LCH butterfly<br>+<br>0 1<br>0<br>1<br>+/- 0 x 0 +/- 0<br>1 1 1<br>(c) PWM butterfly<br>**----- End of picture text -----**<br>


Figure 5: SuperButterfly configuration features for FAFFT multiplication. Note that PWM is much simpler here than in the NTT, both in configuration and at the operational level: only a carryless modular multiplication is used. 

## **4.1.1 Agile modular arithmetic** 

The FAFFT and NTT use completely different arithmetic operations. The FAFFT uses carryless sums, _i.e._ XORs, and addition and subtraction are identical. The NTT works in Z _q_ , with values represented by integers in [0 _, q_ ), and addition and subtraction are distinct. Given representatives _a_ , _b_ for elements of Z _q_ , the representatives for ( _a ± b_ ) mod _q_ are 

**==> picture [362 x 65] intentionally omitted <==**

(Here _x_ denotes bit-wise NOT, so _x_ + 1 is the two’s complement representation of _−x_ .) Figure 6 describes an agile hardware modular adder inspired by the implementation of [ZLL[+] 21]. There are two internal computational units. In the NTT, each computes a separate butterfly; in the FAFFT, with carryless additions, the butterfly result is the concatenation of the two outputs. We can clearly see the two cases of equation (7) in the internal unit: the second requires a sum of three terms. By using a Carry-Save-Adder (CSA), we can perform a carryless addition, as we only need to set a third term to 0. 

This circuit can also divide the final result by 2 when needed for GS butterflies in the INTT. We do this with a shift and an addition: _[x]_[= (] _[x][ ≫]_[1) +] _[ x]_[[0]] _[ ·] q_ +1 . 2[mod] _[ q]_ � 2 � 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

15 

**==> picture [388 x 91] intentionally omitted <==**

Figure 6: The agile modular adder circuit (COMP1). Configurations and control signals are listed in Table 5. 

**==> picture [388 x 103] intentionally omitted <==**

Figure 7: Agile modular arithmetic. The division-by-2 unit, highlighted in red, is included in COMP2 (where it is needed for the GS butterfly), but not in COMP4 (where it is not used). Configurations and control signals are listed in Table 5. 

It is easy to modify COMP1 to enable agile subtraction, which is used in COMP2 and COMP4. For the FAFFT this is trivial (addition and subtraction are identical, and computed by an XOR), and for the NTT we use equation (8). Figure 7 shows the resulting circuit; the supported operations and corresponding control signals are listed in Table 5. 

Table 5: Configurations and control signals for the agile modular adder and arithmetic units (COMP1, COMP2, and COMP4). 

|Supported operation|COMP<br>1 2 4|Control signals<br>`opmode addsub intt`|KEM|
|---|---|---|---|
|Modular addition<br>✓✓✓<br>`0`<br>`0`<br>`0`<br>ML-KEM<br>Modular addition + div-by-2<br>✓✓<br>`0`<br>`0`<br>`1`<br>ML-KEM<br>Modular subtraction<br>✓✓<br>`0`<br>`1`<br>`0`<br>ML-KEM<br>Modular subtraction + div-by-2<br>✓<br>`0`<br>`1`<br>`1`<br>ML-KEM<br>Carryless addition<br>✓✓✓<br>`1`<br>`0`<br>`0`<br>HQC||||



## **4.1.2 Agile modular multiplier** 

Our agile modular multiplication unit (COMP3, Figure 8) processes data in two steps: 

1. a carryless 32-bit multiplication (with 64-bit output) for the FAFFT, or two 16-bit carrying multiplications (each with 32-bit output) for the NTT, followed by 

2. the appropriate modular reduction in each case. 

For agility in the first step we use a _hybrid 2-way Karatsuba_ architecture, called **agile_multiplier** , which performs two 12-bit carry multiplications for the NTT, or one 32-bit carryless multiplication for the FAFFT. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

16 

**==> picture [330 x 172] intentionally omitted <==**

Figure 8: Agile modular multiplier (COMP3) 

This implements Algorithm 2, a divide-and-conquer approach following the classic Karatsuba algorithm: given two _m_ -bit inputs, the result is the concatenation of intermediate values computed on _m/_ 2-bit operands. The same algorithm can also be used for carryless multiplication if all sums and subtractions are replaced by XORs. We will describe this algorithm in detail below. 

For agility in the reduction step we simply parallelize the two methods, then select the desired result. This does not represent hardware sharing, but its effective resource consumption is still very low. Modular reduction for the NTT uses the modified Barrett reduction from [XL21]. (This is a more hardware-friendly approach than the Montgomery reduction in the ML-KEM reference implementation, since it can be optimised for _q_ = 3329 with shifts and additions.) Modular reduction for the FAFFT uses the same shift-and-add strategy, but with carryless addition: we XOR the 32 least significant bits of the operand and left-shift the corresponding 32 bits of the highest value, for each of the monomials in the modulus _g_ ( _x_ ), until the 32 most significant bits of the result are equal to 0. 

## **Algorithm 2:** Hybrid 2-way Karatsuba Algorithm 

**Data:** Two _m_ -bit numbers _a_ and _b_ , one _opmode_ control bit **Result:** The product _P_ = _a · b_ **1** Split _a_ into two _m/_ 2-bit parts: _a_ 1 (high) and _a_ 0 (low) **2** Split _b_ into two _m/_ 2-bit parts: _b_ 1 (high) and _b_ 0 (low) **3** _z_ 0 _← a_ 0 _×M_ 0 _b_ 0 `// Multiplier` _M_ 0 `supports carry and carryless` **4** _z_ 1 _← a_ 1 _×M_ 1 _b_ 1 `// Multiplier` _M_ 1 `supports carry and carryless` **5** _z_ 2 _←_ ( _a_ 0 _⊕ a_ 1) _×M_ 2 ( _b_ 0 _⊕ b_ 1) _⊕ z_ 0 _⊕ z_ 1 `// Multiplier` _M_ 2 `: carryless only` � � **6 if** _opmode = NTT_ **then 7 return** ( _z_ 1 _·_ 2 _[m]_ ) _⊕ z_ 0 **8 else 9 return** ( _z_ 1 _·_ 2 _[m]_ ) _⊕_ ( _z_ 2 _·_ 2 _[m/]_[2] ) _⊕ z_ 0 

Now look more closely at Algorithm 2. The multiplier _M_ 2 operates only in carryless mode, so we implement it with a carryless 2-way Karatsuba strategy operating on _m/_ 4-bit input data. The main innovation, and the main contribution to agility, is in the multipliers _M_ 0 and _M_ 1. Enabling carry propagation determines the results expected by the two butterfly structures integrated in the SuperButterfly, whereas if we disable it, the final 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

17 

result will be that of a _m_ -bit carryless multiplication. 

We implement _M_ 0 and _M_ 1 using an _Array-like Schoolbook_ hardware multiplier [AMR23], which offers better performance than the sequential schoolbook approach. This design is characterized by a regular and repetitive structure which makes it easy to scale. The architecture exploits the parallelism of partial products to generate and accumulate them simultaneously, thus calculating the least significant _m_ bits of the result with a critical path of _m/_ 2 full-adders. The remaining _m_ most significant bits are computed using a traditional Ripple-Carry Adder (RCA) to add the intermediate sum and report values calculated during the accumulation phase. The value of the intermediate partial product accumulation at level _i_ depends on the input carry values, which are output at level _i −_ 1. If these values are forced to 0 (which we trigger using multiplexers depending on the `opmode` control values), both in the array-like structure and in the RCA, then the result is the partial product accumulation without carry propagation: that is, a carryless multiplication. 

## **4.2 PHOENIX Design Rationale** 

Phoenix is a hardware accelerator that uses SuperButterfly units to accelerate polynomial multiplication for ML-KEM and HQC with an effective and agile sharing strategy. We give a high-level description in §4.2.1, describe memory organization, data arrangement, and our conflict-free memory strategy in §4.2.2, and discuss constant management in §4.2.3. 

**==> picture [349 x 290] intentionally omitted <==**

**----- Start of picture text -----**<br>
COEFFICIENT INDEX (CI) POLYNOMIAL MEMORY (PM) address<br>data<br>MEMORY UP<br>INIT ADDRESS<br>BRAM BRAM<br>read up 0 1 PROCESS<br>ELEMENT (PE)<br>UPDATE BRAM BRAM<br>UNIT 2 3<br>SBU 0<br>INDEX INDEX QUEUE MEMORY DOWN<br>SBU 0 SBU 1 BRAM BRAM<br>4 5 SBU 1<br>BANK BRAM BRAM<br>DECODER read down 6 7<br>bank selection<br>HQC ML-KEM<br>TWF AFFT constants<br>CONTROL UNIT ROM  ROM  ROM<br>0 1<br>0<br>TWF<br>ROM  ROM<br>SBU 0 addr 2 3 ROM   NTT constants<br>SBU 1 addr 1<br>CONSTANT MEMORY (CM) PHOENIX<br>**----- End of picture text -----**<br>


Figure 9: The top-level hardware architecture of Phoenix. Data and address signals are in black and red, respectively, with control signals omitted. 

## **4.2.1 Overall architecture** 

Figure 9 shows the Phoenix architecture. The datapath can be divided into four blocks: 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

18 

- `Processing element` contains two SuperButterfly units, SBU0 and SBU1. Generally, these work independently. The only case where they must work together is for PWM in the NTT. Then, `Control Unit` configures SBU0 in `PWM0` and SBU1 in `PWM1` , with the output of SBU0 rearranged for input to SB1. 

- `Polynomial Memories` divides the memory elements in two parts, _memory-up_ and _memory-down_ , which store the polynomial coefficients. The size of each part is determined by the maximum number of coefficients in each polynomial, packed into 32-bit words. 

- `Constant Memories` stores NTT Twiddle Factors and FAFFT constants. 

- `Coefficient Index` computes the index in memory of the coefficients consumed by `Processing element` . `INDEX-SBU 0` and `INDEX-SBU 1` contain registers to store the index-pairs of coefficients to be processed by SBU0 and SBU1, respectively. These are initialized by `INIT-ADDRESS` (according to the polynomial size, depending on the KEM) and incremented by `UPDATE-UNIT` . `BANK-DECODER` computes the memory addresses and instances of coefficients to be processed. 

The `Control Unit` orchestrates everything, sending control signals to the other blocks. Phoenix performs operations _in-place_ : the memory addresses used to read coefficients are also used to write results. The operations process different coefficient couples at each clock cycle; given the fixed latency of SuperButterfly, we use delayed data blocks managed by the `QUEUE` element to correctly synchronize `Processing element` results. 

## **4.2.2 Memories and memory access in PHOENIX** 

Our memory-access scheme uses the methodology of [MRW[+] 22] to address the different levels of parallelism in butterfly executions throughout FFT-like operations. From now on, we refer to a single memory instance as a memory bank, or BRAM. For a given array processing element of width _wP E_ and depth _dP E_ , we use _b_ := 2 _wP E_ banks to store polynomial coefficients. The scheduling algorithm of [MRW[+] 22] generates indexes of coefficients to be consumed by the _wP E × dP E_ processing element units. The authors of [MRW[+] 22] formally prove that this scheme guarantees 

- **conflict-free access** : the 2 _wP E_ coefficients consumed in the `Processing element` unit are read from 2 _wP E_ different banks in all FFT-like operations. This avoids simultaneously reading two or more coefficients from a single bank, though it also induces an overhead in the bank decoder: more coefficients implies more additions (and thus more resources) for memory-bank calculations. 

- **no data-dependency** : the coefficient scheduling algorithm ensures the absence of (read-after-write) data-dependency if _N ≤ bcP E_ , where _N_ is the number of input coefficients and _cP E_ is the latency for a butterfly from coefficient index generation until storage in memory. For example, if _dP E_ = 1, then the coefficient at `index` has 

**==> picture [315 x 21] intentionally omitted <==**

**==> picture [292 x 10] intentionally omitted <==**

In our case there are only two SBUs in `Processing element` , so _wP E_ = 2 and _b_ = 4. 

`Polynomial Memories` contains 8 Dual-Port BRAMs divided in two sets of four, one for each polynomial. Each BRAM has 1024 32-bit data words to handle the maximum polynomial size. For the FAFFT, one coefficient fits well in a word; for the NTT, the corresponding pair of even and odd index coefficients share a BRAM address. We detail the `Constant Memories` block below. 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

19 

## **4.2.3 NTT constant storage and FAFFT constant generation** 

Constants in embedded accelerators are typically precalculated and stored in a read-only memory. The NTT and FAFFT use different constant values, so they cannot be shared in common memory spaces. We therefore divide the `Constant Memories` block in two sections, one for each set of constants. 

For the NTT, the powers of the twiddle factors are often related and grouped within a single address, but data must be replicated when dealing with many PE instances in `Processing element` units. The incomplete NTT used in ML-KEM guarantees processing at least two butterflies per round. We take advantage of this to use two read-only memories (one for each SBU), each storing 256 pre-computed 16-bit twiddle factors (128 for `NTT` CT and 128 for `INTT` GS). 

The FAFFT requires a very high number of constants, so we precompute some (stored in four different read-only memories with a size of 16 x 32 bits) and recompute on the fly the others. Indeed, as we saw above, the FAFFT uses fast evaluation of expressions _sk_ ( _α_ ) = _βm/_ 2+ _i_ + _sk_ ( _γ_ ) where 1 _≤ i ≤ s_ and _γ_ ranges over all the points in _Vs_ . For HQC192 and HQC256 we have _s_ = 12, which means 4096 32-bit evaluation points; HQC128 has _s_ = 11. Storing all these points requires 32KB of memory, which is inconvenient for embedded applications. 

Instead, we store a subset of _V_ 12, and recompute the other elements as we require them. The simplest approach would be to store the basis to combine _β_ 0 _, . . . , β_ 11 and use a network of XORs to combine them. We reduce overhead using the so-called _four Russians_ method (M4R) [ADKF70]. First, we prepare 3 read-only memories _ROM_ 1 _, . . . , ROM_ 3 containing all of the elements in _V_ 4 = _⟨β_ 0 _, . . . , β_ 3 _⟩_ , _⟨β_ 4 _, . . . , β_ 7 _⟩_ , and _⟨β_ 8 _, . . . , β_ 11 _⟩_ , respectively. Splitting the binary vector _γ_ of _γ ∈ V_ 12 into 4-bit chunks, i.e. _γ_ = _γ_ 1 + _γ_ 2 + _γ_ 3 with each _γi ∈⟨β_ 4 _i−_ 4 _, . . . , β_ 4 _i−_ 1 _⟩_ , we have _γ_ = _ROM_ 1[ _γ_ 1] _⊕ ROM_ 2[ _γ_ 2] _⊕ ROM_ 2[ _γ_ 2], using the _γi_ as read memory addresses. To complete the evaluation of _sk_ ( _α_ ) in hardware we prepare another read-only memory, _ROM_ 0, containing the Cantor basis values _βm/_ 2+1 _, . . . , βm/_ 2+ _s_ . In total, this requires storing only 60 32-bit points. 

## **5 Implementing PHOENIX** 

We now describe the integration of Phoenix as a loosely-coupled accelerator in a real System-on-Chip (SoC) scenario, and measure performance results for polynomial multiplication. We will give further detail on integrating Phoenix to accelerate ML-KEM and HQC in §6 below. 

We implemented SuperButterfly and Phoenix using Verilog Hardware Description Language (HDL). We simulated, synthetized and implemented them using Vivado 2019.1 design suite on a Xilinx Zynq-7020 SoC ( `xc7z020clg400-1` ) device containing a dual-core ARM-A9 processor, a 512 MB DDR3L RAM and an Artix-7 based FPGA (13300 Slice, 140 32-Kib BRAM36 and 220 DSP), embedded on Zybo Z7-20 Diligent board. The critical path delay of Phoenix, imposed by the SuperButterfly unit, is 8ns; this corresponds to the maximum frequency of 125MHz. Only one CPU core is used and its clock frequency is set to 125MHz to be close as possible to a final system without clock domain crossing issue. To perform the profiling of the ML-KEM and HQC cryptosystems, we use the PQClean reference[2] [KSSW22] as a baseline software implementation, without using NEON instruction or any assembly optimizations. 

2https://github.com/PQClean/PQClean/ 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

20 

## **5.1 PHOENIX integration** 

We connect Phoenix to the internal communication bus of our Xilinx Zybo Z7-20 board using an AXI4-Lite hardware slave interface. Although this is not well-suited to highbandwidth communication compared to the full AXI4 protocol, it offers a lightweight solution for integrating accelerators. The full SoC, depicted in Figure 10, runs at a working frequency of 125MHz. 

**==> picture [349 x 206] intentionally omitted <==**

**----- Start of picture text -----**<br>
UART<br>Cortex ARM A9 DRAM Controller<br>JTAG<br>M S M S<br>32-bit AMBA Interconnect<br>S<br>cmd, dataIN<br>PHOENIX<br>AXI4-Lite<br>status, dataOUT<br>**----- End of picture text -----**<br>


Figure 10: Overall System-on-Chip FPGA integration of Phoenix. 

Phoenix supports the hardware operations listed in Table 6. The CPU configures Phoenix for these operations using the instruction set sketched in Figure 11. 

**==> picture [213 x 152] intentionally omitted <==**

**----- Start of picture text -----**<br>
9 config bits<br>1 [8:7] 6 [4:1] 0<br>addr<br>opcode<br>up/down<br>security level<br>algo<br>**----- End of picture text -----**<br>


Figure 11: The Phoenix instruction set. The configuration fields are labelled as follows: `algo` selects the cryptosystem (ML-KEM or HQC); `security level` specifies the security level of the chosen cryptosystem; `u/d` selects operation on _Memory-up_ , _Memory-down_ , or both; `addr` : defines the pre-compute starting memory address for ML-KEM operations involving polynomial error; and `opcode` : encodes the value of the operation to be executed. 

_Remark_ 2 _._ We note that in ML-KEM, all three security levels use the same polynomial size ( _n_ = 256, variable parameters are the vector and matrix dimensions: _k_ and _k × k_ ), so the execution of a single `NTT` , `INTT` , or `PWM` is the same for each level (see §6.1). In HQC, 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

21 

Table 6: Configurations of supported operations by opcode. The vector operations in the last columns support ML-KEM optimizations discussed in §6.1. 

|`Opcode`<br>Operation|`Opcode`<br>Operation|`Opcode`<br>Vector operation|
|---|---|---|
||||
|`0100`<br>`NTT`<br>`0001`<br>`INTT`<br>`0010`<br>`PWM`|`0100`<br>`FFT`LCH<br>`1100`<br>`FFT`LCH + `LOAD`<br>`0001`<br>`IFFT`LCH<br>`0010`<br>`PWM`LCH|`0101`<br>`kNTT`<br>`0011`<br>`kPWM`<br>`1010`<br>`kACCUMULATE`<br>`1011`<br>`kACCUMULATE` + `LOAD`|



on the other hand, HQC128 uses one polynomial size while HQC192 and HQC256 use another. 

## **5.2 Resource consumption** 

Table 7 breaks down resource consumption for our design (post-implementation), including the major submodules described in §4.2.1 and the four components of the SBU seen in §4.1. The most area-consuming module in Phoenix is the `Processing element` block, containing two SBU units and accounting for more than 65% of the LUTs and 76% of the FFs. Within each SBU, the major contribution is the agile modular multipler (COMP3), accounting for 66% of the total LUTs and 40% of the FFs. The remaining 60% of FFs are needed for data synchronization. Contrary to traditional NTT-based hardware design, our SBUs do not use DSP resources (this will be important for the area comparison in §5.4). COMP4 is the smallest design sub-block in the SBU, due to the absence of the division-by-2 feature. 

The `Polynomial Memories` block contains 8 BRAM, 4 in each sub-block. For the `Constant Memories` block, the two TWF ROM memory banks for ML-KEM require 2 _×_ 256 _×_ 16 bits, and are mapped into a half BRAM instance. The HQC constant memory banks only require 16 _×_ 32-bits ROMs each; these are not mapped into BRAMs, but rather implemented using LUTs and FFs. The 15% of FFs of Phoenix are used for data and address synchronization because of the internal latency in the SBU units. Finally, the `Control Unit` accounts for 16% of LUTs and 33 internal FSM states. This non-negligible percentage shows the complexity of this block in managing a variety of operations on polynomials of different lengths. 

The lack of existing FAFFT hardware implementations prevents us from measuring the real advantage in resource consumption of the integrated sharing strategy in Phoenix. Our new main objectives will be to demonstrate the performance alignment, as well as the overhead due to agility, of our accelerator compared with state-of-the-art FAFFT and NTT implementations. 

## **5.3 FAFFT performance with PHOENIX** 

In this section, we analyse the impact of Phoenix on a single polynomial multiplication, at all HQC security levels, using the FAFFT. Since there is no previous hardware acceleration of FAFFT to compare for comparison, we compare Phoenix against our own software-only FAFFT implementation running on the same target platform (described above), operating at 125MHz. Table 8 shows the improvement in a single FAFFT polynomial multiplication. 

As we can see, the operational steps targeted for the acceleration are `FFT` LCH, `PWM` LCH and `FFT` LCH. On these steps, Phoenix speeds up performance by two orders of magnitude. _Other_ represents clock cycles during a whole polynomial multiplication dedicated to operations that are not reported in Table 8. This cost is higher in HW-SW implementations due to memory transfer between the software and Phoenix. In the two case studies reported, the overall polynomial multiplication is accelerated by _3.3×_ and _3.5×_ respectively. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

22 

Table 7: Phoenix hardware resource counts for our Artix-7 implementation. `Datapath` includes the given components but also the internal data-selection hardware, performed by multiplexer-based components, that are not explicitly counted elsewhere. 

|**Module**|**LUT**<br>**FF**<br>**BRAM**<br>**DSP**|
|---|---|
|||
|`Control Unit`<br>`Datapath`<br>_|_ `Coeff memory address`<br>_|_ `Write address`<br>_|_ `Polynomial Memories`<br>_|_ `Constant Memories`<br>_⌊_`Processing element`<br>_⌊_1_×_ SuperButterfly<br>_|_ `COMP1`<br>_|_ `COMP2`<br>_|_ `COMP3`<br>_⌊_`COMP4`|826<br>131<br>0<br>0<br>4250<br>3952<br>8.5<br>0<br>238<br>128<br>0<br>0<br>30<br>612<br>0<br>0<br>0<br>0<br>8<br>0<br>37<br>98<br>0.5<br>0<br>3319<br>3114<br>0<br>0<br>1432<br>1380<br>0<br>0<br>160<br>0<br>0<br>0<br>176<br>0<br>0<br>0<br>948<br>548<br>0<br>0<br>148<br>0<br>0<br>0|
|||
|**Total** = `Control Unit` + `Datapath`|**5076**<br>**4083**<br>**8.5**<br>**0**|



The difference between the speedup of the single operations in FAFFT and the total polynomial multiplication is mostly due to the contribution of the software encoding and decoding operations of the polynomials: polynomial basis conversions are relatively inexpensive, because they only use XOR operations. 

Table 8: Performance impact of PHOENIX (Cycles, with speedup in italics) for a single FAFFT polynomial operation. Recall that HQC-128 multiplies polynomials of length _n <_ 2[15] , while HQC-192 and HQC-256 multiply polynomials of _n <_ 2[16] . SW refers to our own software-only implementation; HW-SW uses Phoenix. 

|**Function**|**HQC-128**<br>SW<br>HW-SW|**HQC-192/HQC-256**<br>SW<br>HW-SW|
|---|---|---|
||||
|2_×_ `BasisCvt`<br>2_×_ `Encode`<br>2_×_ `FFT`LCH<br>1_×_ `PWM`LCH<br>1_×_ `IFFT`LCH<br>1_×_ `Decode`<br>1_×_ `iBasisCvt`<br>_Other_|109,940<br>109,940<br>=<br>553,766<br>553,766<br>=<br>3,055,142<br>11,520<br>_256×_<br>252,073<br>1,102<br>_228×_<br>1,522,278<br>5,760<br>_264×_<br>764,880<br>764,880<br>=<br>98,576<br>98,576<br>=<br>1,029<br>332,353|235,096<br>235,096<br>=<br>1,110,258<br>1,110,258<br>=<br>6,651,156<br>25,316<br>_262×_<br>508,071<br>2,258<br>_225×_<br>3,308,442<br>12,658<br>_261×_<br>1,532,064<br>1,532,064<br>=<br>207,426<br>207,426<br>=<br>9,900<br>673,096|
||||
|**Total**|**6,357,684**<br>**1,877,897**<br>**_3.3_**_×_|**13,562,413**<br>**3,798,172**<br>**_3.5_**_×_|



## **5.4 NTT performance with PHOENIX** 

We now describe the impact of Phoenix on performance and resources for a single NTT operation. Unlike the AFFT, there have been many hardware implementations of the NTT operation for ML-KEM. We decided to compare Phoenix with implementations offering either low resource consumption [IUH22] [LTHW22] [BNAMK21], or the best overall cryptosystem performance [YMÖS21]. We note that all these implementations integrate 4 butterflies in their process element unit, which corresponds to our 2 SBUs. 

To compare resources, we use the _Slice Equivalent Cost_ (SEC) metric [LTHW22], which collects and weights various hardware resource costs in a single value. For our Artix-7 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

23 

FPGA platform, 

SEC := _⌊_ LUT _/_ 4 _⌋_ + _⌊_ FF _/_ 8 _⌋_ + 200 _·_ BRAM + 100 _·_ DSP _._ 

We also use the _Area-Time Product_ (ATP) metric, which multiplies a design’s area (in this case SEC) and latency, which is the cycle count divided by the maximum frequency. 

Table 9: Area and performance of PHOENIX on the Artix-7 FPGA and comparison with state-of-the-art solutions on the same FPGA. Reported execution time is referred to the execution the NTT and INTT operations. 

||**LUT**<br>**FF**<br>**BRAM**<br>**DSP**|**SEC**|**Time**<br>Cycles MHz<br>_µ_s|**ATP**<br>Value<br>Ratio|
|---|---|---|---|---|
|**This work**<br>[YMÖS21]<br>[IUH22]<br>[LTHW22]<br>[BNAMK21]|5076<br>4083<br>8.5<br>0<br>2543<br>792<br>9<br>4<br>904<br>811<br>2.5<br>4<br>1170<br>1164<br>2<br>4<br>801<br>717<br>2<br>4|3479<br>2935<br>1227<br>1638<br>1090|236<br>125<br>1.88<br>232<br>182<br>1.27<br>268<br>216<br>1.24<br>235<br>303<br>0.78<br>324<br>222<br>1.46|6569<br>_1_<br>3741<br>_÷1.8_<br>1522<br>_÷4.3_<br>1270<br>_÷5.2_<br>1590<br>_÷4.1_|



The results are shown in Table 9. As expected, compared with dedicated hardware NTT accelerators, hardware-agility implies a higher consumption of resources. For example: the high number of BRAMs in Phoenix is imposed by the need to compute with long HQC polynomials. The agility overhead of Phoenix is lower compared with [YMÖS21], due to the smaller difference in SEC: while Phoenix has 2 _×_ the LUTs and 5 _×_ 5 the FFs, it uses the same number of BRAMs and benefits from the absence of DSPs. The overhead of agility is worse when comparing Phoenix with lower-resource approaches, such as [IUH22][BNAMK21][LTHW22], with ATP overheads between 4.1 _×_ and 5.2 _×_ . It should be noted that this overhead is due to a singular feature of our work. Our hardware can be used to accelerate ML-KEM and HQC. 

Reassuringly, the time-overhead of agility is mild. Phoenix executes NTT and INTT operations with a number of cycles that is consistent with the current state of the art. However, as the lowest-frequency solution, Phoenix has the longest total execution time. For PWM, due to the cascading configuration of the two SBUs during the execution of this operation, the latency is 152 clocks (128 for processing and 24 for pipeline latency). Performances for ML-KEM `KeyGen` , `Encaps` and `Decaps` are reported in Section 6.3. 

## **6 An Agile SoC for ML-KEM and HQC with PHOENIX** 

We now look at the impact of Phoenix on KEM performance for ML-KEM and HQC. We optimize ML-KEM integration using the internal resources of our design in §6.1. We show how to improve HQC performance using an alternative FAFFT-domain data representation in §6.1.2. Section 6.2 gives results for HQC, providing a complete overview between the pure-software and the hardware-software co-design scenarios. Additionally, we describe their comparison using the optimization proposed in §6.1.2. We give results for ML-KEM in §6.3, showing the speedup with respect to the reference version. Furthermore we analyze the Phoenix positioning in the co-design and fully in the hardware state of the art ecosystem, highlighting the impact of our proposed agile solution. 

## **6.1 Optimizing KEM integrations** 

Integrating Phoenix in HQC is straightforward. As we saw in §3.4.3, the FFT is a monolithic operation divided into a sequence of subroutines. Polynomials _A_ and _B_ are converted to the new polynomial basis and encoded, then offloaded to the accelerator to speed up the subsequent `FFT` LCH, `PWM` LCH, and `IFFT` LCH. Phoenix can simultaneously perform an 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

24 

`FFT` LCH and an offload to reduce the latency of the entire polynomial multiplication, but these two operations must be performed separately between the _memory-up_ (MU) and _memory-down_ (MD) blocks in order to be parallelized. To do this, we offload the first polynomial _A_ into MU, perform `FFT` LCH on _A_ and, at the same time, we offload the second polynomial _B_ into MD. After the second `FFT` LCH operation on _B_ , `PWM` LCH is done and the result, stored in MU, is interpolated back with `IFFT` LCH. Finally, the output is transferred from MU to the processor’s main memory, where it is decoded and converted back to the original polynomial basis. 

Integration in ML-KEM is different, for two reasons: first, keys are stored in the NTT domain, and second, we must multiply matrices and vectors of polynomials. This does not favour a monolithic hardware-based operation integration, so the overall acceleration factor is heavily influenced by continuous interoperability and data exchange between hardware and software. We mitigate this with vector operations for Phoenix in §6.1.1. (For HQC, we optimise at the level of data representation instead, without adding new hardware operations to Phoenix.) 

## **6.1.1 Array-Array Polynomial Multiplication in ML-KEM** 

ˆ ˆ Given two _k_ -vectors **a** 0 = ( _a_ 00 _, . . . ,_ ˆ _a_ 0 _k−_ 1) and **y** = ( _y_ 0 _, . . . , yk−_ 1) of polynomials, with the elements of **a** ˆ0 in the NTT-domain (and _k_ depending on the ML-KEM security level), we can compute _t_ 0 = **a** 0 _·_ **y** as 

**==> picture [235 x 13] intentionally omitted <==**

ˆ ˆ which first computes the polynomial vector ˆ **y** = _NTT_ ( **y** ), then the scalar product _t_[ˆ] 0 = **a** 0 _·_ **y** using PWM, before interpolating it back in the original polynomial domain to get the result _t_ 0. In fact, this scalar product is the sum of all the PWM operations between corresponding elements of the input vectors: 

**==> picture [269 x 20] intentionally omitted <==**

This sum corresponds to the _accumulation_ phase of all the temporary PWM results. 

In a traditional NTT integration approach, the accumulation phase is performed in software with PWM in hardware. In this scenario, an NTT accelerator receives the polynomial pair to be multiplied and stores back the result, with this process repeated _k_ times. 

We can do better in Phoenix by exploiting the large available amount of memory (imposed by the long polynomials in HQC) to perform polynomial vector multiplication. To this end, we add three further operations in the `Control Unit` of our accelerator: `kNTT` , `kPWM` and `kACCUMULATE` , together with some support functions at the hardware-software interface level to read and write data structures such as polynomials and polynomial vectors. The opcodes for these “vector” operations appeared in Table 6 above. 

Given two polynomial vectors already offloaded in the Phoenix memories, we can use these vector instructions to compute entirely in hardware at each ML-KEM security level (equation (11)). For example, given a matrix **A**[ˆ] and a polynomial _k_ -vector **y** ˆ, the matrix-vector product **t** = **A**[ˆ] **y** can be computed using _k_ vector-vector polynomial multiplications: 

**==> picture [141 x 31] intentionally omitted <==**

## **6.1.2 Alternative data representation for HQC** 

We can optimize the use of AFFT in HQC by changing the data representation of the private and public keys to the FAFFT domain. (This is compatible with any HQC 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

25 

implementation using the FAFFT, and in particular with Phoenix, where it requires no new instructions.) This alternative data representation doubles the public key size, but the efficiency benefits should still make this approach interesting for applications where public keys are rarely transmitted, e.g. with static or pre-shared public keys. 

We define a procedure `FAFFT` _f_ ( _·_ ) that converts to `novelpoly` , and encodes and evaluates an input polynomial using the new evaluation point sets imposed by Frobenius map. The inverse procedure `FAFFT` _[−] f_[1][(] _[·]_[)][interpolates][back,][decodes,][and][converts][back][to][the][original] basis. Recall that in HQC, the secret key is ( _x, y_ ) and the public key is _pk_ = ( _h, s_ = _x_ + _h·y_ ). If we precompute _pk_ = ( _h_[¨] = `FAFFT` _f_ ( _h_ ) _,_ ¨ _s_ = `FAFFT` _f_ ( _s_ )), then we can save two `FAFFT` _f_ ( _·_ )s in the _Encrypt_ function in the underlying PKE scheme: 

**==> picture [285 x 32] intentionally omitted <==**

¨ Precomputing _y_ = `FAFFT` _f_ ( _y_ ) saves a further `FAFFT` _f_ ( _·_ ) in the _Decrypt_ function: 

**==> picture [291 x 14] intentionally omitted <==**

## **6.2 HQC with PHOENIX** 

Table 10 shows the integration results for HQC-128, HQC-192, and HQC-256 using FAFFT for polynomial multiplication. We use the PQClean reference as a baseline software implementation, as there is no state of the art that includes hardware implementations on the FAFFT applied to HQC. We consider “standard” HQC (compatible with the NIST Round-4 submission specification), and “optimized HQC” proposed in §6.1.2 (with keys in the AFFT domain). Since the “optimized” version targets applications with long-term keys, we only report times for `Encaps` and `Decaps` . 

For standard HQC, using the FAFFT in software already gives a substantial improvement: for example, `Encaps` for HQC-128, -192, and -256 runs 3.8, 5.2, and 8.2 times faster, respectively. Integrating Phoenix brings further improvements: looking at `Encaps` again, the HW-SW codesign runs HQC-128, -192, and -256 9.0, 12.6, and 16.7 times faster, respectively. For “optimized” HQC, we can see further improvements in the performance of `Encaps` and `Decaps` , both in the software and with Phoenix. 

Table 10: Comparison of KEM performance, in number of clock cycles: PQClean reference implementation (SW) vs. this work (SW-based FAFFT multiplication, and HW-SW using Phoenix). The _optimized_ version of HQC is defined in §6.1.2. Values are in MCycles, with speedups over baseline implementation in italics. 

||_Standard_ HQC<br>**Ref.**<br>**FAFFT**<br>**PHOENIX**|_Optimized_ HQC<br>**FAFFT**<br>**PHOENIX**|
|---|---|---|
|**HQC-128**<br>`KeyGen`<br>`Encaps`<br>`Decaps`|28.9<br>7.3<br>_3.9×_<br>2.8<br>_10.3×_<br>58.7<br>15.5<br>_3.8×_<br>6.5<br>_9.0×_<br>91.9<br>27.0<br>_3.4×_<br>13.6<br>_6.8×_|-<br>_-_<br>-<br>_-_<br>9.6<br>_6.1×_<br>5.1<br>_11.5×_<br>20.6<br>_4.5×_<br>13.1<br>_7.0×_|
|**HQC-192**<br>`KeyGen`<br>`Encaps`<br>`Decaps`|85.1<br>15.8<br>_5.4×_<br>6.0<br>_14.2×_<br>171.9<br>33.3<br>_5.2×_<br>13.7<br>_12.6×_<br>262.4<br>54.4<br>_4.8×_<br>25.2<br>_10.4×_|-<br>_-_<br>-<br>_-_<br>20.7<br>_8.3×_<br>10.9<br>_15.8×_<br>39.9<br>_6.6×_<br>23.7<br>_11.1×_|
|**HQC-256**<br>`KeyGen`<br>`Encaps`<br>`Decaps`|155.8<br>17.7<br>_8.8×_<br>7.9<br>_19.7×_<br>314.6<br>38.4<br>_8.2×_<br>18.8<br>_16.7×_<br>483.4<br>69.1<br>_7.0×_<br>39.8<br>_12.1×_|-<br>_-_<br>-<br>_-_<br>25.5<br>_12.3×_<br>15.6<br>_20.2×_<br>52.4<br>_9.2×_<br>36.1<br>_13.4×_|



We emphasize that all of these results include significant overhead from the slow data exchange between the CPU and our loosely-coupled accelerator, with long polynomials pushed through an AXI-4 Lite interface that does not offer high-performance data 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

26 

transmission. A better communication interface should further improve the results in Table 10. 

## **6.3 ML-KEM with PHOENIX** 

Table 11 presents our results for Phoenix integration in ML-KEM. In order to compare the obtained results, we selected, from the current state-of-the-art, two significant hardwaresoftware co-design solutions: [FSS20] and [WZZ[+] 24]. 

It is worth pointing out that a direct comparison of cycle counts for the three implementations is not fair: each was run on a different architecture and board. In particular, both of the other system-on-chip solutions are based on the RISC-V microprocessor architecture; there were no public ML-KEM implementations targeting our development board (i.e., based on the ARM architecture). For this reason, Table 11 shows not only raw cycle counts, but also the acceleration of each HW-SW solution with respect to its own SW baseline. This offers a fairer comparison of the acceleration capability of each solution. 

Table 11: State-of-the-art comparison for NTT acceleration in ML-KEM HW-SW codesign implementations. Clock cycles are reported for HW-SW, with speedups over the respective SW baselines in italics. 

|SW baselines in italics.|||
|---|---|---|
||**Device**|`KeyGen`<br>`Encaps`<br>`Decaps`|
|**ML-KEM 512**<br>[FSS20]<br>**This Work**<br>[WZZ+24]|PULPino<br>Zybo-Z7-20<br>PolarFire|939,932 _×1.21_<br>1,223,887 _×1.26_<br>1,051,003 _×1.45_<br>564,189 _×1.14_<br>570,438 _×1.30_<br>639,403 _×1.38_<br>326,983 _×1.91_<br>415,496 _×2.01_<br>394,661 _×2.42_|
|**ML-KEM 768**<br>[FSS20]<br>**This Work**<br>[WZZ+24]|PULPino<br>Zybo-Z7-20<br>PolarFire|1,768,400 _×1.19_<br>2,138,810 _×1.23_<br>1,889,930 _×1.36_<br>916,828 _×1.15_<br>954,992 _×1.25_<br>1,048,867 _×1.33_<br>536,213 _×1.92_<br>671,082 _×1.98_<br>639,024 _×2.32_|
|**ML-KEM 1024**<br>[FSS20]<br>**This Work**<br>[WZZ+24]|PULPino<br>Zybo-Z7-20<br>PolarFire|2,856,302 _×1.18_<br>3,312,957 _×1.21_<br>2,989,896 _×1.32_<br>1,450,164 _×1.14_<br>1,492,047 _×1.22_<br>1,614,779 _×1.28_<br>844,008 _×1.89_<br>1,015,251 _×1.91_<br>972,598 _×2.18_|



Phoenix accelerates different ML-KEM functions by different factors: `Encaps` improves more than `KeyGen` , and `Decaps` improves even more. While the vector-based optimisations in §6.1 allow a better acceleration of polynomial multiplication with respect to state-ofthe-art NTT accelerators, this is not immediately evident from Table 11, due to the higher communication latency imposed by the slow bus protocol on our board. Proof of this is provided by the slightly greater speedup for `Decaps` . In particular, the `PKE.Decrypt` function (see 2.1) is essentially one vector-based polynomial multiplication, which is precisely the operation targeted by our accelerator, while the `PKE.KeyGen` and `PKE.Encrypt` functions can be seen as a series of vector-based multiplications with data transfer between each. Even considering these limitations, the acceleration offered by Phoenix is similar (and even slightly better in some cases) to that of the _tightly-coupled_[3] solution in [FSS20]. 

When comparing our proposal to [WZZ[+] 24], we see that Phoenix shows a lower acceleration factor. For context, we note that the authors of [WZZ[+] 24] propose assemblybased optimizations for the Keccak functions coupled with the NTT hardware acceleration. This explains some of the difference with our solution. 

## **7 Conclusion and Further works** 

In this paper we introduce Phoenix, a crypto-agile loosely-coupled hardware accelerator for ML-KEM and HQC, aiming to demonstrate performance improvements and resource 

> 3 _Tightly-coupled_ hardware accelerators operate close to the CPU, thus offering reduced data transfer between processor and hardware unit. This allows a high-performance solution, suitable for embedded systems with resource contraints, like RISC-V-based designs. 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

27 

savings compared with non-agile approaches to the individual cryptosystems. At its heart is a new configurable hardware design, SuperButterfly, providing an efficient hardware sharing strategy between completely different mathematical structures to speed FFT-based polynomial multiplication operations in ML-KEM and HQC, namely the NTT and the FAFFT. 

The use of the FAFFT in HQC is innovative: our software implementation is the first of its kind. Not only does it improve performance, even in software, but it is also the key to agility. (It also permits an interesting optimization where keys are stored and transmitted in the FAFFT domain; since this trades faster speeds for larger keys, it is better-suited to applications with static or pre-shared public keys.) 

We have shown that integrating Phoenix yields a significant overall speedup of HQC, and ML-KEM performance close to the state-of-the-art. Comparing Phoenix’s resource consumption with efficient NTT-focused hardware solutions, we see that agility (i.e., simultaneously supporting HQC) inevitably adds an overhead of between 1.8 and 5.2 _×_ , depending on the reference implementation. For HQC, the lack of competing state-ofthe-art hardware FAFFT implementations targeting HQC makes it hard to fully assess the real impact of Phoenix in this arena, but we can still show strong performance improvements—and there is also value in being the first of its kind. 

Phoenix could also accelerate polynomial multiplication in other lattice- or code-based cryptosystems, thus offering even more general _lattice-code_ crypto-agility. For example, Phoenix could be used in ML-DSA [Nat24a], or any other cryptosystem that uses the NTT, by slightly modifying the internal structure of our SuperButterfly. Indeed, the flexibility design of SuperButterfly could be extended to add other butterfly structures, thus accelerating another FFT-based bottleneck operation contained in HQC’s Reed–Muller decoder: the _Fast Hadamard Transform_ . 

## **Acknowledgment** 

This work was supported by the French National Agency within the framework of the “France 2030” program (ANR-10-AIRT-05) and it is also financially supported by the Defense Innovation Agency (AID) from the French Ministry of the Armed Forces. 

## **References** 

[ABPS24] Francesco Antognazza, Alessandro Barenghi, Gerardo Pelosi, and Ruggero Susella. A high efficiency hardware design for the post-quantum KEM HQC. In _2024 IEEE International Symposium on Hardware Oriented Security and Trust (HOST)_ , pages 431–441. IEEE, 2024. [ADKF70] V.L. Arlazov, Y.A. Dinitz, M.A. Kronrod, and I.A. Faradzhev. On economical construction of the transitive closure of an oriented graph. _Dokl. Akad. Nauk SSR_ , 194:487–488, 1970. [AG25] Ciadoux P Cooper D Dang Q Dang T Kelsey J Lichtinger J Liu YK Miller C Moody D Peralta R Perlner R Robinson A Silberg H Smith-Tone D Waller Alagic G, Bros M. (2025) status report on the fourth round of the nist post-quantum cryptography standardization process. 2025. `https://doi.org/10.6028/NIST.IR.8545` . 

[AMAB[+] 24] Carlos Aguilar Melchor, Nicolas Aragon, Slim Bettaieb, Loïc Bidoux, Olivier Blazy, Jurjen Bos, Jean-Christophe Deneuville, Arnaud Dion, Philippe Gaborit, Jérôme Lacan, Edoardo Persichetti, Jean-Marc Robert, Pascal Véron, and Gilles Zémor. HQC (Hamming Quasi-Cyclic), 2024. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

28 

- [AMDD[+] 22] Carlos Aguilar-Melchor, Jean-Christophe Deneuville, Arnaud Dion, James Howe, Romain Malmain, Vincent Migliore, Mamuri Nawan, and Kashif Nawaz. Towards automating cryptographic hardware implementations: a case study of HQC. In _Code-Based Cryptography Workshop_ , pages 62–76. Springer, 2022. 

- [AMI[+] 22] Aikata Aikata, Ahmet Can Mert, Malik Imran, Samuel Pagliarini, and Sujoy Sinha Roy. KaLi: A crystal for post-quantum security using Kyber and Dilithium. _IEEE Transactions on Circuits and Systems I: Regular Papers_ , 70(2):747–758, 2022. 

- [AMR23] Harish Prasad Allam, Suraj Mandal, and Debapriya Basu Roy. A comparative analysis between karatsuba, toom-cook and ntt multiplier for polynomial multiplication in ntru on fpga. In _2023 Asian Hardware Oriented Security and Trust Symposium (AsianHOST)_ , pages 1–6. IEEE, 2023. 

- [ASW[+] 23] Nouri Alnahawi, Nicolai Schmitt, Alexander Wiesmaier, Andreas Heinemann, and Tobias Grasmeyer. On the state of crypto-agility. Cryptology ePrint Archive, Paper 2023/487, 2023. 

- [BC14] Daniel J. Bernstein and Tung Chou. Faster binary-field multiplication and faster binary-field MACs. In _International Conference on Selected Areas in Cryptography_ , pages 92–111. Springer, 2014. 

- [BCC[+] 25] Elaine Barker, Lily Chen, David Cooper, Dustin Moody, Andrew Regenscheid, Murugiah Souppaya, William Newhouse, Russ Housley, and Sean Turner. Considerations for achieving cryptographic agility: Strategies and practices (draft). Technical report, US Department of Commerce, 2025. 

- [BNAMK21] Mojtaba Bisheh-Niasar, Reza Azarderakhsh, and Mehran MozaffariKermani. High-speed NTT-based polynomial multiplication accelerator for post-quantum cryptography. In _2021 IEEE 28th symposium on computer arithmetic (ARITH)_ , pages 94–101. IEEE, 2021. 

- [BUC19] Utsav Banerjee, Tenzin S. Ukyab, and Anantha P. Chandrakasan. Sapphire: A configurable crypto-processor for post-quantum lattice-based protocols. _arXiv preprint arXiv:1910.07557_ , 2019. 

- [Can89] David G Cantor. On arithmetical algorithms over finite fields. _Journal of Combinatorial Theory, Series A_ , 50(2):285–300, 1989. 

- [CCK[+] 17] Ming-Shing Chen, Chen-Mou Cheng, Po-Chun Kuo, Wen-Ding Li, and Bo-Yin Yang. Faster multiplication for long binary polynomials. _arXiv preprint arXiv:1708.09746_ , 2017. 

- [CCK[+] 18] Ming-Shing Chen, Chen-Mou Cheng, Po-Chun Kuo, Wen-Ding Li, and Bo-Yin Yang. Multiplying boolean polynomials with Frobenius partitions in additive Fast Fourier Transform. _arXiv preprint arXiv:1803.11301_ , 2018. 

- [CCK21] Ming-Shing Chen, Tung Chou, and Markus Krausz. Optimizing BIKE for the Intel Haswell and ARM Cortex-M4. _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pages 97–124, 2021. 

- [CLRS22] Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, and Clifford Stein. _Introduction to algorithms_ . MIT press, 2022. 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

29 

- [DMSS24] Stefano Di Matteo, Ivan Sarno, and Sergio Saponara. CRYPHTOR: A memory-unified NTT-based hardware accelerator for post-quantum CRYSTALS algorithms. _IEEE Access_ , 12:25501–25511, 2024. 

- [DRA[+] 24] Moody D., Perlner R., Regenscheid A., Robinson A., and Cooper D. Transition to post-quantum cryptography standards. Technical Report NIST Internal Report (IR) NIST IR 8547, National Institute of Standards and Technology, Gaithersburg, MD, 2024. `https://doi.org/10.6028/NIST. IR.8547.ipd` . 

- [DXN[+] 23] Sanjay Deshpande, Chuanqi Xu, Mamuri Nawan, Kashif Nawaz, and Jakub Szefer. Fast and efficient hardware implementation of HQC. In _International Conference on Selected Areas in Cryptography_ , pages 297–321. Springer, 2023. 

- [FO99] Eiichiro Fujisaki and Tatsuaki Okamoto. Secure integration of asymmetric and symmetric encryption schemes. In Michael Wiener, editor, _Advances in Cryptology — CRYPTO’ 99_ , pages 537–554, Berlin, Heidelberg, 1999. Springer Berlin Heidelberg. 

- [FSS20] Tim Fritzmann, Georg Sigl, and Johanna Sepúlveda. RISQ-V: Tightly coupled RISC-V accelerators for post-quantum cryptography. _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pages 239–280, 2020. 

- [GM10] Shuhong Gao and Todd Mateer. Additive Fast Fourier Transforms over finite fields. _IEEE Transactions on Information Theory_ , 56(12):6265–6272, 2010. 

- [HHK17] Dennis Hofheinz, Kathrin Hövelmanns, and Eike Kiltz. A modular analysis of the Fujisaki–Okamoto transformation. In _Theory of Cryptography Conference_ , pages 341–371. Springer, 2017. 

- [HTB[+] 24] Pengzhou He, Yazheng Tu, Tianyou Bao, Çetin Çetin Koç, and Jiafeng Xie. HSPA: High-throughput sparse polynomial multiplication for code-based post-quantum cryptography. _ACM Transactions on Embedded Computing Systems_ , 2024. 

- [HTX23] Pengzhou He, Yazheng Tu, and Jiafeng Xie. LOCS: Low-latency and constant-timing implementation of fixed-weight sampler for HQC. In _2023 IEEE International Symposium on Circuits and Systems (ISCAS)_ , pages 1–5. IEEE, 2023. 

- [IUH22] Yuma Itabashi, Rei Ueno, and Naofumi Homma. Efficient modular polynomial multiplier for NTT accelerator of Crystals-Kyber. In _2022 25th Euromicro Conference on Digital System Design (DSD)_ , pages 528–533. IEEE, 2022. 

- [KMK[+] 24] ByungJun Kim, Han-Gyeol Mun, Shinwoong Kim, JongMin Lee, and Jaeyoon Sim. A 1.03 MOPS/W lattice-based post-quantum cryptography processor for IoT devices. _JOURNAL OF SEMICONDUCTOR TECHNOLOGY AND SCIENCE_ , 24(1):55–61, 2024. 

- [KML[+] 24] ByungJun Kim, Han-Gyeol Mun, Kyeong-Jun Lee, Jeong-Min Woo, Kiseo Kang, Hyunwoo Son, and Jae-Yoon Sim. A 243 KOPS/W crypto-processor supporting homomorphic encryption and post-quantum cryptography for IoT devices. In _2024 IEEE European Solid-State Electronics Research Conference (ESSERC)_ , pages 468–471. IEEE, 2024. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

30 

- [KMMM23] Kristjane Koleci, Paolo Mazzetti, Maurizio Martina, and Guido Masera. A flexible NTT-based multiplier for post-quantum cryptography. _IEEE Access_ , 11:3338–3351, 2023. 

- [KSFS24] Patrick Karl, Jonas Schupp, Tim Fritzmann, and Georg Sigl. Post-quantum signatures on RISC-V with hardware acceleration. _ACM Transactions on Embedded Computing Systems_ , 23(2):1–23, 2024. 

- [KSSW22] Matthias J. Kannwischer, Peter Schwabe, Douglas Stebila, and Thom Wiggers. Improving software quality in cryptography standardization projects. In _IEEE European Symposium on Security and Privacy, EuroS&P 2022 - Workshops, Genoa, Italy, June 6-10, 2022_ , pages 19–30, Los Alamitos, CA, USA, 2022. IEEE Computer Society. 

- [LANH16] Sian-Jheng Lin, Tareq Y Al-Naffouri, and Yunghsiang S Han. FFT algorithm for binary extension finite fields and its application to Reed–Solomon codes. _IEEE Transactions on Information Theory_ , 62(10):5343–5358, 2016. 

- [LCK[+] 18] Wen-Ding Li, Ming-Shing Chen, Po-Chun Kuo, Chen-Mou Cheng, and Bo-Yin Yang. Frobenius additive Fast Fourier Transform. In _Proceedings of the 2018 ACM International Symposium on Symbolic and Algebraic Computation_ , pages 263–270, 2018. 

- [LGH[+] 24] Daniel Loebenberger, Stefan-Lukas Gazdag, Daniel Herzinger, Eduard Hirsch, and Christian Näther. Formalizing the cryptographic migration problem. _CoRR_ , abs/2408.05997, 2024. 

- [LS15] Adeline Langlois and Damien Stehlé. Worst-case to average-case reductions for module lattices. _Designs, Codes and Cryptography_ , 75(3):565–599, 2015. 

- [LST[+] 23] Chen Li, Suwen Song, Jing Tian, Zhongfeng Wang, and Çetin Kaya Koç. An efficient hardware design for fast implementation of HQC. In _2023 IEEE 36th International System-on-Chip Conference (SOCC)_ , pages 1–6. IEEE, 2023. 

- [LTHW22] Minghao Li, Jing Tian, Xiao Hu, and Zhongfeng Wang. Reconfigurable and high-efficiency polynomial multiplication accelerator for Crystals-Kyber. _IEEE Transactions on Computer-Aided Design of Integrated Circuits and Systems_ , 42(8):2540–2551, 2022. 

- [LZL[+] 24] Jiahao Lu, Jiaming Zhang, Zhixiang Luo, Aobo Li, Tianze Huang, Dongsheng Liu, and Chi Cheng. An efficient and configurable hardware architecture of polynomial modular operation for CRYSTALS-Kyber and Dilithium. In _2024 IEEE 67th International Midwest Symposium on Circuits and Systems (MWSCAS)_ , pages 29–32. IEEE, 2024. 

- [MBB[+] 23] Konstantina Miteloudi, Joppe W Bos, Olivier Bronchain, Björn Fay, and Joost Renes. PQ.V.ALU.E: Post-quantum RISC-V custom ALU extensions on Dilithium and Kyber. In _International Conference on Smart Card Research and Advanced Applications_ , pages 190–209. Springer, 2023. 

- [MRW[+] 22] Jianan Mu, Yi Ren, Wen Wang, Yizhong Hu, Shuai Chen, Chip-Hong Chang, Junfeng Fan, Jing Ye, Yuan Cao, Huawei Li, et al. Scalable and conflict-free NTT hardware accelerator design: Methodology, proof, and implementation. _IEEE Transactions on Computer-Aided Design of Integrated Circuits and Systems_ , 42(5):1504–1517, 2022. 

Ras, Loiseau, Carmona, Pontié, Renault, Smith, Valea 

31 

- [Nat15] National Institute of Standards and Technology. SHA-3 standard: Permutation-based hash and extendable-output functions. Technical Report Federal Information Processing Standards Publications (FIPS PUBS) 202, August 4, 2015, U.S. Department of Commerce, Washington, D.C., 2015. 

- [Nat24a] National Institute of Standards and Technology. Module-lattice-based digital signature standard. Technical Report Federal Information Processing Standards Publications (FIPS PUBS) 204, August 13, 2024, U.S. Department of Commerce, Washington, D.C., 2024. 

- [Nat24b] National Institute of Standards and Technology. Module-lattice-based keyencapsulation mechanism standard. Technical Report Federal Information Processing Standards Publications (FIPS PUBS) 203, August 13, 2024, U.S. Department of Commerce, Washington, D.C., 2024. 

- [NKDNPH24] Trong-Hung Nguyen, Binh Kieu-Do-Nguyen, Cong-Kha Pham, and TrongThuc Hoang. High-speed NTT accelerator for CRYSTAL-Kyber and CRYSTAL-Dilithium. _IEEE Access_ , 2024. 

- [Reg09] Oded Regev. On lattices, learning with errors, random linear codes, and cryptography. _Journal of the ACM (JACM)_ , 56(6):1–40, 2009. 

- [SFW23] Maximilian Schöffel, Johannes Feldmann, and Norbert Wehn. Efficient hardware implementation of constant time sampling for HQC. _arXiv preprint arXiv:2309.16493_ , 2023. 

- [SKN[+] 24] Jonas Schupp, Patrick Karl, Jens Nöpel, Alexander Hepp, Tim Music, and Georg Sigl. RISC-V triplet: Tapeouts for security applications. In _2024 IEEE Nordic Circuits and Systems Conference (NorCAS)_ , pages 1–6. IEEE, 2024. 

- [THCX24] Yazheng Tu, Pengzhou He, Chip-Hong Chang, and Jiafeng Xie. LTE: Lightweight and time-efficient hardware encoder for post-quantum scheme HQC. _IEEE Computer Architecture Letters_ , 2024. 

- [THKX23] Yazheng Tu, Pengzhou He, Çetin Kaya Koç, and Jiafeng Xie. LEAP: Lightweight and efficient accelerator for sparse polynomial multiplication of HQC. _IEEE Transactions on Very Large Scale Integration (VLSI) Systems_ , 31(6):892–896, 2023. 

- [vDHL17] Joris van Der Hoeven and Robin Larrieu. The Frobenius FFT. In _Proceedings of the 2017 ACM on International Symposium on Symbolic and Algebraic Computation_ , pages 437–444, 2017. 

- [VZGG03] Joachim Von Zur Gathen and Jürgen Gerhard. _Modern computer algebra_ . Cambridge university press, 2003. 

- [WZZ[+] 24] Tengfei Wang, Chi Zhang, Xiaolin Zhang, Dawu Gu, and Pei Cao. Optimized hardware-software co-design for Kyber and Dilithium on RISC-V SoC FPGA. _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , 2024(3):99–135, 2024. 

- [XL21] Yufei Xing and Shuguo Li. A compact hardware implementation of CCAsecure key exchange mechanism CRYSTALS-KYBER on FPGA. _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pages 328–356, 2021. 

PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC 

32 

- [YMÖS21] Ferhat Yaman, Ahmet Can Mert, Erdinç Öztürk, and Erkay Savaş. A hardware accelerator for polynomial multiplication operation of CRYSTALSKYBER PQC scheme. In _2021 Design, Automation & Test in Europe Conference & Exhibition (DATE)_ , pages 1020–1025. IEEE, 2021. 

- [YSZ[+] 24] Zewen Ye, Ruibing Song, Hao Zhang, Donglong Chen, Ray Chak-Chung Cheung, and Kejie Huang. A highly-efficient lattice-based post-quantum cryptography processor for IoT applications. _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , 2024(2):130–153, 2024. 

- [ZLL[+] 21] Cong Zhang, Dongsheng Liu, Xingjie Liu, Xuecheng Zou, Guangda Niu, Bo Liu, and Quming Jiang. Towards efficient hardware implementation of NTT for Kyber on FPGAs. In _2021 IEEE international symposium on circuits and systems (ISCAS)_ , pages 1–5. IEEE, 2021. 

- [ZZL[+] 22] Yihong Zhu, Wenping Zhu, Chongyang Li, Min Zhu, Chenchen Deng, Chen Chen, Shuying Yin, Shouyi Yin, Shaojun Wei, and Leibo Liu. RePQC: A 3.4uJ/Op 48-kOPS post-quantum crypto-processor for multiple-mathematical problems. _IEEE Journal of Solid-State Circuits_ , 58(1):124–140, 2022. 

- [ZZO[+] 24] Yihong Zhu, Wenping Zhu, Yi Ouyang, Junwen Sun, Qi Zhao, Min Zhu, Jinjiang Yang, Chen Chen, Qichao Tao, Hanning Wang, et al. PQPU: A 4.4- _µ_ J/Op 69.4-kOPS agile post-quantum crypto-processor across multiple mathematical problems. _IEEE Journal of Solid-State Circuits_ , 2024. 

