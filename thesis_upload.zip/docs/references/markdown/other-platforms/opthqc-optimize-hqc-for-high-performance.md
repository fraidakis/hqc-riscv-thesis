---
source_pdf: docs/references/pdf/other-platforms/OptHQC Optimize HQC for High-Performance.pdf
converted_at: 2026-05-29 22:40
conversion_time: 1.9s
tool: pymupdf4llm
---

## OptHQC: Optimize HQC for High-Performance Post-Quantum Cryptography 

## Ben Dong, Hui Feng, Qian Wang 

Department of Electrical Engineering, University of California, Merced, CA, USA cdong12@ucmerced.edu, hfeng9@ucmerced.edu, qianwang@ucmerced.edu 

_**Abstract**_ **—As post-quantum cryptography (PQC) becomes increasingly critical for securing future communication systems, the performance overhead introduced by quantum-resistant algorithms presents a major computing challenge. HQC (Hamming Quasi-Cyclic) is a newly standardized code-based PQC scheme designed to replace classical key exchange methods. In this paper, we propose OptHQC, an optimized implementation of the HQC scheme to deliver high-performance cryptographic operations. Our approach provides a comprehensive analysis of each computational blocks in HQC and introduces optimizations across all three stages: key generation, encryption, and decryption. We first exploit data-level sparsity in vector multiplication to accelerate polynomial operations during vector generation. We then leverage instruction-level acceleration (e.g., AVX2) in hash computation to further improve performance. Last, we transform multiplication into lookup table indexing and optimize memory access patterns in syndrome computation and error vector recovery, which are the most computationally intensive operations in HQC. Overall, OptHQC achieves an average 55% speedup over the reference HQC implementation on CPU. Keywords: Post-quantum Cryptography, HQC, Optimization, Parallelism** 

## I. INTRODUCTION 

With the computational superiority of the quantum computer, the currently deployed cryptographic algorithms based on the integer factorization problem (e.g., RSA), the discrete logarithm problem (e.g., DH), or the elliptic-curve discrete logarithm problem (e.g., ECC) will all be broken in polynomial time. Therefore, it is crucial to update and upgrade the current algorithms to withstand quantum attacks. The National Institute of Standards and Technology (NIST) has initiated the standardization process to promote newly designed post-quantum cryptographic algorithms [1]. The selected PQC schemes include CRYSTALS-Kyber [2], CRYSTALS-Dilithium [3], and Falcon [4], which are lattice-based, and SPHINCS[+] [5], which is hash-based. Most recently, NIST finalized HQC as the only code-based scheme in the PQC standards [6]. 

While HQC diversifies the KEM portfolio, its computational cost is dominated by several compute-intensive components: (i) the concatenated decoding stage, where a byteparallel Reed–Muller decoder feeds into a Reed–Solomon decoder, which largely determines the decoding latency; (ii) the SHAKE-based seed expansion and domain-separated hashing operations used for randomness generation and key derivation; and (iii) constant-time dense-by-sparse vector and polynomial multiplications, thereby exerting significant pressure on memory bandwidth. Prior evaluation shows that HQC delivered only _∼_ 2% of Kyber’s throughput under identical conditions 

[7]. Our profiling results on HQC, shown as in Figure 2 confirm these three hotspots as the dominant contributors to runtime, motivating the proposed optimizations to reduce overall latency. 

The primary contributions of our paper are as follows: 

- We profile the performance of HQC by decomposing it into key computational stages, including hashing, sampling, encoding, syndrome computation, and concatenated Reed–Muller/Reed–Solomon decoding. We further identify performance overheads, quantify each block’s runtime contribution, and analyze the optimization within each stage. 

- We implement lane-interleaved Keccak (SHAKE) with unrolled rounds, aligned loads/stores, and absorb/squeeze fusion, and provide a minimal adapter to the HQC codebase. The kernel reduces SHAKE PRNG and seed-expansion time by 2×. 

- We implemented an efficient sparse _×_ dense vector algorithm, using the polynomial shifting technique, which resulted in roughly 22% speed up at key generation, 60% speed up at encryption, and 35% speedup at decryption. 

- We optimize the Reed–Solomon encode/decode process by replacing costly multiplications with precomputed lookup tables, converting them into constant-time, cacheefficient XOR and shift operations that also preserve sidechannel resistance. 

## II. BACKGROUNDS 

## _A. HQC Computation Flow_ 

HQC is a secure code-based KEM whose security relies on a decision version of syndrome decoding on structured QC codes. It combines (i) a random QC code with a public paritycheck matrix for security, and (ii) employs a fixed concatenated code consisting of an external shortened Reed–Solomon code and an internal duplicated Reed–Muller code for error correction. 

HQC employs SHAKE functions as a PRNG for sampling, generating either dense coefficients directly or sparse ones through a fixed-weight sampler. Domain-separated SHAKEderived functions _G_ ( _·_ ) _, H_ ( _·_ ) _, K_ ( _·_ ) are used for seed/digest formation and key derivation. 

HQC. _Encrypt_ 1 samples fixed-weight _e, r_ 1 _, r_ 2, encodes _m_ with generator _G_ , forms _u_ = _r_ 1+ _h·r_ 2, and _v_ = _mG_ + _s·r_ 2+ _e_ , yielding the ciphertext as _c_ = ( _u, v_ ). _Decrypt_ 2 computes 

_v−u·s_ and applies Reed–Muller then Reed–Solomon decoding to recover _m[′]_ . 

## **Algorithm 1 HQC.PKE.Encrypt** 

**Input:** Public key _pk_ = ( _h, s_ ), message _m_ Sample _e ←R_ with _ω_ ( _e_ ) = _ωe_ Sample _r_ = ( _r_ 1 _, r_ 2) _←R_[2] with _ω_ ( _r_ 1) = _ω_ ( _r_ 2) = _ωr_ _**u ← r**_ **1 +** _**h · r**_ **2** _**v ← mG**_ **+** _**s · r**_ **2 +** _**e**_ **return** _c_ = ( _u, v_ ) 

## **Algorithm 2 HQC.PKE.Decrypt** 

**Input:** Secret key _sk_ , ciphertext _c_ = ( _u, v_ ) **return** _**C.**_ **Decode(** _**v − u · s**_ **)** 

and flexibility by offloading heavy computations to hardware accelerators while keeping control flow in software, as demonstrated in Code-Based Cryptography in IoT: A HW/SW Co-Design of HQC [12]. Meanwhile, side-channel–resilient implementations aim to defend against timing, power and fault attacks using constant-time decoding, masked Keccak modules and verification-based decapsulation [13]. In contrast, our proposed OptHQC framework targets high-performance, portable software optimization of the HQC scheme. It exploits thread-level and data-level parallelism together with vectorization to accelerate key generation, encryption and decryption, achieving significant speedups on general-purpose processors without requiring specialized hardware. 

## III. METHODOLOGY 

HQC.KEM wraps the PKE using the HHK transform with implicit rejection, which consists of three subroutines as _keyGen_ , _Encap_ , and _Decap_ . _KeyGen_ 3 samples seeds, regenerates _h_ , draws fixed-weight secrets _x_ and _y_ , computes _s_ = _x_ + _h · y_ , and embeds a secret _σ_ for use in _Decap_ . In _Encap_ , the sender derives a session key while generating a ciphertext (calling _Encrypt_ that encapsulates the shared secret. In _Decap_ , the receiver decrypts the ciphertext (calling _Decrypt_ ), and then re-encrypts to verify correctness, and securely rejects invalid ciphertexts without leaking side-channel information. We reference standard parameter sets (HQC-1, -3, and -5), as shown in Table I, throughout our implementation and optimization results. 

## **Algorithm 3 HQC.KEM.KeyGen** 

**Input: param** = ( _n, k, δ, ω, ωr, ωe_ ) Sample _h ←R_ Sample ( _x, y_ ) _←R_[2] with _ω_ ( _x_ ) = _ω_ ( _y_ ) = _ω sk_ = ( _x, y, σ_ ) 

_**pk**_ **= (** _**h, s**_ **=** _**x**_ **+** _**h · y**_ **) return** ( _pk, sk_ ) 

TABLE I: HQC parameter sets 

|Level|_N_|_ω_|_ωe_ =_ωr_|Reed-Solomon|Reed-Muller|
|---|---|---|---|---|---|
|HQC-1<br>HQC-3<br>HQC-5|17,669<br>35,851<br>57,637|66<br>100<br>131|75<br>114<br>149|[46,16,31]<br>[56,24,33]<br>[90,32,59]|[384,8,192]<br>[640,8,320]<br>[640,8,320]|



## _B. Related Works_ 

The implementation of the HQC [8] key encapsulation mechanism has been widely explored since its inclusion in the NIST PQC standardization process. Prior works can be grouped into four main categories: hardware, software, hardware/software co-design and side-channel–resilient implementations. Hardware-based studies focus on FPGA and ASIC designs that enhance performance and resource efficiency through pipelined polynomial multiplication, shared SHAKE modules dual-clock architectures [9], [10]. Software implementations, on the other hand, emphasize algorithmic and data-structure optimizations on general-purpose processors or embedded CPUs, such as bit-slicing, loop unrolling and memory-efficient encoding for ARM Cortex-M4 [11]. The hardware/software co-design approach balances speed 

## _A. HQC Profiling Result_ 

Following the HQC specification, we begin by profiling the computational cost of the KeyGen, Encrypt, and Decrypt subroutines, shown in Figure 1. The HQC execution starts with SHAKE256-based randomness generation, which produces dense coefficients directly and samples fixed-weight sparse indices for secrets and error vectors. Hash-related operations contribute roughly 5% of the overall HQC runtime. 

The vector generation phase dominates the computation in KeyGen, as it constructs the sparse vectors ( _x, y_ ) and the dense vector _h_ through sampling derived from the public seed. The following computation involves polynomial multiplications, usually dense-by-sparse products such as _h·r_ 2 and _s·r_ 2. All HQC wrapper operations, including KeyGen, Encrypt, and Decrypt, perform such polynomial multiplications. The encoder and decoder dominate the encryption and decryption processes. They apply a concatenated scheme combining an outer shortened Reed–Solomon (RS) code with an inner duplicated Reed–Muller (RM) code. 

Based on our profiling results, we explore methods to optimize HQC performance on general computing platforms by leveraging accelerated polynomial multiplication (Section III-B), optimized Keccak implementations (Section III-C), and efficient encoding and decoding (Section III-D) strategies. 

## _B. Multiplication Optimization in AVX_ 

We implement an adaptive ring-multiplication path that switches between sparse–dense and dense–dense strategies based on the Hamming weight of the first operand. This targets directly at the Poly Mult section in the Figure 1. The routine first counts nonzero coefficients in _a_ 1; if the number is below a sparsity threshold, the computation routes to a sparse–dense optimization. Otherwise, it uses dense Toom–Cook multiplication followed by modular reduction. 

For the sparse case, the product is synthesized as a superposition of rotated copies of the dense operand: 

**==> picture [247 x 25] intentionally omitted <==**

Each rotation corresponds to a cyclic shift by a support index followed by XOR accumulation. This scales with the 

**==> picture [422 x 148] intentionally omitted <==**

**----- Start of picture text -----**<br>
SHAKE Vector Resize Code Decode Poly Add<br>Vector Gen Code Encode Poly Mult<br>4.85% 0.15% 3.96% 0.08% 6.20% 0.10%<br>7.30% 12.14% 16.90%<br>0.02%<br>0.04%<br>40.27%<br>54.73%<br>76.50% 76.76%<br>**----- End of picture text -----**<br>


Fig. 1: Percentage breakdown of computational costs in HQC-128. The three pie charts illustrate the operation distribution in the _Key Generation_ , _Encryption_ , and _Decryption_ algorithms. Poly Mult and Code Encode/Decode dominate the runtime, while SHAKE, Vector Gen, Vector Resize, and Poly Add contribute relatively minor overhead. 

number of nonzero coefficients rather than polynomial degree, providing significant efficiency gains for HQC’s fixed-weight secrets. 

_1) AVX-Aligned Word and Bit Rotation:_ Each cyclic shift decomposes into a coarse word rotation and a fine intraword bit rotation. For word-aligned shifts, operands rotate by entire words and accumulate directly; for others, adjacent words share carry bits to maintain continuity across 64-bit boundaries. Rotated results are XORed in parallel across vector lanes. 

Polynomial buffers are stored as contiguous word arrays aligned to AVX2 widths, enabling uniform memory access. A final masking step enforces the ( _X[N] −_ 1) modulus when the polynomial length is not a multiple of the word size. This layout sustains high throughput, minimizes control divergence, and preserves constant-time execution independent of secret data. 

Such alignment and rotation are essential for accelerating dense-by-sparse polynomial multiplication, which is one of the dominant operations in HQC. 

_2) Threshold-Aware Scheduling:_ A hybrid scheduler selects between sparse–dense and dense kernels based on the observed Hamming weight. For small fixed weights _ω_ , the sparse path replaces convolution with _ω_ cyclic shifts and XORs; for denser inputs, it falls back to the dense routine with modular reduction. 

A tunable sparsity threshold, calibrated per parameter set, captures cache and vector-width effects. When placed near the empirical cross-over point, the sparse path removes large constant factors while the fallback path matches dense performance with no regression. The multiplication stage thus becomes bandwidth-bound and highly vectorizable, complementing the system’s AVX2 design choices to reduce end-toend KEM latency. 

## _C. AVX-Accelerated SHAKE (Keccak)_ 

SHAKE contributes roughly 5% of end-to-end HQC cost, mainly from seed expansion, noise sampling, and key derivation. We target this by widening the Keccak’s I/O and exploiting inter-message parallelism. 

_1) Vectorized I/O and round staging:_ The Keccak state and message buffers are arranged for 256-bit loads/stores during absorb and squeeze, reducing loop iterations and consolidating data movement. The permutation ( _θ, ρ, π, χ, ι_ ) remains constant-time in 64-bit operations, while state transfers occur in wide, fixed-stride bursts to keep the vector unit busy and avoid data-dependent control flow. 

_2) Multi-buffer parallelism and integration:_ When multiple SHAKE instances arise naturally (e.g., in _KeyGen_ , _Encrypt_ , _Decrypt_ ), they are processed in small, cache-friendly batches. This preserves interfaces and side-channel properties while measurably reducing SHAKE time within the overall pipeline. 

## _D. Table-driven Reed–Solomon (Encode) and Syndrome (Decode)_ 

The Reed–Solomon encoding process transforms a message into a longer sequence (codeword) through multiple stages of polynomial multiplication. This procedure is computationally intensive, as the polynomial operations are interdependent and thus difficult to parallelize effectively. Moreover, since these multiplications occur based on the number of symbols ( _k_ ), they are not constant-time operations, potentially introducing timing side channels that could leak information. 

We propose to replace per-byte multiplications with a precomputed lookup table, as illustrated in Figure 3. Specifically, a static array (approximately 8 KB) is initialized on first use, storing the products for every combination of generator coefficient _gj_ and byte value _x_ . The streaming encoder maps each data byte directly to the lookup table, leaving the standard parity shift-register logic intact. This transformation reduces the inner loop to pure XOR and shift operations with linear, cache-friendly memory access. It makes each byte access a constant-time table lookup while preserving deterministic behavior and side-channel resistance. 

On the decode path, we apply the same optimization technique to significantly reduce the cost of compute syndromes using two nibble-sliced lookup tables (approximately 14 KB in total). A lazy initializer precomputes the contributions of _α[i]_[(] _[j][−]_[1)] for all high and low nibbles, allowing each byte multiplication to be resolved through a pair of XOR lookups 

Fig. 2: Runtime of HQC component, original [14] VS. our OptHQC. The lower the better. The overall graph shows the overall runtime improvement when we combine all our implemented optimization methods. 

**==> picture [232 x 143] intentionally omitted <==**

**----- Start of picture text -----**<br>
Input byte x<br>0x00 0x01 ... 0xFF<br>...<br>...<br>... ... ... ... ...<br>...<br>XOR<br>Generator index j<br>**----- End of picture text -----**<br>


Fig. 3: Lookup table optimization for Reed–Solomon codes. Each entry stores _gj · x ∈_ GF(2[8] ), replacing runtime multiplications with constant-time lookups. 

( _hi ⊕ lo_ ) without branching. The routine remains constant-time and streaming-compatible while eliminating roughly 1,350 GF(2[8] ) multiplications per codeword. 

## IV. EXPERIMENTAL RESULTS 

## _A. Experiment Setting_ 

All experiments were conducted on a Dell Optiplex 5050 desktop equipped with an Intel Core i7-7700 CPU 4 cores, 8 threads, 3.6 GHz, 16 GB DDR4-2400 MHz RAM, running Ubuntu 20.04 LTS. The HQC reference implementation was obtained from the official HQC website [14] and compared against our optimized **OptHQC** framework when running on our platform. 

All three standardized parameter sets (HQC-1, HQC-3, and HQC-5) were benchmarked across the three cryptographic operations: _KeyGen_ , _Encrypt_ , and _Decrypt_ . Each operation was executed repeatedly to mitigate system jitter, and average timings were recorded using both the rdtsc cycle counter and high-resolution wall-clock timing. Functional correctness was verified against the official test vectors through the built-in unit test suite to ensure bit-for-bit consistency of ciphertexts and shared secrets. All optimizations were compiled in constanttime mode to preserve side-channel resistance. 

## _B. Results and Analysis_ 

Figure 2 summarizes the per-component runtime of the original and optimized HQC implementations, and the overall 

improvement of the algorithm. Across all parameter sets, the optimized design achieves 50-60% reduction in total runtime, with the largest improvements observed in _Decryption_ due to the enhanced Reed–Solomon and Reed–Muller decoding pipeline. 

Performance improvements remain consistent across all security levels, indicating that the optimizations scale proportionally with code length and parameter size rather than relying on any specific configuration. Notably, HQC-3 benefits the most due to its higher decoding depth, which amplifies the efficiency of the optimized Reed–Solomon component. 

_Component-Level Acceleration:_ Profiling results reveal that _polynomial multiplication_ and _concatenated decoding_ dominate HQC’s runtime, jointly contributing over 85% of total latency. The optimized implementation integrates three key accelerations: 

- **Sparse** _×_ **Dense AVX2 Multiplication:** A weight-aware rotation and shift–XOR kernel replaces dense convolution, yielding 20–40% faster multiplication depending on sparsity. 

- **AVX-Parallel SHAKE:** Lane-interleaved Keccak processing accelerates seed expansion by **2** _×_ , reducing KeyGen overhead. 

- **Table-Driven Reed–Solomon Decoder:** Precomputed GF(2[8] ) products convert inner-loop multiplications into cache-friendly XOR lookups, reducing _GF mul_ runtime by 20–25%. 

## V. CONCLUSION 

This work presents a performance analysis and optimization framework for the HQC post-quantum key encapsulation mechanism. By profiling its main computation blocks, such as hashing, sampling, encoding, syndrome computation, and concatenated Reed–Muller/Reed–Solomon decoding, we identified bottlenecks and applied targeted optimizations. An optimized sparse-by-dense polynomial multiplication using vectorized shifting achieves up to 40% faster encryption, while a table-driven Reed–Solomon encoder/decoder replaces costly field multiplications with constant-time, cache-friendly operations. These optimizations collectively enhance HQC efficiency and side-channel resistance, demonstrating the potential of memory-efficient design for accelerating code-based PQC on general-purpose platforms. 

## REFERENCES 

- [1] D. Moody, “Nist pqc standardization update,” _National Institute of Standards and Technology_ , pp. 2021–10, 2021. 

- [2] J. Bos, L. Ducas, E. Kiltz, T. Lepoint, V. Lyubashevsky, J. M. Schanck, P. Schwabe, G. Seiler, and D. Stehl´e, “Crystals-kyber: a cca-secure module-lattice-based kem,” in _2018 IEEE European Symposium on Security and Privacy (EuroS&P)_ . IEEE, 2018, pp. 353–367. 

- [3] L. Ducas, E. Kiltz, T. Lepoint, V. Lyubashevsky, P. Schwabe, G. Seiler, and D. Stehl´e, “Crystals-dilithium: A lattice-based digital signature scheme,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pp. 238–268, 2018. 

- [4] P.-A. Fouque, J. Hoffstein, P. Kirchner, V. Lyubashevsky, T. Pornin, T. Prest, T. Ricosset, G. Seiler, W. Whyte, Z. Zhang _et al._ , “Falcon: Fast-fourier lattice-based compact signatures over ntru,” _Submission to the NIST’s post-quantum cryptography standardization process_ , vol. 36, no. 5, pp. 1–75, 2018. 

- [5] D. J. Bernstein, A. H¨ulsing, S. K¨olbl, R. Niederhagen, J. Rijneveld, and P. Schwabe, “The sphincs+ signature framework,” in _Proceedings of the 2019 ACM SIGSAC conference on computer and communications security_ , 2019, pp. 2129–2146. 

- [6] National Institute of Standards and Technology, “NIST Selects HQC as Fifth Algorithm for Post-Quantum Encryption,” Mar. 2025, accessed: 2025-04-10. [Online]. Available: https://www.nist.gov/news-events/ news/2025/03/nist-selects-hqc-fifth-algorithm-post-quantum-encryption 

- [7] B. Dong and Q. Wang, “Epquic: Efficient post-quantum cryptography for quic-enabled secure communication,” in _Proceedings of the Great Lakes Symposium on VLSI 2025_ , ser. GLSVLSI ’25. New York, NY, USA: Association for Computing Machinery, 2025, p. 141–146. [Online]. Available: https://doi.org/10.1145/3716368.3735199 

- [8] A. Ras, A. Loiseau, M. Carmona, S. Ponti´e, G. Renault, B. Smith, and E. Valea, “Optimizing hqc using frobenius additive fft on a risc-v-based system-on-chip.” 

- [9] L. Roy, D. Dutta, and P. Kumar, “A fast hardware implementation of hqc,” in _Proceedings of the 4th NIST Post-Quantum Cryptography Standardization Conference_ . Gaithersburg, MD, USA: National Institute of Standards and Technology (NIST), 2022, [Online]. Available: https://csrc. nist.gov/presentations/2022/a-fast-hardware-implementation-of-hqc. [Online]. Available: https://csrc.nist.gov/presentations/2022/ a-fast-hardware-implementation-of-hqc 

- [10] S. Deshpande, C. Xu, M. Nawan, K. Nawaz, and J. Szefer, “Fast and efficient hardware implementation of hqc,” in _International Conference on Selected Areas in Cryptography_ . Springer, 2023, pp. 297–321. 

- [11] D. Kim, J. Choi, S. Yoon, and S. C. Seo, “Optimized implementation of hqc on cortex-m4,” _ICT Express_ , 2025. 

- [12] M. Sch¨offel, J. Feldmann, and N. Wehn, “Code-based cryptography in iot: A hw/sw co-design of hqc,” in _2022 IEEE 8th World Forum on Internet of Things (WF-IoT)_ . IEEE, 2022, pp. 1–7. 

- [13] G. Goy, A. Loiseau, and P. Gaborit, “A new key recovery side-channel attack on hqc with chosen ciphertext,” in _International Conference on Post-Quantum Cryptography_ . Springer, 2022, pp. 353–371. 

- [14] T. H. P. Team, “Hqc — post-quantum code-based cryptography repository,” https://gitlab.com/pqc-hqc/hqc/, 2025. 

