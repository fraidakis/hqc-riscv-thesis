---
source_pdf: docs/references/pdf/other-platforms/!!! Faster GF(2)[x] polynomial multiplication using SIMD instructions.pdf
converted_at: 2026-05-29 22:39
conversion_time: 7.3s
tool: pymupdf4llm
---

Journal of Cryptographic Engineering            (2026) 16:3 https://doi.org/10.1007/s13389-026-00392-0 

~~**RESEARCH ARTICLE**~~ 

**==> picture [30 x 29] intentionally omitted <==**

## **Faster GF** _**(**_ **2** _**)**_ **[** _**x**_ **] polynomial multiplication using SIMD instructions** 

## **Jihoon Jang[1] · Myeonghoon Lee[2] · Suhri Kim[3] · Seog Chung Seo[4] · Seokhie Hong[5]** 

Received: 4 July 2025 / Accepted: 12 March 2026 © The Author(s), under exclusive licence to Springer-Verlag GmbH Germany, part of Springer Nature 2026 

## **Abstract** 

Inthiswork,weproposeanoptimizedmethodforpolynomialmultiplicationoverGF _(_ 2 _)_ [ _x_ ],targetingSIMDenvironmentssuch as AVX2 and Neon. Polynomial multiplication is a core operation in code-based cryptographic schemes, including the recently standardized HQC. Our method provides a systematic, branch-free approach that selects efficient Toom-Cook/Karatsuba decomposition for GF _(_ 2 _)_ [ _x_ ] polynomial multiplication. We systematically explore Toom-Cook/Karatsuba decomposition trees and generate specialized implementations without table look-ups or conditional branches, enabling precise selection for a given parameter set. Unlike general-purpose libraries such as gf2x, which use table look-ups and conditional branches to support arbitrary polynomial degrees, our parameter-specific, branch-free design avoids this runtime selection overhead and enables precise algorithm selection for each parameter set. We further implement architecture-specific base multiplications using VPCLMULQDQ for AVX2 and PMULL for Neon. To evaluate our method, we compare against the gf2x library and state-of-the-art implementations of HQC and BIKE in both AVX2 and Neon environments. In particular, for HQC-1 and HQC-3 on AVX2 with PCLMULQDQ, our method reduces polynomial multiplication cycles by 17-32% compared to the official HQC implementation. For HQC-5, we observe that FFT-based multiplication can be preferable. For BIKE in the same environment, we observe a 5-11% improvement in polynomial multiplication cycles compared to the method of Chen et al. (CHES 2021). 

**Keywords** Binary polynomial multiplication · AVX2 · Arm Neon · HQC · BIKE 

## **1 Introduction** 

B Suhri Kim suhrikim@sungshin.ac.kr Jihoon Jang jhw1031506@korea.ac.kr Myeonghoon Lee ope2527@gmail.com Seog Chung Seo scseo@kookmin.ac.kr Seokhie Hong shhong@smartm2m.co.kr 

- 1 School of Cybersecurity, Korea University, 145, Anam-ro, 02841 Seoul, Republic of Korea 

- 2 Samsung Electronics System LSI Business, 1-1, Samsungjeonja-ro, 18448 Hwaseong, Republic of Korea 

- 3 School of Mathematics, Statistics and Data Sciences, Sungshin Women’s University, 2, 34 da-gil, Bomun-ro, 02844 Seoul, Republic of Korea 

- 4 Department of Financial Information Security, Kookmin University, 77, Jeongneung-ro, 02707 Seoul, Republic of Korea 

In quantum computing environments, it is well known that Shor’s algorithm [1] can solve the integer factorization and discrete logarithm problems in polynomial time. Since the currently used public-key cryptography, such as RSA, DSA, and ECC, is based on the hardness of these problems, NIST initiated the PQC standardization project to evaluate and standardize cryptographic schemes that remain secure even in quantum computing environments. In round 4 of this project, HQC [2] and BIKE [3] emerged as one of the most promising candidate algorithms, with HQC ultimately being selected for standardization [4]. Both algorithms are codebased cryptosystems that treat the variables in binary codes as polynomials in GF _(_ 2 _)_ [ _x_ ] _/(x[n]_ − 1 _)_ , performing multiplications and additions over GF _(_ 2 _)_ [ _x_ ]. 

Meanwhile, especially in code-based or lattice-based cryptography, polynomial multiplication is the core compu- 

- 5 SmartM2M, 9, Bongeunsa-ro 37-gil, Gangnam-gu, Seoul, Republic of Korea 

**==> picture [133 x 12] intentionally omitted <==**

123 

3 Page 2 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

tation and accounts for the majority of overall performance. For this reason, efficient polynomial multiplication algorithms such as Karatsuba [5], Toom–Cook [6, 7], and the Number Theoretic Transform (NTT) are used instead of the standard schoolbook method. In particular, schemes such as Dilithium [8] and Kyber [9] perform polynomial multiplication over GF _( p)_ [ _x_ ] _/(x[n]_ ± 1 _)_ , allowing them to exploit NTT to optimize polynomial multiplication. However, in code-based schemes such as HQC and BIKE, which operate over GF _(_ 2 _)_ [ _x_ ], NTT cannot be used directly. Instead, Karatsuba, Toom–Cook, or Additive-FFT [10, 11] are employed to achieve similar performance benefits. 

Additive FFT is an FFT-based multiplication method that can be used to perform multiplications over GF _(_ 2 _)_ [ _x_ ]. It transforms a multiplication over GF _(_ 2 _)_ [ _x_ ] _/(x[n]_ − 1 _)_ into one over GF _(_ 2 _[m] )_ [ _x_ ] _/ p(x)_ with 2 _[m]_ ≥ deg _( p(x)) >_ 2 _n_ , followed by basis conversion and butterfly operations. For GF _(_ 2 _)_ [ _x_ ] polynomial multiplications, this multiplication method provides the fastest performance on platforms that do not support carry-less multiplication instructions, such as the CortexM4 [12–14]. However, on SIMD-capable platforms such as AVX2 and NEON, carry-less multiplication instructions (e.g., PCLMULQDQ, VPCLMULQDQ, and PMULL) are available.Therefore,Karatsuba-andToom–Cook-basedmethods, which rely heavily on carry-less multiplications, tend to be efficient on such platforms. In addition, these methods can be effectively vectorized to exploit SIMD parallelism, which provides a further performance benefit. As a result, optimized AVX2 implementations of code-based schemes such as HQC and BIKE commonly adopt Karatsuba and Toom— Cook approaches for polynomial multiplication [2, 3, 15]. 

Both the Karatsuba and Toom–Cook algorithms are divide-and-conquer methods, allowing for a wide range of combinations depending on the internal multiplication algorithm employed. In [15], the authors optimized GF _(_ 2 _)_ [ _x_ ] operations using the AVX-512 instruction set. However, they evaluated only a limited set of representative combinations among the many possibilities. This has the limitation that other possible combinations were not considered, and no detailed rationale was provided for the selected combinations. 

On the other hand, the gf2x library [16] evaluates the entire set of candidate combinations in a manner similar to our approach. The gf2x library supports carry-less polynomial multiplication for arbitrary input degrees and can be regarded as a general-purpose solution. To accommodate this flexibility, gf2x employs table look-ups and conditional branches during both algorithm selection and execution. Such control-flow operations can cause pipeline flushes and introduce additional overheads even when independent of secret data, making it difficult to accurately assess the performance of combinations in fixed degree polynomial multiplication. In particular, if conditional branches 

are used only during the exploration or benchmarking phase but removed in the actual implementation, the resulting performance comparisons may lead to inaccurate conclusions. Consequently, while the gf2x library supports carry-less polynomial multiplication for arbitrary degrees across various environments, it does not offer efficient polynomial multiplication. 

In this work, we propose optimization methods for polynomial multiplication over GF _(_ 2 _)_ [ _x_ ] in SIMD environments such as AVX2 and Neon. Our method searches ToomCook/Karatsuba decomposition trees to select an efficient algorithmic combination for each target degree, and we further provide an optimized 256-bit base multiplication for platforms supporting AVX2 and VPCLMULQDQ without relyingon AVX-512.Weintegratetheresultingimplementations into HQC and BIKE and show competitive performance against state-of-the-art implementations (including gf2x), while observing that FFT-based approaches can remain preferable for the largest parameter set, HQC-3. 

## **1.1 Related Works** 

As polynomial multiplication over GF _(_ 2 _)_ [ _x_ ] plays a central role in determining the overall performance of code-based cryptography, extensive research has been conducted on optimizing this operation. In [12], the authors present an optimized implementation of BIKE targeting both Intel Haswell and ARM Cortex-M4 platforms. As part of their overall implementation-level optimizations, different polynomial multiplication strategies are adopted depending on the underlying architecture. On x86 platforms, previous BIKE implementations rely on recursive Karatsuba multiplication combined with PCLMULQDQ. To better accommodate the large polynomial degrees used in BIKE, Chen et al. adopt Bernstein’s 5-way recursive algorithm, which is a variant of Toom-Cook 3-way, at the top level of recursion, while retaining Karatsuba at lower levels to balance performance and implementation complexity. While the proposed implementations report noticeable performance improvements over the publicly available BIKE team implementations, the ToomCook algorithm, which is known to be more efficient than Karatsuba for higher-degree polynomials, was not considered in their design. 

In [15], the authors investigate Karatsuba and ToomCook-based polynomial multiplication strategies on SIMDcapable platforms supporting the AVX2 and AVX-512 instruction sets. While previous studies primarily focused on AVX2 implementations using the PCLMULQDQ instruction, the emergence of AVX-512 with support for VPCLMULQDQ motivates a re-examination of Karatsuba multiplication, as wider SIMD registers and increased register availability fundamentally alter performance trade-offs. The authors first evaluated the efficiency of various Karatsuba constructions 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 3 of 21 3 

on AVX-512 and then combined these with Toom-Cook schemes to identify the most effective algorithmic combinations across different polynomial degree ranges. In particular, the study considers recursive Karatsuba as well as fixedsplit variants such as 3-way and 5-way Karatsuba, together with Toom-Cook 3-, 4-, and 5-way, where a Toom-Cook _n_ -way scheme denotes an _n_ -way split requiring 2 _n_ − 1 elementary multiplications. While the study provides valuable experimental insights, the explored design space is limited to selected Karatsuba and Toom-Cook configurations, leaving other possible combinations and a systematic selection methodology unexplored. 

In addition to the above SIMD-focused studies on x86 platforms, a substantial body of work has also investigated efficient binary polynomial multiplication and carry-less polynomial arithmetic on ARM/Neon platforms, including techniques relevant to Armv8-class SIMD implementations [17–19]. These studies provide important low-level implementation insights for SIMD-friendly polynomial arithmetic on ARM processors. However, they primarily focus on arithmetic kernels and implementation techniques, rather than the scheme-level problem considered in this paper, namely the systematic selection of Karatsuba/Toom-Cook decomposition trees for target polynomial degrees in HQC and BIKE under a branch-free execution model. 

The most recent work in this area is the work proposed by Chen et al. [20]. In [20], they address a common challenge in applying additive FFT-based polynomial multiplication to HQC, where the polynomial degrees are often slightly larger than powers of two, which makes standard additive FFTbased methods inefficient for these parameters. To resolve this, they introduce an adaptive strategy based on hardware capabilities. For environments where carry-less multiplication is relatively slow (e.g., Neon without crypto extensions), they employ a novel combination of additive FFT and the Chinese Remainder Theorem (CRT). Conversely, for environments with fast carry-less multiplication support (e.g., AVX2 or Neon with crypto extensions), they demonstrate that a hybrid approach that applies additive FFT to the power-of-two component and handles the remainder directly yields better performance than complex CRT-based methods. Their results provide an important FFT-based comparison point for HQC polynomial multiplication. At the same time, the relative advantage depends on the target degree and parameter set. In particular, while the FFT-based approach shows stronger performance for larger-degree settings such as HQC-3, Karatsuba/Toom-Cook-based SIMD implementations [15] can remain more efficient for smaller-degree settings such as HQC-1 and HQC-3, where the overhead of FFT-based processing may outweigh its asymptotic advantage. 

## **1.2 Motivation** 

Polynomial multiplication over GF _(_ 2 _)_ [ _x_ ] is a core operation in code-based post-quantum cryptographic schemes such as HQC and BIKE, and its performance directly affects the efficiency of the algorithm. As these schemes operate on polynomials with degrees of up to tens of thousands, optimizing polynomial multiplication remains a critical challenge. 

As stated above, previous works typically evaluate the performance of a small number of algorithmic combinations or adopt a fixed decomposition strategy when presenting optimized implementations of HQC or BIKE. While such approaches demonstrate that Toom–Cook/Karatsuba–based methods can significantly outperform school-book multiplication, they do not fully exploit the full range of algorithmic combinations. In practice, polynomial multiplication can be structured as a decomposition tree with many valid configurations, and the optimal choice depends on the polynomial degree as well as the architectural characteristics of the target platform. Fixing the decomposition strategy a priori can therefore lead to suboptimal performance. This motivates the need for a systematic methodology that explores the space of polynomial decomposition trees and identifies the most efficient algorithmic combination. 

Another important limitation of existing studies lies in their choice of target SIMD platforms. Prior work has mainly focused on CPUs that either support AVX512 and VPCLMULQDQ or only support AVX2 without VPCLMULQDQ. However, recent mainstream Intel Core architectures, such as Alder Lake and Raptor Lake, present a differentdeploymentscenario:whiletheysupport VPCLMULQDQ, support for AVX-512 has been removed. Despite the practical relevance of this configuration, polynomial multiplication optimized for the combination of AVX2 and VPCLMULQDQ has received limited attention. As a result, implementations deployed on such platforms must rely on AVX2based designs while still leveraging carry-less multiplication through VPCLMULQDQ. 

## **1.3 Contributions** 

Motivated by these observations, this paper proposes a systematic optimization method for polynomial multiplication over GF _(_ 2 _)_ [ _x_ ], targeting polynomial degrees of up to 100,000. Our approach systematically explores polynomial decomposition trees to identify the most efficient combinations of Karatsuba and Toom–Cook algorithms for each polynomial degree, and optimizes the resulting implementations for SIMD instruction sets such as AVX2 and Neon. 

In selecting the target SIMD platform, we focus on AVX2 as the primary baseline. Although AVX-512 provides wider vector operations, its support on mainstream Intel Core processors effectively ended with the 11th-generation Tiger 

123 

3 Page 4 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

Lake and Rocket Lake architectures, and it has not been supported in subsequent generations released since 2022. Hence, we do not consider AVX-512 in this work and instead focus on AVX2, which remains the most widely available SIMD instruction set across contemporary x86 platforms. 

We evaluate our method across various environments and compare its performance with state-of-the-art implementations used in code-based cryptographic schemes, including HQC and BIKE. The main contributions of this work are as follows. 

- We present a flexible and high-performance multiplication method over GF _(_ 2 _)_ [ _x_ ] that applies to all polynomials with degrees up to approximately 100,000 in a SIMD instruction set environment. Unlike the gf2x library, which determines combinations of the Karatsuba and Toom-Cook algorithms via conditional branching and table look-ups for flexibility, our method is branch-free both in the exploration phase and in the final implementation. This design avoids discrepancies between the exploration phase and the final implementation, ensuring that the selected combination is optimal within our considered search space. As a result, our approach retains flexibility while enabling accurate comparisons and achieving better performance by avoiding the clock cycle overhead associated with conditional branches and table look-ups. 

- We implemented an optimized 256-bit base multiplication tailored for environments that do not support AVX-512 but do support AVX2 and the VPCLMULQDQ instruction, such as Intel Raptor Lake. Prior works by Drucker [21] and Robert [15] assume AVX-512 availability and focus on 512-bit base multiplication. However, given that our target environment supports 256bit ymm registers and the AVX2 instruction set, base multiplication on 256-bit polynomials is more suitable. To this end, we develop an efficient 256-bit base multiplication routine utilizing AVX2 and VPCLMULQDQ. Furthermore, we also implemented an optimized 128bit base multiplication for ARMv8 platforms supporting the Neon instruction set. 

- We present performance comparisons of our proposed method against state-of-the-art GF _(_ 2 _)_ [ _x_ ] multiplication methods across various environments, including those supporting AVX2 with PCLMULQDQ (denoted as AVX2-PCLMULQDQ), VPCLMULQDQ (denoted as AVX2-VPCLMULQDQ), and Neon with vmull_p8 (denoted as Neon-VMULL_P8). To validate its effectiveness, we integrated our method into recent implementations of HQC and BIKE and measured the performance of core operations. For HQC-1 and HQC-3, our method consistently reduced cycle counts across all tested sce- 

- narios compared to existing approaches [2, 20]. For instance, in the AVX2-PCLMULQDQ environment, our method achieves an 18-32% improvement in polynomial multiplication and a 4-18% improvement in key generation, encapsulation, and decapsulation. For the HQC-3 parameter set, the FFT-based implementation by Chen et al. [20] exhibited the best performance, as the asymptotic advantages of the FFT-based approach become more pronounced at larger polynomial degrees. In the case of BIKE, our method outperformed existing ToomCook and Karatsuba-based approaches [3, 12] across all parameter sets. Specifically, in the AVX2-PCLMULQDQ environment, our method improves polynomial multiplication by 5-11% and overall KEM operations by 1-6% compared to the implementation in [12]. These results demonstrate the broad applicability and competitive efficiency of our proposed approach. 

The source code and implementation details of the proposed method are available at: https://github.com/jihoonjang98/ gf2x_opt_SIMD. 

## **2 Preliminaries** 

## **2.1 Notation and Terminology** 

We summarize core terms used throughout the paper. 

|GF_(_2_)_[_x_].|The polynomial ring over|
|---|---|
||thebinaryfeldGF_(_2_)_.Coef-|
||fcients are in {0_,_1} and|
||addition is XOR.|
|_Carry_−_lessmultiplication._|Polynomial multiplication|
||overGF_(_2_)_[_x_]withoutcar-|
||ries.|
|_m_-word multiplication.|The carry-less multiplica-|
||tion of polynomials with|
||degree at_mR_−1, where_R_|
||is the SIMD register size.|
|_Basemultiplication._|Thelowest-levelcarry-less|
||multiplication for polyno-|
||mials of degree at _R_−1.|
|SIMD.|Single-instructionmultiple-|
||data execution model. We|
||use vector instructions to|
||process multiple limbs in|
||parallel (e.g., 256-bit vec-|
||tors on x86 and 128-bit|
||vectors on Arm).|
|AVX2.|IntelAdvancedVectorExten-|
||sions 2, providing 256-bit|



123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 5 of 21 3 

||SIMD integer instructions|
|---|---|
||and YMM registers used|
||in our x86 implementa-|
||tions.|
|AVX-512.|IntelSIMDextensionswith|
||512-bit ZMM registers.|
|PCLMULQDQ.|An x86 instruction that|
||performs carry-less multi-|
||plication on 64-bit halves|
||of XMM inputs and out-|
||puts a 128-bit result.|
|VPCLMULQDQ.|The vector form of carry-|
||less multiplication on x86.|
||Depending on the encod-|
||ing/variant, it can operate|
||on vector registers (e.g.,|
||XMM/YMM/ZMM).|
|Neon.|ArmAdvancedSIMDexten-|
||sionproviding128-bitvec-|
||tor registers and instruc-|
||tions.|
|vmull_p8.|Arm carry-less multipli-<br>cation intrinsic used as a|
||base-multiplication prim-|
||itive in our Neon imple-|
||mentations.|



## **2.2 Polynomial Multiplication Algorithms** 

In GF _(_ 2 _)_ [ _x_ ], operations between coefficients are performed within GF _(_ 2 _)_ , where addition and multiplication correspond to XOR and AND operations, respectively. The schoolbook method is a straightforward way to implement polynomial multiplication. Optimized versions such as Karatsuba and Toom-Cook provide more efficient multiplication over GF _(_ 2 _)_ [ _x_ ] than the schoolbook method. While the schoolbook algorithm has a computational complexity of _O(n_[2] _)_ , the 2-,3-,5-Karatsuba algorithm has a computational complexity of _O(n_[log][2][ 3] _)_ , _O(n_[log][3][ 6] _)_ , _O(n_[log][5][ 15] _)_ , and the _m_ -way Toom-Cook algorithm has a computational complexity of _O(n_[log] _[m]_[ 2] _[m]_[−][1] _)_ , respectively. 

The 2-Karatsuba algorithm splits each input polynomial into two halves and computes the product using three subpolynomial multiplications instead of four required by the schoolbook algorithm. Similarly, the 3- and 5-way Karatsuba algorithms divide the input polynomials into three and five parts, respectively. Compared to the schoolbook method, the 3-Karatsuba algorithm reduces the number of multiplications from 9 to 6, while 5-Karatsuba reduces it from 25 to 15. 

## **2.2.2 Toom-Cook algorithm** 

The Toom-Cook _m_ -way algorithm can be considered as a generalization of the Karatsuba algorithm, designed for multiplying polynomials with degrees at most _mk_ − 1. The Toom-Cook algorithm can be divided into three stages: splitting, evaluation, and interpolation. 

- Splitting: This process divides a polynomial _A(x), B(x)_ of degree at most _mk_ − 1 with _X_ = _x[k]_ as the base into _m_ polynomials of degree at most _k_ − 1 as follows: 

**==> picture [140 x 32] intentionally omitted <==**

**==> picture [140 x 31] intentionally omitted <==**

- The following steps are performed for polynomials _A(X )_ and _B(X )_ of degree _m_ − 1. 

- Evaluation: This process substitutes 2 _m_ − 1 evaluation points into polynomials _A(X )_ and _B(X )_ of degree _m_ − 1 obtainedbysplitting,andmultipliesthem.Inotherwords, this process calculates _C( p_ 1 _), ..., C( p_ 2 _m_ −1 _)_ for evaluation points _p_ 1 _, ..., p_ 2 _m_ −1 as _C( pi )_ = _A( pi )_ × _B( pi )_ for 1 ≤ _i_ ≤ 2 _m_ − 1. 

- Interpolation: This process calculates the coefficients of _C(X )_ = _A(X )_ × _B(X )_ using the 2 _m_ − 1 results obtained from the Evaluation process. This process is equivalent to solving a system of 2 _m_ − 1 linear equations. The coefficients of _C(X )_ are then combined in place to find the result of the multiplication of _A(X )_ and _B(X )_ . 

## **2.2.1 Karatsuba algorithm** 

## **2.3 AVX2 Instruction Sets** 

The _m_ -way Karatsuba algorithm is a divide-and-conquer approach for polynomial multiplication, in which a polynomial of degree _mk_ −1 is split into _m_ smaller sub-polynomials of approximately equal size. By carefully recombining the partial products, the algorithm reduces the total number of required multiplications compared to the schoolbook method. In this work, we focus on the 2-, 3-, and 5-way Karatsuba algorithms, as these variants form the building blocks of our optimized implementations. 

AmongSIMDinstructionsetsavailableoncontemporaryx86 platforms, AVX2 remains the most widely supported baseline, as AVX-512 is mainly available on certain server-class platforms and is not universally available. Hence, we focus on AVX2 in this work. 

The AVX2 instruction set is an extension of Intel’s x86 instructionset,whichisa256-bitSIMDinstructionset. AVX2 uses 128-bit xmm registers and 256-bit ymm registers. There 

123 

3 Page 6 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

are 16 of each, xmm0 through xmm15 and ymm0 through ymm15. Specifically, each xmm register is the lower 128-bit half of its corresponding ymm register. They allow SIMD operations to be performed in 128- or 256-bit units. Using the following AVX2 intrinsic function: 

## __m256i _mm256_xor_si256 _(_ __m256i a _,_ __m256i b _),_ 

allows for faster addition (bitwise-XOR) in GF _(_ 2 _)_ [ _x_ ] by performing it in 256-bit units. This function returns the 256-bit result of a bitwise-XOR of 256-bit a and b. A recent release of HQC also implements the GF _(_ 2 _)_ [ _x_ ] operation using these intrinsic functions. 

Furthermore, using the AVX2 instruction set, fast multiplication on GF _(_ 2 _)_ [ _x_ ] can be implemented. The AVX2 intrinsic function: 

**==> picture [160 x 9] intentionally omitted <==**

operation can also be accessed through the AVX2 intrinsic function: 

**==> picture [184 x 10] intentionally omitted <==**

**==> picture [204 x 9] intentionally omitted <==**

## **2.5 Neon instruction set** 

The Neon instruction set is a SIMD extension designed for ARM architectures, particularly in ARMv7-A, ARMv8-A, and later. It provides 64-bit and 128-bit vectorized operations, enabling efficient parallel computation. Unlike AVX2, which utilizes 256-bit ymm registers, Neon employs 128bit q-registers and 64-bit d-registers, making it suitable for parallel polynomial multiplication over GF _(_ 2 _)_ [ _x_ ]. 

For polynomial multiplication in GF _(_ 2 _)_ [ _x_ ], ARM provides two key Neon intrinsics: 

- _(_ __m128i b _,_ __m128i c _,_ const int Imm8 _)_ 

is mapped to the PCLMULQDQ instruction which can be used to efficiently implement GF _(_ 2 _)_ [ _x_ ] multiplication operations. Let _b(x)_ = _b_ 0 _(x)_ + _b_ 1 _(x)x_[64] and _c(x)_ = _c_ 0 _(x)_ + _c_ 1 _(x)x_[64] be GF _(_ 2 _)_ [ _x_ ] polynomials of degree at most 127. This function returns a 128-bit value as a result of multiplication _bi_ × _c j_ for _i, j_ ∈{0 _,_ 1}, depending on the value of Imm8. 

## **2.4 VPCLMULQDQ instruction** 

The VPCLMULQDQ instruction is an extension to the x86 instruction set that enables parallel execution of two or four 64-bit polynomial multiplications over GF _(_ 2 _)_ [ _x_ ]. When used with ymm registers in an AVX2 environment, it performs two 64-bit GF _(_ 2 _)_ [ _x_ ] multiplications in parallel. The results of the two multiplications are packed side by side in a single 256bit ymm register. In contrast, when used with zmm registers in an AVX-512 environment, it executes four such multiplications in parallel and stores the results in a single 512-bit zmm register. Since the paper targets platforms that do not support AVX-512 environment, we only focus on AVX2 environment. 

In the AVX2 environment, two ymm registers are used to input 256-bit polynomials 

**==> picture [210 x 29] intentionally omitted <==**

along with an 8-bit immediate value Imm8. The instruction then returns a 256-bit value, based on the value of Imm8. Thisisfunctionallyequivalenttoexecutingtwo PCLMULQDQ instructions in parallel, and the two resulting 128-bit products are concatenated and stored in a single ymm register. This 

- vmull_p8: Performs eight parallel 8-bit carry-less multiplications over GF _(_ 2 _)_ [ _x_ ], producing a 128-bit result. It is mapped to the instruction PMULL Vd.8H, Vn.8B, Vm.8B,whereeachpairof8-bitelementsfromthesource vectors is multiplied independently. 

- vmull_p64: Performs a single 64-bit carry-less multiplication over GF _(_ 2 _)_ [ _x_ ], producing a 128-bit result. It correspondstotheinstruction PMULL Vd.1Q, Vn.1D, Vm.1D,andisconceptuallyequivalenttothe PCLMULQDQ instruction in AVX2. However, this intrinsic is only available on platforms that support the ARMv8 cryptographic extension. 

Since vmull_p64 requires the cryptographic extension, on platforms without this extension, only vmull_p8 can be used for polynomial multiplication. 

## **2.6 Polynomial Multiplications in Code-based Cryptography** 

## **2.6.1 Polynomial Multiplication in HQC** 

HQC is a code-based KEM that operates over GF _(_ 2 _)_ [ _x_ ], and it is one of the algorithms selected in the NIST PQC standardization project. Throughout HQC’s key generation, encapsulation, and decapsulation processes, polynomial multiplication over GF _(_ 2 _)_ [ _x_ ] accounts for a significant portion of the computational workload. Table 1 shows the proportion of cycle counts dedicated to GF _(_ 2 _)_ [ _x_ ] multiplication in HQC-1. The measurements were performed using the experimental setup described in Section 5.1. 

As shown in Table 1, polynomial multiplication accounts for 20-32% of the total cycle count, depending on the 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 7 of 21 3 

**Table 1** Proportion of GF _(_ 2 _)_ [ _x_ ] Multiplication in HQC-1 ([2], AVX2). 

|**Table 1** Proportion|of GF_(_2_)_[_x_]Multipl|ication inHQC-1|([2],AVX2).|
|---|---|---|---|
||Total|Mul.1|Prop.2|
|key generation|79,436|24,270|30.6%|
|encapsulation|152,229|47,836|31.4%|
|decapsulation|351,657|72,496|20.6%|



> 1 Mul. = Cycles for GF _(_ 2 _)_ [ _x_ ] multiplication 

> 2 Prop. = Proportion of total cycles 

## **3 Implementations of GF(2)[x] multiplication** 

In this section, we describe the proposed implementation method of polynomial multiplication over GF _(_ 2 _)_ [ _x_ ]. We first describe various base multiplication techniques optimized for different instruction sets, followed by the implementation details of Karatsuba and Toom–Cook methods. 

## **3.1 Base multiplication** 

**Table 2** Proportion of GF _(_ 2 _)_ [ _x_ ] Multiplication in bikel1 ([3], AVX2). 

|AVX2).||||
|---|---|---|---|
||Total|Mul.1|Prop.2|
|key generation|455,594|266,207|58.4%|
|encapsulation|123,841|15,760|12.7%|
|decapsulation|1,699,488|237,411|14.0%|



> 1 Mul. = Cycles for GF _(_ 2 _)_ [ _x_ ] multiplication 

> 2 Prop. = Proportion of total cycles 

operation. This means GF _(_ 2 _)_ [ _x_ ] multiplication is a main performance bottleneck in HQC. 

The latest HQC submission [2] implements polynomial multiplication over GF _(_ 2 _)_ [ _x_ ] using a hybrid of Karatsuba and Toom-Cook algorithms optimized for the AVX2 instruction set [15]. Specifically, Toom3Mult _(_ Karat3 _)_ is used for HQC-1 and -3, while Toom3Mult _(_ Karat5 _)_ is used for HQC-5. These methods apply the Toom-Cook 3-way approach at the top level. Toom3Mult _(_ Karat3 _)_ embeds 3-way Karatsuba, while Toom3Mult _(_ Karat5 _)_ embeds 5-way Karatsuba multiplication. Both methods recursively apply 2-way Karatsuba at deeper levels. 

## **2.6.2 Polynomial Multiplication in BIKE** 

BIKE is a code-based KEM that was a candidate algorithm of NIST PQC round 4. Polynomial multiplication over GF _(_ 2 _)_ [ _x_ ] is required in several parts of the scheme, including public key generation, syndrome computation, and the decoding process. 

The latest BIKE implementation [3] provides optimized versions for AVX2 and AVX-512 platforms. These implementations use 2-Karatsuba recursively to accelerate polynomial multiplication. Table 2 presents the proportion of GF _(_ 2 _)_ [ _x_ ] multiplication in the BIKE Level-1 parameter set, denoted as bikel1, measured under the same experimental setup described in Section 5.1. The results show that polynomial multiplication accounts for a significant portion of the total cycle count. 

As shown in Table 2, GF _(_ 2 _)_ [ _x_ ] multiplication is a main performance bottleneck in BIKE. Consequently, several works have focused on optimizing this operation within BIKE, including [12, 22]. 

Base multiplication is used in the final step of both the Karatsuba and Toom-Cook algorithms. These algorithms divide polynomials into _m_ parts and perform low-degree multiplications. When the polynomial size becomes less than or equal to the SIMD register size _R_ , then the base multiplication is performed. Consequently, optimizing base multiplication is important. Prior works [15, 21, 23] have also focused on optimizing base multiplication for each register size _R_ . 

We define a base multiplication (degree at most _R_ − 1) as a _**1-word multiplication**_ . Furthermore, we define GF _(_ 2 _)_ [ _x_ ] polynomials of degree _mR_ − 1 as _m_ - _**word polynomials**_ , and their multiplication as _m_ - _**word multiplication**_ . 

We implemented the base multiplication in each of the following instruction set environments: AVX2-PCLMULQDQ, AVX2-VPCLMULQDQ, and Neon-VMULL_P8. 

## **3.1.1 Base multiplication on AVX2-PCLMULQDQ** 

For the AVX2-PCLMULQDQ environment, we use the base multiplication for polynomials up to degree 255 as presented in [15]. This function divides a polynomial of degree at most 255 into four 63-degree polynomials, then performs polynomial multiplication by applying the 2-Karatsuba algorithm. Specifically, it uses the _mm_clmulepi64_si128 instruction to carry out nine multiplications of 63-degree polynomials, followed by two rounds of the 2-Karatsuba algorithm. This function, denoted as karat_karat_256 _PCLMUL, is included in Table 3 to provide a comparison across the AVX2-PCLMULQDQ and AVX2-VPCLMULQDQ instruction sets. 

## **3.1.2 Base multiplication on AVX2-VPCLMULQDQ** 

There exist no known base multiplication implementations that utilize both the AVX2 instruction set and the VPCLMULQDQ instruction. Existing AVX2-based implementations submitted by the HQC and BIKE teams, as well as the work in [12], employ base multiplication using the PCLMULQDQ instruction. On the other hand, BIKE also provides an AVX-512 implementation, and [15] presents an optimized polynomial multiplication routine over GF _(_ 2 _)_ [ _x_ ] specifically designed for AVX-512. These AVX-512 implementations utilize 512-bit VPCLMULQDQ instructions with 

123 

3 Page 8 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

**Table 3** Performance comparison of base multiplications on AVX2-PCLMULQDQ, AVX2-VPCLMULQDQ and Neon-VMULL_P8. The experimental settings for each environment are presented in section 5.1. The Clock cycles column represents the average clock cycles per 100 executions. 

|Environment|Function|Method description||Clock cycles|
|---|---|---|---|---|
|||128-bit|256-bit||
|AVX2-PCLMULQDQ|karat_karat_256_PCLMUL|2-Karatsuba|2-Karatsuba|1,958|
|AVX2-VPCLMULQDQ|karat_karat_256_VPCLMUL|2-Karatsuba|2-Karatsuba|1,927|
||karat_SB_256_VPCLMUL|2-Karatsuba|Schoolbook|1,794|
||SB_karat_256_VPCLMUL|Schoolbook|2-Karatsuba|1,768|
||SB_SB_256_VPCLMUL|Schoolbook|Schoolbook|1,570|
|Neon-VMULL_P8|karat_128_NEON|2-Karatsuba|-|10,403|
||SB_128_NEON|Schoolbook|-|12,097|



zmm registers, making them incompatible with AVX2-based architectures. 

More concretely, VPCLMULQDQ on ymm registers performs two 64-bit carry-less multiplications in parallel, reducing the relative cost of the base multiplications. While Karatsuba reduces the number of multiplications, it must compute the cross term _(A_ 0 + _A_ 1 _)(B_ 0 + _B_ 1 _)_ and perform the recombination _(A_ 0 + _A_ 1 _)(B_ 0+ _B_ 1 _)_ + _A_ 0 _B_ 0 + _A_ 1 _B_ 1 to assemble the middle part of the product, which incurs additional XOR and data-movement or permutation overhead. Consequently, despite using more multiplications, the schoolbook variant can outperform Karatsuba in this setting due to lower non-multiplication overhead and a simpler data flow. 

Accordingly, for the AVX2-VPCLMULQDQ environment, we implemented and evaluated four different base multiplication routines targeting 256-bit inputs. We investigated which combinations of algorithms at the 128-bit and 256-bit levels provide the most efficient base multiplication under this setting. The four functions are as follows: karat_karat_256_VPCLMUL This function applies the 2-Karatsuba algorithm at both the 128-bit and 256-bit levels. Since the 2-Karatsuba algorithm is nested twice, a total of 9 multiplications of 63-degree polynomials are required, whichcorrespondsto ⌈9 _/_ 2⌉= 5 VPCLMULQDQ instructions. karat_SB_256_VPCLMUL This function applies the 2- Karatsuba algorithm at the 128-bit level and the schoolbook algorithm at the 256-bit level. Since these two algorithms are combined, a total of 12 multiplications of 63-degree polynomials are required, along with ⌈12 _/_ 2⌉= 6 VPCLMULQDQ instructions. SB_karat_256_VPCLMUL This function applies the schoolbook algorithm at the 128-bit level and the 2-Karatsuba algorithm at the 256-bit level. Since these two algorithms are combined, it requires 12 multiplications of 63-degree polynomials and ⌈12 _/_ 2⌉= 6 VPCLMULQDQ instructions in total. SB_SB_256_VPCLMUL This function applies the schoolbook algorithm at both the 128-bit and 256bit levels. Since the schoolbook algorithm is nested twice, it requires 16 multiplications of 63-degree polynomials and ⌈16 _/_ 2⌉= 8 VPCLMULQDQ instructions in total. 

## **3.1.3 Base multiplication on Neon** 

For the Neon-VMULL_P8 environment, the SIMD register size _R_ is 128 bits, which differs from the 256-bit size defined for the AVX2 environment in Section 3.1. In this setting, where 64-bit carry-less multiplication is performed via the vmull_p8 primitive without ARM cryptographic extensions such as vmull_p64, we adopt the 64-bit carryless multiplication routine from [20] as the building block for our 128-bit base multiplication. 

To determine the best 128-bit base multiplication strategy in this setting, we implemented both the schoolbook method and the 2-Karatsuba algorithm and compared their performance. Table 3 shows the performance of SB_128_NEON and karat_128_NEON. While the VPCLMULQDQ environment supports parallel execution of two 64-bit multiplications, making it highly compatible with the schoolbook method, the,, Neon-VMULL_P8 environment requires 8 vmull_p8 instructions for each 64-bit multiplication. As a result, the 2-Karatsuba method is more efficient in this setting. Specifically, SB_128_NEON requires a total of 32 calls whereas karat_128_NEON requires 24 calls. All experiments were conducted under the setup described in Section 5.1. 5.1. 

Table 3 presents a performance comparison of all the aforementioned approaches, measured in clock cycles per 100 operations. All experiments were conducted under the setup described in Section 5.1. 

Amongthefour256-bitmultiplicationfunctions, SB_SB_256_VPCLMULmethod, the,, which employs the schoolbook algorithm at both the 128-bit vmull_p8 and 256-bit levels, exhibits the highest efficiency. The use a result, the of the VPCLMULQDQ instruction reduces the computational setting. complexity of multiplication, thus favoring the schoolbook calls whereas approach, which involves fewer operations such as permutaexperiments tions and XOR beyond the multiplication. Section 5.1. 5.1. 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 9 of 21 3 

**Algorithm 1** 2-Karatsuba on GF _(_ 2 _)_ [ _x_ ] 

**Require:** _A(X )_ = _A_ 1 _X_ + _A_ 0 _, B(X )_ = _B_ 1 _X_ + _B_ 0 **Ensure:** _C(X )_ = _A(X )_ × _B(X )_ 1: _C_ 0 ← _A_ 0 × _B_ 0 2: _C_ 2 ← _A_ 1 × _B_ 1 3: _C_ 1 ← _(A_ 0 + _A_ 1 _)_ × _(B_ 0 + _B_ 1 _)_ 4: _C(X )_ ← _C_ 2 _X_[2] + _(C_ 0 + _C_ 1 + _C_ 2 _)X_ + _C_ 0 

5: **return** _C(X )_ 

**Algorithm 2** 3-Karatsuba on GF _(_ 2 _)_ [ _x_ ] 

**Require:** _A(X )_ = _A_ 2 _X_[2] + _A_ 1 _X_ + _A_ 0, _B(X )_ = _B_ 2 _X_[2] + _B_ 1 _X_ + _B_ 0 **Ensure:** _C(X )_ = _A(X )_ × _B(X )_ 1: _R_ 0 ← _A_ 0 × _B_ 0 2: _R_ 1 ← _A_ 1 × _B_ 1 3: _R_ 2 ← _A_ 2 × _B_ 2 4: _R_ 3 ← _(A_ 0 + _A_ 1 _)_ × _(B_ 0 + _B_ 1 _)_ 5: _R_ 4 ← _(A_ 0 + _A_ 2 _)_ × _(B_ 0 + _B_ 2 _)_ 6: _R_ 5 ← _(A_ 1 + _A_ 2 _)_ × _(B_ 1 + _B_ 2 _)_ 7: _C_ 0 ← _R_ 0 8: _C_ 1 ← _R_ 3 + _R_ 0 + _R_ 1 9: _C_ 2 ← _R_ 4 + _R_ 0 + _R_ 1 + _R_ 2 10: _C_ 3 ← _R_ 5 + _R_ 1 + _R_ 2 11: _C_ 4 ← _R_ 2 12: _C(X )_ ← _C_ 4 _X_[4] + _C_ 3 _X_[3] + _C_ 2 _X_[2] + _C_ 1 _X_ + _C_ 0 13: **return** _C(X )_ 

## **3.2 Karatsuba algorithm** 

In this section, we describe the implementation details of the Karatsuba algorithm over GF _(_ 2 _)_ [ _x_ ]. 

## **3.2.1 2-Karatsuba algorithm** 

The 2-Karatsuba algorithm over GF _(_ 2 _)_ [ _x_ ] is performed as in Algorithm 1. For a 2 _k_ -word multiplication of _A(X )_ and _B(X )_ , the 2-Karatsuba algorithm splits the polynomials as _A(X )_ = _A_ 1 _X_ + _A_ 0 and _B(X )_ = _B_ 1 _X_ + _B_ 0, where _A_ 0, _A_ 1 and _B_ 0, _B_ 1 are all _k_ -word polynomials. Thus, this process requires three _k_ -word multiplications. 

If the polynomials _A_ and _B_ have odd lengths of 2 _k_ + 1, then _A_ 1 and _B_ 1 are _k_ -word, and _A_ 0 and _B_ 0 are ( _k_ + 1)-word polynomials. In this case, the internal multiplications include one _k_ -word multiplication and two ( _k_ + 1)-word multiplications. The lengths of the internal multiplications required in the 2-Karatsuba algorithm are shown in Table 4. 

## **3.2.2 3-Karatsuba algorithm** 

The 3-Karatsuba algorithm over GF _(_ 2 _)_ [ _x_ ] is performed as in Algorithm 2. For a 3 _k_ -word multiplication of _A(X )_ and _B(X )_ , the 3-Karatsuba algorithm splits the polynomials as _A(X )_ = _A_ 2 _X_[2] + _A_ 1 _X_ + _A_ 0 and _B(X )_ = _B_ 2 _X_[2] + _B_ 1 _X_ + _B_ 0, where _A_ 0, _A_ 1, _A_ 2 and _B_ 0, _B_ 1, _B_ 2 are all _k_ -word polynomials. 

**Table 4** Internal multiplication counts by operand length (in words) for 2-, 3-, 5-Karatsuba algorithm in the AVX2 setting. 

||Algorithm|Length|# of internal<br>_k_-word|multiplications<br>_(k_+1_)_-word|
|---|---|---|---|---|
||2-Karatsuba|2_k_<br>2_k_+1|3<br>1|0<br>2|
||3-Karatsuba|3_k_|6|0|
|||3_k_+1|3|3|
|||3_k_+2|1|5|
||5-Karatsuba|5_k_|15|0|



This process requires six polynomial multiplications, all of which are _k_ -word multiplications. 

If the polynomials _A, B_ are (3 _k_ + 1)-word polynomials, then _A_ 2 and _B_ 2 are( _k_ +1)-word,while _A_ 1 _, A_ 0 _, B_ 1,and _B_ 0 are _k_ -word polynomials. In this case, the internal multiplications are three _k_ -word and three ( _k_ + 1)-word multiplications. 

Also, if the polynomials _A, B_ are (3 _k_ +2)-word polynomials, then _A_ 2 and _B_ 2 are _k_ -word polynomials and _A_ 1 _, A_ 0 _, B_ 1, and _B_ 0 are ( _k_ + 1)-word polynomials. In this case, the internal multiplications are five in _k_ + 1-word and one in _k_ -word multiplications. The word of the required internal multiplications using the 3-Karatsuba algorithm is shown in Table 4. 

## **3.2.3 5-Karatsuba algorithm** 

For a 5 _k_ -word multiplication of _A(X )_ and _B(X )_ , the 5- Karatsuba algorithm splits the polynomials as _A(X )_ = _A_ 4 _X_[4] + _A_ 3 _X_[3] + _A_ 2 _X_[2] + _A_ 1 _X_ + _A_ 0 and _B(X )_ = _B_ 4 _X_[4] + _B_ 3 _X_[3] + _B_ 2 _X_[2] + _B_ 1 _X_ + _B_ 0, where _Ai_ and _Bi_ are all _k_ -word polynomials for 0 ≤ _i_ ≤ 4. As shown in Algorithm 3.2.3, this process requires 15 _k_ -word polynomial multiplications. The computational complexity of the 5-Karatsuba algorithm is _O(n_[log][5][ 15] _)_ , which is large compared to other algorithms. Therefore, we only consider the 5-Karatsuba algorithm when the word of the multiplication is a multiple of 5. 

## **3.3 Toom-Cook algorithm** 

Toom-Cook _m_ -way requires 2 _m_ − 1 evaluation points, and selecting them over GF _(_ 2 _)_ [ _x_ ] is nontrivial. Bodrato [7] proposed using the indeterminate _x_ to define evaluation points in GF _(_ 2 _)_ [ _x_ ], for example {0 _,_ 1 _, x, x_ + 1 _,_ ∞} for 3-way and {0 _,_ 1 _, x, x_ +1 _,_ 1 _/x,_ 1 _/(x_ +1 _),_ ∞} for 4-way. However, while increasing _m_ reduces the number of elementary multiplications asymptotically, it also leads to more complex evaluation points and a more expensive interpolation step, which can introduce substantial overhead in practice. Consistent with this observation, when we ran the tuning procedure provided by gf2x over 2048 input bit-lengths from 64 bits up to 

123 

3 Page 10 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

**Algorithm 3** 5-Karatsuba on GF _(_ 2 _)_ [ _x_ ] **Algorithm 4** Toom-Cook 3-way on GF _(_ 2 _)_ [ _x_ ] [23] **Require: Require:** _A(X )_ = _A_ 2 _X_[2] + _A_ 1 _X_ + _A_ 0, _A(X )_ = _A_ 4 _X_[4] + _A_ 3 _X_[3] + _A_ 2 _X_[2] + _A_ 1 _X_ + _A_ 0 _B(X )_ = _B_ 2 _X_[2] + _B_ 1 _X_ + _B_ 0 _B(X )_ = _B_ 4 _X_[4] + _B_ 3 _X_[3] + _B_ 2 _X_[2] + _B_ 1 _X_ + _B_ 0 **Ensure:** _C(X )_ = _A(X )_ × _B(X )_ **Ensure:** _C(X )_ = _A(X )_ × _B(X )_ Let _W_ = _x[w]_ 1: _R_ 0 ← _A_ 0 × _B_ 0 **Evaluation :** 2: _R_ 1 ← _A_ 1 × _B_ 1 1: _C_ 0 ← _A_ 1 _W_ + _A_ 2 _W_[2] 3: _R_ 2 ← _A_ 2 × _B_ 2 2: _C_ 4 ← _B_ 1 _W_ + _B_ 2 _W_[2] 4: _R_ 3 ← _A_ 3 × _B_ 3 3: _C_ 5 ← _A_ 0 + _A_ 1 + _A_ 2 5: _R_ 4 ← _A_ 4 × _B_ 4 4: _C_ 2 ← _B_ 0 + _B_ 1 + _B_ 2 6: _R_ 5 ← _(A_ 0 + _A_ 1 _)_ × _(B_ 0 + _B_ 1 _)_ 5: _C_ 1 ← _C_ 2 × _C_ 5 = _A(_ 1 _)_ × _B(_ 1 _)_ 7: _R_ 6 ← _(A_ 0 + _A_ 2 _)_ × _(B_ 0 + _B_ 2 _)_ 6: _C_ 5 ← _C_ 5 + _C_ 0 8: _R_ 7 ← _(A_ 0 + _A_ 3 _)_ × _(B_ 0 + _B_ 3 _)_ 7: _C_ 2 ← _C_ 2 + _C_ 4 9: _R_ 8 ← _(A_ 0 + _A_ 4 _)_ × _(B_ 0 + _B_ 4 _)_ 8: _C_ 0 ← _C_ 0 + _A_ 0 10: _R_ 9 ← _(A_ 1 + _A_ 2 _)_ × _(B_ 1 + _B_ 2 _)_ 9: _C_ 4 ← _C_ 4 + _B_ 0 11: _R_ 10 ← _(A_ 1 + _A_ 3 _)_ × _(B_ 1 + _B_ 3 _)_ 10: _C_ 3 ← _C_ 2 × _C_ 5 = _A(W_ + 1 _)_ × _B(W_ + 1 _)_ 12: _R_ 11 ← _(A_ 1 + _A_ 4 _)_ × _(B_ 1 + _B_ 4 _)_ 11: _C_ 2 ← _C_ 0 × _C_ 4 = _A(W )_ × _B(W )_ 13: _R_ 12 ← _(A_ 2 + _A_ 3 _)_ × _(B_ 2 + _B_ 3 _)_ 12: _C_ 0 ← _A_ 0 × _B_ 0 = _A(_ 0 _)_ × _B(_ 0 _)_ 14: _R_ 13 ← _(A_ 2 + _A_ 4 _)_ × _(B_ 2 + _B_ 4 _)_ 13: _C_ 4 ← _A_ 2 × _B_ 2 = _A(_ ∞ _)_ × _B(_ ∞ _)_ 15: _R_ 14 ← _(A_ 3 + _A_ 4 _)_ × _(B_ 3 + _B_ 4 _)_ **Interpolation:** 16: _C_ 0 ← _R_ 0 14: _C_ 3 ← _C_ 3 + _C_ 2 17: _C_ 1 ← _R_ 5 + _R_ 0 + _R_ 1 15: _C_ 2 ← _C_ 2 + _C_ 0 18: _C_ 2 ← _R_ 1 + _R_ 6 + _R_ 0 + _R_ 2 16: _C_ 2 ← _C_ 2 _/W_ + _C_ 3 19: _C_ 3 ← _R_ 7 + _R_ 0 + _R_ 3 + _R_ 9 + _R_ 1 + _R_ 2 17: _C_ 2 ←{ _C_ 2 + _(_ 1 + _W_[3] _)C_ 4} _/(_ 1 + _W )_ 20: _C_ 4 ← _R_ 2 + _R_ 8 + _R_ 0 + _R_ 4 + _R_ 10 + _R_ 1 + _R_ 3 18: _C_ 1 ← _C_ 1 + _C_ 0 21: _C_ 5 ← _R_ 11 + _R_ 1 + _R_ 4 + _R_ 12 + _R_ 2 + _R_ 3 19: _C_ 1 ← _C_ 1 + _C_ 0 22: _C_ 6 ← _R_ 3 + _R_ 13 + _R_ 2 + _R_ 4 20: _C_ 3 ← _C_ 3 + _C_ 1 23: _C_ 7 ← _R_ 14 + _R_ 3 + _R_ 4 21: _C_ 3 ← _C_ 3 _/(W_[2] + _W )_ 24: _C_ 8 ← _R_ 4 25: _C(X )_ ← _C_ 8 _X_[8] + _C_ 7 _X_[7] + _C_ 6 _X_[6] + _C_ 5 _X_[5] 23:22: _CC_ 12 ←← _CC_ 12 + + _C C_ 23 + _C_ 4 + _C_ 4 _X_[4] + _C_ 3 _X_[3] + _C_ 2 _X_[2] + _C_ 1 _X_ + _C_ 0 24: _C(X )_ ← _C_ 4 _X_[4] + _C_ 3 _X_[3] + _C_ 2 _X_[2] + _C_ 1 _X_ + _C_ 0 26: **return** _C(X )_ 25: **return** _C(X )_ 

64 × 2048 = 131 _,_ 072 bits, Toom-Cook 4-way was selected in only 3 cases and the measured gain over the 3-way variant was below 1%. Therefore, in this work, we focus on ToomCook 3-way and use the evaluation points {0 _,_ 1 _, x, x_ +1 _,_ ∞}. 

We now describe the Toom-Cook 3-way algorithm over GF _(_ 2 _)_ [ _x_ ] used in this work. Specifically, we follow the algorithm presented in Section 2.3 of [23]. 

Toom-Cook 3-way splits _A(X )_ and _B(X )_ into three terms as _A(X )_ = _A_ 2 _X_[2] + _A_ 1 _X_ + _A_ 0 and _B(X )_ = _B_ 2 _X_[2] + _B_ 1 _X_ + _B_ 0 and performs five internal multiplications _C( p)_ = _A( p)_ × _B( p)_ at the evaluation points _p_ ∈{0 _,_ 1 _, W , W_ + 1 _,_ ∞}. In particular, the operands _A( p)_ (or _B( p)_ ) involve linear combinations of _A_ 0, _A_ 1, _A_ 2, _A_ 1 _W_ , and _A_ 2 _W_[2] (or _B_ 0, _B_ 1, _B_ 2, _B_ 1 _W_ , and _B_ 2 _W_[2] ). Therefore, the operand sizes of these internal multiplications depend not only on the choice _W_ = _x[w]_ , but also on the choice of the splitting base _X_ , which determines the word lengths of _A_ 0 _, A_ 1 _, A_ 2 _, B_ 0 _, B_ 1 _, B_ 2. 

In the AVX2 environment, where polynomials are stored as 256-bit data arrays, we consider three variants: TC3_256 with _W_ = _x_[256] , TC3_128 with _W_ = _x_[128] , and TC3_64 with _W_ = _x_[64] . If the length in words of A and B is a multiple of 3, i.e., 3k, we use the balanced split with _X_ = _x_[256] _[k]_ , so that _A_ 0 _, A_ 1 _, A_ 2 _, B_ 0 _, B_ 1 _, B_ 2 each occupy _k_ words. The operand length for internal multiplication is determined based on the W value of each variant. However, when the length is not a 

multiple of 3, exact division into three equal parts is impossible. In such cases, the split base _X_ is determined as shown in Table 5 for each case. Consequently, the operand word lengths and the number of internal multiplications are summarized in Table 6. 

## **3.3.1 Splitting strategy for irregular lengths** 

Let _m_ = 3 _k_ + _r_ with _r_ ∈{0 _,_ 1 _,_ 2} denote the word length of the inputs _A_ and _B_ . When _r_ ̸= 0, we handle the irregular length by using an unbalanced split. In our setting, the split base _X_ is chosen depending on the TC3 variant, and _W_ = _x[w]_ is fixed by the variant as well. For each TC3 variant (TC3_256, TC3_128, TC3_64) and each case _m_ ∈ {3 _k,_ 3 _k_ + 1 _,_ 3 _k_ + 2}, Table 5 specifies the chosen split base _X_ and, as a consequence, the operand word lengths of the five evaluation products _(C(_ 0 _), C(_ 1 _), C(W ), C(W_ + 1 _), C(_ ∞ _))_ . Irregular lengths do not require any special runtime handling. Once _(m, W )_ is fixed, the five internal multiplication sizes are determined, and the corresponding code path can be generated and selected without runtime branching. 

Example for _n_ = 17669 on AVX2. We demonstrate the irregular length handling with Toom-Cook 3-way. For a polynomial of degree _n_ − 1, in the AVX2 setting, the length 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 11 of 21 3 

|||
|---|---|
|**Table 5** Split base _X_ and<br>operand lengths (in words) for<br>the fve evaluation products<br>_C(p)_= _A(p)B(p)_forTC3n_,<br>in theAVX2setting.|Algorithm<br>Length<br>Split base _X_<br>Operand length of_C(p)_= _A(p)B(p)_<br>_C(_0_)_<br>_C(_1_)_<br>_C(W)_<br>_C(W_ +1_)_<br>_C(_∞_)_|
||TC3_256<br>3_k_<br>_x_256_k_<br>_k_<br>_k_<br>_k_+2<br>_k_+2<br>_k_<br>3_k_+1<br>_x_256_(k_+1_)_<br>_k_+1<br>_k_+1<br>_k_+2<br>_k_+2<br>_k_−1<br>3_k_+2<br>_x_256_(k_+1_)_<br>_k_+1<br>_k_+1<br>_k_+2<br>_k_+2<br>_k_<br>TC3_128<br>3_k_<br>_x_256_k_<br>_k_<br>_k_<br>_k_+1<br>_k_+1<br>_k_<br>3_k_+1<br>_x_256_k_+128<br>_k_+1<br>_k_+1<br>_k_+1<br>_k_+1<br>_k_<br>3_k_+2<br>_x_256_(k_+1_)_<br>_k_+1<br>_k_+1<br>_k_+2<br>_k_+2<br>_k_<br>TC3_64<br>3_k_<br>_x_256_k_<br>_k_<br>_k_<br>_k_+1<br>_k_+1<br>_k_<br>3_k_+1<br>_x_256_k_+128<br>_k_+1<br>_k_+1<br>_k_+1<br>_k_+1<br>_k_<br>3_k_+2<br>_x_256_k_+192<br>_k_+1<br>_k_+1<br>_k_+1<br>_k_+1<br>_k_+1|



**Table 6** Internal multiplication counts by operand length (in words) for TC3 n_ in the AVX2 setting. 

|Algorithm|Length|# of internal multiplications|# of internal multiplications|||
|---|---|---|---|---|---|
|||_(k_−1_)_-word|_k_-word|_(k_+1_)_-word|_(k_+2_)_-word|
|TC3_256|3_k_|0|3|0|2|
||3_k_+1|1|0|2|2|
||3_k_+2|0|1|2|2|
|TC3_128|3_k_|0|3|2|0|
||3_k_+1|0|1|4|0|
||3_k_+2|0|1|2|2|
|TC3_64|3_k_|0|3|2|0|
||3_k_+1|0|1|4|0|
||3_k_+2|0|0|5|0|



in words is _m_ = ⌈ _n/_ 256⌉= ⌈17669 _/_ 256⌉= 70. Since 70 = 3 · 23 + 1, we have _k_ = 23 and apply the unbalanced split rule for the _(_ 3 _k_ + 1 _)_ case. 

As a concrete instantiation, we consider the TC3_64 variant. Table 5 indicates that the split base is _X_ = _x_[256] _[k]_[+][128] and the evaluation point is _W_ = _x_[64] . Hence we write _A(x)_ = _A_ 0 _(x)_ + _A_ 1 _(x)X_ + _A_ 2 _(x)X_[2] and _B(x)_ = _B_ 0 _(x)_ + _B_ 1 _(x)X_ + _B_ 2 _(x)X_[2] , where the unbalanced split yields 

deg _(A_ 0 _),_ deg _(A_ 1 _) <_ 256 _k_ + 128 _,_ deg _(A_ 2 _) <_ 256 _k,_ 

and the same bounds hold for _B_ 0 _, B_ 1 _, B_ 2. 

To see why the evaluation products may require _(k_ + 1 _)_ words, consider the terms appearing in _A(W )_ = _A_ 0+ _A_ 1 _W_ + _A_ 2 _W_[2] . Since deg _(W )_ = 64, we have 

deg _(A_ 1 _W ) < (_ 256 _k_ + 128 _)_ + 64 = 256 _k_ + 192 _,_ deg _(A_ 2 _W_[2] _) < (_ 256 _k)_ + 128 = 256 _k_ + 128 _._ 

Consequently, Table 5 indicates that computing _C(_ 0 _)_ , _C(_ 1 _)_ , _C(W )_ , and _C(W_ + 1 _)_ requires _(k_ + 1 _)_ -word multiplications, and computing _C(_ ∞ _)_ = _A_ 2 × _B_ 2 requires one additional _k_ -word multiplication. 

## **3.3.2 Comparison between TC3_256, TC3_128, and TC3_64** 

From Table 6, we observe that TC3_64 is more efficient in terms of internal multiplication compared to TC3_256. However, aside from internal multiplication, TC3_256 outperforms TC3_64. For instance, when dividing by _(_ 1 + _W )_ , TC3_256 shifts the polynomial in 256-bit units, whereas TC3_64 shifts in 64-bit units. Since the polynomial coefficients are stored in a 256-bit data array in the AVX2 environment, the small-scale shifting in TC3_64 results in relatively higher overhead. In contrast, TC3_128 strikes a balance between these two extremes. Thus, each case has its own advantages and disadvantages, and we consider all three cases. 

Therefore deg _(A(W )) <_ 256 _k_ +192, i.e., _A(W )_ is a _(k_ +1 _)_ - word polynomial. The same reasoning applies to _B(W )_ , and also to _A(W_ + 1 _)_ and _B(W_ + 1 _)_ since addition in GF _(_ 2 _)_ [ _x_ ] does not increase degree. 

123 

3 Page 12 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

## **4 Optimization of GF(2)[x] multiplication** 

Karatsuba and Toom-Cook algorithms both require smaller multiplications within their internal processes. In this section, we explore optimal combinations of these algorithms to improve multiplication performance over GF _(_ 2 _)_ [ _x_ ]. 

To optimize _m_ max-word multiplication, we adopt an inductive bottom-up search procedure (Fig. 1). We start from _m_ = 2 and, for each word length _m_ , define a candidate set _Sm_ of all applicable decomposition algorithms (e.g., Karatsuba and Toom-Cook variants) for _m_ -word inputs. For each candidate _A_ ∈ _Sm_ , we generate the corresponding branch-free implementation and measure its average cycle count, denoted by _ccA_ . When generating code for length _m_ , all internal submultiplications of smaller lengths _mi < m_ are implemented using the previously selected optimal routines _A_[∗] _mi_[,][ensur-] ing a consistent execution model across the search. We then select the optimal algorithm for length _m_ as _A_[∗] _m_[=][ arg] _A_[min] ∈ _Sm ccA,_ 

storeitscode,andrepeatthisprocedurefor _m_ = 3 _,_ 4 _, . . . , m_ max. For example, in the AVX2 environment, _S_ 2 includes 2- Karatsuba and TC3_64 for 2-word multiplication, and the candidate with the lowest measured _ccA_ is selected. This inductive process enables accurate performance comparisons without conditional branches during execution and yields an optimal combination of decomposition strategies up to the target length _m_ max. Since the cycle count is obtained by executing the generated code on the target platform, it reflects microarchitectural effects such as memory-access patterns, cache behavior, and pipeline behavior. Therefore, although we do not explicitly model cache or memory factors in the search, the inductive selection implicitly optimizes for these effects under the same execution conditions as the final implementation. 

Note that the gf2x library conducts an evaluation of the entire set of candidate combinations in a manner similar to our approach. However, the gf2x library is a generalpurpose solution that supports carry-less polynomial multiplication for arbitrary input degrees. Hence, gf2x employs table look-ups and conditional branches during execution. While such a design is necessary for supporting arbitrary degrees, conditional branches can cause pipeline flushes and introduce control-flow overheads that degrade performance. As a result, a combination identified as optimal under a branch-based execution model is not guaranteed to remain optimal once implemented in a branch-free manner. 

In contrast, our goal is to generate highly efficient multiplication code for fixed polynomial degrees, to use in cryptographic schemes such as HQC and BIKE. We therefore generate branch-free source code offline for each target 

**==> picture [220 x 439] intentionally omitted <==**

**Fig. 1** The inductive bottom-up search process of the GFmulOpt framework. The system determines the optimal algorithm _A_[∗] _m_[by using] optimal _A_[∗] _mi_[for internal multiplications and measuring cycles.] 

degree and perform the exploration of algorithmic combinations using the same branch-free execution model. By ensuring consistency between the exploration phase and the final implementation, our approach guarantees that the selected combination is truly optimal for branch-free execution in fixed-degree settings. 

We use four files: gfopt_head, gfopt_head_init, gfopt_middle, and gfopt_tail, which have the following initial state. 

- gfopt_head : Initially an empty file. 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 13 of 21 3 

- gfopt_head_init : Contains the header code and the code of the base multiplication function and other necessary functions. It is used first in order to initialize gfopt_head. 

## **4.3 gfopt_tail** 

This file consists of the following five codes. 

- gfopt_middle : Initially an empty file. 

- gfopt_tail : Contains five pieces of code, which are described in more detail in Section 4.3. 

These files are sequentially combined to generate gfopt_ len m_ .c, and then compiled and executed. The executed program then finds the most efficient algorithm for _m_ -word multiplication and modifies gfopt_head and gfopt_middle based on the result. It will then combine these files in turn to create gfopt_len_( _m_ + 1).c, and the process is repeated until _m_ reaches the target length _mmax_ . For clarity, the remainder of this section will use the AVX2 environment as an example. 

## **4.1 gfopt_head** 

When generating gfopt_len m_ .c, the file contains the following three codes. 

- Code for measuring the average cycle count taken by performing _m_ -word polynomial multiplication using the six algorithms. 

- Code to output the function code of the algorithm with the lowest cycles count among the six algorithms to gfopt_head. 

- Code to output the codes for the six algorithms for _(m_ + 1 _)_ -word polynomial multiplication to gfopt_middle. 

- Codeforconcatenating gfopt_head, gfopt_middle, and gfopt_tail to generate gfopt_len_( _m_ +1).c. 

- Code for compiling gfopt_len_( _m_ +1).c and executing it. 

Unlike gfopt_head and gfopt_middle, which are modified as the measurements are repeated, gfopt_tail 

## **4.4 The process of optimization** 

- Code for functions of divide_by_x_plus_one _256, divide_by_x_plus_one_128,and divide _by_x_plus_one_64. 

- Code for the function of base multiplication. 

- Code for functions of the algorithms with the smallest number of cycles in 2 _,_ 3 _,_ · · · _,_ ( _m_ − 1)-word multiplication, respectively. 

divide_by_x_plus_one_256, divide_by_x_plus_ one_128, and divide_by_x_plus_one_64 are functions required by TC3_256, TC3_128, and TC3_64, respectively,andbasemultiplicationisthefunctiondescribed in 3.1. At first, gfopt_head is created by copying gfopt_head_init, which contains the code for base multiplication along with those functions. Then, each time gfopt_len m_ is executed, the code of the _m_ -word multiplication functions is appended. 

## **4.2 gfopt_middle** 

When generating gfopt_len m_ .c, the file contains the function code for the up to six algorithms of _m_ -word multiplication to be compared. Depending on _m_ , there can be fewer than six functions. For example, when generating gfopt_len_3.c, only the 2-Karatsuba, 3-Karatsuba, and TC3_64 algorithms are included in gfopt_middle, as these are the only applicable functions for 3-word multiplication. 

GF _(_ 2 _)_ [ _x_ ] multiplication is optimized in the following order, and the resulting code is stored in the gfopt_len mmax_ .c 

- Step 1: Copy gfopt_head_init to gfopt_head. 

- Step2:Create,compile,andrunthefile gfopt_len_2.c by concatenating gfopt_head, gfopt_middle, and gfopt_tail. During execution, Steps 3 through 6, as described below, are executed. 

- Step 3: Compute the 2-word polynomial multiplication with different algorithms and measure the average number of cycles for each algorithm. 

- Step 4: Output the algorithm code with the lowest cycle count from the results obtained in Step 3 to gfopt_head. The output from this step is appended into the existing gfopt_head code. 

- Step 5: Print the code of the algorithms for 2-word polynomial multiplication to gfopt_middle. In this step, the existing codes in gfopt_middle are cleared before the output is written. 

- Step6:Concatenatethepartialsourcefiles gfopt_head, gfopt_middle,and gfopt_tail tocreate gfopt_ 

len_3.c, then compile and execute it. During execution,steps3through6areperformedwith3-wordpolynomialmultiplicationandrepeateduntil gfopt_len mmax_ .c is executed. 

123 

3 Page 14 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

Using the proposed method, we can obtain the most efficient _m_ max-word GF _(_ 2 _)_ [ _x_ ] polynomial multiplication algorithm within our considered search space. For an _m_ - word multiplication algorithm, all internal multiplications, such as the _m_ 1-, _m_ 2-, and _m_ 3-word cases, use the most efficient algorithms previously selected for each length. For irregular operand lengths, the optimization procedure follows the splitting rules summarized in Section 3.2 and 3.3.1, and instantiates the corresponding internal multiplications accordingly. By applying this selection process inductively, the resulting _mmax_ -word multiplication algorithm is optimal within this restricted set of candidates. More specifically, the obtained algorithm is the most efficient among those utilizing 2-, 3-, and 5-way Karatsuba, TC3_64, TC3_128, and TC3_256. Repeating this process up to length _mmax_ yields the most efficient combination of multiplication algorithms. 

the BGF-flip decoder and does not include BIKE-flip, we used the BGF-flip version in our experiments. Although the number of error-correction iterations (NbIter) is 5 in BGF-flip and 7 in BIKE-flip, the BGF-flip decoder performs two additional syndrome computations in the first iteration. Therefore, the total number of multiplications is nearly the same, and the performance difference between the two decoders is expected to be negligible. 

## **5.1 Experimental setup** 

Table 7 summarizes each experimental environment. For AVX2-based experiments, Turbo Boost and hyper-threading were disabled to ensure consistent measurements. Since the Raspberry Pi 4 does not support the ARM cryptographic extension, the vmull_p64 instruction is unavailable on this platform. Therefore, we used the vmull_p8 instruction for carry-less multiplication over GF _(_ 2 _)_ [ _x_ ]. 

## **5 Experimental results and comparisons** 

For stable cycle-count measurements, Turbo Boost and hyper-threading were disabled for AVX2 setup. Each target operation was executed 100,000 times and we report the average clock cycles. On AVX2 platforms, cycles were measured using the TSC (timestamp counter). On Neon platforms, cycles were measured using the PMCCNTR_EL0 performance counter. Since PMCCNTR_EL0 is a per-core counter, we pinned the benchmark process to a fixed CPU core to ensure that the start and end readings are taken on the same core. 

This section compares our polynomial-multiplication get method over GF _(_ 2 _)_ [ _x_ ] against state-of-the-art multiplicathe tion methods, including those in the official HQC/BIKE implementations, the gf2x library, and previously proposed optimizations. We evaluate all methods across three instruction-set environments, namely AVX2-PCLMULQDQ, AVX2-VPCLMULQDQ, and Neon. We evaluate all methods acrossthreeinstruction-setenvironments,namely AVX2-PCLMULQDQ, AVX2-VPCLMULQDQ, and Neon, as summarized in Table 7. For each environment and for each parameter set of HQC **5.2** and BIKE, we measure the cycle counts of the underlying GF _(_ 2 _)_ [ _x_ ] multiplication as implemented by each method, and we also report the corresponding end-to-end KEM actually performance when applicable. We perform the following evaluations: 

## **5.2 Benchmarking for GF** _**(**_ **2** _**)**_ **[** _**x**_ **] multiplication** 

We benchmark the GF _(_ 2 _)_ [ _x_ ] multiplication routines that are actually used inside HQC and BIKE for each parameter set and each instruction-set environment. We consider three environments, namely AVX2-PCLMULQDQ, AVX2-VPCLM ULQDQ, and Neon-VMULL_P8, and report both (i) instruction counts and (ii) measured cycle counts. Table 8 summarizes the results using three metrics: _cnt_ mul (the number of carry-less multiplication instructions), _cnt_ xor (the number of XOR instructions), and _cc_ (the measured cycle count). Here, _cnt_ mul counts PCLMULQDQ on AVX2-PCLMULQDQ, VPCLMULQDQ on AVX2-VPCLMULQDQ, and vmull_p8 (PMULL) on Neon-VMULL_P8. This combined view is useful because the observed cycle counts closely follow the combined effect of _cnt_ mul and _cnt_ xor, revealing the platformdependent trade-offs of different decomposition strategies. Reporting instruction counts _cnt_ mul _, cnt_ xor with measured cycles ( _cc_ ) provides a explanation of the performance differences between methods under the same instruction set. To illustrate how the selected decomposition depends on the instruction set environments, Appendix A provides decomposition trees for HQC-1 and bikel1 across AVX2-PCLMULQDQ, AVX2-VPCLMULQDQ, and Neon-V 

1. For HQC, we compare the polynomial-multiplication methodinthelatestofficialimplementation[2],the gf2x library [16], the FFT-based method of [20] when applicable, and our method. 

2. For BIKE, we compare the polynomial-multiplication methodinthelatestofficialimplementation[3],the gf2x library [16], the method of [12], and our method. 

3. We also provide an instruction-count analysis of the polynomial-multiplication routines for these methods, reporting ( _cnt_ mul, _cnt_ xor) together with measured cycle counts as summarized in table 8. 

For the BIKE experiments, we clarify the decoder choice used in our measurements. After Round 4 of NIST PQC standardization, BIKE switched its decoder from BGF-flip to BIKE-flip to reduce the decryption failure rate. However, since the official BIKE implementation only includes 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 15 of 21 3 

**Table 7** Experimental setup by instruction set. 

|instruction set|AVX2|Neon|
|---|---|---|
|Platform|Desktop PC (WSL2)|Raspberry Pi 4|
|CPU|Intel® Core i7-13700K|ARM Cortex-A72|
||(Raptor Lake)|(ARMv8-A)|
|L2 Cache|24 MiB|1 MiB|
|L3 Cache|30 MiB|N/A|
|Memory|32 GiB|8 GiB|
|OS|Ubuntu 22.04.2 LTS|Linux (Raspbian)|
|Compiler|GCC 11.4.0|GCC 10.2.1|
|Kernel Version|6.6.87.2-microsoft-standard-WSL2|6.1.21-v8+|
|Compiler Flags|-O3 -mavx2 -mpclmul|-O3|
||(-mvpclmulqdqforAVX2-VPCLMULQDQ)||



MULL_P8. Decomposition choices for the remaining parameter sets are reflected in the instruction counts and cycle counts in Table 8. 

## **5.2.3 Neon-VMULL_P8** 

In the Neon-VMULL_P8 environment, Table 8 compares our method against the portable (reference) implementations of HQC and BIKE, as well as the additive-FFT-based HQC implementation of [20]. 

## **5.2.1 AVX2-PCLMULQDQ** 

Since the official releases of HQC and BIKE do not provide Neon-optimizedimplementations,weuse Neon-ported baselines for comparison. For HQC, we use the Neonported implementation provided in [20], which is marked as [2]* in Table 8. This Neon port preserves the original decomposition strategy (e.g., Toom3Mult(Karat3) or Toom3Mult(Karat5)) while adapting the base multiplication layer to the target Neon environment. 

In the AVX2-PCLMULQDQ environment, Table 8 compares the official scheme implementations, gf2x, and our method under the same instruction set. For HQC, we additionally compare against the recent FFT-based implementation of [20], while for BIKE we include the optimized implementation of [12]. Note that the AVX2 code reported in [15] has been incorporated into the current official HQC release. Hence, the [2] row in Table 8 corresponds to the same AVX2 baseline as [15].15].]. 

For BIKE, we constructed a Neon-ported baseline from baseline as [15].15].]. the official BIKE reference implementation. In particular, For the AVX2 HQC baseline [2], the decomposition strucwe ported the Karatsuba routines and the base multiplicatureisfixedanddescribedinSection2.6.1. Toom3Mult(Karat3)tion routines so that they use Neon intrinsics in the target isusedfor HQC-1 and HQC-3,and Toom3Mult(Karat5) environment. is used for HQC-3, with recursive 2-way Karatsuba at deeper Because the base multiplication width is reduced comlevels. In contrast, GFmulOpt selects degree-specific decompared with the AVX2-side implementation, the lower-level position trees by branch-free bottom-up search. For HQC-1, 2-Karatsuba recursion requires one additional layer in the the resulting decomposition tree is shown in 2. Compared Neon port. Moreover, because our target platform does not port. Moreover, because our target platform does not with the [2] baseline, the GFmulOpt-selected tree reduces support the ARM cryptographic extension, vmull_p64 is vmull_p64 is is both carry-less multiplication counts and XOR counts in unavailable, and carry-less multiplication is performed using Table 8, which is reflected in lower measured cycle counts. 

Because the base multiplication width is reduced compared with the AVX2-side implementation, the lower-level 2-Karatsuba recursion requires one additional layer in the Neon port. Moreover, because our target platform does not port. Moreover, because our target platform does not support the ARM cryptographic extension, vmull_p64 is vmull_p64 is is unavailable, and carry-less multiplication is performed using vmull_p8. 

## **5.2.2 AVX2-VPCLMULQDQ** 

## **5.3 Performance analysis** 

In the AVX2-VPCLMULQDQ environment, Table 8 compares our method against the official HQC and BIKE implementations [2, 3], as well as the optimized BIKE implementation of [12]. Since these baselines do not use VPCLMULQDQ, we additionally report their *-marked variants obtained by replacing only the base-multiplication routine with our SB_SB_256_VPCLMUL routine while all other components remain unchanged. 

To analyze the speedups, we interpret our results through two operation counts in the polynomial multiplication: the number of carry-less multiplication instructions ( _cnt_ mul) and the number of XOR instructions ( _cnt_ xor). For each environment and parameter set of HQC and BIKE, we report _cnt_ mul and _cnt_ xor together with the measured cycle counts ( _cc_ ) for the polynomial multiplication in Table 8. This analysis relates the measured cycles to _cnt_ mul and _cnt_ xor. 

123 

3 Page 16 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

**Table 8** Instruction-count analysis and measured cycle counts for GF _(_ 2 _)_ [ _x_ ] polynomial multiplication in HQC and BIKE. Here, _cnt_ mul denotesthe numberofcarry-lessmultiplicationinstructionsusedineach environment (PCLMULQDQ for AVX2-PCLMULQDQ, VPCLMULQDQ 

for AVX2-VPCLMULQDQ, and vmull_p8 for Neon-VMULL_P8), _cnt_ xor denotes the number of XOR instructions, and _cc_ denotes the measured clock-cycle count. 

|Environment|Method|HQC-1|||HQC-3|||HQC-5|||
|---|---|---|---|---|---|---|---|---|---|---|
|||_cnt_mul|_cnt_xor|_cc_|_cnt_mul|_cnt_xor|_cc_|_cnt_mul|_cnt_xor|_cc_|
|AVX2-PCLMULQDQ|[2]|7,290|24,618|24,340|21,870|73,538|73,031|54,675|183,269|182,491|
||[16]|7,215|34,299|26,831|21,751|101,590|79,667|43,128|201,267|166,915|
||[20]|-|-|51,312|-|-|123,475|-|-|180,976|
||[20](GFNI)|-|-|34,970|-|-|90,994|-|-|112,510|
||This work|7,263|22,625|19,992|21,789|67,717|60,865|41,796|138,587|124,780|
|AVX2-VPCLMULQDQ|[2]*|6,480|13,278|15,260|19,440|39,518|43,785|6,075|43,544|106,859|
||This work|6,464|13,017|14,226|17,496|36,958|42,719|5,030|36,902|88,902|
|Neon-VMULL_P8|[2]*|58,320|154,680|301,471|174,960|464,888|904,462|437,400|1,165,696|2,245,668|
||[20]|-|-|356,783|-|-|857,009|-|-|1,410,745|
||This work|51,696|120,424|273,176|147,528|344,636|785,803|298,008|717,143|1,775,794|
||**BIKE**||||||||||
|Environment|Method|bikel1|||bikel3|||bikel5|||
|||_cnt_mul|_cnt_xor|_cc_|_cnt_mul|_cnt_xor|_cc_|_cnt_mul|_cnt_xor|_cc_|
|AVX2-PCLMULQDQ|[3]|5,391|17,307|15,739|15,885|51,303|48,578|38,331|123,603|128,225|
||[16]|4,660|20,467|16,138|11,529|56,694|47,327|22,654|139,929|102,864|
||[12]|4,030|18,613|13,441|12,475|44,183|39,771|-|-|-|
||This work|4,293|13,378|12,798|11,691|38,018|35,341|25,920|84,045|75,799|
|AVX2-VPCLMULQDQ|[3]*|4,792|8,921|11,466|14,120|26,593|36,264|34,072|63,977|96,368|
||[12]*|3,240|12,365|10,686|9,720|25,245|31,927|-|-|-|
||This work|4,336|8,209|8,801|10,440|22,033|26,045|24,896|50,535|57,505|
|Neon-VMULL_P8|[3]*|48,600|110,591|274,836|145,800|332,197|834,656|367,416|839,307|2,167,520|
||This work|30,888|72,043|164,944|81,936|195,668|454,789|181,944|428,837|984,254|



A useful first-order interpretation is that the cost is largely governed by a weighted sum of these two counts, 

**==> picture [239 x 10] intentionally omitted <==**

where _α_ and _β_ are the relative costs of one base multiplication and one XOR, and _ccovh_ aggregates the remaining overheads such as data rearrangement and temporary-value handling. Under this view, improvements arise when an implementation reduces _cnt_ mul, or achieves a favorable trade-off between _cnt_ mul and _cnt_ xor in the evaluation/interpolation and recomposition steps. 

Thebestapproachcandifferbetween AVX2-PCLMULQDQ, AVX2-VPCLMULQDQ, and Neon-VMULL_P8 because the relative costs _(α, β)_ and the residual term _ccovh_ are backend dependent. 

In particular, VPCLMULQDQ enables a different basemultiplication strategy on AVX2 than PCLMULQDQ, which changes the effective cost of _cnt_ mul and shifts the optimal balance against _cnt_ xor. 

Overall, Table 8 makes this relationship explicit. The observed cycle counts closely follow the combined effect of ( _cnt_ mul, _cnt_ xor), which reveals the characteristic trade-offs of each method. By comparing the operation counts across different methods, we see that [12] minimize the number of carry-less multiplications while incurring higher XOR operations, whereas our method reduces both _cnt_ mul and _cnt_ xor in a more balanced way, leading to better overall performance across the evaluated platforms. Additional end-to-end benchmark results for HQC and BIKE are provided in table 9. 

## **6 Conclusion** 

In this paper, we present an efficient and flexible method for polynomial multiplication over GF _(_ 2 _)_ [ _x_ ], optimized for SIMD instruction sets such as AVX2 and Neon. Our approach combines Karatsuba and Toom–Cook algorithms and employs a bottom-up search strategy that identifies the most efficient combination for each polynomial degree up to 100,000bymeasuringcyclecountsofsmallermultiplications 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 17 of 21 3 

and building up from the most efficient cases. Similar to the gf2x library, our proposed method supports a wide range of polynomial degrees. However, by generating branchfree code offline for specific degrees, our approach further improves execution efficiency. Unlike general-purpose libraries that may incur overhead from runtime selection logic, such as table look-ups and conditional branches, our method eliminates these control-flow dependencies. This optimization strategy makes our approach well-suited for high-performance cryptographic applications. 

Experimental results show that our method achieves significant speedups over existing approaches. We evaluated our implementation across three instruction set environments: AVX2-PCLMULQDQ and AVX2-VPCLMULQDQ on x86, and Neon on ARMv8. When integrated into HQC and BIKE for the latest official releases in the AVX2-PCLMULQDQ environment, our method reduces GF(2)[x] multiplication cycle counts by up to 32% in HQC and 41% in BIKE. Moreover, our method achieves consistent speedups in key generation, encapsulation, and decapsulation, relative to the latest official releases of HQC and BIKE, the gf2x library, and the implementation in [12]. limitations and future work 

Our current optimization/search space focuses on Karatsu ba/Toom-Cook-based decomposition trees, which is wellsuited for SIMD platforms with fast carry-less multiplication and for the HQC/BIKE parameter ranges considered in our evaluation. For large degrees, FFT-based or more general hybridstrategiescanbepreferable.Inparticular,theproposed search space is most effective for small degree settings such as HQC-1 and HQC-3, whereas FFT-based approaches can become preferable for the largest settings such as HQC-3. In addition, on platforms without efficient carry-less multiplication support or with limited SIMD resources, the performance benefit of our approach may diminish compared to FFT-based alternatives. 

Forfuturework,weplantoextendtheproposed GFmulOpt framework in several directions. First, we plan to broaden our evaluation across a wider range of processors and platforms, since our experimental evaluation in this work is limited to a single x86 CPU and a single ARMv8 CPU and performance may vary across microarchitectures and toolchains. We also plantoextend GFmulOpt toadditionalSIMDenvironments, including those supporting AVX-512, to further optimize HQC and BIKE implementations in such settings.3, 4, 5, 6 

**==> picture [234 x 282] intentionally omitted <==**

**----- Start of picture text -----**<br>
70<br>TC3 128<br>24 23<br>2-Karat 2-Karat<br>12 12 11<br>2-Karat 2-Karat 2-Karat<br>6 6 6 5<br>2-Karat 2-Karat 2-Karat 5-Karat<br>3 3 3 1<br>3-Karat 3-Karat 3-Karat base mul<br>1 1 1<br>base mul base mul base mul<br>**----- End of picture text -----**<br>


**Fig. 2** Decomposition tree of the GF _(_ 2 _)_ [ _x_ ] multiplication routine for HQC-1 on AVX2-PCLMULQDQ, selected by GFmulOpt. 

such hybrid strategies will further improve the flexibility and efficiency of GFmulOpt for a wider range of polynomial degrees. 

## **Appendix A Decomposition Trees and Benchmark Results** 

This appendix provides representative decomposition trees produced by GFmulOpt and additional benchmark results. Figs. 2–7 show the decomposition trees selected by GFmulOpt for GF _(_ 2 _)_ [ _x_ ] multiplication for HQC-1 and bikel1 under AVX2-PCLMULQDQ, AVX2-VPCLMULQDQ, and Neon-VMULL_P8. 

Table 9 reports end-to-end KEM benchmark results for HQC and BIKE using different GF _(_ 2 _)_ [ _x_ ] multiplication implementations. 

Second, inspired by the optimization strategy in [12], we plan to enhance GFmulOpt. In particular, Karatsuba and Toom-Cook decompositions are known to be highly efficient for polynomial degrees of the form 2 _[i]_ or 3 · 2 _[i]_ . For polynomials whose degree can be expressed as _n_ = 2 _[i]_ + _r_ or _n_ = 3 · 2 _[i]_ + _r_ , we plan to first apply optimized multiplication routines for the 2 _[i]_ or 3 · 2 _[i]_ components, followed by a dedicated treatment of the remaining _r_ -degree part. Incorporating 

123 

3 Page 18 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

|Environment<br>Method<br>HQC-1<br>HQC-3<br>HQC-3<br>keygen<br>encaps<br>decaps<br>keygen<br>encaps<br>decaps<br>keygen<br>encaps<br>decaps|AVX2-PCLMULQDQ<br>[2]<br>79,436<br>152,229<br>351,657<br>188,167<br>357,635<br>729,115<br>380,624<br>724,413<br>1,430,298<br>[16]<br>81,282<br>154,946<br>356,706<br>194,465<br>368,203<br>751,455<br>362,514<br>692,388<br>1,380,581<br>[20]<br>106,552<br>189,845<br>410,087<br>239,455<br>428,321<br>844,655<br>376,168<br>654,015<br>1,346,029<br>[20](GFNI)<br>90,803<br>165,211<br>367,404<br>207,121<br>374,183<br>766,860<br>308,066<br>538,160<br>1,160,023<br>This work<br>75,632<br>142,970<br>337,014<br>176,417<br>336,631<br>696,679<br>320,473<br>599,013<br>1,237,967<br>AVX2-VPCLMULQDQ<br>[2]*<br>71,377<br>133,709<br>323,494<br>162,971<br>305,174<br>644,777<br>307,709<br>577,747<br>1,204,807<br>This work<br>67,405<br>127,489<br>318,212<br>157,953<br>294,807<br>639,631<br>287,335<br>531,426<br>1,140,883<br>Neon-VMULL_P8<br>[2]*<br>417,935<br>817,626<br>1,381,839<br>1,181,514<br>2,315,837<br>3,691,946<br>2,757,451<br>5,452,952<br>8,582,331<br>[20]<br>474,489<br>827,198<br>1,449,411<br>1,137,638<br>2,022,715<br>3,332,810<br>1,922,873<br>3,386,640<br>5,738,085<br>This work<br>390,441<br>757,202<br>1,298,305<br>1,064,835<br>2,083,097<br>3,335,295<br>2,287,988<br>4,504,033<br>7,142,399|**BIKE**<br>Environment<br>Method<br>bikel1<br>bikel3<br>bikel5<br>keygen<br>encaps<br>decaps<br>keygen<br>encaps<br>decaps<br>keygen<br>encaps<br>decaps|AVX2-PCLMULQDQ<br>[3]<br>455,594<br>123,841<br>1,699,488<br>1,382,521<br>283,760<br>5,462,612<br>3,566,724<br>596,562<br>15,660,984<br>[16]<br>463,144<br>121,096<br>1,682,321<br>1,361,936<br>282,449<br>5,417,704<br>3,030,749<br>568,321<br>14,893,658<br>[12]<br>440,416<br>128,284<br>1,689,743<br>1,220,671<br>273,646<br>5,325,756<br>-<br>-<br>-<br>This work<br>413,296<br>122,705<br>1,662,252<br>1,145,540<br>269,975<br>5,209,745<br>2,529,099<br>540,916<br>14,483,780<br>AVX2-VPCLMULQDQ<br>[3]*<br>381,203<br>122,044<br>1,628,844<br>1,146,985<br>271,321<br>5,242,017<br>2,924,233<br>559,313<br>14,938,083<br>[12]*<br>368,415<br>120,373<br>1,629,262<br>1,079,650<br>270,386<br>5,206,677<br>-<br>-<br>-<br>This work<br>339,390<br>117,216<br>1,590,403<br>972,281<br>264,615<br>5,071,575<br>2,160,569<br>515,805<br>14,384,863<br>Neon-VMULL_P8<br>[3]*<br>7,150,444<br>832,589<br>13,470,802<br>21,154,486<br>2,345,407<br>44,140,952<br>52,551,242<br>5,920,958<br>105,304,666<br>This work<br>5,292,184<br>724,848<br>11,965,991<br>13,918,702<br>1,959,175<br>37,846,579<br>28,869,054<br>4,738,335<br>88,859,524|
|---|---|---|---|



123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 19 of 21 3 

**==> picture [601 x 459] intentionally omitted <==**

**----- Start of picture text -----**<br>
70<br>49<br>TC3 128<br>TC3 128<br>24 23<br>2-Karat 3-Karat<br>12 8 7 17 16<br>3-Karat 2-Karat 2-Karat<br>2-Karat 2-Karat<br>4 4 4 3<br>2-Karat 2-Karat 2-Karat 2-Karat<br>2 2 2 2 1 9 8 8<br>2-Karat 2-Karat 2-Karat 2-Karat base mul<br>2-Karat 2-Karat 2-Karat<br>1 1 1 1<br>base mul base mul base mul base mul<br>Fig. 3 Decomposition tree of the GF ( 2 ) [ x ] multiplication routine for 3 4 4<br>HQC-1 on AVX2-VPCLMULQDQ, selected by GFmulOpt.<br>2-Karat 2-Karat 2-Karat<br>139<br>TC3 1 28<br>48 47 45<br>TC3 6 4 TC3 1 28 TC3 6 4 1 2 2<br>2-Karat17 2-Karat16 2-Karat17 2-Karat16 2-Karat15 2-Karat16 2-Karat15 base mul 3-Karat 3-Karat<br>9 8 8 8 7<br>3-Karat 2-Karat 2-Karat 2-Karat 2-Karat<br>3 4 4 3 1 1<br>3-Karat 2-Karat 2-Karat 3-Karat<br>base mul base mul<br>1 2<br>base mul 2-Karat<br>Fig. 5 Decomposition tree of the GF ( 2 ) [ x ] multiplication routine<br>1<br>base mul bikel1 on AVX2-PCLMULQDQ, selected by GFmulOpt. on AVX2-PCLMULQDQ, selected by GFmulOpt. AVX2-PCLMULQDQ, selected by GFmulOpt., selected by GFmulOpt.<br>**----- End of picture text -----**<br>


**Fig. 5** Decomposition tree of the GF _(_ 2 _)_ [ _x_ ] multiplication routine for bikel1 on AVX2-PCLMULQDQ, selected by GFmulOpt. on AVX2-PCLMULQDQ, selected by GFmulOpt. AVX2-PCLMULQDQ, selected by GFmulOpt., selected by GFmulOpt. 

**Fig. 4** Decomposition tree of the GF _(_ 2 _)_ [ _x_ ] multiplication routine for HQC-1 on Neon-VMULL_P8, selected by GFmulOpt. Repeated identical subtrees are omitted for readability. 

123 

3 Page 20 of 21 

Journal of Cryptographic Engineering             (2026) 16:3 

**==> picture [234 x 243] intentionally omitted <==**

**----- Start of picture text -----**<br>
49<br>TC3 1 28<br>25 24<br>2-Karat 2-Karat<br>13 12 12<br>2-Karat 3-Karat 3-Karat<br>7 6 4 4<br>2-Karat 3-Karat 2-Karat 2-Karat<br>4 3 2 2 2<br>2-Karat 2-Karat 2-Karat 2-Karat 2-Karat<br>2 2 1 1 1 1<br>2-Karat 2-Karat base mul base mul base mul base mul<br>1 1<br>base mul base mul<br>**----- End of picture text -----**<br>


**Fig. 6** Decomposition tree of the GF _(_ 2 _)_ [ _x_ ] multiplication routine for bikel1 on AVX2-VPCLMULQDQ, selected by GFmulOpt. 

**Acknowledgements** This work was supported by Institute of Information & communications Technology Planning & Evaluation (IITP) grant funded by the Korea government (MSIT) (No. 2022-0-00518, Blockchain privacy preserving techniques based on data encryption). 

**Author Contributions** Jihoon Jang wrote the main manuscript text. Suhri Kim, Seog Chung Seo and Seokhie Hong supervised our work. All authors reviewed the manuscript. 

**Data Availability** No datasets were generated or analysed during the current study. 

**==> picture [234 x 377] intentionally omitted <==**

**----- Start of picture text -----**<br>
97<br>TC3 64<br>33 32<br>TC3 64 2-Karat<br>12 11 16<br>2-Karat 3-Karat 2-Karat<br>6 3 4 8<br>2-Karat 3-Karat 2-Karat 2-Karat<br>3 1 2 4<br>3-Karat base mul 2-Karat 2-Karat<br>1 1 2<br>base mul base mul 2-Karat<br>1<br>base mul<br>**----- End of picture text -----**<br>


**Fig. 7** Decomposition tree of the GF _(_ 2 _)_ [ _x_ ] multiplication routine for bikel1 on Neon-VMULL_P8, selected by GFmulOpt. 

## **Declarations** 

**Competing interests** The authors declare no competing interests. 

## **References** 

1. Shor, P.W.: Polynomial-time algorithms for prime factorization and discretelogarithmsonaquantumcomputer.SIAMRev. **41** (2),303– 332 (1999). https://doi.org/10.1137/S0036144598347011 

2. Aguilar-Melchor, C., Aragon, N., Bettaieb, S., Bidoux, L., Blazy, O., Deneuville, J.-C., Gaborit, P., Persichetti, E., Zémor, G., Bos, J., Dion,A.,Lacan,J.,Robert,J.-M.,Veron,P.:HQC.Technicalreport, National Institute of Standards and Technology (2022). available at https://csrc.nist.gov/Projects/post-quantum-cryptography/ round-4-submissions 

3. Aragon, N., Barreto, P., Bettaieb, S., Bidoux, L., Blazy, O., Deneuville, J.-C., Gaborit, P., Gueron, S., Guneysu, T., AguilarMelchor, C., Misoczki, R., Persichetti, E., Sendrier, N., Tillich, J.P., Zémor, G., Vasseur, V., Ghosh, S., Richter-Brokmann, J.: BIKE. Technical report, National Institute of Standards and Technology (2022). available at https://csrc.nist.gov/Projects/post-quantumcryptography/round-4-submissions 

4. Alagic, G., Bros, M., Ciadoux, P., Cooper, D., Dang, Q., Dang, T., Kelsey, J., Lichtinger, J., Liu, Y.-K., Miller, C., Moody, D., Peralta, R., Perlner, R., Robinson, A., Silberg, H., Smith-Tone, D., Waller, N.: Status report on the fourth round of the NIST post-quantum cryptography standardization process. NIST Internal Report (IR) NIST IR 8545, National Institute of Standards and Technology (NIST), Gaithersburg, MD (2025). https://doi.org/10.6028/NIST. IR.8545 

5. Karatsuba, A.A., Ofman, Y.P.: Multiplication of many-digital numbers by automatic computers. In: Dokl. Akad. Nauk SSSR **145** , 293–294 (1962) Russian Academy of Sciences 

6. Cook, S.A., Aanderaa, S.O.: On the minimum computation time of functions. Trans. Am. Math. Soc. **142** , 291–314 (1969). https:// doi.org/10.2307/1995359 

7. Bodrato, M.: Towards optimal toom-cook multiplication for univariate and multivariate polynomials in characteristic 2 and 0. In: Arithmetic of Finite Fields, 116–133. Springer, Berlin, Heidelberg (2007). https://doi.org/10.1007/978-3-540-73074-3_10 

8. Lyubashevsky, V., Ducas, L., Kiltz, E., Lepoint, T., Schwabe, P., Seiler, G., Stehlé, D., Bai, S.: CRYSTALS-DILITHIUM. Technical report, National Institute of Standards and Technology (2022). available at https://csrc.nist.gov/Projects/post-quantumcryptography/selected-algorithms-2022 

123 

Journal of Cryptographic Engineering             (2026) 16:3 

Page 21 of 21 3 

9. Schwabe, P., Avanzi, R., Bos, J., Ducas, L., Kiltz, E., Lepoint, T., Lyubashevsky, V., Schanck, J.M., Seiler, G., Stehlé, D., Ding, J.: CRYSTALS-KYBER. Technical report, National Institute of Standards and Technology (2022). available at https://csrc.nist.gov/ Projects/post-quantum-cryptography/selected-algorithms-2022 

10. Cantor, D.G.: On arithmetical algorithms over finite fields. Journal of Combinatorial Theory, Series A **50** (2), 285–300 (1989). https:// doi.org/10.1016/0097-3165(89)90020-4 

11. Gao, S., Mateer, T.: Additive fast fourier transforms over finite fields. IEEE Trans. Inf. Theor. **56** (12), 6265–6272 (2010). https:// doi.org/10.1109/TIT.2010.2079016 

12. Chen, M.-S., Chou, T., Krausz, M.: Optimizing BIKE for the intel haswell and ARM Cortex-M4. IACR TCHES **2021** (3), 97–124 (2021). https://doi.org/10.46586/tches.v2021.i3.97-124 

13. Lee, M., Jang, J., Kim, S., Hong, S.: Improved frobenius fft for code-based cryptography on cortex-m4. IEEE Internet Things J. **12** (17), 36318–36327 (2025). https://doi.org/10.1109/JIOT.2025. 3583021 

14. Jang, J., Lee, M., Kwon, D., Hong, S., Kim, S., Lee, S.: Efficient Polynomial Multiplication for HQC on ARM Cortex-M4. Cryptology ePrint Archive, Paper 2025/1939 (2025). https://eprint.iacr. org/2025/1939 

15. Robert, J.-M., Véron, P.: Faster multiplication over F2[ _X_ ] using AVX512 instruction set and VPCLMULQDQ instruction. J. Cryptogr. Eng. **13** (1), 37–55 (2023). https://doi.org/10.1007/s13389021-00278-3 

16. Brent, R.P., Gaudry, P., Thomé, E., Zimmermann, P.: gf2x library. https://gitlab.inria.fr/gf2x/gf2x. Accessed: Feb. 11, 2023. [Online] (2023) 

19. Seo, H., Liu, Z., Nogami, Y., Choi, J., Kim, H.: Binary field multiplication on armv8. Security and Communication Networks **9** (13), 2051–2058 (2016). https://doi.org/10.1002/sec.1462 

20. Chen, M.-S., Chiu, C.-M., Peng, C.-T., Yang, B.-Y.: Accelerating HQC with Additive FFT. Cryptology ePrint Archive, Paper 2026/014 (2026). https://eprint.iacr.org/2026/014 

21. Drucker, N., Gueron, S., Kostic, D.: Fast Polynomial Inversion for Post Quantum QC-MDPC Cryptography. In: Cyber Security Cryptography and Machine Learning, 110–127. Springer, Cham (2020). https://doi.org/10.1007/978-3-030-49785-9_8 

22. Chen, M.-S., Güneysu, T., Krausz, M., Thoma, J.P.: Carry-less to BIKE faster. ACNS 22. LNCS **13269** , 833–852 (2022). https://doi. org/10.1007/978-3-031-09234-3_41 

23. Brent, R.P., Gaudry, P., Thomé, E., Zimmermann, P.: Faster multiplication in gf(2)[x]. In: Algorithmic Number Theory, 153–166. Springer, Berlin, Heidelberg (2008).https://doi.org/10.1007/9783-540-79456-1_10 

**Publisher’s Note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

17. Câmara, D., Gouvêa, C.P.L., López, J., Dahab, R.: Fast software polynomial multiplication on arm processors using the neon engine. In: Security Engineering and Intelligence Informatics, pp. 137–154. Springer, Berlin, Heidelberg (2013). https://doi.org/10. 1007/978-3-642-40588-4_10 

18. Gouvêa, C.P., López, J.: Implementing gcm on armv8. CTRSA 2015. LNCS **9048** , 167–180 (2015). https://doi.org/10.1007/ 978-3-319-16715-2_9 

123 

