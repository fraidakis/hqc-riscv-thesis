---
source_pdf: docs/references/pdf/other-platforms/Accelerating HQC with Additive FFT.pdf
converted_at: 2026-05-29 22:40
conversion_time: 7.6s
tool: pymupdf4llm
---

## **Accelerating HQC with Additive FFT** 

Ming-Shing Chen[1] , Chun-Ming Chiu[1] , Chun-Tao Peng[1] and Bo-Yin Yang[1] 

## IIS and CITI, Academia Sinica, Taipei, Taiwan 

```
mschen@crypto.tw,r12922085@csie.ntu.edu.tw,PengTaiwan6517@gmail.com,by@crypto.tw
```

**Abstract.** This paper presents an accelerated implementation of the Hamming Quasi-Cyclic (HQC) key encapsulation mechanism by leveraging additive Fast Fourier Transform (FFT) for polynomial multiplication ( _polymuls_ ). A common challenge when applying FFT-based polymuls to HQC are the polynomial degrees fractionally greater than powers of two, making standard FFT polymuls inefficient for those parameters. We introduce a novel combination of additive FFT with the Chinese Remainder Theorem (CRT) to multiply such just-above-power-of-two degree polynomials. Further optimizations are achieved by caching the FFT transforms of the public and secret keys during or after key generation and reusing the transform of the shared random polynomial during the encapsulation and decapsulation processes. This approach significantly reduces redundant computations. 

The effectiveness of these optimizations is evaluated across various hardware platforms, including x86-64 with AVX2 and Galois Field New Instructions (GFNI), as well as ARM NEON on Apple M1 and Cortex-A72 processors. Benchmarks show that on platforms with long carry-less multiplication instructions like `PCLMULQDQ` , the proposed caching and reuse strategies allow FFT-based implementations to outpace traditional Toom-Karatsuba methods in the Encap and Decap operations of the HQC scheme, even with comparable raw multiplication speeds. On platforms lacking long carry-less multiplication instructions, the additive FFT approach already gives the superior performance. 

**Keywords:** HQC · additive FFT · F2 polynomial multiplication · extended CRT 

## **1 Introduction** 

To counter the threat of quantum computers, the NIST Post-Quantum Cryptography (PQC) Standardization Process [MPR[+] 24] has been ongoing since 2016. Among the selected finalists, _Hamming Quasi-Cyclic (HQC)_ [AAB[+] 22, AAB[+] 25] stands out as a code-based public key encapsulation mechanism (KEM) rooted in the hardness of decoding quasi-cyclic codes—a problem believed to be resistant even against quantum adversaries. Recently, HQC has been officially selected for standardization, becoming the future standard KEMs. 

One of the most performance-critical operations in HQC is implementing multiplication in the polynomial ring _R_ = F2[ _x_ ] _/_ ( _X[n]_ + 1). The multiplication length for HQC ranges from 18k to 58k bits, depending on the chosen security level. Efficient multiplication in this ring is thus essential for optimizing key generation, encapsulation, and decapsulation times. 

The reference and optimized implementations in[AAB[+] 22, AAB[+] 25] uses Toom and Karatsuba for polynomial multiplications (polymuls). Given the polynomial lengths and previous studies in code-based cryptosystems, we believe that Fast Fourier Transform (FFT)-based algorithms can enhance the performance of polymuls used in HQC. In this paper, we explore the use of FFT-based algorithms to replace the original polymuls in [AAB[+] 22, AAB[+] 25]. We evaluate our approach across different parameter sets and CPUs, 

Chen, Chiu, Peng, and Yang 

1 

including x86 with AVX2 and GFNI instructions, Raspberry Pi4 and Mac M1. 

## **1.1 Our Contributions** 

In this work, we present optimized implementations of HQC on both Arm NEON and x86 AVX2 platforms, including support for the Galois Field New Instructions (GFNI) [Int21] as well as CPUs lacking long F2-polymul instructions. 

We propose a novel combination of additive FFT with the Chinese Remainder Theorem (CRT) to multiply in HQC-1 and HQC-3. This approach allows us to multiply polynomials of degree slightly greater than powers of 2, where direct usage of additive FFT is inefficient. 

FFT-based multiplications are particularly beneficial in the **Encryption** function. This function includes two polynomial multiplications that share a common input polynomial. We eliminate redundant FFT transforms, saving roughly 1 _/_ 8 computation time on x86 AVX2 and 1 _/_ 6 computation time on ARM NEON for two FFT multiplications. 

We also introduce a caching strategy for caching the (FFT) transformed polynomials in the encapsulation and decapsulation keys, These cached transforms are reused in the encapsulation and decapsulation phases, further reducing computational overhead. 

Finally we present time-constant optimized encoding and decoding of the Reed-Muller and Reed-Solomon codes used in HQC that mitigate side-channel vulnerabilities. 

**Source code** The source code for all our implementations is available under CC0 copyrightwaiver at `https://github.com/ChunTaoPengim/HQC_with_addFFT_tches2026` . 

## **1.2 Related Works** 

HQC optimization is a persistent focus of hardware research. Work began with [DXN[+] 24] in 2023, which focused on accelerating sparse polynomial multiplication, and followed by [ABP25], which presented a fully parameterized RTL implementation. Recently, research has concentrated on FFT and system integration: Ras et al. [RLC[+] 25b] proposed sharing addFFT units for area/throughput gains. This group subsequently [RLC[+] 25a] presented an optimized FFT implementation integrated into a RISC-V System-On-Chip. 

The two forms of additive FFT used in our implementation have been studied in the literature. Chen et al. [CCK[+] 17] applied additive FFT with Kronecker segmentation to multiplication of long binary polynomials. [LCK[+] 18, CCK[+] 18] applied Frobenius additive FFT to F2[ _x_ ] multiplications, showing that even with dedicated F2-polymul instructions, FFT outperforms Karatsuba when multiplying polynomials that are 10 _k_ ’s-bits long. 

The polymul performance in schemes like BIKE and HQC on embedded systems is a highly competitive and active area of research. Early FFT-based implementations [CCK21] established the first benchmark, proving superior to Karatsuba for polynomials over 20 kbits on instruction-limited platforms. This performance lead was subsequently challenged in [CGKT22]. The authors leverage the standard 32 _×_ 32 _→_ 64-bit _integer_ multiplication instruction for carry-less polynomial multiplication. Their optimized Karatsuba implementation outperformed previous FFT methods for polynomial degrees below 20 kbits, establishing a clear performance crossover point. The latest work [LJKH25] focused on FFT-based multiplication again and further accelerated FFT implementations that outperformed previous implementations in the HQC scheme within the embedded context. 

## **1.3 Organization of this paper** 

Section 2 introduces HQC, target microarchitectures, and additive FFT. Section 3 reviews FFT-based F2-polymul and presents implementation techniques on targeted platforms. 

Accelerating HQC with Additive FFT 

2 

Table 1: Parameter sets of HQC-KEM: Sizes of keypair (ekKEM _,_ dkKEM), ciphertext **c** KEM and shared key _K_ are in Bytes. 

|red key _K_|are in Bytes.||
|---|---|---|
||_n_<br>_w_<br>_wr_ =_we_|_|_ekKEM_|_<br>_|_dkKEM_|_†<br>_|_**c**KEM_|_<br>_|K|_|
||||
|HQC-1<br>HQC-3<br>HQC-5|17 669<br>66<br>75<br>35 851<br>100<br>114<br>57 637<br>131<br>149|2241<br>2321<br>4433<br>32<br>4514<br>6402<br>8978<br>32<br>7237<br>7333<br>14 421<br>32|



†Here shows the size of the default mode. _|_ dkKEM _|_ are all 32 bytes in compressed mode. 

Section 4 describes optimizing of HQC with FFT-based multiplication. Section 5 shows our implementation and performance results. Our conclusions are presented in Section 6. 

## **2 Preliminaries** 

## **2.1 HQC** 

HQC (Hamming Quasi-Cyclic) [AAB[+] 25] is a code-based post-quantum key encapsulation mechanism (KEM), which was selected to be standardized by NIST recently. Its core component is a public-key encryption scheme HQC-PKE. The KEM HQC-KEM is derived from HQC-PKE using the Fujisaki-Okamoto transformation [FO99] following the HHK framework [HHK17]. The encapsulation key ekKEM is the same as the encryption key ekPKE. Due to the re-encryption operation in FO transform, the decapsulation key dkKEM comprises (ekPKE _,_ dkPKE _, σ,_ seedKEM) where dkPKE is the decryption key, _σ_ is randomness for the shared key of KEM, and seedKEM is the 32-byte seed for all elements in HQC-KEM. 

**Algorithm 1** Main components in HQC-PKE 

1: Global parameters: ( _n, w, wr, we, ℓ, C_ ). 

2: HQC-PKE.Keygen( seedPKE ): 3: Derive (dkPKE _,_ seedPKE.ek) _←_ HASH _._ I(seedPKE). 4: Sample ( _y, x_ ) _←−−−R_ dkPKE _w × Rw_ . seedPKE.ek 5: Sample _h ←−−−−−R_ . 6: Set ekPKE = (seedPKE.ek _, s ← x_ + _h · y_ ). 7: **return** (ekPKE _,_ dkPKE). 8: HQC-PKE.Encrypt(ekPKE _, m, θ_ ): randomness _θ_ 9: Sample ( _r_ 2 _, e, r_ 1) _←−−−−−−−−_ ( _Rwr , Rwe , Rwr_ ). ekPKE 10: Sample _h ←−−−R_ . 11: Set _u ← r_ 1 + _h · r_ 2. 12: Set _v ←C_ .Encode( _m_ ) + truncate( _s · r_ 2 + _e, ℓ_ ). 13: **return c** PKE = ( _u, v_ ). 14: HQC-PKE.Decrypt(dkPKE _,_ **c** PKE = ( _u, v_ )): dkPKE 15: Sample _y ←−−−Rw_ . 16: **return** _C_ .Decode( _v −_ truncate( _u · y, ℓ_ )). 

Algorithm 1 depicts HQC-PKE components with main computations being multiplying in 

**==> picture [243 x 11] intentionally omitted <==**

The parameter _n_ and other specifications for 3 different security levels are listed in Table 1. When F2 polynomials in the ring are sparse, extra parameters ( _w, wr, we_ ) specify their Hamming weight of coefficients. HQC-PKE specifies an error correcting code _C_ 

Chen, Chiu, Peng, and Yang 

3 

(see Subsubsection 2.1.1 for details). A parameter _ℓ_ denotes the truncated bits when transforming polynomials in _R_ into F2 vectors used in its code _C_ . 

Throughout this paper, we always process the multiplication in the ring _R_ := F2[ _x_ ] _/_ ( _x[n] −_ 1) as follows: 1) Lift the ring elements in _R_ into polynomials in F2[ _x_ ] and process polynomial multiplication in F2[ _x_ ]. 2) Reduce the products in F2[ _x_ ] by adding the terms of degree _≥ n_ into the terms of lower degrees and map the results back to elements in _R_ . Hence, we focus on multiplying polynomials in F2[ _x_ ] in the following contents. 

## **2.1.1 Concatenated Reed-Muller and Reed-Solomon Codes** 

HQC adopts a concatenated coding scheme that combines a duplicated Reed-Muller (RM) code as the inner code and a Reed-Solomon (RS) code as the outer code. (See [LC04] for the details of RS and RM code.) The RS code operates over the finite field F256 and performs a systematic encoding to a message. The RM code further encodes each byte of the RS codeword into a 128-bit vector, and repeats it 3 or 5 times to form the final codeword. In the decryption process, the RM code first sums the duplicated codewords and applies the maximum likelihood decoding algorithm to recover the RS codeword. The RS code then uses syndrome decoding to retrieve the message in BCH view. The code parameters are specified in [AAB[+] 25] and the method is decribed in [AGZ]. 

## **2.2 Targeting Architectures** 

We evaluate our HQC implementations across both the x86 and `ARMv8-A` ( `AArch64` ) instruction set architectures (ISAs). 

The Intel AVX2 instruction set provides 16 256-bit ymm registers. Since it operates as Single Instruction, Multiple Data (SIMD), the 256-bit registers can be operated as lanes of various sizes, such as 4 _×_ 64, 8 _×_ 32, 16 _×_ 16, or 32 _×_ 8-bit. We list the instructions for polynomial multiplication in x86 architecture here: 

- `PCLMULQDQ` from the AESNI [Int14] instruction set performs 64 _×_ 64 _→_ 128 multiplication in F2[ _x_ ]. Its core application is in the Galois/Counter Mode (GCM) of AES encryption. `PCLMULQDQ` is widely supported across most modern x86 processors. 

- The `GF2P8MULB` instruction, introduced in the GFNI [Int21] instruction set, performs native field multiplication in F256 := F2[ _x_ ] _/_ ( _x_[8] + _x_[4] + _x_[3] + _x_ + 1). When paired with the AVX2 instruction set, one `GF2P8MULB` instruction performs 32 field multiplications simultaneously. It was introduced in 2019 and has since been supported by newer Intel and AMD CPUs. However, its adoption is less widespread than AESNI. 

Both `PCLMULQDQ` and `GF2P8MULB` can coexist in longer SIMD architectures, e.g., `VPCLMULQDQ` , requiring a different CPUID from `PCLMULQDQ` , are capable of 4 multiplications in one instruction with AVX-512 instruction set. However, we confine our HQC implementations to AVX2+ `PCLMULQDQ` and AVX2+ `PCLMULQDQ` +GFNI in this paper for better algorithmic comparison with official HQC optimization on AVX2+ `PCLMULQDQ` . 

The `ARMv8-A` ( `AArch64` ) architecture supports the NEON SIMD instruction set. ARM NEON is a 128-bit SIMD instruction set with 32 vector registers. There are two instructions dedicated to polynomial multiplications in F2[ _x_ ]: 

- The `PMULL.P8` instruction performs 8 _×_ 8 _→_ 16 multiplication in F2[ _x_ ]. One `PMULL.P8` processes 8 multiplications simultaneously in one 128-bit register. It is widely available even on low cost devices, e.g., Raspberry Pi4. 

- The `PMULL.P64` instruction performs 64 _×_ 64 _→_ 128 multiplication in F2[ _x_ ]. This is the ARM equivalence instruction of `PCLMULQDQ` in the x86 world. 

Accelerating HQC with Additive FFT 

4 

## **2.2.1 Side-Channel Resistance** 

We keep our implementations with a time constancy property, in which memory access and control flow are independent of secret values, to prevent timing side-channel leakage. We do not specialize our polymuls for the sparse polynomials in HQC to prevent leaking degrees of the terms in sparse polynomials. We also make the RM-RS decoder resistant to power side-channel attacks proposed in [PRJB23] and [MNMD25] with SIMD instructions. 

## **2.3 Additive Fast Fourier Transform** 

Here is the additive FFT [Can89, GM10], which efficiently evaluates a polynomial over some additive subgroups of the coefficient field, from the viewpoint of [LCH14, LANHC16]. 

**Binary field and Cantor basis** We only handle the boolean extension fields F2 _m_ where _m_ is a power of 2 in this paper. Our implementations use the fields F264, F2562, and F25622. 

**==> picture [360 x 45] intentionally omitted <==**

An element in F264 is represented as a Boolean polynomial of degree 63 or an unsigned 64-bit integer. We represent elements in the extension field F2562 as two coefficients of a degree-1 polynomial in F256[ _y_ ] and F25622 as degree-1 polynomials in F2562[ _z_ ]. Although we present FFT algorithms through the example of F264, the same properties apply to F2562 and F25622 as well. 

We denote the Cantor basis in F264 as 64 particular field elements _{v_ 0 _, . . . , v_ 63 _}_ which spans the whole linear space of F264 , i.e., span _{v_ 0 _, . . . , v_ 63 _}_ = F264 , and follows the relation 

**==> picture [235 x 13] intentionally omitted <==**

and _v_ 0 = `1` . Let F264 = span _{v_ 0 _, . . . , v_ 63 _}_ be an ordered set. We enumerate the set as 

**==> picture [151 x 23] intentionally omitted <==**

Hence, we also refer to the elements in F264 as indices of the ordered set. We call the index as a Cantor basis representation for elements in F264 in addition to a Boolean polynomial representation. Given a number _i_ written in its binary form _i_ =[�][63] _j_ =0 _[i][j][·]_[ 2] _[j]_[where] _ij ∈{_ 0 _,_ 1 _}_ , the field element referred by the index _i_ is[�] _j[i][j][ ·][ v][j]_[.][The][index][representation] simplifies the symbols to F264 = span _{v_ 0 _, . . . , v_ 63 _}_ = _{_ 0 _,_ 1 _,_ 2 _, . . . ,_ 2[64] _−_ 1 _}_ . 

**Vanishing polynomials and the polynomial basis for fast evaluation** We define a series of subspaces from a Cantor basis as _V_ 0 = _{_ 0 _}_ and 

**==> picture [347 x 31] intentionally omitted <==**

For example, _V_ 1 = span _{v_ 0 _}_ = _{_ 0 _,_ 1 _} ,_ and _V_ 2 = span _{v_ 0 _, v_ 1 _}_ = _{_ 0 _,_ 1 _, v_ 1 _, v_ 1 + _v_ 2 _}_ = _{_ 0 _,_ 1 _,_ 2 _,_ 3 _}_ , and so on. Note that _|Vi|_ = 2 _[i]_ and _V_ 64 = F264. 

We then define the vanishing polynomial _si_ of degree 2 _[i]_ as the polynomial that maps all elements in the subspace _Vi_ to 0, i.e., 

**==> picture [318 x 13] intentionally omitted <==**

Chen, Chiu, Peng, and Yang 

5 

and _si_ ( _x_ ) _�→_ 0 for all _x ∈ Vi_ . For example, _s_ 0( _x_ ) :=[�] _j∈V_ 0[(] _[x][−][j]_[)][=] _[x]_[,] _[s]_[1][(] _[x]_[)][:=] � _j∈V_ 1[(] _[x][ −][j]_[) =] _[ x]_[(] _[x][ −]_[1) =] _[ x]_[2] _[ −][x]_[,] _[s]_[2][(] _[x]_[) :=][ �] _j∈V_ 2[(] _[x][ −][j]_[) =] _[ x]_[(] _[x][ −]_[1)(] _[x][ −]_[2] )( _x −_ 3), etc. We recall important properties of _si_ from [GM10, LCH14]. 

**==> picture [389 x 41] intentionally omitted <==**

Note that the generating relation (5) can be seen as evaluating _s_ 1( _x_ ) at a basis element _vi_ : 

**==> picture [294 x 12] intentionally omitted <==**

In [LCH14], Lin, Chung, and Han show an additive FFT algorithm for evaluating polynomials in a series of basis polynomials _{_ 1 _, X_ 1( _x_ ) _, X_ 2( _x_ ) _, X_ 3( _x_ ) _, . . .}_ . The basis polynomial _Xi_ of degree _i_ is defined from vanishing polynomials _si_ as 

**==> picture [316 x 24] intentionally omitted <==**

For example, _X_ 0( _x_ ) := 1, _X_ 1( _x_ ) := _s_ 0( _x_ ) = _x_ , _X_ 2( _x_ ) := _s_ 1( _x_ ) = _x ·_ ( _x −_ 1), _X_ 3( _x_ ) := _s_ 0( _x_ ) _· s_ 1( _x_ ), and so on. 

**Divide-and-conquer process for evaluating polynomials** We define the additive FFT ( `addFFT` ) as evaluating the input polynomial on an affine subspace of Cantor basis, i.e., 

`addFFT` ( _f, a_ + _Vi_ ) _�→_ ( _f_ ( _a_ + 0) _, f_ ( _a_ + 1) _, f_ ( _a_ + 2) _, . . . , f_ ( _a_ + 2 _[i] −_ 1)) _._ 

In this context, _f_ is a polynomial in F2 _m_ [ _x_ ] and the domain of evaluation is the affine subspace _a_ + _Vi_ = _{a_ + _u|u ∈ Vi}_ , where _a ∈_ F2 _m_ is fixed and _Vi_ = span _{_ 1 _, v_ 1 _, . . . , vi−_ 1 _}_ is a linear subspace of F2 _m_ . The function outputs the evaluated values of _f_ over _a_ + _Vi_ . 

Let _f_ be a polynomial of degree _n −_ 1 in the polynomial basis (11): _f_ = _f_ 0 + _f_ 1 _X_ 1 + _· · ·_ + _fn−_ 1 _Xn−_ 1 where _n_ = 2 _[i]_ is a power of 2. Suppose _f_ is stored as a list of _n_ coefficients ( _f_ 0 _, f_ 1 _, . . . , fn−_ 1) _∈_ F _[n]_ 2 _[m]_[.][The] `[addFFT]`[operation][outputs] _[n]_[evaluated][values][on][the] evaluating domain _a_ + _Vi_ as ( _f_ ( _a_ ) _, f_ ( _a_ + 1) _, . . . , f_ ( _a_ + _n −_ 1)). The `addFFT` computation proceeds in _⌈_ log _n⌉_ = _i_ stages, the core operation of each being a recursive step reducing the problem size. 

In each stage, _f_ is partitioned into two sub-polynomials as _f_ = _fl_ + _Xn/_ 2 _· fh_ by splitting the coefficient list into ( _f_ 0 _, . . . , fn/_ 2 _−_ 1) and ( _fn/_ 2 _, . . . , fn−_ 1). Since _n_ is a power of 2, _Xn/_ 2 = _si−_ 1. The linear space _Vi_ is similarly decomposed into two disjoint sets: _Vi−_ 1 and _vi−_ 1 + _Vi−_ 1. By utilizing the properties: _si−_ 1( _vi−_ 1) = 1 and _si−_ 1( _Vi−_ 1) = 0, the evaluation of _f_ on _a_ + _Vi_ is reduced to two smaller evaluations: `addFFT` ( _fl_ + _si−_ 1( _a_ ) _fh, a_ + _Vi−_ 1)) and `addFFT` ( _fl_ +( _si−_ 1( _a_ )+1) _fh, a_ + _vi−_ 1 + _Vi−_ 1). Consequently, the output of `addFFT` ( _f, a_ + _Vi_ ) is the concatenation of the results from these two recursive calls. 

A so-called ’Butterfly’ operation computes terms _fl_ + _si−_ 1( _a_ ) _· fh_ and _fl_ + ( _si−_ 1( _a_ ) + 1) _· fh_ in each stage. Figure 1 visualizes a butterfly operation. Only one multiplication by _si−_ 1( _a_ ) is performed in each butterfly unit. 

Algorithm 2 presents the `addFFT` procedure. It takes two inputs, which are a polynomial _f_ and the evaluation domain _a_ + _Vi_ , and performs the following operations: 

1. `BasisCvt` : Converting the polynomial basis of _f_ from monomial basis to the polynomial basis (11). This step has _O_ ( _n_ log _n_ log log _n_ ) complexity [LANHC16] but can be skipped if the polynomial _f_ is already in the polynomial basis (11). 

Accelerating HQC with Additive FFT 

6 

**==> picture [237 x 51] intentionally omitted <==**

Figure 1: The butterfly operation 

## **Algorithm 2** The `addFFT` algorithm 

1: `addFFT` ( _f, a_ + _Vi_ ): _▷f_ is a polynomial of degree _n −_ 1 and _n_ = 2 _[i]_ . 2: **if** _f_ in monomial basis **then** 3: _f ←_ `BasisCvt` ( _f_ ). _▷_ Converting to polynomial basis (11) 4: **return** `Butterfly` ( _f, a_ + _Vi_ ). 5: `Butterfly` ( _f, a_ + _Vi_ ): 6: Let _f_ = _fl_ + _si−_ 1 _· fh_ . _▷fl_ and _fh_ are polynomials of degrees _n/_ 2 _−_ 1. 7: **if** _i_ = 1 **then** 8: **return** ( _fl_ + _a · fh, fl_ + ( _a_ + 1) _· fh_ ). 9: Set _fl[′][←][f][l]_[ +] _[ s][i][−]_[1][(] _[a]_[)] _[ ·][ f][h]_[.] 10: Set _fh[′][←][f][l]_[ + (] _[s][i][−]_[1][(] _[a]_[) + 1)] _[ ·][ f][h]_[.] 11: **return** ( `Butterfly` ( _fl[′][, a]_[ +] _[ V][i][−]_[1][)] _[,]_ `[ Butterfly]`[(] _[f] h[ ′][, a]_[ +] _[ v][i][−]_[1][ +] _[ V][i][−]_[1][)).] 

2. `Butterfly` : Perform log _n_ stages of butterfly operations (Figure 1) on the converted polynomial _f_ for evaluating on _c_ + _Vi_ . Since each stage computes _n/_ 2 butterflies operation, this step has _O_ ( _n_ log _n_ ) complexity. 

The presented `addFFT` has complexity _O_ ( _n_ log _n_ ) for a polynomial in the basis (11). However, if the polynomial is in the monomial basis, the fastest `addFFT` requires _O_ ( _n_ log _n_ log log _n_ ) complexity because converting the polynomial basis dominates its asymptotic complexity. 

## **2.4 Polynomial Multiplication in** F **2[** _**x**_ **]** 

We categorize polynomial multiplication algorithms in F2[ _x_ ] by polynomial length. The first category, base multiplication, directly performs multiplication operations using hardware instructions. This is typically employed when the length of the polynomials being multiplied is equal to the machine word size of the underlying architecture. 

The second category of algorithms is more suitable for medium-sized polynomials, particularly when base multiplication method (tied to the underlying architecture’s word size) has already been determined. For instance, the official HQC implementation utilizes a hybrid Toom-Karatsuba algorithm (see [Knu97]) for multiplying polynomials of specific lengths. The Karatsuba algorithm divides a multiplication of ( _A_ 0 + _A_ 1 _x[n]_ ) _·_ ( _B_ 0 + _B_ 1 _x[n]_ ) into three multiplications of _A_ 0 _· B_ 0, _A_ 1 _· B_ 1, and ( _A_ 0 + _A_ 1) _·_ ( _B_ 0 + _B_ 1) by ( _A_ 0 + _A_ 1 _x[n]_ ) _·_ ( _B_ 0 + _B_ 1 _x[n]_ ) = _A_ 0 _B_ 0 + [( _A_ 0 + _A_ 1) _·_ ( _B_ 0 + _B_ 1) + _A_ 0 _B_ 0 + _A_ 1 _B_ 1] _x[n]_ + _A_ 1 _B_ 1 _x_[2] _[n]_ . The algorithm is applied recursively until the length of the divided polynomials is equal to the base multiplication. Its asymptotic complexity is _O_ ( _n_[log][2][ 3] ). The Toom-Cook algorithm evaluates divided parts of input polynomials on some easily computable points and interpolates the products of evaluated values into its polynomial form. Toom and Karatsuba are usually considered simpler with a higher asymptotic complexity compared to the last category. 

The last category is FFT-based algorithms, which provide the lowest asymptotic complexity and are considered good for polynomials of “large” degrees. We present these FFT-based algorithms for polynomial multiplication in Subsection 3.1. 

Chen, Chiu, Peng, and Yang 

7 

The distinction between “medium” and “large” polynomial degrees, which dictates the choice of algorithm, is not fixed. The practical crossover point, where FFT-based methods become more efficient than Toom-Karatsuba like algorithms, is influenced by the instruction set available on the underlying hardware architecture. For example, a processor equipped with wide carry-less multiplication instructions (e.g., 64x64-bit `PCLMULQDQ` ) will favor Karatsuba for much longer polynomials compared to a processor limited to shorter multiplication instructions (e.g., 8x8-bit `PMULL.P8` ). Therefore, the ideal algorithm is a function of both the polynomial degree and the specific hardware capabilities. 

## **3 Polynomial Multiplication in** F **2[** _**x**_ **] with** **`addFFT`** 

A primary performance bottleneck in HQC is the multiplication within its defined polynomial ring, _R_ := F2[ _x_ ] _/_ ( _x[n]_ + 1). More specifically, a key challenge is that the parameter _n_ is not a power of two in the settings of HQC, which makes standard FFT-based polymuls inefficient. To overcome this obstacle, our strategy is twofold. First, we employ highly efficient algorithms based on `addFFT` to handle the large, power-of-two portion of the polynomial multiplication. Second, to address the non-power-of-two degrees, we introduce a split of the polynomial ring for the combination of additive FFT with the Chinese Remainder Theorem (CRT). This approach allows us to decompose one large, irregular multiplication problem into two smaller, more regular sub-problems. In doing so, we can leverage the power of `addFFT` where it is most effective, while bypassing the limitations imposed by the polynomial’s specific degree. 

This section is organized as follows: Subsection 3.1 describes two practical methods for using `addFFT` to multiply polynomials in F2[ _x_ ]: Kronecker Segmentation (KS) and the Frobenius Additive FFT (FAFFT). Subsection 3.2 details our new technique for combining `addFFT` with the CRT to efficiently handle the non-power-of-two polynomial degrees in HQC. Finally, Subsection 3.3 synthesizes these techniques, compares their estimated computational cost against the previous Toom-Karatsuba method. The performance benchmarks with regard to various platforms are presented in Section 5. 

## **3.1 FFT-based Polynomial Multiplication in** F **2[** _**x**_ **]** 

We introduce two FFT-based methods for multiplying polynomials in F2[ _x_ ] in this section. 

## **3.1.1 Kronecker Segmentation** 

The basic FFT-based method for multiplying Boolean polynomials is Kronecker segmentation (KS). Because the polynomial degree plays an important role on describing the method, we denote the polynomials of degree less than _n_ as F2[ _x_ ] _<n_ . Given two polynomials _A, B ∈_ F2[ _x_ ] _<n_ , we compute _C_ = _A · B ∈_ F2[ _x_ ] _<_ 2 _n_ using KS as follows: 

1. Partition _a_ ¯ _i ∈_ F2[ _x_ ] _<mA_ andand _By_ =into _x[m] m_ . -bit blocks, i.e., _A_ =[�] 0 _[n][−]_[1] _aix[i]_ =[�] _[n/m]_ 0 _[−]_[1] _a_ ¯ _iy[i]_ where 

2. Lift coefficients _a_ ¯ _i ∈_ F2[ _x_ ] _<m_ into F22 _m_ and let _A_[¯] =[�] 0 _[n/m][−]_[1] _a_ ¯ _iy[i] ∈_ F22 _m_ [ _y_ ] _<n/m_ . 

3. Compute the product _C_[¯] _∈_ F22 _m_ [ _y_ ] _<_ 2 _n/m_ = _A_[¯] _· B_[¯] by using a standard FFT-based polynomial multiplication over F22 _m_ [ _y_ ] as follows: 

   - (a) Forward FFT transform: _A_[ˆ] = ( _a[′]_ 0 _[, . . . , a][′]_ 2 _n/m−_ 1[)] _[ ∈]_[F][2] 2 _[n/m]_[2] _[m] ←_ `addFFT` ( _A, V_[¯] log(2 _n/m_ )). (b) Forward FFT transform: _B_[ˆ] = ( _b[′]_ 0 _[, . . . , b][′]_ 2 _n/m−_ 1[)] _[ ∈]_[F][2] 2 _[n/m]_[2] _[m] ←_ `addFFT` ( _B, V_[¯] log(2 _n/m_ )). 

Accelerating HQC with Additive FFT 

8 

- (c) Pointwise multiplication on two evaluated sets: 

**==> picture [246 x 16] intentionally omitted <==**

- (d) Inverse FFT transform: _C_[¯] _∈_ F22 _m_ [ _y_ ] _<_ 2 _n/m ←_ `addFFT` _[−]_[1] ( _C, V_[ˆ] log(2 _n/m_ )). 

4. Map _C_[¯] _→ C ∈_ F2[ _x_ ] _<_ 2 _n_ by substituting _y_ = _x[m]_ . 

Note that we split the polynomials into blocks of size _m_ and compute in F22 _m_ to prevent “overflow”. This also increases the required storage space for storing coefficients. 

In our implementation for HQC, we apply the KS method to multiply polynomials with degrees ranging from 2[14] to 2[16] bits. The polynomials are partitioned into 8-bit blocks, which means the operations are performed in a field of size 2[16] . However, instead of a standard F216 , representation, we follow the strategy from [CCK[+] 17] for using an extension field, specifically F2562. This choice offers two main advantages: 

- Efficient Arithmetic: The field F256 is based on an 8-bit polynomial representation. This specific size is highly suitable for leveraging short polynomial multiplication instructions, e.g., `PMULL.P8` . 

- Faster Butterfly Operations: While computing `addFFT` , many of the constant multipliers are elements of the subfield F256. For example, for any _a ∈_ F216, _si_ ( _a_ ) _∈_ F28 for stages of _i ≥_ 8 due to Eq. (9). Multiplying elements of F2562 by an element from this subfield only requires two multiplications in F256, making these initial FFT stages faster than if they were performed in a pure F2562 field. 

The main drawback of this approach is the need to perform a field isomorphism to map elements from F216 to F2562, which is implemented as a 16 _×_ 16 linear transformation. 

## **3.1.2 Frobenius Additive FFT** 

**A naive FFT polynomial multiplication** With the `addFFT` algorithm, we can naively perform multiplications in F2[ _x_ ] : given polynomials _A, B ∈_ F2[ _x_ ] _<n_ such that _C_ = _A · B_ is of degree smaller than 2 _n_ = 2 _[l]_[+1] , we can lift _A_ and _B_ to F2 _m_ [ _x_ ] _<n_ such that _m_ is a power of 2 and _l_ + 1 _≤ m_ . We perform _A_[ˆ] = `addFFT` ( _A, Vl_ +1) and _B_[ˆ] = `addFFT` ( _B, Vl_ +1), pointwise multiplication, and inverse `addFFT` to obtain _C_ = `addFFT` _[−]_[1] ( _A_[ˆ] _⊗ B, V_[ˆ] _l_ +1). This FFT-based multiplication works. However, it is less efficient than the KS method because it maps only one F2 coefficient to one F2 _m_ . The KS method packs _m/_ 2 coefficients from F2 into a single F2 _m_ coefficient. 

In 2017, Hoeven and Larrieu [vdHL17] improved the naive (multiplicative) FFT-based multiplication with the help of Frobenius map _ϕ_ 2 (squaring in F2): Given _a ∈_ F2 _m_ , the value _A_ ( _ϕ_ 2( _a_ )) can be deduced from _ϕ_ 2( _A_ ( _a_ )), meaning one can evaluate _A_ on a smaller set and then deduce values outside the set with _ϕ_ 2. 

**Frobenius additive FFT** In prior work [LCK[+] 18, CCK[+] 18], the authors proposed the evaluation domain for `addFFT` to be 

**==> picture [234 x 12] intentionally omitted <==**

subject to the conditions 

**==> picture [255 x 22] intentionally omitted <==**

The key finding is that the evaluation map `addFFT` ( _·,_ Σ), which transforms a polynomial _f_ into _f_ (Σ), is invertible. This is because the specific design of Σ includes a “gap” of _m/_ 2 

Chen, Chiu, Peng, and Yang 

9 

between the element _vl′_ + _m/_ 2 and the space _Vl′_ . This gap enables the 2 _n/m_ evaluation values (obtained from `addFFT` ( _·,_ Σ)) to be converted into 2 _n_ elements in the field F2 _m_ using the Frobenius map. It means that we can accomplish the multiplications in F2[ _x_ ] by evaluating _A, B_ only on the set Σ and interpolating their product _C_ from value space back to coefficients successfully. This way, the number of evaluation points is reduced by a factor of _m_ compared to the naive FFT multiplication. They called the method of performing addFFT on the set Σ as Frobenius additive FFT (FAFFT). 

While interpolating from the 2 _n/m_ evaluations in Σ to 2 _n_ coefficients in F2 _m_ , we actually perform the inverse `addFFT` on the larger domain Σ[˜] = _vl′_ + _m/_ 2 + _Vl′_ +log2 _m_ such that Σ _⊂_ Σ[˜] and _|_ Σ[˜] _|_ = 2 _n_ . Hence, we present the full polynomial multiplication with FAFFT as : 

**FAFFT for polynomial multiplication** Given two polynomials _A, B ∈_ F2[ _x_ ] _<n_ , the FAFFT method computes their product _C_ = _A · B ∈_ F2[ _x_ ] _<_ 2 _n_ as follows: 

1. Lift the coefficient ring of the polynomials _A, B ∈_ F2[ _x_ ] _<n_ to _A, B ∈_ F2 _m_ [ _x_ ] _<n_ . 

2. Compute additive FFT transforms: _A,_[ˆ] _B_[ˆ] _∈_ F[2] 2 _[n/m][m]_ = `addFFT` ( _A,_ Σ) _,_ `addFFT` ( _B,_ Σ). 

3. Pointwise multiplication: _C_[ˆ] _∈_ F[2] 2 _[n/m][m] ← A_[ˆ] _⊗ B_[ˆ] . 

4. Inverse FFT transform: _C ∈_ F2 _m_ [ _x_ ] _<_ 2 _n ←_ `addFFT` _[−]_[1] ( _C,_[ˆ] Σ).[˜] 

5. Map the coefficients of _C_ to F2 such that _C ∈_ F2[ _x_ ] _<_ 2 _n_ . 

The complexity of the polynomial multiplication is the same as the FFT in use. 

**Encode: a truncated computation of addFFT** When performing the computation `addFFT` ( _A,_ Σ) of FAFFT, there is a mismatch between the number of coefficients of _A_ and the number of evaluating points _|_ Σ _|_ = 2 _n/m_ . FAFFT see this as an evaluation on a matched set `addFFT` ( _A,_ Σ[˜] ) with truncation of the unnecessary values of points outside Σ. The starting log _m_ butterfly stages of this truncated additive FFT, which reduces the starting 2 _n_ points to 2 _n/m_ , are seen as an **Encoding** operation: With respect to Σ[˜] , **Encoding** is an invertible linear map which maps coefficients of _f_ ( _x_ ), e.g., ( _f_ 0 _, f_ 1 _, . . . , f_ 2 _n−_ 1) _∈_ F[2] 2 _[n]_ to ( _f_ 0 _[′][, . . . , f] n[ ′][′] −_ 1[)] _[ ∈]_[F] 2 _[n][m][′]_[where][the] _[f] i[ ′]_[is][defined][as] 

**==> picture [197 x 32] intentionally omitted <==**

where ( _j_ 0 _, j_ 1 _, . . . , j_ log _m−_ 1) _∈{_ 0 _,_ 1 _}_[log] _[ m]_ is the binary representation of the integer _j_ , i.e., _j_ =[�][log] _k_ =0 _[ m][−]_[1] _jk ·_ 2 _[k]_ . The constants _rj_ are derived from the accumulation of constant multipliers across stages of the `addFFT` algorithm. Specifically, _rj_ is defined as the product of the constant multipliers _si−_ 1( _a_ ) from log _m_ stages of the `Butterfly` operation, detailed in Algorithm 2. The initial constant _a_ for FAFFT starts with _a_ = _vl′_ + _m/_ 2 as defined in the domain Σ (Eq. (12)). 

## **3.1.3 Comparison of FFT-based Multiplication Methods** 

Both the FAFFT and KS methods share the same subroutines and asymptotic complexity _O_ ( _n_ log _n_ log log _n_ ), reflecting the complexity of `addFFT` operations. However, they differ in practical efficiency and memory usage. 

The primary advantage of FAFFT lies in its computational and memory efficiency. When multiplying polynomials to produce a product of 2 _n_ bits, FAFFT performs its transform on an evaluation domain of size 2 _n/m_ over the field F2 _m_ . In contrast, the KS method 

Accelerating HQC with Additive FFT 

10 

partitions the 2 _n_ bits into _m_ -bit blocks and operates on a domain of the same size (2 _n/m_ ) but over the larger field F22 _m_ . Consequently, FAFFT requires approximately half the storage space for the transformed polynomial values and subsequently about half the run time for the transform and pointwise multiplication steps. 

However, while multiplying polynomials of the same size, the KS method can usually operate with smaller fields. For instance, multiplying polynomials with a degree approaching 2[16] bits is not feasible with FAFFT over F216 because the required domain size _|_ Σ[˜] _|_ = 2[17] would exceed the field size 2[16] . In contrast, KS can partition the 2[16] bits into 2[13] byte segments and perform an `addFFT` for a polynomial in F216[ _x_ ] over a domain _V_ 14. 

In summary, FAFFT is generally faster and more memory-efficient as long as the polynomial degree is well within the limits imposed by the chosen field size. KS, while requiring more storage and operations, allows for operation in a smaller field that can be chosen to align with the underlying instruction set. 

## **3.2 Combination of Additive FFT and Chinese Remainder Theorem** 

The FFT-based multiplications are efficient for polynomials of degrees that are powers of 2. However, the polynomial lengths, or degrees, used in HQC are not precisely powers of 2. This discrepancy poses a challenge, as direct application of standard FFT algorithms becomes inefficient. To overcome this, a new technique combining additive FFT and Chinese Remainder Theorem (CRT) is employed. This approach allows for the efficient multiplication of polynomials with degrees of the form 2 _[k]_ + _c_ , where 2 _[k]_ is the largest power of 2 less than the polynomial degree, and _c_ is the remaining part. The core idea is to decompose the larger problem into smaller, more manageable sub-problems using CRT: 

**==> picture [169 x 14] intentionally omitted <==**

This decomposition enables the use of efficient additive FFT for the ring F2[ _x_ ] _/sk_ and a simpler modular reduction for the F2[ _x_ ] _/x[c]_ ring, thereby optimizing the overall multiplication process for non-power-of-2 degrees. While a similar CRT decomposition utilizing F[ _x_ ] _/x[c]_ as one of the smaller rings was previously proposed for polynomial multiplication over prime fields by [CYW25], our approach is fundamentally distinct. We are the first to adapt this decomposition to binary fields and combine it with the additive FFT framework instead of NTT in this work. 

While CRT usually requires moduli to be coprime, a generalized version can be applied even when moduli share a common factor, provided certain conditions are met. This section clarifies some key properties relevant to our application of CRT with additive FFT. 

## **Proposition 1.** `GCD` ( _si, x[c]_ ) = _x_ . 

Since _si_ = _x ·_ Π _j_ ( _x − j_ ) for all _j ∈ Vi_ and _j_ = 0 by (6) and _x[c]_ by definition has _x_ as its only irreducible factor, their Greatest Common Divisor (GCD) is _x_ . . 

**Proposition 2.** CRT works despite `GCD` ( _si, x[c]_ ) = _x ̸_ = 1. 

A challenge with this CRT-based decomposition is that the moduli, _si_ and _x_ are not coprime. As in Proposition 1, they share a common factor of _x_ . Therefore, the standard Chinese Remainder Theorem does not directly apply. 

However, a generalized version of the CRT can be used. For a polynomial _f_ to be uniquely determined by its remainders, _c_ 0 = _f_ mod _x[c]_ and _c_ 1 = _f_ mod _si_ , a consistency condition must be met: the two remainders must be congruent modulo their GCD, _x_ , i.e., 

_c_ 0 _≡ c_ 1 (mod _x_ ) _,_ 

Chen, Chiu, Peng, and Yang 

11 

requiring _c_ 0 and _c_ 1 have the same constant term. 

- This consistency condition is satisfied in our polymul application, where we compute _f_ = _g · h_ . The constant terms of the remainders are guaranteed to be identical as: 

   - The modulus _si_ is a multiple of _x_ by its definition (6), so the operation _f_ mod _si_ does not change the constant term of _f_ . 

   - Similarly, the operation _f_ mod _x[c]_ does not change the constant term. 

Since both remainders _c_ 0 and _c_ 1 preserve the original constant term of the product _f_ , they have the same constant term. 

## **Proposition 3.** `addFFT` ( _f, Vi_ ) = `addFFT` ( _f_ mod _si, Vi_ ). 

The vanishing polynomial _si_ is defined such that its roots are precisely the set of evaluation points _Vi_ , i.e., for any _v ∈ Vi_ , _si_ ( _v_ ) = 0. If we have a polynomial _f_ and we divide _f_ by _si_ to obtain _f_ = _Q · si_ + _R_ , where _R_ = _f_ mod _si_ is the remainder with deg _R <_ deg _si_ . For any evaluation point _v ∈ Vi_ , we can substitute _v_ into the equation: 

**==> picture [115 x 11] intentionally omitted <==**

Since _si_ ( _v_ ) = 0 for all _v ∈ Vi_ , the equation simplifies to : 

**==> picture [141 x 11] intentionally omitted <==**

This demonstrates that _f_ and its remainder _f_ mod _si_ evaluate to the same values at all points in _Vi_ . This proposition implies we cannot apply the same setting to FAFFT since FAFFT evaluates on points outside _Vi_ when used for polynomial multiplication. 

**The reverse CRT map** The Reverse CRT map is required to combine the results obtained from the two smaller modular rings, (F2[ _x_ ] _/si ×_ F2[ _x_ ] _/x[c]_ ), in order to recover the desired polynomial _f_ in the larger ring F2[ _x_ ] _<_ 2 _i_ + _c_ . 

Specifically, given the results _c_ 0 and _c_ 1 from the smaller rings (where deg _c_ 0 _< c_ and deg _c_ 1 _<_ 2 _[i]_ ), we seek a polynomial _f ∈_ F2[ _x_ ] _<c_ +2 _i−_ 1 satisfying: 

**==> picture [95 x 26] intentionally omitted <==**

To find the polynomial _f_ , the reverse CRT map is executed in two steps: 

1. We first determine the auxiliary polynomial _k ∈_ F2[ _x_ ] _<c−_ 1 via this congruence: 

**==> picture [259 x 12] intentionally omitted <==**

This step involves multiplying a pre-computed polynomial _Is_ (the inverse of _si/x_ modulo _x[c][−]_[1] ) Note that only the first _c −_ 1 terms of ( _c_ 0 _− c_ 1) _/x_ are required in the computation since deg _Is < c −_ 1 . 

2. Once _k_ is determined, the final result _f_ is recovered directly using the definition: 

**==> picture [218 x 11] intentionally omitted <==**

The polynomial _f_ lies in the target ring F2[ _x_ ] _<c_ +2 _i−_ 1. 

The derivation of Equation (13) is based on applying the extended Euclidean algorithm to Proposition 1, which establishes the relation 

1 _≡ Is ·_ ( _si/x_ ) (mod _x[c][−]_[1] ) _._ 

Accelerating HQC with Additive FFT 

12 

By substituting _f_ = _c_ 1 + _k · si_ into the first congruence: _f ≡ c_ 0 (mod _x[c]_ ), we arrive at 

_k ·_ ( _si/x_ ) _≡_ ( _c_ 0 _− c_ 1) _/x_ (mod _x[c][−]_[1] ) _._ 

Since _c_ 0 _− c_ 1 is divisible by _x_ by Proposition 2, dividing by _x_ and multiplying by the inverse _Is_ yields the expression for _k_ in Equation (13). 

For optimization, we employ a product scanning technique to compute the resulting terms of _f_ . This optimization collects all required source terms from two input polynomials ( _c_ 0 and _c_ 1) for a specific output degree. This approach significantly reduces redundant memory accesses to the destination terms, which is a bottleneck during the CRT computation. 

## **3.3 Polynomial Multiplication in HQC** 

In this section, we detail the steps for combining the KS and CRT techniques for polynomial multiplication in HQC. We use HQC-1 as a concrete example. In HQC-1, the polynomial length is _n_ = 17669. The steps are as follows: 

1. **Lift to** F2[ _x_ ] _<_ 32768+3072: The product of two polynomials has a degree less than 2 _n_ = 35338. To apply our method, we choose the nearest power of two, 2[15] = 32768, and handle the remaining portion. Our multiplication operates on polynomials in F2[ _x_ ] _<_ 32768+3072 to produce a product of degree up to 32768 + 3072 = 35840. 

2. **Map to** F216[ _x_ ] _<_ 4096+384 **by Kronecker segmentation** : The lifted polynomial in F2[ _x_ ] is then segmented into one-byte blocks, and the one-byte data are mapped into coefficients of polynomials in the ring F216 [ _x_ ]. Since all mapped coefficients are single-byte, this step in effectively a null operation. 

3. **Map to** F216[ _x_ ] _/s_ 12 _×_ F216[ _x_ ] _/x_[384] **by CRT** : Using the CRT, the polynomial in F216 [ _x_ ]4096+384 is decomposed into two components. The first component is modulo _s_ 12 = _x_[4096] + _. . ._ . Since deg _s_ 12 = 4096 _>_ (17669 _/_ 8), degree of input polynomial in F216 , this map is conceptual and has nothing to do again. The second component is modulo _x_[384] , which involves a simple truncation and can be multiplied directly. 

4. **Multiplication in the two rings:** F216 [ _x_ ] _/s_ 12 **and** F216 [ _x_ ] _/x_[384] : The multiplication on F216 [ _x_ ] _/x_[384] is done with a _truncated_ Karatsuba algorithm, truncating coefficients of degree _≥_ 384. Since the coefficients are only one byte, the multiplication between coefficients will not induce the “reduce” operation in the field multiplication, which is more efficient than normal field multiplication. 

We use KS for the multiplication in F216[ _x_ ] _/s_ 12. Again, we extract the one-byte coefficients to perform `BasisCvt` in the byte-data format. After `BasisCvt` and before `Butterfly` , we change this field representation of input polynomials from F216 [ _x_ ] to F2562[ _x_ ] (field isomorphism). This way, given an input polynomial _g ∈_ F2562[ _x_ ], we perform `addFFT` ( _g, V_ 12) and exploit the fast subfield multiplication described in 3.1.1. After the pointwise multiplication, inverse `addFFT` are finished, we change the field representation of the product back to F216[ _x_ ]. 

5. **Map the two products back to ring on** F216[ _x_ ] _<_ 4096+384 **by CRT** : 

   - (a) Find _k_ = _Is ·_ ( _c_ 0 _− c_ 1) _/x_ (mod _x_[383] ) by (13). We need only 383 terms of ( _c_ 0 _− c_ 1) _/x_ and multiply _Is_ with degree _<_ 383 for _k_ 

   - (b) Find _f_ = _c_ 1 + _k · s_ 12 by (14). 

6. **Recover the product to** F2[ _x_ ] _<_ 32768+3072. 

On the contrary, if we use FAFFT, we partition the input polynomials in F2[ _x_ ] _<_ 16384+1536 into 2 parts. The first part comprises terms of degrees _<_ 16384, and we perform their 

Chen, Chiu, Peng, and Yang 

13 

Table 2: Comparison of estimating numbers of base multiplications 

|Implementation|Base multiplication|_n_=17669|_n_=35851|_n_=57637|
|---|---|---|---|---|
||||||
|[AAB+25]|`PCLMULQDQ`|7290|21 870|54 675|
|**Proposed FFT-based methods**|||||
||||||
|Algorithm|Base multiplication|16 384 + 1536|32 768 + 4096|65 536|
||||||
|FAFFT<br>FAFFT<br>KS+CRT|F264 + `PCLMULQDQ`<br>F25622+ `PCLMULQDQ`<br>F2562 + `PMULL.P8`|7424 + 3672<br>16 384 + 3672<br>77 824 + 3240|16 384 + 12 393<br>35 840 + 12 393<br>167 936 + 17 496|35 840 + 0<br>77 824 + 0<br>360 448 + 0|



multiplication by FAFFT. The second part comprises terms of degrees _≥_ 16384, which are relatively short polynomials. Their multiplications are performed with Karatsuba. However, we have to perform the multiplication for all the cross terms between the two parts, which can be avoided by using the CRT method. 

We process HQC-3 which _n_ = 35851 _<_ 32768 + 4096 with similar methods as HQC1. Now the ring after KS becomes F216[ _x_ ] _<_ 8192+1024 and the two rings for CRT are F216[ _x_ ] _/_ ( _s_ 13) _×_ F216[ _x_ ] _/_ ( _x_[1024] ). The multiplication in the ring F216[ _x_ ] _/_ ( _s_ 13) is performed by addFFT multiplication over F2562[ _x_ ]. 

For HQC-5, the polynomial length is _n_ = 57637, which is slightly less than 2[16] = 65536. Therefore, the multiplication can be processed by straightforward FFT-based multiplication in the previous sections. 

**Summary** Table 2 summarizes our proposed FFT-based implementations, detailing the estimated number of base multiplications required for multiplying Boolean polynomials of different degrees. These estimates are derived by summing the operations across three major components: the addFFT transforms, the pointwise multiplications, and the Karatsuba combination steps applied to the remaining segments. We note that the CRT operation consumes only addition costs and involves no multiplication overhead. 

In Toom-Karatsuba, the numbers are measured from the implementation in [AAB[+] 25]. In the implementation, the base multiplication is 64 _×_ 64 _→_ 128 bits polynomial multiplication, which are `PCLMULQDQ` and `PMULL.P64` in x86 and ARMv8 architectures, respectively. 

In our FFT-based implementations, since the `addFFT` algorithm is suitable for processing polynomials of 2-power-sized, the 17669, 35851, and 57 637 bits of polynomials are processed as 16384+1536, 32768+4096, and 65 536 bits polynomials respectively. The long segments of 2-powered bits are multiplied with FFT-based algorithms, either FAFFT or KS. The remaining short segments are processed with Karatsuba. 

In FAFFT implementation, the base multiplication is field multiplication in F264 or F25622 for the `addFFT` computation and `PCLMULQDQ` for the remaining Karatsuba segment. In KS+CRT implementation, the base multiplication is field multiplication in F2562 for `addFFT` computation and `PMULL.P8` for the multiplication in the ring F216[ _x_ ] _/x[c]_ . 

## **4 Optimizing HQC** 

While FFT-based multiplication may not always significantly outperform a highly-optimized Karatsuba algorithm in raw performance, we can leverage its unique computational structure to achieve substantial overall performance gains in HQC’s encapsulation and decapsulation operations. The optimization methods we propose, as detailed in Algorithm 3, focus on two key strategies: cached key transform and common input transforms. We 

Accelerating HQC with Additive FFT 

14 

note that the two strategies are similar to those used in NTT-based schemes such as ML-KEM/Kyber [SAB[+] 22], which also cache values in the transformed domain. 

## **Algorithm 3** HQC-PKE with `addFFT` 

_Note: (1) We use the term_ _`addFFT` to denote the input transform operation shared by both the FAFFT and KS methods. We omit the specific evaluation domains of these two methods for brevity. (2) Blue text indicates a reused input transform._ 

- 1: Global parameters: ( _n, w, wr, we, ℓ, C_ ). 

2: HQC-PKE.KeygenCache( seedPKE ): 3: Derive (dkPKE _,_ seedPKE.ek) _←_ HASH _._ I(seedPKE). 4: Sample ( _y, x_ ) _←−−−R_ dkPKE _w × Rw_ . seedPKE.ek 5: Sample _h ←−−−−−R_ . 6: Set _h,_[ˆ] ˆ _y_ = `addFFT` ( _h_ ) _,_ `addFFT` ( _y_ ). ˆ ˆ 7: Set _s_ = `addFFT` ( _x_ + `addFFT` _[−]_[1] ( _h_[ˆ] _⊗ y_ )). 8: Set ekCPKE _,_ dkCPKE = (seedPKE.ek _,_ ˆ _s, h_[ˆ] ) _,_ (dkPKE _,_ ˆ _y_ ). 9: **return** (ekCPKE _,_ dkCPKE). 10: HQC-PKE.EncryptCache(ekCPKE _, m, θ_ ): randomness _θ_ 11: Sample ( _r_ 2 _, e, r_ 1) _←−−−−−−−−_ ( _Rwr , Rwe , Rwr_ ). ˆ 12: Set _r_ 2 = `addFFT` ( _r_ 2). 13: Set _u ← r_ 1 + `addFFT` _[−]_[1] ( _h_[ˆ] _⊗ r_ ˆ2). 14: Set _v ←C_ .Encode( _m_ ) + truncate( `addFFT` _[−]_[1] (ˆ _s ⊗ r_ ˆ2) + _e, ℓ_ ). 15: **return c** PKE = ( _u, v_ ). 16: HQC-PKE.DecryptCache(dkCPKE _,_ **c** PKE = ( _u, v_ )): ˆ 17: **return** _C_ .Decode( _v −_ truncate( `addFFT` _[−]_[1] ( `addFFT` ( _u_ ) _⊗ y_ ) _, ℓ_ )). 

## **4.1 Cached Key Transforms** 

A primary overhead in FFT-based multiplication comes from the “input transform” process, which converts a polynomial from its coefficient representation to evaluation value representation. To minimize this overhead, we introduce a key caching strategy. 

As shown in HQC-PKE.KeygenCache in Algorithm 3, we can perform a one-time preprocessing step on the keys, either during key generation or before their **first use** , while still preserving the original key format. Specifically: 

- The polynomials _h_ and _s_ in the encryption key are transformed and stored in their value representations, _h_[ˆ] and _s_ ˆ, in the cached encryption key ekCPKE. The ekCPKE ˆ 

- format simply appends two auxiliary terms ( _h_[ˆ] and _s_ ) to the original ekPKE. 

- ˆ 

- • Similarly, the decryption key polynomial _y_ is transformed to _y_ and appended to the original dkPKE as dkCPKE. 

These cached value representations – ( _h,_[ˆ] ˆ _s_ ) in ekCPKE and _y_ ˆ in dkCPKE – can then be used directly in subsequent encryption and decryption operations. The main advantage is that the costly `addFFT` input transforms are not performed repeatedly during frequent operations, thus amortizing their computational cost. The other benefit is that we remove the sampling process for polynomials _h_ and _y_ in HQC-PKE.Encrypt and HQC-PKE.Decrypt, respectively. 

We note that the cached key format requires more storage space compared to the original keys (see Table 3). This storage increase is attributed to the transformed value representations. Specifically, the polynomial _s_ (of size _|s|_ ) is transformed into its cached form _s_ ˆ 

Chen, Chiu, Peng, and Yang 

15 

(of size _|s_ ˆ _|_ ). The cached polynomial size _|s_ ˆ _|_ is approximately 2 _×_ the original size _|s|_ for FAFFT, and approximately 4 _×_ for KS. 

However, in many application scenarios – such as a server handling numerous requests with the same key pair – this time-for-space tradeoff is highly effective. We emphasize that cached keys are solely designed to accelerate encapsulation and decapsulation operations. Since they are pre-processed locally from the original keys, they are not intended for communication, meaning the increased size only affects local storage. Crucially, as the cached data contains the original key material, it requires the same level of cryptographic protection as the original keys. 

Table 3: Sizes (in bytes) of polynomials and cached keys 

||Standard|Standard|Standard|FAFFT|FAFFT|FAFFT|KS+CRT|KS+CRT|KS+CRT|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||
||_|s|_|_|_ekKEM_|_|_|_dkKEM_|_|_|_ˆ_s|_|_|_ekCKEM_|_|_|_dkCKEM_|_|_|_ˆ_s|_|_|_ekCKEM_|_|_|_dkCKEM_|_|
|||||||||||
|HQC-1|2209|2241|2321|4096+2240|12 673|19 089|8192+384|19 009|27 665|
|||||||||||
|HQC-3|4482|4514|4602|8192+4608|25 506|38 394|16384+1024|38 306|55 802|
|||||||||||
|HQC-5|7205|7237|7333|16 384|40 005|56 485|32 768|72 773|105 637|



## **4.2 Encryption Optimization: Common Input Transform** 

Our second optimization strategy takes full advantage of the internal structure of HQC-PKE. In HQC-PKE.Encrypt from Algorithm 1, the random polynomial _r_ 2 is used to compute two separate parts of the ciphertext: 

- _u ← r_ 1 + _h · r_ 2. 

- _v ←_ truncate( _s · r_ 2 + _e, ℓ_ ) + _C_ .Encode( _m_ ). 

With conventional multiplication, this would require two full polynomial multiplications. However, using the FFT-based method in the HQC-PKE.EncryptCache procedure from Algorithm 3, this process is significantly streamlined: 

1. **Single Transform** : We compute _r_ ˆ2 with only one input transform of _r_ 2. 

2. **Reuse** : This _r_ ˆ2 is then reused, undergoing pointwise multiplication ( _⊗_ ) with the cached elements _h_[ˆ] and _s_ ˆ in ekCPKE, respectively. 

3. **Inverse Transform** : Finally, the results of the pointwise multiplications are converted back to polynomial form using the inverse transform ( `addFFT` _[−]_[1] ). 

By sharing the transformed result of _r_ 2, we save one input transform. When combined with the key caching in Subsection 4.1, the number of `addFFT` computations is minimized during encryption, and the dominant operations become two output transforms. 

Due to the FO transform, the decapsulation operation includes a re-encryption step, meaning the aforementioned optimizations for encryption also effectively accelerate the overall performance of decapsulation. 

## **4.3 Faster Implementation for RM-RS Codes** 

## **4.3.1 SIMD RM Decoding** 

The encoding of the RM code is straightforward, as it involves a simple matrix vector product using `XOR` and duplication of the message bits. 

Accelerating HQC with Additive FFT 

16 

For decoding, while various algorithms exist—such as the Sidelnikov-Pershakov algorithm or recursive list decoding—we adopt the approach based on the Fast Hadamard Transform (FHT). This choice is made to comply with the official HQC specification [AAB[+] 25], ensuring compatibility. Furthermore, the FHT’s regular butterfly structure facilitates a constant-time implementation to mitigate timing side-channels and maps efficiently to the SIMD vector instructions focused on in this work. 

The decoding algorithm in general goes through the following steps: 

- `expand_and_sum` : expands codeword bits into computing units and sums the 3 or 5 multiple codeword copies into one. 

- `Hadamard` : performs the Hadamard transform, the maximum-likelihood decoding algorithm on first-order RM codes, on the collected codewords. 

- `find_peaks` : finds the location of the highest value in the Hadamard transform result. 

We implemented a vectorized version of the sequential `expand_and_sum` procedure defined in [AAB[+] 25]. Our SIMD approach efficiently processes data by broadcasting 2-byte data across all SIMD lanes and performing the required bit extraction using bit-masking. This vectorized `expand_and_sum` not only improves performance but also mitigates the power side-channel vulnerabilities demonstrated in [PRJB23, MNMD25], which specifically target the sequential bit splitting process. 

## **4.3.2 Improving Multiplication in** F **256** 

The encoding and decoding of the RS code involves heavy multiplications in F256. The implementation in [AAB[+] 25] uses `PCLMULQDQ` for the multiplication phase on the field in F256 to keep the time-constancy. To achieve higher performance, we instead implemented the SIMD F256 multiplication from [BCH[+] 23] in our implementation. All multiplications in F256 are accomplished using table look-up instructions. Although the `GF2P8MULB` instruction in GFNI is designed for F256 arithmetic in the AES representation, we note that the affine transform instruction also available in GFNI provides an efficient method to change the field representation. This allows for the effective integration of `GF2P8MULB` into any F256 multiplication routine. 

## **5 Implementation and Benchmarks** 

This section details our optimized implementations on the target platforms and presents their performance benchmarks. Subsection 5.1 reports the results of polynomial multiplication with `addFFT` . Subsection 5.2 reports our SIMD optimization for _C_ .Encode and _C_ .Decode. Subsection 5.3 reports the overall performance gain from our implementation. 

- **Benchmark Platforms** We evaluated the performance of our implementation across three distinct hardware architectures: a high-end x86 server (AMD EPYC), an Apple M1 system, and a low-power ARM embedded platform (Cortex-A72). The specifics of each platform and the build environment are detailed below. • AMD EPYC 9754 ( **X86Avx2** and **GFNI** ): Benchmarks on the x86 platform were performed on an AMD EPYC 9754. This CPU supports the AVX2, `PCLMULQDQ` , and GFNI instruction sets. To evaluate the impact of instruction sets, we define two specific execution environments: AVX2+ `PCLMULQDQ` ( **X86Avx2** ) and AVX2+ `PCLMULQDQ` +GFNI ( **GFNI** ). All x86 benchmarks were performed on Ubuntu 24.04.2 LTS using GCC 13.3.0. Turbo Boost and Hyper-Threading (SMT) were disabled. 

Chen, Chiu, Peng, and Yang 

17 

- Apple M1 ( **AplM1** ): We used an Apple M1 CPU running macOS 26.0.1. The code was compiled with Apple Clang 17.0.0. 

- ARM Cortex-A72 ( **Pi4** ). This platform utilized a Raspberry Pi 4 featuring an ARM Cortex-A72 CPU. The environment was Debian GNU/Linux 12 with GCC 12.2.0. 

All measurements report the median of 1000 measurements from random instances. 

## **5.1 Polynomial Multiplication** 

## **5.1.1 Implementation** 

We implemented platform-specific optimization strategies to leverage the instruction set architectures. 

**X86Avx2** For polynomial multiplication in F264, we utilize the `PCLMULQDQ` instruction. The process involves two primary phases: 1) Multiplication: A single `PCLMULQDQ` performs the 64 _×_ 64-bit polynomial multiplication, resulting in a 127-degree polynomial. 2) Modular Reduction: The result is then reduced modulo the field polynomial. This involves multiplying the terms with degrees greater than 63 by the module _x_[4] + _x_[3] + _x_ + 1 with one `PCLMULQDQ` . As the intermediate result may still reach degree 67, a subsequent `PSHUFB` instruction is employed to reduce the terms of degree 64 to 67 down to degrees 0 to 7. 

On optimizing the `addFFT` computation, we process two butterfly stages simultaneously, letting us perform fewer modular reduction operations over accumulating two products. Furthermore, we maximize instruction throughput and effectively hide the latency associated with field multiplication by processing four field multiplications in parallel. 

**GFNI** We adopt the field of F25622 as (4) in FAFFT, enabling us to leverage the `GF2P8MULB` instruction for native multiplication in F256. For `addFFT` optimization in this setting, the constant multipliers are consistently smaller than 2[24] . This ensures the highest byte in the F25622 field is always zero, allowing for faster field arithmetic by skipping the processing of the zero-valued byte. 

**AplM1** Our implementation and optimization strategy on the Apple M1 platform is similar to **X86Avx2** platform, as the ARM `PMULL.P64` instruction is functionally equivalent to the `PCLMULQDQ` instruction. The transition from 256-bit AVX registers to 128-bit NEON registers provided an additional benefit by reducing some data rearrangement overhead, which proved advantageous for the FAFFT implementation. 

**Pi4** On platforms lacking a dedicated long polynomial multiplication instruction, e.g. `PMULL.P64` , we adopted a multiplication algorithm based on short multiplication instructions. We implemented the KS+CRT method for polynomial multiplication, running the `addFFT` over the relatively small field F2562 (as defined in Eq. (3)), which contrasts with the larger F264 or F25622 fields used in FAFFT. 

The `PMULL.P8` instruction performs 8 _×_ 8-bit polynomial multiplication, making it suitable for the multiplication phase of field arithmetic in F256. The subsequent reduction phase is efficiently accomplished using two table look-up operations. 

Furthermore, during the `addFFT` computation within the KS algorithm, the multiplier constants used in the butterfly operations are consistently in the F256 subfield in starting butterfly stages. This allows the multiplications in butterfly to become two F256 multiplications instead of a normal multiplication in F2562, due to the carefully chosen field representation specified in Eq. (3). 

On the CRT method, we need to compute the multiplication in the modular rings F216 [ _x_ ] _/x_[384] or F216 [ _x_ ] _/x_[1024] . The multiplication in these rings is executed using a Karat- 

Accelerating HQC with Additive FFT 

18 

Table 4: Cycle counts of polynomial multiplication 

|Platform<br>Algorithm<br>HQC-1<br>HQC-3<br>HQC-5<br>_n_=17 669<br>_n_=35 851<br>_n_=57 637<br>**X86Avx2**<br>Toom-Karatsuba ([AAB+25])<br>27 662<br>80 881<br>195 234<br>FAFFT (F264)<br>57 612<br>139 629<br>202 792<br>FAFFT (F25622,**GFNI**)<br>34 042<br>87 652<br>102 997<br>**AplM1**<br>Toom-Karatsuba (porting [AAB+25])<br>31 359<br>93 172<br>236 753<br>FAFFT (F264)<br>39 032<br>92 186<br>135 700<br>**Pi4**<br>Toom-Karatsuba (porting [AAB+25])<br>301 632<br>912 250<br>2 293 670<br>KS + CRT (F2562)<br>329 319<br>788 052<br>1 317 323|Algorithm|HQC-1<br>_n_=17 669|HQC-3<br>_n_=35 851|HQC-5<br>_n_=57 637|
|---|---|---|---|---|
||Toom-Karatsuba (porting [AAB+25])<br>KS + CRT (F2562)|301 632<br>329 319|912 250<br>788 052|2 293 670<br>1 317 323|



Table 5: Cycle counts of codec in HQC 

|Platform<br>Implementation|Platform<br>Implementation|Platform<br>Implementation|HQC-1|HQC-1|HQC-3|HQC-3|HQC-3|HQC-3|
|---|---|---|---|---|---|---|---|---|
||||Encode|Decode|Encode|Decode|Encode||
||||||||||
|**X86Avx2**|[AAB+25]<br>This work<br>This work,**GFNI**||2932<br>1271<br>1219|90 465<br>64 062<br>63 157|4037<br>1713<br>1481|139 102<br>79 523<br>78 540|8346<br>2650<br>2519|262 629<br>158 793<br>157 719|
||||||||||
|**AplM1**|This work||1364|53 619|1797|69 152|2688|141 366|
||||||||||
|**Pi4**|This work||1243|134 793|1599|173 903|2500|360 966|



suba algorithm layered over a base 8 _×_ 8 schoolbook multiplication over F216. Since the input data is handled in byte chunks by the KS method, the product of two byte-chunk inputs does not trigger the reduction phase of F216 multiplication. Consequently, the `PMULL.P8` instruction is ideal for the base multiplication. 

The reverse CRT map, which involves repeated multiplication and reduction steps, typically leads to frequent memory accesses to the two intermediate products. To address this overhead, we employ a product scan technique to minimize memory load and store operations. Instead of repeatedly accessing the full memory blocks, we sequentially collect all the intermediate coefficients contributing to the final result. Most product coefficients require only data rearrangement. For the remaining complex coefficients, we load only the essential data on demand, thus effectively avoiding redundant data transfers. 

## **5.1.2 Benchmark Results** 

We report the performance of our FFT-based polynomial multiplication implementation in _Table_ 4. The results indicate that the FFT-based approach outperforms Toom-Karatsuba for polynomials of sufficiently high degree, confirming the expected asymptotic advantage of the FFT method. For comparison on the **Pi4** platform, we adapted the Toom-Karatsuba polynomial multiplication algorithms provided by the official HQC team. Specifically, the 64 _×_ 64 _→_ 128 base multiplication in F2[ _x_ ] was built using the schoolbook method detailed in [CGLD13], with Karatsuba then applied for higher-degree polynomials. 

**Comparative performance analysis** Our evaluation focuses on three key comparisons to highlight the algorithmic advantages and the impact of instruction set architectures. 

We begin by comparing the polynomial multiplication algorithms across the **X86Avx2** and **AplM1** platforms, which utilize functionally equivalent instructions for long polynomial multiplication ( `PCLMULQDQ` and `PMULL.P64` ). On **AplM1** , the benchmark results indicate a crossover point where FAFFT begins to outperform Toom-Karatsuba, occurring between 

Chen, Chiu, Peng, and Yang 

19 

HQC-1 and HQC-3. Conversely, on **X86Avx2** , Toom-Karatsuba retains a slight advantage, outperforming FAFFT by 6% even at the largest scale, HQC-5. This result suggests that the two algorithms achieve a near-even break in the context of HQC’s required polynomial degrees, given the availability of dedicated long polymul instructions. The relative performance advantage appears to be highly sensitive to the underlying microarchitecture. 

Next, we quantify the performance effect of the GFNI instruction set by comparing the results between the **X86Avx2** and **GFNI** platforms. While both implementations utilize the same FAFFT algorithm, they operate over two distinct fields: F264 and F25622 , respectively. The results show that the specialized GFNI instruction set provides a significant performance improvement over pure `PCLMULQDQ` , yielding a performance gain of approximately 100% for HQC-5. We emphasize that this improvement is not a naive benefit of a powerful new ISA. Instead, the gain stems from the co-design of the algorithm and the hardware instructions. To fully utilize the `GF2P8MULB` instruction within GFNI, we specifically adopted the F25622 field and its representation in Eq. (4) to minimize the cost of constant multiplication during the Butterfly process. 

Finally, on the resource-constrained **Pi4** platform, which is equipped only with the `PMULL.P8` instruction for multiplication, we observe a distinct crossover point, where the KS+CRT algorithm begins to surpass Toom-Karatsuba, occurring approximately near the complexity of HQC-1. This result indicates that on resource-limited embedded systems, the FFT-based approach proves more efficient than the Toom-Karatsuba algorithms for the polynomial degrees used in HQC. This finding aligns strongly with prior research. The study by [LJKH25] demonstrated that a bit-sliced implementation of the FAFFT algorithm is more efficient than Karatsuba algorithms across all HQC parameters on embedded systems lacking dedicated polynomial multiplication instructions. 

**Addressing portability and performance attribution** Our evaluation clarifies the performance gains attributable to portable algorithmic improvements versus platform-specific instruction sets. The performance comparison between **X86Avx2** and **AplM1** , which rely on functionally equivalent `PCLMULQDQ` instructions, demonstrates the portability of the FFT-based approaches. However, the 100% gain observed in **GFNI** is attributable to the non-portable GFNI ( `GF2P8MULB` ) instruction set. This highlights that while the core FFT algorithm is portable, maximum performance is achieved through dedicated algorithm-ISA co-design. The performance dominance observed on the resource-constrained **Pi4** platform further validates the portability and effectiveness of the FFT-based approach even in the absence of any long-multiplication instruction. 

## **5.2 SIMD Code Implementation** 

_Table_ 5 summarizes our SIMD-optimized RM-RS codec, confirming the effectiveness of SIMD across all tested platforms. Our proposed optimizations achieve substantial speedups over the official implementation [AAB[+] 25] on **X86Avx2** , notably providing an approximate 1 _._ 66 _×_ acceleration for the HQC-5 decoding operation. These performance gains are attributed to two key SIMD strategies: optimized F256 multiplication and vectorized bit extraction in the `expand_and_sum` procedure. Furthermore, the vectorized bit extraction mitigates side-channel vulnerabilities. The F256 multiplication is further enhanced on **GFNI** platforms using AESMUL, providing an additional performance reduction. Our implementation also demonstrates strong scalability on `ARMv8-A` , with the **Pi4** platform validating the `PMULL.P8` -based method’s effectiveness on resource-limited embedded systems. 

Accelerating HQC with Additive FFT 

20 

Table 6: Kilo-cycle counts of HQC implementations 

|Platform|Implementation|Implementation|HQC-1|HQC-3|HQC-3|
|---|---|---|---|---|---|
||||Key/Enc/Dec|Key/Enc/Dec||
|||||||
|**X86Avx2**|[AAB+25]||72 / 141 / 315|173 / 340 / 671|353 / 697 / 1344|
||This work<br>cache key||103 / 187 / 363<br>117 / 139 / 292|231 / 427 / 761<br>263 / 330 / 610|358 / 648 / 1197<br>423 / 463 / 910|
||This work, **GFNI**<br>cache key||78 / 144 / 296<br>87 / **110** / **245**|179 / 339 / 622<br>200 / **272** / **517**|249 / 464 / 901<br>292 / **343** / **711**|
|||||||
|**AplM1**|Porting [AAB+25]||72 / 155 / 303|186 / 398 / 688|412 / 842 / 1445|
||This work<br>cache key||80 / 157 / 313<br>93 / **125** / **259**|188 / 374 / 672<br>212 / **302** / **554**|308 / 588 / 1092<br>352 / **460** / **870**|
|||||||
|**Pi4**|Porting [AAB+25]||416 / 820 / 1391|1191 / 2342 / 3735|2798 / 5551 / 8725|
||This work<br>cache key||447 / 784 / 1374<br>547 / **568** / **1029**|1078 / 1903 / 3137<br>1279 / **1465** / **2399**|1801 / 3185 / 5336<br>2278 / **2348** / **3986**|



## **5.3 Optimized Implementations of HQC** 

Table 6 compares our HQC implementations, which incorporate FFT-based polynomial multiplication and SIMD codec optimizations, against the official optimization [AAB[+] 25]. The results demonstrate that the FFT-based approach, when combined with the cache key strategy, outperforms the HQC official optimization in both encapsulation and decapsulation across all tested platforms, despite exhibiting slower raw multiplication speeds in the HQC-1 implementation. The performance gain is distinctly two-fold: First, the GFNI-enabled implementation shows the most significant acceleration, leading a clear performance gap over x86 platforms (e.g., a 1 _._ 68 _×_ speedup on HQC-5 **Dec** over our base **X86Avx2** implementation). This emphasizes the impact of algorithm-ISA co-design. Second, the cache key strategy shifts the input transform cost from the frequent **Enc** and **Dec** operations to the one-time **KeyGen** operation. This strategy results in the best cycle counts for **Enc** and **Dec** operations across all security levels, regardless of the underlying microarchitecture. 

**Performance profiling of HQC KEM** We conduct a more thorough cost comparison for the four major computational components in the HQC KEM. Table 7 shows the detailed cycle counts consumed by these major components. The results from the reference implementation of the HQC team indicate that ring multiplication is indeed the computational bottleneck in HQC. This situation is particularly severe on platforms lacking dedicated hardware instructions, where only the reference code can be executed. Conversely, the profiling data from our optimized implementation demonstrates that the optimization of ring operations significantly reduces their percentage of the total execution time. However, even after optimizing the ring operation with dedicated instructions, it still accounts for the largest fraction of the total running time, affirming that it remains the most critical target for future optimization efforts. 

## **6 Concluding Remarks** 

In this work, we demonstrated that FFT-based multiplication can significantly accelerate the HQC key encapsulation mechanism. Our concluding findings are twofold: 

First, the primary performance advantage of our approach does not necessarily come from the raw speed of FFT-based multiplication, which are actually comparable to highlyoptimized Toom-Karatsuba on platforms on HQC’s settings of polynomial degrees. Instead, 

Chen, Chiu, Peng, and Yang 

21 

Table 7: Kilo-cycle counts for major operations in HQC 

|**HQC**<br>**Operation**|**HQC**<br>**Operation**|**Ofcial Reference**[AAB+25]<br>**Hash Sample**<br>**Ring**<br>**Code**|**Ofcial Reference**[AAB+25]<br>**Hash Sample**<br>**Ring**<br>**Code**|**The GFNI Implementation**<br>**Hash Sample Ring**<br>**Code**|
|---|---|---|---|---|
||||||
|**HQC-1**<br>Keygen<br>Encap<br>Decap||1.8<br>104.6<br>3612.8<br>0.0<br>52.3<br>142.6<br>7222.4<br>27.0<br>146.0<br>142.1<br>10829.6<br>347.1||1.5<br>40.5<br>33.4<br>0.0<br>44.1<br>37.8<br>59.6<br>1.2<br>97.8<br>37.4<br>92.8<br>64.3|
||||||
|**HQC-3**<br>Keygen<br>Encap<br>Decap||1.9<br>283.3<br>10988.2<br>0.0<br>102.7<br>407.6<br>21954.2<br>42.9<br>328.8<br>406.9<br>32933.2<br>473.2||1.5<br>87.4<br>87.6<br>0.0<br>86.8<br>86.0<br>161.7<br>1.5<br>199.2<br>85.5<br>249.6<br>80.0|
||||||
|**HQC-5**<br>Keygen<br>Encap<br>Decap||2.2<br>552.5<br>27081.2<br>0.0<br>162.6<br>828.9<br>54100.9<br>101.8<br>574.1<br>827.9<br>81132.9 1059.0||1.5<br>150.1<br>95.1<br>0.0<br>136.9<br>157.4<br>161.1<br>2.5<br>321.6<br>156.9<br>255.9<br>160|



the most substantial gains are achieved by eliminating redundant computations. By caching the input transforms of key pairs and reusing the transform of the common operand _r_ 2 during encryption, we effectively reduce the computational overhead in both Encap and Decap. As evidenced by our benchmarks, this strategy leads to better performance, particularly for HQC-1, even when the multiplication itself is not the fastest. 

Second, our results show that the optimal choice of a polynomial multiplication algorithm is highly dependent on the target architecture’s available instructions, more so than on asymptotic complexity alone. We conclude with the following recommendations: 

- For platforms with long multiplication instruction (e.g., `PCLMULQDQ` and `PMULL.P64` ): The performance between FAFFT and Toom-Karatsuba is characterized by a neareven break for HQC-sized polynomials. Specifically, the FAFFT shows an advantage on the Apple M1 microarchitecture (with the crossover point near HQC-1/HQC-3), while Toom-Karatsuba maintains a slight edge on the AMD EPYC (x86) microarchitecture at larger scales. This indicates that the relative performance superiority is highly sensitive to the underlying microarchitectural implementation. However, our work shows that even when raw multiplication is slower, an FFT-based implementation yields superior overall KEM performance in encapsulation and decapsulation due to significant savings from transform caching and reuse. 

- For platforms with only short multiplication instructions (e.g., `PMULL.P8` ): On these architectures, the crossover point occurs at a lower polynomial degree. Our findings clearly show that the additive FFT approach, combined with CRT, becomes the superior strategy for the HQC-3 and HQC-5 parameter sets. While Toom-Karatsuba holds a narrow lead in raw multiplication for the HQC-1, the FFT-based approach still delivers better overall KEM performance when caching is applied, making it the more effective strategy. 

## **Acknowledgements** 

We are supported by Academia Sinica Grand Challenge Project (AS-GCP-114-M01), and National Science and Technology Council grants 114-2221-E-001-014-MY3, 113-2221-E001-023-MY3 

Accelerating HQC with Additive FFT 

22 

## **References** 

- [AAB[+] 22] Carlos Aguilar-Melchor, Nicolas Aragon, Slim Bettaieb, Loïc Bidoux, Olivier Blazy, Jean-Christophe Deneuville, Philippe Gaborit, Edoardo Persichetti, Gilles Zémor, Jurjen Bos, Arnaud Dion, Jerome Lacan, Jean-Marc Robert, and Pascal Veron. HQC. Technical report, National Institute of Standards and Technology, 2022. available at `https://csrc.nist.gov/Projects/ post-quantum-cryptography/round-4-submissions` . 

- [AAB[+] 25] Carlos Aguilar-Melchor, Nicolas Aragon, Slim Bettaieb, Loïc Bidoux, Olivier Blazy, Jean-Christophe Deneuville, Philippe Gaborit, Edoardo Persichetti, Gilles Zémor, Jurjen Bos, Arnaud Dion, Jerome Lacan, Jean-Marc Robert, Pascal Veron, Paulo L. Barreto, Santosh Ghosh, Shay Gueron, Tim Güneysu, Rafael Misoczki, Jan Richter-Brokmann, Nicolas Sendrier, Jean-Pierre Tillich, and Valentin Vasseur. HQC. Technical report, pqc-hqc.org, 2025. available at `https://pqc-hqc.org/doc/hqc_specifications_2025_08_22.pdf` . 

- [ABP25] Francesco Antognazza, Alessandro Barenghi, and Gerardo Pelosi. An Efficient and Unified RTL Accelerator Design for HQC-128, HQC-192, and HQC-256 . _IEEE Transactions on Computers_ , 74(07):2306–2320, July 2025. 

- [AGZ] Nicolas Aragon, Philippe Gaborit, and Gilles Zémor. Hqc-rmrs, an instantiation of the hqc encryption framework with a more efficient auxiliary errorcorrecting code. `https://arxiv.org/abs/2005.10741` . 

- [BCH[+] 23] Ward Beullens, Ming-Shing Chen, Shih-Hao Hung, Matthias J. Kannwischer, Bo-Yuan Peng, Cheng-Jhih Shih, and Bo-Yin Yang. Oil and vinegar: Modern parameters and implementations. _IACR TCHES_ , 2023(3):321–365, 2023. 

- [Can89] David G Cantor. On arithmetical algorithms over finite fields. _Journal of Combinatorial Theory, Series A_ , 50(2):285–300, 1989. 

- [CCK[+] 17] Ming-Shing Chen, Chen-Mou Cheng, Po-Chun Kuo, Wen-Ding Li, and Bo-Yin Yang. Faster multiplication for long binary polynomials. _CoRR_ , abs/1708.09746, 2017. 

- [CCK[+] 18] Ming-Shing Chen, Chen-Mou Cheng, Po-Chun Kuo, Wen-Ding Li, and Bo-Yin Yang. Multiplying boolean polynomials with frobenius partitions in additive fast fourier transform. _CoRR_ , abs/1803.11301, 2018. 

- [CCK21] Ming-Shing Chen, Tung Chou, and Markus Krausz. Optimizing BIKE for the intel haswell and ARM Cortex-M4. _IACR TCHES_ , 2021(3):97–124, 2021. 

- [CGKT22] Ming-Shing Chen, Tim Güneysu, Markus Krausz, and Jan Philipp Thoma. Carry-less to BIKE faster. In Giuseppe Ateniese and Daniele Venturi, editors, _ACNS 2022_ , volume 13269 of _LNCS_ , pages 833–852, Rome, Italy, June 20–23, 2022. Springer, Cham, Switzerland. 

- [CGLD13] Danilo Câmara, Conrado P. L. Gouvêa, Julio López, and Ricardo Dahab. Fast software polynomial multiplication on arm processors using the neon engine. In Alfredo Cuzzocrea, Christian Kittl, Dimitris E. Simos, Edgar Weippl, and Lida Xu, editors, _Security Engineering and Intelligence Informatics_ , pages 137–154, Berlin, Heidelberg, 2013. Springer Berlin Heidelberg. 

- [CYW25] Chun-Ming Chiu, Bo-Yin Yang, and Bow-Yaw Wang. A new trick for polynomial multiplication: A verified crt polymul utilizing a monomial factor. _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , 2025(4):795– 816, Sep. 2025. 

Chen, Chiu, Peng, and Yang 

23 

- [DXN[+] 24] Sanjay Deshpande, Chuanqi Xu, Mamuri Nawan, Kashif Nawaz, and Jakub Szefer. Fast and efficient hardware implementation of HQC. In Claude Carlet, Kalikinkar Mandal, and Vincent Rijmen, editors, _SAC 2023_ , volume 14201 of _LNCS_ , pages 297–321, Fredericton, Canada, August 14-18, 2024. Springer, Cham, Switzerland. 

- [FO99] Eiichiro Fujisaki and Tatsuaki Okamoto. Secure integration of asymmetric and symmetric encryption schemes. In Michael J. Wiener, editor, _CRYPTO’99_ , volume 1666 of _LNCS_ , pages 537–554, Santa Barbara, CA, USA, August 15–19, 1999. Springer Berlin Heidelberg, Germany. 

- [GM10] Shuhong Gao and Todd D. Mateer. Additive fast fourier transforms over finite fields. _IEEE Trans. Inf. Theory_ , 56(12):6265–6272, 2010. 

- [HHK17] Dennis Hofheinz, Kathrin Hövelmanns, and Eike Kiltz. A modular analysis of the fujisaki-okamoto transformation. In Yael Kalai and Leonid Reyzin, editors, _Theory of Cryptography_ , pages 341–371, Cham, 2017. Springer International Publishing. 

- [Int14] Intel. Intel carry-less multiplication instruction and its usage for computing the gcm mode, 2014. `https://cdrdv2-public.intel.com/836172/ clmul-wp-rev-2-02-2014-04-20.pdf` . 

- [Int21] Intel. Galois field new instructions (gfni) technology guide, 2021. `https://cdrdv2.intel.com/v1/dl/getContent/644497?fileName=GFNI_ TechGuide_644497v2.pdf` . 

- [Knu97] Donald E. Knuth. _The art of computer programming, volume 2 (3rd ed.): seminumerical algorithms_ . Addison-Wesley Longman Publishing Co., Inc., USA, 1997. 

- [LANHC16] Sian-Jheng Lin, Tareq Y. Al-Naffouri, Yunghsiang S. Han, and Wei-Ho Chung. Novel polynomial basis with fast fourier transform and its application to reed–solomon erasure codes. _IEEE Transactions on Information Theory_ , 62(11):6284–6299, 2016. 

- [LC04] Shu Lin and Daniel J. Costello. _Error Control Coding, Second Edition_ . Prentice-Hall, Inc., USA, 2004. 

- [LCH14] Sian-Jheng Lin, Wei-Ho Chung, and Yunghsiang S. Han. Novel polynomial basis and its application to reed-solomon erasure codes. In _55th FOCS_ , pages 316–325, Philadelphia, PA, USA, October 18–21, 2014. IEEE Computer Society Press. 

- [LCK[+] 18] Wen-Ding Li, Ming-Shing Chen, Po-Chun Kuo, Chen-Mou Cheng, and BoYin Yang. Frobenius additive fast fourier transform. In Manuel Kauers, Alexey Ovchinnikov, and Éric Schost, editors, _Proceedings of the 2018 ACM on International Symposium on Symbolic and Algebraic Computation, ISSAC 2018, New York, NY, USA, July 16-19, 2018_ , pages 263–270. ACM, 2018. 

- [LJKH25] Myeonghoon Lee, Jihoon Jang, Suhri Kim, and Seokhie Hong. Improved frobenius fft for code-based cryptography on cortex-m4. _IEEE Internet of Things Journal_ , 12(17):36318–36327, 2025. 

- [MNMD25] Nathan Maillet, Cyrius Nugier, Vincent Migliore, and Jean-Christophe Deneuville. Key recovery from side-channel power analysis attacks on nonSIMD HQC decryption. In Yael Tauman Kalai and Seny F. Kamara, editors, 

Accelerating HQC with Additive FFT 

24 

   - _CRYPTO 2025, Part V_ , volume 16004 of _LNCS_ , pages 70–102, Santa Barbara, CA, USA, August 17–21, 2025. Springer, Cham, Switzerland. 

- [MPR[+] 24] Dustin Moody, Ray Perlner, Andrew Regenscheid, Angela Robinson, and David Cooper. Transition to post-quantum cryptography standards. NIST Internal Report (IR) NIST IR 8547, National Institute of Standards and Technology, Gaithersburg, MD, 2024. `https://doi.org/10.6028/NIST.IR. 8547.ipd` . 

- [PRJB23] Thales Paiva, Prasanna Ravi, Dirmanto Jap, and Shivam Bhasin. Et tu, brute? SCA assisted CCA using valid ciphertexts - A case study on HQC KEM. Cryptology ePrint Archive, Report 2023/1626, 2023. 

- [RLC[+] 25a] Antonio Ras, Antoine Loiseau, Mikael Carmona, Simon Pontié, Guénaël Renault, Benjamin Smith, and Emanuele Valea. Optimizing hqc using frobenius additive fft on a risc-v-based system-on-chip. NIST Sixth PQC Standarization Conference, 2025. available at `https://csrc.nist.gov/ csrc/media/events/2025/sixth-pqc-standardization-conference/ optimizing%20hqc%20using%20frobenius%20additive%20fft.pdf` . 

- [RLC[+] 25b] Antonio Ras, Antoine Loiseau, Mikaël Carmona, Simon Pontié, Guénaël Renault, Benjamin Smith, and Emanuele Valea. PHOENIX: Crypto-agile hardware sharing for ML-KEM and HQC. Cryptology ePrint Archive, Report 2025/601, 2025. 

- [SAB[+] 22] Peter Schwabe, Roberto Avanzi, Joppe Bos, Léo Ducas, Eike Kiltz, Tancrède Lepoint, Vadim Lyubashevsky, John M. Schanck, Gregor Seiler, Damien Stehlé, and Jintai Ding. CRYSTALS-KYBER. Technical report, National Institute of Standards and Technology, 2022. available at `https://csrc.nist.gov/Projects/post-quantum-cryptography/ selected-algorithms-2022` . 

- [vdHL17] Joris van der Hoeven and Robin Larrieu. The frobenius fft. In _Proceedings of the 2017 ACM International Symposium on Symbolic and Algebraic Computation_ , ISSAC ’17, page 437–444, New York, NY, USA, 2017. Association for Computing Machinery. 

