---
source_pdf: docs/references/pdf/other-platforms/LEAP_Lightweight_and_Efficient_Accelerator_for_Sparse_Polynomial_Multiplication_of_HQC.pdf
converted_at: 2026-05-29 22:40
conversion_time: 2.2s
tool: pymupdf4llm
---

IEEE TRANSACTIONS ON VERY LARGE SCALE INTEGRATION (VLSI) SYSTEMS, VOL. 31, NO. 6, JUNE 2023 

892 

## LEAP: Lightweight and Efficient Accelerator for Sparse Polynomial Multiplication of HQC 

## Yazheng Tu , Pengzhou He 

## , Çetin Kaya Koç , and Jiafeng Xie 

efficiency of the scheme implementation [4]. However, one has to be aware that the polynomial multiplier of HQC involves operations of sparse matrices or vectors with very large dimensions [4], [7], for example, polynomials of size _n_ = 57 637 with only 149 nonzero elements, which is extremely time- and space-consuming. Overall, there exist two challenges: 1) for the multiplication algorithm, the size and sparsity of the polynomial multiplication make it difficult to deploy a suitable algorithmic procedure and 2) for the hardware architecture design, the selection of a proper processing strategy is tricky, as it will affect the other components (like memories) and the total performance. Finally, we also consider the fact that very few hardware designs are released so far. 

_**Abstract**_ **— The Hamming quasi-cyclic (HQC) code-based encryption scheme is one of the fourth-round algorithms selected by the National Institute of Standards and Technology (NIST) postquantum cryptography (PQC) standardization process. However, very few hardware implementations have been reported for HQC to date. In this brief, we propose a novel Lightweight and Efficient Accelerator for sparse Polynomial multiplication (LEAP) of HQC, compatible with different parameters, on the field-programmable gate array (FPGA) platform. First, we give a mathematical derivation process for the sparse polynomial multiplication deployed in HQC. Then, we explain the proposed hardware structure in detail. Finally, we present the FPGA implementation results to confirm the efficiency of the proposed LEAP, for example, the proposed design for hqc-192 has at least 31.03% less area-delay product (ADP) than the existing design. LEAP can be extended further to construct efficient HQC cryptoprocessors.** 

Thus, in this brief, we propose a **L** ightweight and **E** fficient **A** ccelerator for sparse **P** olynomial multiplication (LEAP) of HQC. In particular, we made three layers of contributions, as follows. 

_**Index Terms**_ **— Hamming quasi-cyclic (HQC), hardware design, lightweight and efficient accelerator, postquantum cryptography (PQC), sparse polynomial multiplication.** 

## I. INTRODUCTION 

- 1) We give a detailed mathematical formulation to derive a new algorithm for the sparse polynomial multiplication in HQC. 

It has been proven that traditional cryptosystems such as RSA and ECC are vulnerable to attacks launched from large-scale quantum computers [1]. Hence, the need for cryptosystems that are safe against quantum attacks, collectively known as postquantum cryptography (PQC), is at an all-time high [1], [2]. The National Institute of Standards and Technology (NIST) has started the PQC standardization process, and the code-based Hamming quasi-cyclic (HQC) is recently selected as one of the fourth-round candidates [3], [4]. 

- 2) We construct the proposed LEAP through efficient algorithmto-architecture mapping techniques and strategies. 

- 3) We provide sufficient implementation and comparison results to showcase the superior performance of the proposed LEAP. 

The rest of this brief is organized as follows. The preliminaries are introduced in Section II. The mathematical derivation is presented in Section III. The proposed LEAP is presented in Section IV. Implementation and comparison are presented in Section V. Conclusions are given in Section VI. 

Code-based cryptography refers to the cryptosystem that is based on error-correcting codes [5]. HQC is a code-based PQC scheme whose security relies on decoding small weight vectors of random quasi-cyclic codes [4], [6]. Following the NIST PQC standardization process, efforts are needed for efficient hardware implementation of HQC, for example, on field-programmable gate array (FPGA) [3], [7], which offers flexibility and fast development cycle to evaluate the PQC scheme’s hardware complexity (a recent trend in the PQC field [2]). 

## II. PRELIMINARIES 

## _A. Notations [4]_ 

We define Z as the ring of integers and F2 as the binary finite field. _V_ is a vector space of dimension _n_ over F2, where _n_ ∈ Z. Elements in _V_ are vectors/polynomials in _R_ = F2[ _X_ ] _/(X[n]_ −1 _)_ (lower-case bold), while matrices are denoted by upper-case bold letters. _ω(_ · _)_ denotes the Hamming weight of a vector (number of its nonzero coordinates). _C_ [ _n, k_ ] denotes a linear code with length _n_ and dimension. Elements of _C_ are referred to as codewords [8]. _δ_ is the minimum number of errors that the decoding algorithm can correct. All computations in HQC are made in the ambient space F _[n]_ 2[.] 

On the other side, however, very few hardware implementation reports have been released for HQC: 1) the authors of HQC have given a high-level synthesis-based hardware result [4] (no subcomponents’ results like polynomial multiplier) and 2) another recent hardware design was reported in [7]. 

## _A. Challenges_ 

We have also used _G_ , _D_ , and _W_ to represent related polynomials for the proposed algorithm ([ _G_ ] denotes the corresponding matrix). _P_ [·] denotes the index of nonzero elements. _N_ mem is the processing bit-length of the memory. 

It is noted that the polynomial multiplier over F2 is a critical component of HQC and its performance largely determines the overall 

Manuscript received 14 October 2022; revised 1 January 2023; accepted 9 February 2023. Date of publication 13 March 2023; date of current version 23 May 2023. The work of Jiafeng Xie was supported in part by NIST60NANB20D20 and in part by NSF under Grant SaTC-2020625. The work of Çetin Kaya Koç was supported by TUBITAK under Grant 1001-121F348. _(Corresponding author: Yazheng Tu.)_ 

## _B. Hamming Quasi-Cyclic_ 

HQC is an Indistinguishability under Chosen Ciphertext Attack (IND-CCA) secure encryption scheme built on the hardness of a decision version of the syndrome decoding on structured codes [4]. HQC uses a decodable code _C_ [ _n, k_ ] and a random double-circulant [2 _n, n_ ] code, which features a precise upper bound for the decryption failure probability analysis [4]. 

Yazheng Tu, Pengzhou He, and Jiafeng Xie are with the Department of Electrical and Computer Engineering, Villanova University, Villanova, PA 19085 USA (e-mail: ytu1@villanova.edu; phe@villanova.edu; jiafeng.xie@villanova.edu). 

Çetin Kaya Koç is with the Department of Computer Science (DEEC), University of California at Santa Barbara, Santa Barbara, CA 93106 USA, and also with I˘gdır University, NUAA, Nanjing 210016, China (e-mail: cetinkoc@ucsb.edu). 

## _C. Algorithms_ 

Let _G(_ · _), H(_ · _), K(_ · _)_ denote SHAKE256-512 (B7||G_FCT_ DOMAIN), SHAKE256-512 (B7||H_FCT_DOMAIN), and SHAKE256-512 (B7||K_FCT_DOMAIN), respectively. Algorithms 1 

Color versions of one or more figures in this article are available at https://doi.org/10.1109/TVLSI.2023.3246923. Digital Object Identifier 10.1109/TVLSI.2023.3246923 

1063-8210 © 2023 IEEE. Personal use is permitted, but republication/redistribution requires IEEE permission. See https://www.ieee.org/publications/rights/index.html for more information. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 15,2026 at 11:36:04 UTC from IEEE Xplore.  Restrictions apply. 

IEEE TRANSACTIONS ON VERY LARGE SCALE INTEGRATION (VLSI) SYSTEMS, VOL. 31, NO. 6, JUNE 2023 

893 

**Algorithm 1** HQC.PKE [4] 

**==> picture [223 x 189] intentionally omitted <==**

## **Algorithm 2** HQC.KEM [4] 

**==> picture [227 x 308] intentionally omitted <==**

**==> picture [209 x 118] intentionally omitted <==**

Fig. 1. Indices and related columns within [ _G_ ] and [ _D_ ]. 

defined as a “sparse polynomial multiplier.” For instance, in hqc128, the Hamming weight of the vector is only _ω_ = 66 or _ω_ **e** = 75 when _n_ = 17 669 [4]. Thus, traditional strategies like the schoolbook method would be inappropriate as its complexity is _O(n_[2] _)_ . Based on this consideration, we decided to propose a new polynomial multiplication algorithm. 

_Definition 1:_ We define the sparse polynomial multiplication for HQC as _W_ = _GD_ mod _f (x)_ , where _f (x)_ = _x[n]_ − 1, _W_ = � _in_ =−01 _[w][i][ x][i]_[,] _[G]_[=][ �] _i[n]_ =[−] 0[1] _[g][i][ x][i]_[,][and] _[D]_[=][ �] _i[n]_ =[−] 0[1] _[d][i][ x][i]_[(] _[g][i]_[,] _[d][i]_[,][and] _[w][i]_ are all binary values in F2 _/(x[n]_ − 1 _)_ ). Note that _G_ is a polynomial with only _ω_ nonzero coefficients. Then, we have 

**==> picture [250 x 47] intentionally omitted <==**

**==> picture [253 x 129] intentionally omitted <==**

## _A. Proposed Computation Strategy_ 

The direct computation of (3) will incur huge resource usage and long delay time. Even with the deploying of subquadratic complexity fast algorithms such as the Karatsuba algorithm [6], the computation complexity could still be large. Considering that _G_ is a polynomial with only _ω_ nonzero coefficients and [ _G_ ] _[n]_[×] _[n]_ is a circulant matrix, we thus have the following definition. 

_Definition 2:_ For a polynomial _G_ = _(g_ 1 _, g_ 2 _, . . . , gn_ −1 _)_ ∈ F _[n]_ 2[,] we define its circulant matrix **rot** ( _G_ ) as 

and 2 are the public-key encryption (PKE) and key encapsulation mechanism (KEM) versions of HQC, respectively. 

## _D. Security_ 

There exist three security levels of HQC: hqc-128, hqc-192, and hqc-256 [4] (LEAP is applicable to all three levels). 

## III. LEAP (MATHEMATICAL DERIVATION) 

Polynomial multiplication over ring _R_ = F2[ _X_ ] _/(X[n]_ − 1 _)_ exists in most steps of HQC and thus has a huge impact on the overall performance. Due to the large size of operand vectors but with only very few nonzero elements, this polynomial multiplication is 

**==> picture [219 x 49] intentionally omitted <==**

We can then have 

[ _W_ ] _[n]_[×][1] = **rot** _(G)_ × [ _D_ ] _[n]_[×][1] = **rot** _(D)_ × [ _G_ ] _[n]_[×][1] _._ (5) 

From (4) and (5), one can see that after we switched the circulant matrix from **rot** _(G)_ to **rot** _(D)_ , we can compute (3) as follows: 1) mark the nonzero indices of those coefficients within vector [ _G_ ] _[n]_[×][1] and 2) sum the corresponding columns in the circulant matrix of **rot** _(D)_ to obtain the final results, as shown in Fig. 1. Following 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 15,2026 at 11:36:04 UTC from IEEE Xplore.  Restrictions apply. 

IEEE TRANSACTIONS ON VERY LARGE SCALE INTEGRATION (VLSI) SYSTEMS, VOL. 31, NO. 6, JUNE 2023 

894 

**==> picture [101 x 156] intentionally omitted <==**

Fig. 2. Sum of column vectors. 

**Algorithm 3** Proposed Algorithm for Sparse Polynomial Multiplication of HQC 

**==> picture [221 x 154] intentionally omitted <==**

this strategy, the computation complexity of (3) is now reduced to only _O(nω)_ . 

As shown in Fig. 1, the indices of nonzero elements _G_ are denoted as _P_ [·] and we can see that the polynomial multiplication is equivalent to the sum of column vectors in **rot** _(D)_ corresponding to the nonzero elements in [ _G_ ] _[n]_[×][1] (Fig. 2). We finally summarize this process in Algorithm 3. 

IV. LEAP (PROPOSED HARDWARE STRUCTURE DESIGN) 

The overall structure of the proposed accelerator is shown in Fig. 3, where it consists of two major components—the Preparatory Component and the Multiplier—as described below. 

## _A. Preparatory Component_ 

The Preparatory Component contains one memory and one Index Marker. As the proposed Algorithm 3 executes the multiplication process assuming that the indices of nonzero elements in polynomial _G_ are provided as the input, an Index Marker for nonzero elements is needed to deliver the correct indices to the following Multiplier. 

## _B. Index Marker_ 

As is shown in Fig. 4, the Index Marker consists of a circular-shift register ( _ω_ blocks, each with ⌈log2 _n_ ⌉ bits) and a counter. The Index Marker takes one coefficient of the polynomial as its only input each cycle and outputs the indices of the nonzero coefficients/elements in serial. The counter counts one up each cycle and delivers the count to the shift register; while the register, taking the count as an input and the incoming coefficient/element of the polynomial as its _enable_ signal, records the count, that is, the index, when the element is “1.” After recording the index, the shift register will shift 1 block (⌈log2 _n_ ⌉ bits) until all elements are examined. 

**==> picture [180 x 8] intentionally omitted <==**

**----- Start of picture text -----**<br>
Fig. 3. Overview of the proposed accelerator: LEAP.<br>**----- End of picture text -----**<br>


Fig. 4. Structural details of the Index Marker. 

**==> picture [220 x 105] intentionally omitted <==**

Fig. 5. Structural details of the Multiplier Component. Control signals: “addr_rd” denotes the address read; “rd_data” is the data read; “wen” denotes the write enable; “addr_wr” represents the address write; and “wr_data” is the data write. 

**==> picture [183 x 104] intentionally omitted <==**

Fig. 6. Internal structure of the Execution Unit. Signal “rd_data_Daddr” denotes the data read of _D_ -related address and “rd_data_acc” represents the data read of accumulation. 

## _C. Multiplier Component_ 

LEAP deals with the data reading from a whole memory block at a time based on Algorithm 3 (see Fig. 5). According to Fig. 2, the summation of the columns in **rot** _(D)_ is bit-wise XOR operations, where one operand can be obtained by circularly shifting from another. The Component executes the multiplication by taking a whole block of memory and adding it to the sum of the previous column(s) read from the other memory (new input) and then writing the data back. Note _N_ mem is the processing bit-length of the memory. 

The Control Unit of the Multiplier Component takes the indices from the Index Marker as its input and then calculates the corresponding reading addresses. Apart from that, the Control Unit also determines the position of the first bit in the column vector, that is, the index of _p_ [ _i_ ][0] in the memory block of Fig. 1. Then starting from the calculated bit, the Control Unit determines if the next memory block will be used to form a _N_ mem-bit calculation segment, which is XORed with the data read from the other memory. A counter counting from 0 to ⌈ _n/N_ mem⌉−1 is also involved when calculating the reading addresses for coefficients of _G_ . Also, a ⌈log2 _n_ ⌉-bit counter is used for calculating the writing addresses. 

The Execution Unit (see Fig. 6) contains two _N_ mem-bit registers, which are used to store the calculation segment and coefficients formed/read in the previous cycle. The Calculation Segment 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 15,2026 at 11:36:04 UTC from IEEE Xplore.  Restrictions apply. 

895 

IEEE TRANSACTIONS ON VERY LARGE SCALE INTEGRATION (VLSI) SYSTEMS, VOL. 31, NO. 6, JUNE 2023 

TABLE I 

IMPLEMENTATION RESULTS FOR THE PROPOSED LEAP 

**==> picture [225 x 226] intentionally omitted <==**

Generator generates an _N_ mem-bit calculation segment based on the count from the Control Unit, the remainder of _index/N_ mem, and the data segments from two registers. The generated calculation segment and the data read from memory are written to the two _N_ mem-bit registers, which can be used in the next cycle when a new calculation segment is generated. 

The XOR gates perform the XOR operation of the calculation segment and the data read from the other memory, that is, _N_ mem XOR gates in parallel to perform _N_ mem bit-wise additions that _N_ mem results of sum-of-product can be calculated and updated to the memory at one cycle. 

LEAP is compatible with all commonly used memories by simply adjusting the number of XORs and the register length (and Control Unit). The RAMs used for _G_ and _D_ are single-port, while the one storing the accumulated values is dual-port. 

## V. LEAP (COMPLEXITY AND COMPARISON) 

## _A. Complexity Analysis_ 

The complexities of the Index Marker are: one ⌈log2 _n_ ⌉× _n_ bit circular shift register and one ⌈log2 _n_ ⌉ counter. The Index Marker needs _n_ cycles to examine _G_ and records the indices of the nonzero coefficients. 

The complexities of the proposed LEAP are listed below: the Control Unit requires a ⌈log2 _n_ ⌉-bit counter and a ⌈log2 _n/N_ mem⌉-bit counter; the Execution Unit requires two _N_ mem-bit registers and _N_ mem XOR gates. The latency is ⌈ _(n/N_ mem + 1 _)_ ⌉× _ω (_ or _ωr )_ cycles. 

## _B. Implementation_ 

The experimental setup is as follows: 1) the proposed LEAP was coded in VHDL and tested using Modelsim, then implemented using Xilinx Vivado 2020.2; 2) the accelerator was coded in a generic format that different parameter sets of HQC ( _n, ω_ , and _ωr_ ) can be set during the implementation process; 3) different memory block lengths were also chosen, that is, _N_ mem = 32, 64, and 128, respectively (these are the regular memory processing bits, the implemented results help us to have a comprehensive understanding of the complexity of the proposed design); and 4) the accelerator was implemented on the Artix-7 xc7a200t-3 FPGA. The obtained results are listed in Table I, including the number of LUTs, FFs, CLBs, and required BRAM tiles. 

## _C. Performance Discussion_ 

The area usage of LEAP grows with the length of the memory block (see Table I). This is because the registers storing the unemployed coefficients (during the formation of the calculation segment) possess the same length as the memory blocks and become larger as the length of memory blocks increases. Also, the involved XORs increase linearly with the length of the memory blocks. Besides, the number of memory blocks involved decreases as _N_ mem becomes larger. Finally, it is worth mentioning that the slight differences in CLB usage between two cases (same _n_ and _N_ mem, but different _ω_ ) are due to the parameter changes in the Control Unit and related place and route efficiency on the FPGA. 

The latency is inversely proportional to the length of memory blocks, while the maximum frequency for the proposed accelerator overall remains high (delay time decreases as the _N_ mem increases while proportionally changes to _ω_ and _n_ ). Following Table I, one can choose the desired LEAP with a proper _N_ mem based on the potential application requirements. 

## _D. Comparison_ 

We have also listed the results of the state-of-the-art work in Table II for comparison, based on the same memory block size, the same _ω_ , and the same FPGA device. Note that the existing report of [7] does not give the CLB usage and hence we just use the LUT to obtain the equivalent LUT (ELUT) to calculate area-delay product (ADP) (following the strategy in [9] that one BRAM (8 k) is equal to 70 CLBs and one CLB contains four LUTs). It is shown that the proposed design has better overall area-time complexities than the existing one. For the security levels of hqc-128, hqc-192, and hqc256, the proposed LEAP has 23.46%, 31.03%, and 24.72% less ADP than the one of [7], respectively. 

## _E. Extension to the Sparse Polynomial Multiplier in BIKE and Comparison_ 

BIKE is another NIST fourth-round PQC standardization candidate [3], [12], which also involves a sparse polynomial multiplier with different parameter settings. We have extended the proposed design to the sparse polynomial multiplier in BIKE [12] and implemented it on the Artix-7 xc7a200t-3 FPGA and compared the performance with [10], [11] (on the same FPGA). We have followed the comparison strategy of Table III; both area reduction and time reduction are considered comprehensively to reach the final conclusion: the proposed one has better area–time complexities than the existing ones given in [10] and [11] (note that as both the proposed and the existing designs have reported the CLB usage, we just follow the strategy of [9] to convert the overall resource usage into equivalent CLB (ECLB) usage). For instance, for _n_ = 12 _,_ 323 and _ω_ = 134, the proposed design has 35.92% more CLBs than [10] but with 50% reduction in BRAM usage (the ECLB of the proposed design is smaller than [10]). Meanwhile, as LEAP has 14.03% less latency time than [10], the ADP of LEAP is 16.44% less than [10]. A similar situation applies to the comparison with [11]: 84.18% less ADP than [11]. 

## _F. Discussion and Future Works_ 

The proposed accelerator is lightweight overall as it contains relatively small resource usage. Meanwhile, the proposed LEAP has a low latency time and hence is also feasible for high-performance applications. 

While the major focus of this work is to develop an efficient polynomial multiplier accelerator for HQC, future works may focus on the construction of an HQC accelerator, further complexity reduction, and side-channel attacks. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 15,2026 at 11:36:04 UTC from IEEE Xplore.  Restrictions apply. 

896 

IEEE TRANSACTIONS ON VERY LARGE SCALE INTEGRATION (VLSI) SYSTEMS, VOL. 31, NO. 6, JUNE 2023 

TABLE II 

IMPLEMENTATION RESULTS AND COMPARISON (SPARSE POLYNOMIAL MULTIPLIER FOR HQC) 

**==> picture [493 x 153] intentionally omitted <==**

TABLE III 

IMPLEMENTATION RESULTS AND COMPARISON (EXTENSION TO BIKE, WHERE _N_ mem = 128) 

**==> picture [494 x 109] intentionally omitted <==**

## _G. Other Works_ 

Other hardware implementations in the PQC field also include lattice-based PQC designs of [13], [14], [15], [16], [17], [18], and [19]. 

## VI. CONCLUSION 

This brief proposes a novel hardware accelerator for a sparse polynomial multiplier of HQC: LEAP. We derived a new algorithm for the targeted sparse polynomial multiplication. Then, we provided the architectural details of the proposed accelerator. Finally, we presented the complexity analysis and implementation, and a related comparison confirms the superior performance of the proposed LEAP. This work is expected to be useful for the ongoing NIST PQC standardization process. 

## REFERENCES 

- [1] P. W. Shor, “Algorithms for quantum computation: Discrete logarithms and factoring,” in _Proc. 35th Annu. Symp. Found. Comput. Sci._ , 1994, pp. 124–134. 

- [2] J. Xie, K. Basu, K. Gaj, and U. Guin, “Special session: The recent advance in hardware implementation of post-quantum cryptography,” in _Proc. IEEE 38th VLSI Test Symp. (VTS)_ , Apr. 2020, pp. 1–10. 

- [3] _PQC Standardization Process: Announcing Four Candidates to be Standardized, Plus Fourth Round Candidates_ . [Online]. Available: https://csrc.nist.gov/News/2022/pqc-candidates-to-be-standardizedand-round-4 

- [4] C. A. Melchor et al. _Hamming Quasi-Cyclic (HQC) (NIST Round 4 Submission)_ . [Online]. Available: https://pqc-hqc.org/index.html 

- [5] R. Overbeck and N. Sendrier, “Code-based cryptography,” in _Post-Quantum Cryptography_ . Cham, Switzerland: Springer, 2009, pp. 95–145. 

- [6] C.-Y. Lee and J. Xie, “Digit-serial versatile multiplier based on a novel block recombination of the modified overlap-free Karatsuba algorithm,” _IEEE Trans. Circuits Syst. I, Reg. Papers_ , vol. 66, no. 1, pp. 203–214, Jan. 2019. 

- [7] S. Deshpande, M. Nawan, K. Nawaz, J. Szefer, and C. Xu, “Towards a fast and efficient hardware implementation of HQC,” _Cryptol. ePrint Arch._ , pp. 1–24, 2022. 

- [8] S. Lin and D. J. Costello, _Error Control Coding_ , vol. 2. New York, NJ, USA: Prentice-Hall, 2001. 

- [9] W. Liu, S. Fan, A. Khalid, C. Rafferty, and M. O’Neill, “Optimized schoolbook polynomial multiplication for compact lattice-based cryptography on FPGA,” _IEEE Trans. Very Large Scale Integr. (VLSI) Syst._ , vol. 27, no. 10, pp. 2459–2463, Oct. 2019. 

- [10] R.-Brockmann et al., “Racing BIKE: Improved polynomial multiplication and inversion in hardware,” in _Proc. IACR TCHES_ , 2022, pp. 557–588. 

- [11] J. Hu, W. Wang, R. C. C. Cheung, and H. Wang, “Optimized polynomial multiplier over commutative rings on FPGAs: A case study on BIKE,” in _Proc. Int. Conf. Field-Program. Technol. (ICFPT)_ , Dec. 2019, pp. 231–234. 

- [12] N. Aragon et al. _Bit Flipping Key Encapsulation (BIKE)) (NIST Round 4 Submission)_ . [Online]. Available: https://bikesuite.org/ 

- [13] A. Basso and S. S. Roy, “Optimized polynomial multiplier architectures for post-quantum KEM saber,” in _Proc. 58th ACM/IEEE Design Autom. Conf. (DAC)_ , Dec. 2021, pp. 1285–1290. 

- [14] T. Bao, P. He, and J. Xie, “Systolic acceleration of polynomial multiplication for KEM saber and binary ring-LWE post-quantum cryptography,” in _Proc. IEEE Int. Symp. Hardw. Oriented Secur. Trust (HOST)_ , Jun. 2022, pp. 157–160. 

- [15] K. Basu et al., “NIST post-quantum cryptography—A hardware evaluation study,” _Cryptol. ePrint Arch._ , pp. 1–16, 2019. 

- [16] D.-E.-S. Kundi, A. Khalid, S. Bian, C. Wang, M. O’Neill, and W. Liu, “AxRLWE: A multilevel approximate ring-LWE co-processor for lightweight IoT applications,” _IEEE Internet Things J._ , vol. 9, no. 13, pp. 10492–10501, Jul. 2022. 

- [17] C. P. Rentería-Mejía and J. Velasco-Medina, “High-throughput ringLWE cryptoprocessors,” _IEEE Trans. Very Large Scale Integr. (VLSI) Syst._ , vol. 25, no. 8, pp. 2332–2345, Aug. 2017. 

- [18] S. Bian, M. Hiromoto, and T. Sato, “Filianore: Better multiplier architectures for LWE-based post-quantum key exchange,” in _Proc. 56th Annu. Design Autom. Conf._ , Jun. 2019, pp. 1–6. 

- [19] B. J. Lucas et al., “Lightweight hardware implementation of binary ring-LWE PQC accelerator,” _IEEE Comput. Archit. Lett._ , vol. 21, no. 1, pp. 17–20, Jan. 2022. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 15,2026 at 11:36:04 UTC from IEEE Xplore.  Restrictions apply. 

