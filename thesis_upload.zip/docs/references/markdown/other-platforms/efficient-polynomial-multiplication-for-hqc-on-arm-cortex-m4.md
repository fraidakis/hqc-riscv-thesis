---
source_pdf: docs/references/pdf/other-platforms/!Efficient Polynomial Multiplication for HQC on ARM Cortex-M4.pdf
converted_at: 2026-05-29 22:39
conversion_time: 7.4s
tool: pymupdf4llm
---

Published: 17/01/26 

## **Efficient Polynomial Multiplication for HQC on ARM Cortex-M4** 

Jihoon Jang[1] , Myeonghoon Lee[1] , Donggeun Kwon[2] , Seokhie Hong[3] , Suhri Kim[4] and Sangjin Lee[1] 

- 1 Korea University, Seoul, South Korea, `{jhw1031506` _,_ `ope2527` _,_ `sangjin}@korea` _._ `ac` _._ `kr` 

2 Korea Testing & Research Institute, Pangyo, South Korea, `donggeun` _._ `kwon@gmail` _._ `com` 3 Contec, Daejeon, South Korea, `shhong@contec` _._ `kr` 

- 4 Sungshin Women’s University, Seoul, South Korea, `suhrikim@sungshin` _._ `ac` _._ `kr` 

## **Abstract.** 

HQC, a code-based Key Encapsulation Mechanism (KEM) recently selected for NIST post-quantum cryptography standardization, utilizes polynomial multiplication over F2[ _x_ ], the efficiency of which determines the overall performance of the scheme on embedded targets. On the ARM Cortex-M4, where carry-less multiplication instructions are unavailable, prior works have focused on the Frobenius Additive FFT (FAFFT) and radix-16 methods. However, for polynomial lengths _n_ = 2 _[k]_ + _r_ with small _r_ , such as those in HQC-1 and -3, applying FAFFT requires a transform length of 2 _[k]_[+2] _≈_ 4 _n_ , introducing substantial padding overhead. 

In this paper, we propose three optimized approaches to enhance HQC performance on the Cortex-M4: (i) Hybrid FAFFT-CRT, (ii) Hybrid FAFFT-Karatsuba, and (iii) a radix-16 method. To reduce the padding overhead of FAFFT, we use the Hybrid FAFFT-CRT and FAFFT-Karatsuba methods. The Hybrid FAFFT-CRT method maps the polynomial ring to a product of a FAFFT-friendly ring and a small-degree polynomial ring, and the Hybrid FAFFT-Karatsuba method utilizes a 2-way split to align subproducts with smaller power-of-two FAFFT lengths. We further optimize the core FAFFT butterfly operation by shortening XOR sequences and improving register scheduling. For the radix-16 approach, we apply it to HQC for the first time and develop an operation-count cost model to identify optimal Karatsuba and Toom-Cook combinations. 

On a NUCLEO-L4R5ZI board with a Cortex-M4 microcontroller, all of these methods are more efficient than the state-of-the-art for HQC-1 and -3. The Hybrid FAFFT-CRT method reduces polynomial multiplication cycles by 33.4% and 27.2% for HQC-1 and -3, respectively. This leads to cycle reductions for key generation, encapsulation, and decapsulation by 23.7%, 24.2%, and 21.9% for HQC-1, and 18.0%, 18.6%, and 17.7% for HQC-3. For HQC-5, our optimized butterfly FAFFT provides a consistent speedup of 1.4 - 1.6% across all KEM operations. 

**Keywords:** Additive FFT, Radix-16 representation, Finite field multiplication, CortexM4, HQC 

## **1 Introduction** 

HQC [AAB[+] 22] is a key encapsulation mechanism (KEM) that was officially selected as a NIST standard for post-quantum cryptography in March 2025. Since polynomial multiplication over F2[ _x_ ] is the core operation on HQC, the efficiency of HQC depends on how fast polynomial multiplication over F2[ _x_ ] can be performed. In particular, on embedded targets such as ARM Cortex-M4, which lack carry-less multiplication instructions, polynomial multiplication dominates the overall execution time. To address this issue, 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

2 

two implementation approaches are especially relevant on such platforms. The first is the Frobenius Additive FFT (FAFFT), which reduces evaluation points by exploiting the Frobenius map. The second is a radix-16 method, which turns F2[ _x_ ] polynomial multiplications into ordinary 32-bit integer multiplications that the Cortex-M4 can execute efficiently. 

## **1.1 Contributions** 

This work considers both approaches and optimizes them for the polynomial degrees used in HQC. In particular, for FAFFT, our focus is on reducing the overhead that arises from applying the method to polynomial degrees of the form _n_ = 2 _[d]_ + _r_ with small _r_ , such as in HQC-1 and -3. Since FAFFT operates on lengths of a power of 2, the previous approach requires a transform length of 2 _[d]_[+2] , which is nearly 4 _n_ , leading to significant overhead. To address this, we propose two hybrid methods. First, we apply the Hybrid FAFFT-CRT method, which maps the polynomial ring to a product of a FAFFT-friendly ring of size 2 _[d]_[+1] and a small-degree polynomial ring, recombining them via the Chinese Remainder Theorem. Second, we apply a Hybrid FAFFT-Karatsuba method using a 2-way split at 2 _[d]_ . The subproducts of size 2 _[d]_ are evaluated using a FAFFT of size 2 _[d]_[+1] , while the residual of size _r_ is handled via radix-16 multiplication. Additionally, in the FAFFT butterfly stage, we shorten the XOR sequences resulting from fixed-coefficient multiplications and reduce clock cycles by scheduling operations to utilize all 14 general-purpose registers. We also optimize bit permutations between registers using `SWAPMOVE` . For radix-16 multiplication, we use a cost model based on operation counts to explore Karatsuba and Toom-Cook combinations, producing optimal candidates that are validated on the target device. The main contributions of this paper are summarized as follows: 

- We apply the Hybrid FAFFT-CRT method to efficiently handle polynomial degrees that do not align well with FAFFT. By mapping the polynomial ring F2[ _x_ ] _/_ ( _x[n] −_ 1) to a ring F2[ _x_ ] _/_ ( _Pd_ +1( _x_ ) _· x[r][c]_ ), where F2[ _x_ ] _/Pd_ +1( _x_ ) corresponds to the FAFFT of size 2 _[d]_[+1] and F2[ _x_ ] _/x[r][c]_ covers the residual, this method avoids the large padding overhead of the previous method of FAFFT. During the reconstruction process via the Chinese Remainder Theorem (CRT), we optimized the multiplication between _Pd_ +1( _x_ ) and intermediate polynomials as a sparse-dense product tailored for the ARM Cortex-M4 architecture. 

- We propose the Hybrid FAFFT-Karatsuba method to handle small residual part during polynomial multiplication. To the best of our knowledge, this is the first work to optimize FAFFT using a 2-way Karatsuba split for polynomial degrees of the form _n_ = 2 _[d]_ + _r_ with small _r_ . Since FAFFT has a complexity of _O_ ( _n_ log _n_ ), performing two FAFFT evaluations of size 2 _[d]_[+1] plus one small-degree multiplication for _r_ is cheaper than a single FAFFT of size 2 _[d]_[+2] when _r_ is sufficiently small. 

- We optimize the FAFFT butterfly algorithm for the ARM Cortex-M4. For the multiplications by constant coefficients _v_ 17 _, . . . , v_ 27 within the butterfly stages, we shorten the XOR sequences and reduce the cycle count by scheduling operations to fully saturate all 14 available general-purpose registers. Furthermore, in the final five layers, we utilize the `SWAPMOVE` operation to minimize the overhead of required bit swaps between registers. 

- We apply radix-16 multiplication to HQC for the first time, to the best of our knowledge, and utilize a cost model based on operation counts to identify optimal Karatsuba and Toom-Cook combinations without relying on a measurement-based method. This avoids inaccuracies from conditional branches and table lookups during the search. Under the same algorithm sets, we compare against the `gf2x` library for 

J. Jang et al. 

3 

the three HQC degrees. The resulting combination is identical for HQC-1 and HQC-3, while for HQC-5 our method produces a more efficient combination. 

- We compare our implementations with the state-of-the-art Cortex-M4 implementation [LJKH25]. For HQC-1 and HQC-3, our Hybrid FAFFT-CRT method achieves the best performance. Specifically, for HQC-1, it reduces clock cycles by 23.7%, 24.2%, and 21.9% for key generation, encapsulation, and decapsulation, respectively. For HQC-3, it reduces them by 18.0%, 18.6%, and 17.7%. For HQC-5, although both hybrid FAFFT is less effective due to the large residual and the polynomial degree is too high for radix-16 method, our butterfly-optimized FAFFT achieves a performance gain of 1.4 - 1.6% over the previous state-of-the-art across all KEM operations. 

The source code and implementation details of the proposed method are available at: `https://github` _._ `com/jhw1031506/Efficient-Polynomial-Multiplication-for-HQCon-ARM-Cortex-M4` . 

## **1.2 Related Work** 

The ARM Cortex-M4 serves as the baseline embedded evaluation platform in the NIST PQC standardization project. As noted in NIST IR 8413, performance of PQC algorithms on embedded devices is one of the evaluation criteria. Specifically, the Cortex-M4 has been widely adopted in academic literature as a representative embedded platform because of its balance between resource constraints and computational capabilities. NIST has also formally acknowledged its prevalence and recommended it as an optimization target for the second round of the PQC project. As a result, many PQC schemes have been optimized for Cortex-M4 [BKS19, ABCG20, CHK[+] 21, CC21, CCK21, GKS21, ACC[+] 22, AHKS22, HZZ[+] 22, HAZ[+] 24, LJKH25]. In particular, pqm4 serves as the standard testing and benchmarking infrastructure for Cortex-M4 implementations [KPR[+] ]. Code-based schemes are no exception. Because the performance of code-based schemes such as HQC, BIKE, and Classic McEliece is largely determined by the efficiency of polynomial multiplication, prior research has focused on two main optimization approaches. 

The first approach is to use an additive FFT. Cantor [Can89] described how to compute length _n_ = 2 _[m]_ FFTs over F2 _m_ efficiently when _m_ is a power of two, with further improvements in [VzGG96, GM10]. Especially, in [GM10], additive FFT is optimized by introducing new algorithms based on Taylor expansion over finite fields of characteristic two, which significantly reduce the number of multiplications compared to previous approaches in [VzGG96]. Based on this, Li et al. [LCK[+] 18] introduced the Frobenius Additive FFT (FAFFT). By using the Frobenius map, FAFFT reduces the number of evaluation points required for FFTs of length 2 _[m]_ , leading to significantly faster binary polynomial multiplication compared to previous additive FFT techniques. Using FAFFT, Chen et al. [CCK21] and Lee et al. [LJKH25] optimized BIKE and HQC on Cortex-M4, respectively. Furthermore, to address the inefficiency of additive FFT when polynomial degrees are slightly larger than a power of two, Chen et al. [CCPY26] proposed a novel combination of additive FFT with the CRT. While their implementation targeted high-performance platforms such as x86-64 and ARM NEON, they demonstrated that the CRT-based approach allows FFT-based implementations to outperform traditional Toom-Cook and Karatsuba methods for HQC parameters. 

The second approach is to use a radix-16 representation. This approach was proposed in [CC21], and the paper demonstrates an optimized implementation of Classic McEliece on Cortex-M4. In particular, the paper introduces a radix-16 representation to efficiently perform field multiplications required in the Berlekamp–Massey algorithm. By exploiting the structure of radix-16 polynomials and using the `umlal` instruction to emulate carryless multiplications, the implementation achieves low-latency multiplication and inversion 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

4 

operations in F212 and F213, resulting in significant speedups on 32-bit microcontrollers. Chen et al. [CGKT22] apply the approach to BIKE, using Karatsuba and Toom-Cook for large-degree polynomial multiplication and selecting the optimal combination with the `gf2x` library. 

## **1.3 Organization** 

## **2 Frobenius Additive FFT** 

## **2.1 Additive FFT using novel polynomial basis** 

In 2014, Lin et al. proposed a method for performing the Additive FFT (AFFT) using a novel polynomial basis [LCH14]. This basis is constructed as a product of vanishing polynomials defined over the Cantor basis. 

## **2.1.1 Cantor basis and vanishing polynomial** 

The Cantor basis, introduced by Cantor in 1989 [Can89], is a specially constructed basis used for efficient computation of the Fast Fourier Transform (FFT) over binary extension fields F2 _[m]_ , where _m_ is a power of two. Cantor basis enables AFFT algorithms by leveraging the structure of F2 _m_ as a vector space over F2. 

Let the Cantor basis be defined as the ordered set _{v_ 0 _, v_ 1 _, . . . , vm−_ 1 _} ⊂_ F2 _m_ , where the elements satisfy the following recurrence relation: 

_v_ 0 = 1 _, vi_[2] +1[+] _[ v][i]_[+1][=] _[ v][i][,]_ for 0 _≤ i < m −_ 1 _._ 

Using this basis, we define a sequence of subspaces _Wk ⊆_ F2 _[m]_ as the linear span over F2 of the first _k_ basis elements: 

**==> picture [214 x 12] intentionally omitted <==**

To represent the elements of _Wk_ , we adopt a binary expansion encoding. For each _k ≥_ 1, the ( _i_ + 1)-th element _ωi ∈ Wk_ is expressed as a linear combination: 

**==> picture [147 x 10] intentionally omitted <==**

where the coefficients _ij ∈{_ 0 _,_ 1 _}_ are obtained from the binary expansion 

**==> picture [157 x 12] intentionally omitted <==**

We further define a family of polynomials _{si_ ( _x_ ) _}_ recursively as follows: 

**==> picture [233 x 13] intentionally omitted <==**

The basis elements _vi_ , the subspaces _Wi_ , and the polynomials _si_ ( _x_ ), for 0 _≤ i < m_ , satisfy the following properties: 

- deg( _si_ ( _x_ )) = _|Wi|_ = 2 _[i]_ . 

- The polynomials satisfy the identity _si_ ( _x_ + _y_ ) = _si_ ( _x_ ) + _si_ ( _y_ ), and _sk_ ( _x_ ) = _x_[2] _[k]_ + _x_ if and only if _k_ is a power of two. 

- _si_ ( _x_ + _y_ ) = _si_ ( _x_ ) + _si_ ( _y_ ), _si_ + _j_ ( _x_ ) = _si_ ( _sj_ ( _x_ )). 

- The polynomial _sk_ ( _x_ ) can be represented as a product over the subspace _Wk_ : 

**==> picture [92 x 23] intentionally omitted <==**

and is referred to as a _vanishing polynomial_ over _Wk_ . 

J. Jang et al. 

5 

- The evaluation of _sk_ ( _x_ ) at basis elements _vi_ satisfies: 

**==> picture [115 x 43] intentionally omitted <==**

## **2.1.2 Novel polynomial basis and Additive FFT** 

In 2014, Lin et al. introduced a novel polynomial basis _{Xk_ ( _x_ ) _}_ for efficient AFFT computations. Each basis polynomial _Xk_ ( _x_ ) is defined as a product of vanishing polynomials: 

**==> picture [93 x 23] intentionally omitted <==**

where the index _k_ is represented in binary as _k_ =[�] _bi_ 2 _[i]_ , with _bi ∈{_ 0 _,_ 1 _}_ . Since _bi_ = 1 if and only if the _i_ -th bit of _k_ is 1, the degree of _Xk_ ( _x_ ) is computed as 

**==> picture [125 x 15] intentionally omitted <==**

Thus, the basis polynomial _Xk_ ( _x_ ) has degree exactly _k_ , matching the binary expansion of its index. Based on this property, any polynomial _f_ ( _x_ ) over F2 _m_ of degree less than _n_ can be uniquely represented in the form: 

**==> picture [187 x 11] intentionally omitted <==**

where each _gi ∈_ F2 _m_ . 

Novel polynomial basis _{Xk_ ( _x_ ) _}_ satisfies the following properties: 

- _Xa·_ 2 _i_ ( _x_ ) _· Xb_ ( _x_ ) = _Xa·_ 2 _i_ + _b_ ( _x_ ) if _b <_ 2 _[i]_ . 

- _Xi_ ( _sj_ ( _x_ )) = _Xi·_ 2 _j_ ( _x_ ) 

In a subsequent work [LANH16], the authors proposed an efficient basis conversion algorithm that transforms a polynomial expressed in the monomial basis into its representation in the novel polynomial basis. The algorithm exploits the recursive structure of the vanishing polynomials _si_ ( _x_ ), particularly when _i_ = 2 _[k]_ , where _si_ ( _x_ ) = _x_[2] _[i]_ + _x_ . The conversion process follows these steps: 

1. Identify the largest _i_ = 2 _[k]_ such that deg( _si_ ( _x_ )) _< n_ . 

2. Express _f_ ( _x_ ) as a polynomial in _si_ ( _x_ ) = _x_[2] _[i]_ + _x_ : 

**==> picture [318 x 13] intentionally omitted <==**

where _hj_ ( _x_ ) =[�][2] _r_ =0 _[i][−]_[1] _[h][j,r][x][r]_[are][polynomials][with][deg][(] _[h][j]_[(] _[x]_[))] _[ <]_[ deg][(] _[s][i]_[(] _[x]_[)) = 2] _[i]_[.][Let] _y_ = _si_ ( _x_ ), then _f_ ( _x_ ) can be represented as follows: 

**==> picture [196 x 31] intentionally omitted <==**

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

6 

3. Recursively apply the conversion to _h_ 0 _,r_ + _h_ 1 _,r y_ + _· · ·_ + _ht,r y[t]_ . Since _Xt′_ ( _y_ ) = _Xt′_ ( _si_ ( _x_ )) = _X_ 2 _i·t′_ ( _x_ ), _f_ ( _x_ ) can be represented as follows: 

**==> picture [240 x 137] intentionally omitted <==**

4. Recursively apply the conversion to _qt[′]_ ( _x_ ). Since _X_ 2 _i·t′_ ( _x_ ) _· Xj_ ( _x_ ) = _X_ 2 _i·t′_ + _j_ ( _x_ ), we can write _f_ ( _x_ ) in the novel polynomial basis as follows: 

**==> picture [350 x 45] intentionally omitted <==**

The full procedure is summarized in Algorithm 1, denoted as BasisCvt. Since all operations are performed over F2, the algorithm consists entirely of bitwise XORs. 

**Algorithm 1** BasisCvt: Monomial to Novel Polynomial Basis Conversion 

**Require:** Monomial basis polynomial _f_ ( _x_ ) = _f_ 0 + _f_ 1 _x_ + _· · ·_ + _fn−_ 1 _x[n][−]_[1] **Ensure:** _g_ ( _X_ ) = _g_ 0 + _g_ 1 _X_ 1( _x_ ) + _· · ·_ + _gn−_ 1 _Xn−_ 1( _x_ ) in novel polynomial basis 1: **if** deg( _f_ ( _x_ )) _≤_ 1 **then** 2: **return** _f_ 0 + _f_ 1 _X_ 1 3: **end if** 4: Find the largest _i_ = 2 _[k]_ such that deg( _si_ ( _x_ )) _≤_ deg( _f_ ( _x_ )) 5: Compute _h_ ( _x, y_ ) = _h_[ˆ] ( _y_ ) = _h_ 0( _x_ ) + _h_ 1( _x_ ) _y_ + _· · ·_ + _hty[t]_ s.t. _f_ ( _x_ ) = _h_ ( _x, si_ ( _x_ )). Here deg( _hj_ ( _x_ )) _<_ 2 _[i]_ . 6: Compute _h[′]_ ( _Y_ ) = _q_ 0( _x_ ) + _· · ·_ + _qt_ ( _x_ ) _X_ 2 _i·t_ ( _x_ ) _←_ BasisCvt( _h_[ˆ] ( _y_ )). 7: Compute _g_ 2 _i·t′_ + _g_ 2 _i·t′_ +1 _X_ 1( _x_ ) + _· · ·_ + _g_ 2 _i·t′_ +2 _i−_ 1 _X_ 2 _i−_ 1( _x_ ) _←_ BasisCvt( _qt[′]_ ( _x_ )) for all coefficient _qt′_ ( _x_ ) of _h[′]_ ( _Y_ ). 8: **return** _g_ ( _X_ ) = _g_ 0 + _g_ 1 _X_ 1( _x_ ) + _· · ·_ + _gn−_ 1 _Xn−_ 1( _x_ ) 

Once the input polynomial _f_ ( _x_ ) has been converted into the novel polynomial basis form _g_ ( _X_ ) using the BasisCvt procedure, the next step is to evaluate the polynomial at multiple points efficiently as part of AFFT. Specifically, the butterfly operation is used to compute _f_ at _n_ = 2 _[l]_ points of the form _α_ + _ω_ , where _ω ∈ Wl_ and _α ∈_ F2 _m_ . 

This step is performed by the Btfy algorithm, which recursively divides the polynomial _g_ ( _X_ ) into two parts, _p_ 0( _X_ ) and _p_ 1( _X_ ), and computes the intermediate values _h_ 0( _X_ ) and _h_ 1( _X_ ) as follows: 

**==> picture [143 x 26] intentionally omitted <==**

where _si_ ( _x_ ) is the vanishing polynomial of degree 2 _[i]_ corresponding to the largest power of two less than the target evaluation length. Since _si_ ( _vi_ ) = 1, each recursive step of the 

J. Jang et al. 

7 

butterfly algorithm splits the polynomial and performs two field additions and one field multiplication. The full butterfly operation is detailed in Algorithm 2. 

**Algorithm 2** Btfy: Butterfly Operation for Additive FFT 

**Require:** Polynomial _g_ ( _X_ ) = _f_ ( _x_ ) of degree _n_ in novel polynomial basis, and offset _α ∈_ F2 _m_ **Ensure:** Evaluation list [ _f_ ( _ω_ 0 + _α_ ) _, f_ ( _ω_ 1 + _α_ ) _, . . . , f_ ( _ω_ 2 _l−_ 1 + _α_ )] where _ωj ∈ Wl_ 1: **if** deg( _g_ ( _X_ )) = 0 **then** 2: **return** [ _g_ 0] 3: **end if** 

- 4: Find _i ←⌈_ log2 _n⌉−_ 1 such that deg( _si_ ( _x_ )) = 2 _[i] < n_ 

5: Split _g_ ( _X_ ) as _g_ ( _X_ ) = _p_ 0( _X_ ) + _X_ 2 _i_ ( _X_ ) _· p_ 1( _X_ ) = _p_ 0( _X_ ) + _si_ ( _x_ ) _· p_ 1( _X_ ) 

6: Compute _h_ 0( _X_ ) _← p_ 0( _X_ ) + _si_ ( _α_ ) _· p_ 1( _X_ ) 

7: Compute _h_ 1( _X_ ) _← h_ 0( _X_ ) + _si_ ( _vi_ ) _· p_ 1( _X_ ) 

- 8: **return** [Btfy( _h_ 0( _X_ ) _, α_ ) _,_ Btfy( _h_ 1( _X_ ) _, vi_ + _α_ )] 

The Btfy algorithm exploits the recursive structure of the novel polynomial basis and the properties of vanishing polynomials to perform Additive FFT efficiently. Since each recursive step handles half the size of the input and involves minimal operations, it achieves efficient evaluation over _Wl_ . 

Consequently, the complete process for performing the additive FFT on a polynomial _f_ ( _x_ ) _∈_ F2 _m_ [ _x_ ] of degree less than _n_ consists of two main stages. First, the polynomial is transformed from the monomial basis into the novel polynomial basis using the BasisCvt algorithm, as described in the previous section. 

With the polynomial represented as _g_ ( _X_ ) in the novel basis, the second stage employs the Btfy algorithm. This step recursively evaluates _g_ ( _X_ ) at _n_ = 2 _[l]_ points of the form _α_ + _ω_ , where _ω ∈ Wl_ and _α ∈_ F2 _m_ . These recursive butterfly operations enable the efficient evaluation of _f_ ( _x_ ) over the set _α_ + _Wl_ . 

This two-step procedure is summarized in Algorithm 3, denoted as AFFT. 

**Algorithm 3** AFFT: Additive FFT Algorithm 

**Require:** Polynomial _f_ ( _x_ ) = _f_ 0 + _f_ 1 _x_ + _· · ·_ + _fn−_ 1 _x[n][−]_[1] _∈_ F2 _m_ [ _x_ ] **Ensure:** Evaluation values _{f_ ( _ω_ ) : _ω ∈ Wn}_ 1: Convert to novel basis: _g_ ( _X_ ) _←_ BasisCvt( _f_ ( _x_ )) 

- 2: **return** Btfy( _g_ ( _X_ ) _,_ 0) 

## **2.2 Frobenius Additive FFT** 

## **2.2.1 Frobenius map and Frobenius partition** 

The Frobenius Additive FFT (FAFFT) [LCK[+] 18, CCK21] employs the Frobenius map to reduce the number of evaluation points required for polynomial multiplication compared with AFFT. Concretely, if AFFT evaluates a polynomial at 2 _[l]_ points in the coset _α_ + _Wl_ , FAFFT evaluates only 2 _[l] /m_ points, where _m_ is the extension degree of F2 _m_ . For example, when _l_ = 16 and _m_ = 32, FAFFT requires only 2[16] _/_ 32 = 2 _,_ 048 evaluations to achieve the same result. 

**Frobenius map.** Let _ϕ_ 2 : F2 _[m] →_ F2 _[m]_ denote the _Frobenius map ϕ_ 2( _a_ ) = _a_[2] . For any polynomial _f_ ( _x_ ) _∈_ F2[ _x_ ] _⊂_ F2 _m_ [ _x_ ] and any _a ∈_ F2 _m_ , it holds that _f_ ( _ϕ_ 2( _a_ )) = _ϕ_ 2( _f_ ( _a_ )). 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

8 

**Order and partition under Frobenius.** Given a finite set Σ _⊆_ F2 _m_ , the _order_ of the Frobenius map _ϕ_ 2 for a set Σ, denoted Ord _ϕ_ 2 (Σ), is the smallest _j ∈_ N such that Σ = _ϕ_ 2 _[j]_[(Σ).] Σ is called a _Frobenius partition_ of Ωif 

**==> picture [155 x 13] intentionally omitted <==**

with pairwise disjoint unions, where _j_ = Ord _ϕ_ 2(Σ). 

**Properties with respect to the Cantor basis.** Let _{v_ 0 _, . . . , vm−_ 1 _}_ be the Cantor basis of F2 _m_ . Then the following hold: 

- Ord _ϕ_ 2( _vi_ ) = 2 _·_ 2 _[⌊]_[log][2] _[ i][⌋]_ for _i >_ 0. 

**==> picture [109 x 11] intentionally omitted <==**

Let _k_ = _l −_ log2 _m <[m]_ 2[and][define][Σ :=] _[ v][k]_[+] _[m/]_[2][ +] _[ W][k]_[.][Then,][by][the][properties][above,][the] following properties hold: 

- Ord _ϕ_ 2(Σ) = _m_ and _|_ Σ _|_ = 2 _[k]_ = 2 _[l] /m_ . 

**==> picture [231 x 12] intentionally omitted <==**

- _ϕ_ 2 _[j]_[(Σ)][are][disjoint][sets][for][0] _[ ≤][j][< m]_[.] 

From these properties, it follows that Σ = _vk_ + _m/_ 2 + _Wk_ is a Frobenius partition of Ω. Therefore, evaluating _f_ at the _|_ Σ _|_ = 2 _[k]_ = 2 _[l] /m_ points recovers the full set of 2 _[l]_ values by applying _ϕ_ 2. This allows us to truncate the first _ℓm_ = log2 _m_ butterfly layers in Btfy. 

**Vanishing polynomial and the ring structure.** The set Ωconstructed above serves as the evaluation domain for FAFFT. We define the modulus polynomial _Pl_ ( _x_ ) as the vanishing polynomial over Ω: 

**==> picture [88 x 24] intentionally omitted <==**

Since Ωconsists of 2 _[l]_ = 2 _[k]_[+] _[ℓ][m]_ distinct elements, _Pl_ ( _x_ ) is a polynomial of degree 2 _[l]_ . Unlike AFFT which typically utilizes a subspace vanishing polynomial _sl_ ( _x_ ), FAFFT uses _Pl_ ( _x_ ) constructed from the Frobenius orbits of Σ. A key property of FAFFT is that the point-wise multiplication of evaluations over Ωcorresponds to polynomial multiplication modulo _Pl_ ( _x_ ). Thus, the FAFFT algorithm effectively computes the product in the ring F2[ _x_ ] _/Pl_ ( _x_ ). 

## **2.2.2 Multiplication over** F **2[** _**x**_ **] with Frobenius Additive FFT** 

In this section, we describe how to multiply two polynomials _f, g ∈_ F2[ _x_ ] using FAFFT. FAFFT proceeds in three stages: BasisCvt, Encode, and Btfy. (i) The BasisCvt step (Algorithm 1) converts the input from the monomial basis to the novel polynomial basis. (ii) The Encode step uses the Frobenius partition to truncate the first _ℓm_ = log2 _m_ butterfly layers, reducing the set of points from _n_ to _n/m_ . (iii) The remaining layers are performed by the recursive Btfy procedure (Algorithm 2), which evaluates the polynomial at the _n/m_ points. The structure of the algorithm is based on Algorithm 4. 

J. Jang et al. 

9 

**Encode and Decode (truncation of the first** _**ℓm**_ **butterfly layers).** The Encode step corresponds to the first _ℓm_ = log2 _m_ butterfly layers of AFFT. In these layers, at each node of Btfy only one of the two recursive calls is executed, whereas in the remaining _l − ℓm_ layers both recursive calls are executed as in AFFT. Consequently, FAFFT performs explicit evaluations at only _n/m_ points. 

Moreover, this truncation prevents the memory usage from increasing by a factor of _m_ . The encoding process in the Btfy algorithm involves only a single recursive call, which means that multiplication is performed only once. At each layer, the values multiplied with the polynomial are fixed and given by _vm/_ 2 _−ℓm_ +1 _, · · · , vm/_ 2. Furthermore, the input and output lie in F _[n]_ 2[and][F] _[n/m]_ 2 _[m]_[,][respectively,][both][having][the][same][bit][length][of] _[n]_[.][Therefore,] the encoding process can be represented as a matrix-vector multiplication, which avoids an increase in memory usage. 

## **Algorithm 4** Polynomial multiplication using FAFFT 

**Require:** _A_ ( _x_ ) = _a_ 0 + _a_ 1 _x_ + _· · ·_ + _an−_ 1 _x[n][−]_[1] _∈_ F2 _m_ [ _x_ ] _/Pl_ ( _x_ ), _B_ ( _x_ ) = _b_ 0 + _b_ 1 _x_ + _· · ·_ + _bn−_ 1 _x[n][−]_[1] _∈_ F2 _m_ [ _x_ ] _/Pl_ ( _x_ ). **Ensure:** _C_ ( _x_ ) = _c_ 0 + _c_ 1 _x_ + _· · ·_ + _c_ 2 _n−_ 2 _x_[2] _[n][−]_[2] _∈_ F2 _m_ [ _x_ ] _/Pl_ ( _x_ ). 1: _A_ ( _X_ ) _←_ BasisCvt( _A_ ( _x_ )). 2: _f_ ( _X_ ) _←_ Encode( _A_ ( _X_ )). ˆ 3: � _a_ 0 _, · · · ,_ ˆ _a_ 2 _l−_ 1� _←_ Btfy( _f_ ( _X_ ) _, vk_ + _m/_ 2). 4: _B_ ( _X_ ) _←_ BasisCvt( _B_ ( _x_ )). 5: _g_ ˆ( _X_ ) _←_ ˆEncode( _B_ ( _X_ )). 6: � _b_ 0 _, · · · , b_ 2 _k−_ 1� _←_ Btfy( _g_ ( _X_ ) _, vk_ + _m/_ 2). ˆ 7: _C_[ˆ] _← c_ 0 = ˆ _a_ 0 _·_[ˆ] _b_ 0 _, · · · ,_ ˆ _c_ 2 _k−_ 1 = ˆ _a_ 2 _k−_ 1 _·_[ˆ] _b_ 2 _k−_ 1 . � � 8: _h_ ( _X_ ) _←_ invBtfy( _C, v_[ˆ] _k_ + _m/_ 2). 

9: _C_ ( _X_ ) _←_ Decode( _h_ ( _X_ )). 10: _C_ ( _x_ ) _←_ invBasisCvt( _C_ ( _X_ )). 11: **return** Btfy( _g_ ( _X_ ) _,_ 0) 

## **3 Proposed method for optimizing FAFFT for HQC** 

In this section, we propose the hybrid FAFFT-Karatsuba method that applies FAFFT more efficiently for the HQC polynomial degrees. FAFFT can be applied only to polynomials of degree 2 _[l] −_ 1. To ensure that reduction does not affect the result, one chooses the smallest _l_ such that 2 _n −_ 2 _<_ 2 _[l]_ . For the degree of polynomials on HQC _n_ = 2 _[d]_ + _r_ , this condition leads to _l_ = _d_ + 2. Consistent with this rule, the state-of-the-art implementation [LJKH25] selects 2 _[l]_ = 65536, 131072, and 131072 for HQC-1, -3, and -5, respectively, as shown in Table 1. 

**Table 1:** FAFFT parameters for HQC used in [LJKH25]. 

|**Table 1:** FA|FFT|parame|ters for H|QC u|sed i|n [L|JKH25].|
|---|---|---|---|---|---|---|---|
|Parameter|set|_n_|2_l_|_m_|_k_||Σ|
|HQC-1||17669|65536|32|11|_v_27|+_W_11|
|HQC-3||35851|131072|32|12|_v_28|+_W_12|
|HQC-5||57637|131072|32|12|_v_28|+_W_12|



Consequently, FAFFT is performed on polynomials whose degree is at least twice and less than four times the original degree. In particular, HQC-1, -3 have _n_ = 2[14] + 1285 and _n_ = 2[15] + 3083, which are slightly larger than powers of two. This mismatch introduces substantial overhead, and as a result HQC-3 uses the same 2 _[l]_ as HQC-5. The observation 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

10 

in [LJKH25] that the polynomial-multiplication performance of HQC-3 and HQC-5 is very similar supports this explanation. To address this, we utilize the Hybrid FAFFT–CRT method and the Hybrid FAFFT–Karatsuba method. These methods align large subproducts with a power of two for FAFFT evaluation, while handling the small residual part separately. This allows FAFFT to be applied more efficiently to the polynomial degrees used in HQC. Lastly, to further optimize these FAFFT-based implementations, we improve the butterfly operation in FAFFT by shortening the XOR sequences in fixed-coefficient multiplications and carefully scheduling operations to fully saturate the 14 general-purpose registers available on the ARM Cortex-M4. 

## **3.1 The hybrid FAFFT–CRT method** 

In the context of HQC, polynomial multiplication requires computing _C_ ( _x_ ) = _A_ ( _x_ ) _·B_ ( _x_ ) in F2[ _x_ ]. As discussed in Section 2.2.1, for the polynomial multiplication of degree _n_ = 2 _[d]_ + _r_ with _r >_ 0, the previous approach using FAFFT operates over the ring F2[ _x_ ] _/Pd_ +2( _x_ ). For HQC-1 ( _n_ = 17 _,_ 669), the previous approach typically employs _P_ 16( _x_ ) of degree 2[16] = 65 _,_ 536. This results in significant padding overhead since the required product length is only about 35 _,_ 338. 

To address this inefficiency, we apply the Hybrid FAFFT–CRT method that applies the Chinese Remainder Theorem (CRT) to compute the product over a modulus _Pd_ +1( _x_ ) _· x[r][c]_ . Here, _Pd_ +1( _x_ ) corresponds to a FAFFT instance, and _x[r][c]_ covers the residual part. Since _Pd_ +1( _x_ ) is not divisible by _x_ , the moduli _Pd_ +1( _x_ ) and _x[r][c]_ are coprime, allowing unique reconstruction. 

For HQC-1 such that _d_ = 14, instead of using _P_ 16( _x_ ), we select the smaller modulus _P_ 15( _x_ ) of degree 2[15] = 32 _,_ 768. To ensure the total ring size covers the linear product without reduction, we choose _rc_ = 2 _,_ 592 as a multiple of 32 for alignment. The condition for correctness is satisfied as: 

**==> picture [296 x 11] intentionally omitted <==**

The computation is split into two parts: 

**==> picture [303 x 11] intentionally omitted <==**

_C_ 1( _x_ ) is computed efficiently using FAFFT of length 2[15] , and _C_ 2( _x_ ) is computed using radix-16 polynomial multiplication. The final result is reconstructed using the explicit CRT formula. First, we compute the correction term _t_ ( _x_ ) modulo _x[r][c]_ : 

**==> picture [243 x 13] intentionally omitted <==**

Here, _P_ 15 _[−]_[1][(] _[x]_[)][is][the][modular][inverse][of] _[P]_[15][(] _[x]_[)][modulo] _[x][r][c]_[.][Finally,][the][product] _[C]_[(] _[x]_[)][is] recovered as: 

**==> picture [129 x 11] intentionally omitted <==**

The final multiplication _t_ ( _x_ ) _· P_ 15( _x_ ) is performed efficiently by taking advantage of the sparsity of _P_ 15( _x_ ). Although _P_ 15( _x_ ) has a degree of 32,768, it contains only 501 non-zero terms in our parameter set, making it significantly sparse compared to a random dense polynomial. In standard HQC implementations, optimized sparse-dense multiplication is generally avoided because the sparse polynomial usually represents a secret key or error vector. Thus, the operation requires constant-time execution to prevent timing attacks. However, _P_ 15( _x_ ) is a fixed and public polynomial determined by the FAFFT parameters. Therefore, we can employ a fast sparse-dense multiplication algorithm without the risk of leaking sensitive information. 

For HQC-5 ( _n_ = 57 _,_ 637), the required CRT residual degree must satisfy _rc ≥_ 49 _,_ 736. Consequently, applying the hybrid FAFFT-CRT method to HQC-5 necessitates at least 

J. Jang et al. 

11 

a FAFFT of size 65 _,_ 536 and a polynomial multiplication of degree _rc_ . To verify the feasibility of this approach, we estimated a conservative lower bound on the required clock cycles by summing the cycle counts of the FAFFT of size 65 _,_ 536 and a polynomial multiplication of degree 35 _,_ 851 (taken from our HQC-3 benchmark). Since the degree 35 _,_ 851 is strictly smaller than the required _rc_ and we explicitly exclude additional overheads, such as _t_ ( _x_ ) _· P_ 16( _x_ ), this estimate represents a strictly lower bound. Even this lower bound amounts to 7 _,_ 448 _,_ 930 clock cycles, which already exceeds the 6 _,_ 290 _,_ 039 cycles achieved by the state-of-the-art implementation [LJKH25]. Therefore, the hybrid FAFFT-CRT method offers no performance benefit for HQC-5. 

**Table 2:** Parameters for Hybrid FAFFT–CRT method in HQC-1 ,-3. _ω_ ( _Pi_ ) denotes the Hamming weight of the _Pi_ ( _x_ ). 

|Parameter set<br>_n_|FAFFT for _C_1<br>|CRT|
|---|---|---|
||2_l_~~_′_~~<br>_m_<br>_k_<br>Σ|_rc_<br>_ω_(_Pi_)|
|HQC-1<br>17669<br>HQC-3<br>35851|32768<br>32<br>10<br>_v_26+_W_10<br>65536<br>32<br>11<br>_v_27 +_W_11|2592<br>501<br>6176<br>473|



## **3.1.1 Efficient sparse-dense polynomial multiplication** 

The final step of the CRT reconstruction requires computing the product _t_ ( _x_ ) _· Pd_ +1( _x_ ). Since _Pd_ +1( _x_ ) is a sparse polynomial and _t_ ( _x_ ) is a dense polynomial, we employ an optimized shift-and-XOR strategy tailored to the 32-bit word architecture of the ARM Cortex-M4. As previously noted, since _Pd_ +1( _x_ ) is a fixed and public polynomial, utilizing its sparsity does not incur side-channel leakage. As detailed in Algorithm 5, we optimize this sparse-dense polynomial multiplication by introducing two key strategies: index grouping and batch processing. 

**Index grouping** A naive implementation would iterate through every non-zero term _x[ι]_ of _Pd_ +1( _x_ ) and accumulate _t_ ( _x_ ) _· x[ι]_ . This approach requires shifting the dense polynomial _t_ ( _x_ ) by an arbitrary bit index _ι_ . On the ARM Cortex-M4, performing a bitwise shift on the polynomial is not a single instruction. It requires a sequence of a bitwise shift and a logical OR-shift (utilizing the barrel shifter) for every word of the dense polynomial. To reduce these costs, we minimize bitwise shift operations by grouping the indices of non-zero terms based on their offsets within a 32-bit word. Let _IPd_ +1 denote the set of indices corresponding to the exponents of the non-zero terms in _Pd_ +1( _x_ ). We decompose each index _ι ∈ IPd_ +1 into a quotient _qι_ and a bitwise shift amount _s_ such that _ι_ = 32 _· qι_ + _s_ , where 0 _≤ s <_ 32. Based on this decomposition, the multiplication can be reformulated as: 

**==> picture [307 x 51] intentionally omitted <==**

In our implementation, we group the indices of _Pd_ +1( _x_ ) by their bitwise shift amount _s_ . The process is as follows: 

1. We compute the bit-shifted dense polynomial _ts_ ( _x_ ) = _t_ ( _x_ ) _·x[s]_ within registers, reusing it for all terms with the same shift amount _s_ . 

2. For every term in the group with shift amount _s_ , we accumulate _ts_ ( _x_ ) shifted by _qι_ words. Since word-level shifts correspond to simple memory pointer adjustments, they incur negligible computational cost. 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

12 

This optimization reduces the number of bitwise shift operations required, significantly accelerating the sparse-dense multiplication. 

**Batch processing** To further optimize performance, we process consecutive words of the dense polynomial in batches per iteration, rather than iterating word-by-word. This strategy provides two advantages: 

- **Reduction of load and shift overhead:** Computing the bit-shifted result for a batch of _α_ target words requires loading (Line 8) and shifting (Line 13) _α_ + 1 words: the _α_ target words ( _v_ 1 _, . . . , vα_ ) and the preceding word ( _v_ 0) which supplies the carry bits. Consequently, the number of load and shift operations required per generated output word is proportional to ( _α_ + 1) _/α_ , which decreases as the batch size _α_ increases. 

- **Utilization of** **`LDM` and** **`STM` :** Handling consecutive words enables the use of `LDM` (Load Multiple) and `STM` (Store Multiple) instructions. These instructions minimize the instruction fetch overhead and maximize memory bandwidth utilization compared to executing a sequence of single `LDR` / `STR` instructions. 

In our specific implementation on the ARM Cortex-M4, we adopted a 5-word batch configuration ( _α_ = 5). The Cortex-M4 provides 14 usable GP registers (R0-R12 and LR). Our innermost loop (lines 15-18) requires four registers to store the result array base address & _R_ [ _i_ ], the pointer _ptr_ , the offset _off_ , and the loop counter _j_ . To maximize throughput of this loop using `LDM` / `STM` , we must allocate 5 registers to hold the pre-loaded dense polynomial batch ( _v_ 1 _, . . . , v_ 5) and 5 additional registers as a result polynomial batch _R_ [ _i_ + _off , · · · , i_ + _off_ + 4] for the accumulation (load, XOR, store) process. This requires a total of 14 registers, which efficiently uses all of the available GP registers and prevents unnecessary memory accesses. Note that the carry word _v_ 0 is preserved on the stack as it is not required for the XOR accumulation step. 

Algorithm 5 outlines the detailed procedure of the proposed sparse-dense polynomial multiplication. To efficiently manage the indices of the sparse polynomial _Pd_ +1( _x_ ), the algorithm uses two pre-computed data arrays. The sorted index array ( _Idx_ ) stores the word offsets ( _qι_ ) of the non-zero terms, rearranged such that all terms having the same bit offset 0 _≤ s <_ 32 are grouped continuously. Complementing this, the count array ( _Cnt_ ) records the number of non-zero terms associated with each bit offset _s_ . Specifically, for a given bit offset _s_ , the elements of _Idx_ in the range 

**==> picture [148 x 31] intentionally omitted <==**

correspond exactly to the set of word offsets � _qι_ �� 32 _· qι_ + _s ∈ IPd_ +1�. 

The algorithm takes the dense polynomial array _t_ and these pre-sorted structures as inputs. It iterates through the dense polynomial in 5-word batches. For each batch, the inner loop iterates through shift amounts _s_ from 0 to 31, handling all sparse terms that require a bitwise shift of exactly _s_ . Within this loop, the working registers _{v_ 1 _, . . . , v_ 5 _}_ are updated via a 1-bit left shift (linked with _v_ 0) to align with the current bit index. Subsequently, utilizing _Cnt_ [ _s_ ] and the sequential segment of _Idx_ , the bit-shifted values are XORed into the corresponding positions of the result array _R_ , minimizing redundant operations. 

J. Jang et al. 

13 

**Algorithm 5** Optimized Sparse-Dense Polynomial Multiplication 

**Require:** _R_ (result array), _t_ (dense polynomial array), _Idx_ (sorted word offsets), _Cnt_ (term counts per shift) **Ensure:** _R ← R_ + _t_ ( _x_ ) _· Pd_ +1( _x_ ) 1: **for** _i_ = 0 **to** len( _t_ ) _−_ 5 **step** 5 **do** 2: _/* Load 5 data words (v_ 1 _. . . v_ 5 _) and 1 carry word (v_ 0 _) */_ 3: **if** _i_ = 0 **then** 4: _v_ 0 _←_ 0 5: **else** 6: _v_ 0 _← t_ [ _i −_ 1] 7: **end if** 8: ( _v_ 5 _, v_ 4 _, v_ 3 _, v_ 2 _, v_ 1) _←_ ( _t_ [ _i_ + 4] _, t_ [ _i_ + 3] _, t_ [ _i_ + 2] _, t_ [ _i_ + 1] _, t_ [ _i_ ]) 9: _ptr ← Idx /* Unified Shift and XOR Processing */_ 10: **for** _s_ = 0 **to** 31 **do** 11: **if** _s >_ 0 **then** 12: _/* Shift chain including carry v_ 0 _*/_ 13: ( _v_ 5 _, v_ 4 _, v_ 3 _, v_ 2 _, v_ 1 _, v_ 0) _←_ ( _v_ 5 _, v_ 4 _, v_ 3 _, v_ 2 _, v_ 1 _, v_ 0) _≪_ 1 14: **end if** 15: **for** _j_ = 0 **to** _Cnt_ [ _s_ ] _−_ 1 **do** 16: _off ←∗ptr_ `++` 17: _R_ [ _i_ + _off , · · · , i_ + _off_ + 4] _⊕_ = ( _v_ 1 _, v_ 2 _, v_ 3 _, v_ 4 _, v_ 5) 18: **end for** 19: **end for** 20: **end for** _Note: Remaining words processed sequentially if len_ ( _t_ ) _̸_ = 0 (mod 5) _._ 

## **3.2 The hybrid FAFFT–Karatsuba method** 

For HQC-1 and HQC-3, we write the degree parameter as _n_ = 2 _[d]_ + _r_ with 0 _< r <_ 2 _[d]_ and split the inputs at 2 _[d]_ : 

**==> picture [252 x 14] intentionally omitted <==**

where deg _A_ 0 _,_ deg _B_ 0 _<_ 2 _[d]_ and deg _A_ 1 _,_ deg _B_ 1 _< r_ . Then we compute 

**==> picture [263 x 11] intentionally omitted <==**

Finally, the result of multiplication is 

**==> picture [245 x 14] intentionally omitted <==**

We compute _C_ 0 and _C_ 1 using FAFFT with 2 _[l][′]_ = 2 _[d]_[+1] , and _C_ 2 using radix-16 multiplication. 

**Algorithm 6** Hybrid FAFFT–Karatsuba method 

**Require:** _A_ ( _x_ ) = _A_ 1 _X_ + _A_ 0 _, B_ ( _X_ ) = _B_ 1 _X_ + _B_ 0 for _X_ = _x_[2] _[l]_[0] **Ensure:** _C_ ( _x_ ) = _A_ ( _x_ ) _× B_ ( _x_ ) 1: _C_ 0 _← A_ 0 _× B_ 0 using `FAFFT` algorithm. 

2: _C_ 2 _← A_ 1 _× B_ 1 using radix-16 algorithm. 

3: _C_ 1 _←_ ( _A_ 0 + _A_ 1) _×_ ( _B_ 0 + _B_ 1) using `FAFFT` algorithm. 4: _C_ ( _x_ ) _← C_ 2 _X_[2] + ( _C_ 0 + _C_ 1 + _C_ 2) _X_ + _C_ 0. 5: **return** _C_ ( _x_ ) 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

14 

In our approach, we choose _X_ = _x_[2] _[d]_ as the split point. While one could split the polynomials at _X_ = _x[r]_ , which would only require modifying lines 1 and 2 of Algorithm 6, splitting at _X_ = _x_[2] _[d]_ is more efficient for the following reason. 

Let _X_ = _x_[2] _[d]_ . Given the degrees deg _A_ 0 = deg _B_ 0 = 2 _[d] −_ 1 and deg _A_ 1 = deg _B_ 1 = _r −_ 1, the Karatsuba components have degrees deg _C_ 0 = deg _C_ 1 = 2 _·_ 2 _[d] −_ 2 and deg _C_ 2 = 2 _r −_ 2. With the split point _X_ = _x_[2] _[d]_ , the degrees of the individual terms in the final result _C_ ( _x_ ) = _C_ 0 + ( _C_ 0 + _C_ 1 + _C_ 2) _X_ + _C_ 2 _X_[2] relate to the total degree 2 _n −_ 2 as follows: 

**==> picture [313 x 12] intentionally omitted <==**

Since the total degree is deg _C_ ( _x_ ) = 2 _n −_ 2, the degree of the middle term must satisfy: 

**==> picture [141 x 11] intentionally omitted <==**

**==> picture [211 x 12] intentionally omitted <==**

If the condition 2 _r <_ 2 _[d]_ is satisfied, which holds for both HQC-1 and HQC-3, we obtain the following inequality: 

deg( _C_ 0 + _C_ 1 + _C_ 2) _≤_ 2 _[d]_ + 2 _r −_ 2 _<_ 2 _·_ 2 _[d] −_ 2 = max _{_ deg _C_ 0 _,_ deg _C_ 1 _,_ deg _C_ 2 _}._ (1) 

Note that 2 _·_ 2 _[d] −_ 2 is the maximum degree supported by the FAFFT of length 2 _[d]_[+1] used to compute _C_ 0 and _C_ 1. Consequently, in line 4 of Algorithm 6, when computing the sum _C_ 0 + _C_ 1 + _C_ 2, the upper 2 _[d] −_ 2 _r_ bits do not need to be calculated or XORed, as they are guaranteed to be zero. 

In contrast, if the polynomials are split at _X_ = _x[r]_ , the degree of the middle term is deg( _C_ 0 + _C_ 1 + _C_ 2) = 2 _·_ 2 _[d]_ + _r −_ 2. Since this exceeds 2 _·_ 2 _[d] −_ 2, the inequality in (1) does not hold. Thus, splitting at _X_ = _x_[2] _[d]_ reduces the XOR operations required for reconstruction. 

**Table 3:** parameters for FAFFT with Karatsuba in HQC-1, -3. 

|Parameter set<br>_n_|FAFFT for _C_0_, C_1<br>|radix-16 for _C_2|
|---|---|---|
||2_l_~~_′_~~<br>_m_<br>_k_<br>Σ|_r_|
|HQC-1<br>17669<br>HQC-3<br>35851|32768<br>32<br>10<br>_v_26+_W_10<br>65536<br>32<br>11<br>_v_27 +_W_11|1285<br>3083|



## **3.3 Optimizing butterfly algorithm of FAFFT** 

During the butterfly stage, the term _si_ ( _α_ ) _· p_ 1( _X_ ) is evaluated as follows [LJKH25]. For _m_ = 32, write _si_ ( _α_ ) = _w_ + _v_ with _w ∈ Wk_ and _v ∈{v_ 17 _, . . . , vk_ +16 _}_ . Then _si_ ( _α_ ) _· p_ 1( _X_ ) = _w · p_ 1( _X_ ) + _v · p_ 2( _X_ ) _._ Since _k <_ 16, _w_ lies in a proper subspace F _[m]_ 2 _[′]_ ⊊F[32] 2[with] _[m][′][≤]_[16.] Consequently, the product _w · p_ 1( _X_ ) over F[32] 2[can][be][computed][as][(32] _[/m][′]_[)][products][over] F _[m]_ 2 _[′]_[.][For][the][term] _[v][ ·][ p]_[2][(] _[X]_[),][[][LJKH25][]][exploits][that] _[v][∈{][v]_[17] _[, . . . , v][k]_[+16] _[}]_[is][fixed,][converts] the fixed part into a matrix–vector multiplication, and then searches XOR sequences for this operation using the method of [XZL[+] 20]. This yields a 23-44% reduction in XORs compared with the previous implementation [CCK21]. 

We searched XOR sequences that use fewer XORs than [LJKH25]. Moreover, by spilling the input and output registers to the stack and scheduling with all 14 GP registers and 32 FP registers of Cortex-M4, we achieved a more efficient register allocation, which reduces `vmov` instructions. Table 4 presents a comparison of XOR and instruction counts against [LJKH25]. For _v_ 24, our sequence uses more XORs, but it is more suitable for register scheduling, which reduces the overall instruction count. Since performance depends on the instruction count rather than the XOR count, we select the implementation with fewer instructions. 

J. Jang et al. 

15 

**Table 4:** XOR and instruction counts for multiplication by _vi_ . 

|Multiplier|[LJKH25]<br>XOR<br>clock cycle|[LJKH25]<br>XOR<br>clock cycle|XOR|Ours<br>clock cycle|
|---|---|---|---|---|
|_v_17|161|485|159|462|
|_v_18|153|465|153|440|
|_v_19|171|515|166|479|
|_v_20|173|511|172|485|
|_v_21|172|514|166|483|
|_v_22|165|501|160|469|
|_v_23|163|497|163|476|
|_v_24|178|548|180|503|
|_v_25|189|555|180|501|
|_v_26|190|562|179|516|
|_v_27|179|539|173|538|
|_v_28|187|559|183|518|



In addition, we optimize the swap operations that occur during the butterfly using the `SWAPMOVE` subroutine proposed in [MPC00]. The `SWAPMOVE` operation applies a mask to select specific bits from register _R_ 2 and swaps them with the bits of register _R_ 1 shifted by _n_ . We denote it as `SWAPMOVE` ( _R_ 1 _, R_ 2 _,_ mask _, n_ ). On the Cortex-M4, this operation can be implemented using four instructions. Algorithm 7 represents the `SWAPMOVE` subroutine. 

## **Algorithm 7** `SWAPMOVE` 

|**Algorith**|**m 7** `SWAPMOVE`|
|---|---|
|**Require:**|_R_1, _R_2, mask, _n_|
|**Ensure:**|bit swap between the _R_1, _R_2|
|1: `EOR`|tmp, _R_2, _R_1, `LSR` _n_|
|2: `AND`|tmp, tmp, mask|
|3: `EOR`|_R_2, _R_2, tmp|
|4: `EOR`|_R_1, _R_1, tmp, `LSL` _n_|



Our butterfly is implemented in a bitsliced manner on a Cortex-M4 with 32-bit registers. In the final five layers of Algorithm 2, the offset _n_ between the data corresponding to _p_ 0( _X_ ) and _p_ 1( _X_ ) is at most 16. In the bitsliced representation, the two slices reside within the same 32-bit word. For this reason, bit swaps in registers are required. There are 2 _[l] /_ 32 such swaps for each layer, so a single FAFFT multiplication performs 2 _[l] /_ 32 _·_ 5 _·_ 2 swaps in total. [LJKH25] implements this swap as Algorithm 8. 

**Algorithm 8** Bit swap in the butterfly stage [LJKH25] 

**Require:** `data[i+j], data[i+32+j]` **Ensure:** `data[i+j], data[i+32+j]` s.t. the bits selected by `MASK` are exchanged between the two words with shift offset `n` . 

- 1: `uint32_t data_l = (data[i+j] & ~MASK) | ((data[i+32+j]& ~MASK) « n);` 

- 2: `uint32_t data_h = ((data[i+j] & MASK) » n) | (data[i+32+j] & MASK);` 

- 3: `data[i+j] = data_l;` 

- 4: `data[i+32+j] = data_h;` 

The implementation in Algorithm 8 requires eight instructions. Using `SWAPMOVE` , the same operation can be realized with four instructions as Algorithm 9, reducing four instructions for each swap. 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

16 

**Algorithm 9** Bit swap in the butterfly stage with `SWAPMOVE` 

**Require:** `data[i+j], data[i+32+j]` **Ensure:** `data[i+j], data[i+32+j]` s.t. the bits selected by `MASK` are exchanged between the two words with shift offset `n` . 

- 1: `uint32_t tmp = data[i+32+j] ^ (data[i+j] » n);` 

- 2: `tmp = tmp & MASK;` 

- 3: `data[i+32+j] = data[i+32+j] ^ tmp;` 

- 4: `data[i+j] = data[i+j] ^ (tmp « n);` 

## **4 Radix-16 multiplicaton** 

In [CC21], a radix-16 representation for degree-7 polynomials over F2[ _x_ ] was introduced. Given 

**==> picture [135 x 13] intentionally omitted <==**

and define its radix-16 representation as the 32-bit integer 

**==> picture [161 x 12] intentionally omitted <==**

Under this encoding, the product of two polynomials _A_ ( _x_ ) and _B_ ( _x_ ) can be computed by a single integer multiplication: 

**==> picture [327 x 12] intentionally omitted <==**

Since for each coefficient index _k_ the sum[�] _i_ + _j_ = _k[a][i][b][j]_[contains][at][most][seven][terms] (each equal to 0 or 1), no partial sum exceeds 8 _<_ 16, so no carries occur across 4-bit boundaries. Therefore, extracting the bits at positions 0 _,_ 4 _,_ 8 _, . . . ,_ 56 from the 64-bit product recovers exactly the 15 coefficients of _A_ 0( _x_ ) _× B_ 0( _x_ ) in F2[ _x_ ]. Figure 1 represents the 32-bit integer multiplication to compute 8-bit F2[ _x_ ] polynomial multiplication under the radix-16 representation. 

_A[′]_ 0[=][0001][0001][0001][0001][0001][0001][0001][0001] _B_ 0 _[′]_[=][0001][0001][0001][0001][0001][0001][0001][0001] 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 _P_ 0 _,_ 0 = 0000 0001 0010 0011 0100 0101 0110 0111 1000 0111 0110 0101 0100 0011 0010 0001 & 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 0001 _C_ 0 _[′]_[=] 0000 0001 0000 0001 0000 0001 0000 0001 0000 0001 0000 0001 0000 0001 0000 0001 

Upper 32 bits of _C_ 0 _[′]_ Lower 32 bits of _C_ 0 _[′]_ 

**Figure 1:** 8-bit F2[ _x_ ] polynomial multiplication with radix-16 representation. 

Using this method, polynomial multiplication can be reduced to integer multiplication. Unlike high-performance architectures such as AVX2 and NEON, embedded systems like Cortex-M4 do not support carry-less multiplication instructions. Therefore, for Cortex-M4, implementing F2[ _x_ ] multiplication with carry-less multiplication via radix-16 multiplication is efficient. 

J. Jang et al. 

17 

## **4.1 32-bit base multiplication in radix-16 representation** 

Using the method introduced in the previous section, 8-bit multiplications over F2[ _x_ ] can be performed. In this section, we describe the technique for 32-bit F2[ _x_ ] multiplication as proposed in [CGKT22]. 

For given 32-bit F2[ _x_ ] polynomial _A_ ( _x_ ) = _a_ 0 + _a_ 1 _x_ + _· · ·_ + _a_ 31 _x_[31] and _B_ ( _x_ ) = _b_ 0 + _b_ 1 _x_ + _· · ·_ + _b_ 31 _x_[31] _,_ we split each 32-bit polynomial into four 8-bit polynomials: 

**==> picture [202 x 31] intentionally omitted <==**

Finally, _Pi,j_ = _Ai_ ( _x_ ) _× Bj_ ( _x_ ) are summed at their appropriate offsets to compute _C[′]_ ( _x_ ), the radix-16 representation of _C_ ( _x_ ) = _A_ ( _x_ ) _× B_ ( _x_ ). Each multiplication _Ai_ ( _x_ ) _× Bj_ ( _x_ ) is computed via integer multiplication on its radix-16 representation, as shown in Figure 1. We now introduce efficient methods for the radix-16 conversion and the summation of _Pi,j_ . 

## **4.1.1 Data conversion for the radix-16 representation** 

Storing each 8-bit polynomial _Ai_ ( _x_ ) as a 32-bit integer _A[′] i_[in][a][32-bit][register][incurs] increases register usage by a factor of four. To eliminate this overhead, [CGKT22] proposes an efficient method that converts four 8-bit polynomials into their radix-16 representations within a single 32-bit register. We call it _packed radix-16 representation_ . 

The conversion method is based on the `SWAPMOVE` operation. Let each 8-bit polynomial _Ai_ ( _x_ ) =[�][7] _j_ =0 _[a][i,j][x][j]_[be][stored][in][a][32-bit][register][as] 

**==> picture [273 x 12] intentionally omitted <==**

Then three `SWAPMOVE` operations with shifts of 12, 6, and 3 bits reorder these bits in place to 

[ _a_ 0 _,_ 0 _, a_ 2 _,_ 0 _, a_ 1 _,_ 0 _, a_ 3 _,_ 0 _, a_ 0 _,_ 1 _, a_ 2 _,_ 1 _, a_ 1 _,_ 1 _, a_ 3 _,_ 1 _, . . . , a_ 0 _,_ 7 _, a_ 2 _,_ 7 _, a_ 1 _,_ 7 _, a_ 3 _,_ 7 ] _._ 

In total, only 12 instructions are required to construct _A[′] pack_[,][the][packed][radix-16][repre-] sentation of _A_ . The full instruction sequence and its use for data conversion are given in Algorithm 10. 

**Algorithm 10** Data conversion for the radix-16 representation 

**Require:** 32-bit polynomial _A_ **Ensure:** _A[′] pack_[the][radix-16][representation][of] _[A]_ 1: _A[′] pack[←][A]_ 2: `SWAPMOVE` ( _A[′] pack[, A][′] pack[,]_ `[ 0x0000 f0f0]` _[,]_[ 12)] 3: `SWAPMOVE` ( _A[′] pack[, A][′] pack[,]_ `[ 0x00cc 00cc]` _[,]_[ 6)] 4: `SWAPMOVE` ( _A[′] pack[, A][′] pack[,]_ `[ 0x0a0a 0a0a]` _[,]_[ 3)] 5: **return** _A[′] pack_ 

After this conversion, the 32-bit radix-16 representations for each 8-bit polynomial can be extracted by simple mask-and-shift operations. Let mask = `0x1111 1111` . Then each of the four radix-16 representations, _A[′]_ 0[,] _[A][′]_ 1[,] _[A][′]_ 2[,][and] _[A][′]_ 3[,][can][be][computed][with][a][single] instruction as follows: 

**==> picture [115 x 61] intentionally omitted <==**

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

18 

After completing all multiplications in the radix-16 representation, the inverse conversion should be applied to convert the data back to its original format. The inverse conversion can be performed by executing the `SWAPMOVE` sequence in reverse order with shifts of 3, 6, and 12 bits using the same masks. This holds because `SWAPMOVE` is self-inverse, i.e., applying it twice serves as the identity. 

## **4.1.2 Construction of the 32-bit polynomial multiplication** 

_C[′]_ ( _x_ ) which is the radix-16 representation of _C_ ( _x_ ) can be obtained by summing the sixteen 64-bit integer products _Pi,k−i_ = _A[′] i[×][ B] j[′]_[as][Figure][2][.][Each] _[P][i,j]_[contains][other][set][bits] outside the positions 0, 4, 8, ..., 56. To ensure correctness, _Pi,j_ would be masked with _mask_ = 0x1111 1111 1111 1111 via AND operation before accumulation. 

**==> picture [234 x 245] intentionally omitted <==**

**----- Start of picture text -----**<br>
P 0 [′] , 0<br>P 0 [′] , 1<br>P 0 [′] , 2<br>P 0 [′] , 3<br>P 1 [′] , 0<br>P 1 [′] , 1<br>P 1 [′] , 2<br>P 1 [′] , 3<br>P 2 [′] , 0<br>P 2 [′] , 1<br>P 2 [′] , 2<br>P 2 [′] , 3<br>P 3 [′] , 0<br>P 3 [′] , 1<br>P 3 [′] , 2<br>P 3 [′] , 3<br>C [′] ( x ) : radix-16 representation of C ( x ) =  A ( x )  × B ( x )<br>**----- End of picture text -----**<br>


**Figure 2:** Constructing the 32-bit base multiplication. 

However, as shown in figure 1, adding two upper 32-bit halves or upper 32-bit half to lower 32-bit half does not propagate carries beyond 4 bits. Therefore, in these cases, it is not necessary to perform AND with _mask_ before addition, saving one less instruction. In addition, the UMLAL instruction is not applicable to uninitialized registers. If both the upper and lower 32-bit halves to be added are uninitialized, the UMULL instruction must be employed. However, if only one of them is uninitialized, it is necessary to employ the UMLAL instruction after initializing the uninitialized 32-bit half with MOV instruction. The former requires one instruction, while the latter requires two. Consequently, the total number of instructions depends on the order of addition of the _Pi,j_ s. Considering all of these and register scheduling, the accumulation operation is performed in the order of Figure 3. 

After obtaining _C[′]_ ( _x_ ) using the method in Figure 3, it must be converted from the radix-16 representation to the original format. As aforementioned, the conversion from the packed radix-16 representation to the original format is performed by the three `SWAPMOVE` s in Algorithm 10 in reverse order, requiring a total of 12 instructions. To employ this technique, one converts _C[′]_ ( _x_ ) to a packed radix-16 representation to get _Cpack[′]_[,][then] converts to _C_ ( _x_ ). In summary, 32-bit base multiplication in radix-16 representation is 

J. Jang et al. 

19 

**==> picture [234 x 245] intentionally omitted <==**

**----- Start of picture text -----**<br>
P 0 [′] , 0<br>P 0 [′] , 2<br>P 0 [′] , 1<br>P 1 [′] , 0<br>P 1 [′] , 3<br>P 0 [′] , 3<br>P 1 [′] , 1<br>P 1 [′] , 2<br>P 2 [′] , 0<br>P 2 [′] , 1<br>P 2 [′] , 2<br>P 3 [′] , 0<br>P 3 [′] , 3<br>P 2 [′] , 3<br>P 3 [′] , 1<br>P 3 [′] , 2<br>C [′] ( x ) = radix-16 representation of C ( x ) =  A ( x )  × B ( x )<br>**----- End of picture text -----**<br>


**Figure 3:** Optimized sequence for constructing the 32-bit base multiplication. 

performed as follows: 

- **Step 1** : Apply algorithm 10 to _A_ ( _x_ ) and _B_ ( _x_ ) to obtain _A[′] pack_[and] _[B] pack[′]_[.] 

- **Step 2** : Extract _A[′] i_[and] _[B] i[′]_[(0] _[ ≤][i][ ≤]_[3)][from] _[A][′] pack_[and] _[B] pack[′]_[.] 

- **Step 3** : Compute _Pi,j_ = _A[′] i[×][ B] j[′]_[(0] _[ ≤][i, j][≤]_[3)][by][integer][multiplication.] 

- **Step 4** : Accumulate the _Pi,j_ in the order of Figure 3 to form _C[′]_ ( _x_ ). 

- **Step 5** : Construct _Cpack[′]_[by][repacking] _[C][′]_[(] _[x]_[).] 

- **Step 6** : Convert _Cpack[′]_[to] _[C]_[(] _[x]_[)][by][the][inverse][of][Algorithm][10][.] 

## **4.2 Toom-Cook and Karatsuba algorithms with the radix-16 representation** 

HQC-1, -3, -5 contain F2[ _x_ ] polynomial multiplications of degree 17668, 35850, and 57636, respectively. The Toom-Cook and Karatsuba algorithms are efficient for polynomial multiplications of these large orders, reducing the complexity of the multiplication. Since both algorithms on F2[ _x_ ] are performed word-wise and all operations are bitwise XOR except for the base multiplication, they can be applied with the radix-16 representation without any modification. 

Therefore, before performing the polynomial multiplications, we first convert the polynomial to a radix-16 representation. We then apply the Karatsuba and Toom-Cook algorithms to split the polynomial until it is 32-bit, and perform Steps 2-5 of 4.1 to perform multiplications with inputs and outputs in the radix-16 representation. 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

20 

## **5 Proposed method for optimizing the radix-16 multiplication for HQC** 

In this section, we present a method to optimize radix-16 multiplication by exploring Karatsuba/Toom-Cook combinations. In [CGKT22], the authors employed the `gf2x` library to identify optimal algorithmic combinations. In contrast, our work adopts a theoretical approach based on instruction count, as in [JLK[+] 24], to explore optimal combinations. The Cortex-M4 processor lacks features such as out-of-order execution and cache, ensuring that each instruction consistently executes within a fixed number of clock cycles. This makes instruction count a suitable metric for algorithmic optimization. Furthermore, since we optimize under an operation-count cost model rather than hardware-specific autotuning, the resulting optimal combination set is consistent across platforms. Under the assumption that other instructions, such as MOV, LDR, and STR, scale proportionally with the number of XOR and base multiplications, we argue that our approach yields the theoretically most efficient combination. A detailed performance comparison between the `gf2x` library and our optimized combination is provided in Section 5.3. The following describes the search method applied in this paper. 

## **5.1 Karatsuba/Toom-Cook optimization using instruction count** 

Both the Karatsuba and Toom-Cook algorithms consist of only XOR operations and internal multiplications. The combination of the two algorithms determines the number of XORs and base multiplications. Since the target platform is a Cortex-M4 processor, where operations are performed on 32-bit words, we define an _n_ -word multiplication as a polynomial multiplication between two polynomials represented by _n_ 32-bit words. Based on this definition, [JLK[+] 24] finds the optimal combination that minimizes the following cost function: 

**==> picture [174 x 11] intentionally omitted <==**

where _cnt_ XOR( _n_ ) and _cnt_ mul( _n_ ) denote the numbers of 32-bit XOR operations and base multiplications, respectively, and _w_ mul is the weight assigned to base multiplications. By definition, for _n_ = 1, the values are: 

**==> picture [217 x 11] intentionally omitted <==**

Let _L_ denote the set of all candidate algorithms under consideration. When computing an _n_ -word multiplication using some _A ∈ L_ , we denote by _α_ the number of XOR operations performed at the top level, by _n_ 1 _, · · · , nr_ the word-lengths of the internal multiplications, and by _β_ 1 _, · · · , βr_ the counts of internal multiplications on _n_ 1 _, · · · , nr_ -word polynomials, respectively. Then, the total number of 32-bit XOR operations and base multiplications at the top level for algorithm _A_ , denoted by cnt _[A]_ XOR[(] _[n]_[)][and][cnt] _[A]_ mul[(] _[n]_[),][respectively,][and][the] corresponding cost function cost _[A]_ ( _n_ ) are as follows: 

**==> picture [183 x 78] intentionally omitted <==**

Let _A[∗]_ = arg min cost _[A]_ ( _n_ ) _._ Then _A∈L_ 

cntXOR( _n_ ) = cnt _[A]_ XOR _[∗]_[(] _[n]_[)] _[,]_ cnt _mul_ ( _n_ ) = cnt _[A] mul[∗]_[(] _[n]_[)] _[,]_ cost( _n_ ) = cost _[A][∗]_ ( _n_ ) _._ 

J. Jang et al. 

21 

**Table 5:** The number of internal multiplications and XORs in the Karatsuba and ToomCook algorithms. 

|Input<br>Algorithm<br>(words)|# of internal multiplications<br>(_k −_1)-word<br>_k_-word<br>(_k_+ 1)-word<br>(_k_+ 2)-word<br>XOR|
|---|---|
|2-Karat<br>2_k_<br>2_k_+ 1<br>3-Karat<br>3_k_<br>3_k_+ 1<br>3_k_+ 2<br>5-Karat<br>5_k_<br>TC3<br>3_k_<br>3_k_+ 1<br>3_k_+ 2|0<br>3<br>0<br>0<br>7_k_<br>0<br>1<br>2<br>0<br>7_k_+ 3<br>0<br>6<br>0<br>0<br>20_k_<br>0<br>3<br>3<br>0<br>20_k_+ 8<br>0<br>1<br>5<br>0<br>20_k_+ 14<br>0<br>15<br>0<br>0<br>80_k_<br>0<br>3<br>0<br>2<br>38_k_+ 18<br>1<br>0<br>2<br>2<br>38_k_+ 22<br>0<br>1<br>2<br>2<br>38_k_+ 32|



In this way, the most efficient algorithm in each length can be determined, and the optimal combination of algorithms for multiplication in the desired lengths can be found. In an ideal case where only XORs and base multiplications occur, _w_ mul can be set as the ratio of clock cycles required for the two operations. However, in a real implementation additional, `MOV` , `LDR` and `STR` instructions are required to load operands and store results before and after each operation. Since the number of these operations depends on the number of XORs and base multiplications, _w_ mul must be set to account for this. Consequently, we enumerate all optimal algorithmic combinations for each of _w_ mul and experimentally measure their performance to determine the optimal combinations. 

Table 5 lists the number of XOR instructions and internal multiplications performed for each Karatsuba and Toom-Cook algorithm. From this table, cntXOR( _n_ ) and cnt _mul_ ( _n_ ) can be derived. 

## **5.2 The best combinations for HQC** 

This section describes the optimal combination of algorithms for polynomial multiplication of HQC-1, -3, and -5 obtained through the methods described in 5.1. For 1 _≤ wmul ≤_ 500, we explored the optimal combinations for 50,000 cases by increasing _wmul_ in 0.01 increments. This resulted in 4, 6, and 5 combinations for HQC-1, -3, and -5, respectively, depending on the range of _wmul_ . 

Table 6 shows the performance on Cortex-M4 for each optimal combination selected by the cost model over ranges of _w_ mul. Minimum clock cycles occurred at 1 _≤ w_ mul _≤_ 29 _._ 00 (HQC-1), 2 _._ 49 _≤ w_ mul _≤_ 500 (HQC-3), and 1 _._ 60 _≤ w_ mul _≤_ 5 _._ 06 (HQC-5). The environment of benchmarking is described in 6. 

## **5.3 Comparison with** **`gf2x` library** 

In this section, we compare our method with the `gf2x` library. The `gf2x` library is the state-of-the-art approach for selecting optimal F2[ _x_ ] multiplication methods at arbitrary polynomial degrees. It generates optimized routines for diverse environments and provides a multiplication API. It chooses among candidate algorithms by experimentally measuring and comparing their clock cycles. However, this procedure includes additional operations such as conditional branches and table lookups, which prevent a fair comparison. 

For a fair comparison, both approaches must consider the same set of algorithms. In a radix-16 representation, performing shifts within a 32-bit word requires more complex operations [CGKT22]. Among the algorithms considered by `gf2x` library that avoid such shifts, the options are Toom-Cook 3-way (TC3), Toom-Cook 4-way (TC4), and 2-Karatsuba. 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

22 

**Table 6:** Performance (clock cycles) of optimal Karatsuba/Toom-Cook combinations across _w_ mul for HQC parameter sets on Cortex-M4. 

|Parameter|set|Case||Weight|Clock cycle|
|---|---|---|---|---|---|
|HQC-1||1|1|_≤w_mul _≤_29_._00|2,145,505|
|||2|29_._01|_≤w_mul _≤_34_._00|2,178,419|
|||3|34_._01|_≤w_mul _≤_50_._61|2,201,402|
|||4|50_._62|_≤w_mul _≤_500|2,226,850|
|HQC-3||1|1|_≤w_mul _≤_1_._51|6,320,177|
|||2|1_._52|_≤w_mul _≤_1_._74|6,306,667|
|||3|1_._75|_≤w_mul _≤_1_._85|6,183,733|
|||4|1_._86|_≤w_mul _≤_2_._16|6,164,280|
|||5|2_._17|_≤w_mul _≤_2_._48|6,131,652|
|||6|2_._49|_≤w_mul _≤_500|6,078,474|
|HQC-5||1|1|_≤w_mul _≤_1_._59|12,464,389|
|||2|1_._60|_≤w_mul _≤_5_._06|12,456,160|
|||3|5_._07|_≤w_mul _≤_13_._66|12,466,520|
|||4|13_._67|_≤w_mul _≤_14_._00|12,513,222|
|||5|14_._01|_≤w_mul _≤_500|12,460,612|



Although TC4 has the best asymptotic complexity, its practical performance is poor, and it does not arise for polynomial degrees up to those of HQC [CGKT22]. Therefore, in both `gf2x` library and our approach, we consider only TC3 and 2-Karatsuba, and we compare clock cycles at the polynomial degrees corresponding to the three HQC parameter sets. Since our objective is to compare the generated algorithmic combinations themselves, we did not rely on the API provided by `gf2x` library. Instead, we implemented the candidate algorithms under identical conditions and compared them directly. As a result, for the polynomial degrees of HQC-1 and HQC-3, both approaches produced the same algorithmic combinations, whereas for HQC-5 they differed. For HQC-5, the combination produced by our method required 21 _._ 7% fewer clock cycles than the combination produced by `gf2x` library. Detailed cycle counts are provided in Table 7. 

**Table 7:** Clock cycle comparison on Cortex-M4 for `gf2x` library [BGTZ23] and our method, both restricted to Toom-Cook 3-way and 2-Karatsuba. 

|Algorithm|`gf2x` library|Our method|
|---|---|---|
|HQC-1|2,636,770|2,636,770|
|HQC-3|7,576,158|7,576,158|
|HQC-5|21,985,410|17,204,103|



## **6 Experimental results and comparisons** 

In this section, we evaluate the efficiency of the optimization methods proposed in Section 3 and Section 5 by implementing and benchmarking them on a NUCLEO-L4R5ZI evaluation board equipped with an STM32L4R5ZI microcontroller. The platform is based on an ARM Cortex-M4 core and features 2 MB of flash memory and 640 KB of SRAM. As specified by the `pqm4` framework [KPR[+] ], we set the system clock to 20 MHz to achieve zero wait states, and we compile all code with `arm-none-eabi-gcc` version 11.3.1. 

J. Jang et al. 

23 

## **6.1 FAFFT butterfly** 

Table 8 compares the performance of the optimized FAFFT butterfly described in Section 3.3 against the implementation in [LJKH25]. Our optimized butterfly reduces the cycle count by 3.2% to 3.5% across all lengths used in HQC. 

**Table 8:** Clock cycle comparison of the FAFFT butterfly. 

|**:** Clock c|ycle compari|son of the FAFFT b|
|---|---|---|
|2_l_|[LJKH25]|Our code|
|32768|314,494|303,740 (-3.4%)|
|65536|709,110|683,954 (-3.5%)|
|131072|1,589,934|1,539,345 (-3.2%)|



## **6.2 Polynomial multiplication** 

Table 9 presents the benchmark results for various polynomial multiplication methods. In this comparison, the FAFFT column of our code refers to the implementation from [LJKH25] with our butterfly optimization applied. 

For HQC-1 and HQC-3, the Hybrid FAFFT-CRT method achieves the highest efficiency. Specifically, for HQC-1, the FAFFT-CRT method reduces the cycle count by 33.4% compared to the baseline. For HQC-3, it results in a 27.2% reduction. While the Hybrid FAFFT-Karatsuba and Radix-16 methods also outperform the baseline for these parameters, they are less efficient than the FAFFT-CRT approach. 

For HQC-5, where hybrid splitting methods are not applied, our FAFFT code with our optimized butterfly algorithm reduces the cycle count by 3.0% compared to the baseline. The Radix-16 method is significantly less efficient for this degree due to the increased complexity of Karatsuba and Toom-Cook combinations required for the larger degree. 

**Table 9:** Clock cycle comparison of HQC polynomial multiplication. 

|Param.|_n_|[LJKH25]|FAFFT|Our <br>FAFFT-CRT|code<br>FAFFT-Karat|Radix-16|
|---|---|---|---|---|---|---|
|HQC-1|17,669|2,841,783|2,756,150|1,891,458|2,521,564|2,147,797|
|HQC-3|35,851|6,279,452|6,092,539|4,572,399|5,697,162|6,083,163|
|HQC-5|57,637|6,290,041|6,103,141|-|-|12,460,424|



## **6.3 Application to HQC** 

In this section, we evaluate the performance of the three HQC parameter sets across five distinct implementations: (i) the baseline FAFFT from [LJKH25], (ii) the FAFFT with our optimized butterfly algorithm, (iii) the hybrid FAFFT-CRT method, (iv) the hybrid FAFFT-Karatsuba method, and (v) the radix-16 implementation. Notably, both hybrid FAFFT approaches also integrate the optimized butterfly algorithm. The benchmark results are summarized in Table 10, where Keygen, Encap, and Decap denote key generation, encapsulation, and decapsulation, respectively. 

For HQC-1, our FAFFT-CRT method improves the performance of key generation, encapsulation, and decapsulation by 20.5%, 19.9%, and 18.4%, respectively, compared to the baseline. In the case of HQC-3, the same method provides improvements of 16.7%, 16.5%, and 15.8%. For HQC-5, where hybrid methods are not applied, our optimized FAFFT achieves a consistent improvement of approximately 1.3%. Conversely, the Radix16 method at this security level is slower by 48-51%, which is consistent with the asymptotic advantage of FFT-based multiplication for larger polynomial degrees. 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

24 

**Table 10:** Clock cycles for HQC key generation, encapsulation, and decapsulation on Cortex-M4. 

|**Table 10:** Clock c<br>Cortex-M4.|**Table 10:** Clock c<br>Cortex-M4.|ycles for HQ|C key generat|ion, encapsula|tion, and decaps|ulation on|
|---|---|---|---|---|---|---|
|Algorithm||[LJKH25]|FAFFT|Our <br>FAFFT-CRT|code<br>FAFFT-Karat|Radix-16|
|HQC-1|Keygen|4,015,835|3,930,193|3,065,459|3,692,595|3,322,032|
||Encap|7,843,285|7,671,995|5,942,521|7,196,807|6,455,688|
||Decap|13,026,321|12,769,358|10,175,173|12,056,601|10,944,987|
|HQC-3|Keygen|9,497,097|9,310,200|7,790,316|8,914,845|9,300,408|
||Encap|18,341,826|17,968,035|14,928,198|17,177,322|17,948,454|
||Decap|28,863,458|28,302,758|23,743,111|27,116,701|28,273,407|
|HQC-5|Keygen|12,700,457|12,513,535|–|–|18,874,866|
||Encap|24,109,313|23,735,473|–|–|36,458,054|
||Decap|38,752,685|38,191,910|–|–|57,275,806|



## **7 Conclusion** 

In this paper, we present several optimization techniques for HQC polynomial multiplication on the ARM Cortex-M4, including hybrid FAFFT-Karatsuba, hybrid FAFFT-CRT, and radix-16 methods. 

The hybrid FAFFT-Karatsuba and FAFFT-CRT methods are particularly efficient for polynomial degrees of the form _n_ = 2 _[d]_ + _r_ with a small _r_ . These methods enable the multiplication to be performed using an FAFFT of size 2 _[d]_[+1] , whereas the previous approach requires a size 2 _[d]_[+2] transform. Furthermore, we improved the FAFFT butterfly through efficient register scheduling, shortened XOR sequences for fixed-coefficient multiplications, and the replacement of bit swaps with the `SWAPMOVE` instruction. 

Radix-16 multiplication is an efficient technique for environments like the Cortex-M4 that do not support dedicated carry-less multiplication instructions but provide MultiplyAccumulate (MAC) instructions. It accelerates the computation by performing carry-less multiplication through integer multiplication. We apply radix-16 multiplication to HQC for the first time, to the best of our knowledge. We further refined this approach by identifying more efficient Karatsuba and Toom-Cook combinations through an operation-count cost model. 

Experimental results on the NUCLEO-L4R5ZI board show that our methods improve the state-of-the-art implementation of HQC for cortex-M4. The hybrid FAFFT-CRT method achieved the highest efficiency for HQC-1 and HQC-3. For HQC-1, it reduces the cycle counts for key generation, encapsulation, decapsulation by 23.7%, 24.2%, 21.9%, respectively, and for HQC-3, it reduces them by 18.0%, 18.6%, and 17.7%, respectively. For HQC-5, where hybrid methods are not suitable for the given degree, our optimized butterfly still provided a performance gain of 1.4 - 1.6%. As HQC is selected for NIST standardization, our optimizations enable its practical deployment on resource-constrained embedded platforms. 

## **References** 

- [AAB[+] 22] Carlos Aguilar-Melchor, Nicolas Aragon, Slim Bettaieb, Loïc Bidoux, Olivier Blazy, Jean-Christophe Deneuville, Philippe Gaborit, Edoardo Persichetti, Gilles Zémor, Jurjen Bos, Arnaud Dion, Jerome Lacan, Jean-Marc Robert, and Pascal Veron. HQC. Technical report, National Institute of Standards and Technology, 2022. available at `https://csrc` _._ `nist` _._ `gov/Projects/postquantum-cryptography/round-4-submissions` . 

J. Jang et al. 

25 

- [ABCG20] Erdem Alkim, Yusuf Alper Bilgin, Murat Cenk, and François Gérard. CortexM4 optimizations for {R,M}LWE schemes. _IACR TCHES_ , 2020(3):336–357, 2020. 

- [ACC[+] 22] Amin Abdulrahman, Jiun-Peng Chen, Yu-Jia Chen, Vincent Hwang, Matthias J. Kannwischer, and Bo-Yin Yang. Multi-moduli NTTs for Saber on Cortex-M3 and Cortex-M4. _IACR TCHES_ , 2022(1):127–151, 2022. 

- [AHKS22] Amin Abdulrahman, Vincent Hwang, Matthias J. Kannwischer, and Amber Sprenkels. Faster Kyber and Dilithium on the Cortex-M4. In Giuseppe Ateniese and Daniele Venturi, editors, _ACNS 22International Conference on Applied Cryptography and Network Security_ , volume 13269 of _LNCS_ , pages 853–871. Springer, Cham, June 2022. 

- [BGTZ23] R. P. Brent, P. Gaudry, E. Thomé, and P. Zimmermann. gf2x library. `https: //gitlab` _._ `inria` _._ `fr/gf2x/gf2x` , 2023. Accessed: Feb. 11, 2023. [Online]. 

- [BKS19] Leon Botros, Matthias J. Kannwischer, and Peter Schwabe. Memory-efficient high-speed implementation of Kyber on Cortex-M4. In Johannes Buchmann, Abderrahmane Nitaj, and Tajje eddine Rachidi, editors, _AFRICACRYPT 19_ , volume 11627 of _LNCS_ , pages 209–228. Springer, Cham, July 2019. 

- [Can89] David G Cantor. On arithmetical algorithms over finite fields. _Journal of Combinatorial Theory, Series A_ , 50(2):285–300, 1989. 

- [CC21] Ming-Shing Chen and Tung Chou. Classic McEliece on the ARM Cortex-M4. _IACR TCHES_ , 2021(3):125–148, 2021. 

- [CCK21] Ming-Shing Chen, Tung Chou, and Markus Krausz. Optimizing BIKE for the intel haswell and ARM Cortex-M4. _IACR TCHES_ , 2021(3):97–124, 2021. 

- [CCPY26] Ming-Shing Chen, Chun-Ming Chiu, Chun-Tao Peng, and Bo-Yin Yang. Accelerating HQC with additive FFT. Cryptology ePrint Archive, Paper 2026/014, 2026. 

- [CGKT22] Ming-Shing Chen, Tim Güneysu, Markus Krausz, and Jan Philipp Thoma. Carry-less to BIKE faster. In Giuseppe Ateniese and Daniele Venturi, editors, _ACNS 22International Conference on Applied Cryptography and Network Security_ , volume 13269 of _LNCS_ , pages 833–852. Springer, Cham, June 2022. 

- [CHK[+] 21] Chi-Ming Marvin Chung, Vincent Hwang, Matthias J. Kannwischer, Gregor Seiler, Cheng-Jhih Shih, and Bo-Yin Yang. NTT multiplication for NTTunfriendly rings. _IACR TCHES_ , 2021(2):159–188, 2021. 

- [GKS21] Denisa O. C. Greconici, Matthias J. Kannwischer, and Amber Sprenkels. Compact Dilithium implementations on Cortex-M3 and Cortex-M4. _IACR TCHES_ , 2021(1):1–24, 2021. 

- [GM10] Shuhong Gao and Todd Mateer. Additive fast fourier transforms over finite fields. _IEEE Transactions on Information Theory_ , 56(12):6265–6272, 2010. 

- [HAZ[+] 24] Junhao Huang, Alexandre Adomnicai, Jipeng Zhang, Wangchen Dai, Yao Liu, Ray C. C. Cheung, Çetin Kaya Koç, and Donglong Chen. Revisiting Keccak and Dilithium implementations on ARMv7-M. _IACR TCHES_ , 2024(2):1–24, 2024. 

Efficient Polynomial Multiplication for HQC on ARM Cortex-M4 

26 

- [HZZ[+] 22] Junhao Huang, Jipeng Zhang, Haosong Zhao, Zhe Liu, Ray C. C. Cheung, Çetin Kaya Koç, and Donglong Chen. Improved plantard arithmetic for latticebased cryptography. _IACR TCHES_ , 2022(4):614–636, 2022. 

- [JLK[+] 24] Jihoon Jang, Myeonghoon Lee, Suhri Kim, Seogchung Seo, and Seokhie Hong. Optimized implementation of GF(2)[x] multiplication for HQC on AVX2. _Journal of the Korea Institute of Information Security & Cryptology_ , 34(5):841–853, 2024. 

- [KPR[+] ] Matthias J. Kannwischer, Richard Petri, Joost Rijneveld, Peter Schwabe, and Ko Stoffelen. PQM4: Post-quantum crypto library for the ARM Cortex-M4. `https://github` _._ `com/mupq/pqm4` . 

- [LANH16] Sian-Jheng Lin, Tareq Y Al-Naffouri, and Yunghsiang S Han. FFT algorithm for binary extension finite fields and its application to reed–solomon codes. _IEEE Transactions on Information Theory_ , 62(10):5343–5358, 2016. 

- [LCH14] Sian-Jheng Lin, Wei-Ho Chung, and Yunghsiang S. Han. Novel polynomial basis and its application to reed-solomon erasure codes. In _55th FOCS_ , pages 316–325. IEEE Computer Society Press, October 2014. 

- [LCK[+] 18] Wen-Ding Li, Ming-Shing Chen, Po-Chun Kuo, Chen-Mou Cheng, and Bo-Yin Yang. Frobenius additive fast fourier transform. In _Proceedings of the 2018 ACM International Symposium on Symbolic and Algebraic Computation_ , pages 263–270, 2018. 

- [LJKH25] Myeonghoon Lee, Jihoon Jang, Suhri Kim, and Seokhie Hong. Improved frobenius fft for code-based cryptography on cortex-m4. _IEEE Internet of Things Journal_ , 12(17):36318–36327, 2025. 

- [MPC00] Lauren May, Lyta Penna, and Andrew J. Clark. An implementation of bitsliced DES on the Pentium MMX[TM] processor. In Ed Dawson, Andrew Clark, and Colin Boyd, editors, _ACISP 00_ , volume 1841 of _LNCS_ , pages 112–122. Springer, Berlin, Heidelberg, July 2000. 

- [VzGG96] Joachim Von zur Gathen and Jürgen Gerhard. Arithmetic and factorization of polynomial over F2. In _Proceedings of the 1996 international symposium on Symbolic and algebraic computation_ , pages 1–9, 1996. 

- [XZL[+] 20] Zejun Xiang, Xiangyong Zeng, Da Lin, Zhenzhen Bao, and Shasha Zhang. Optimizing implementations of linear layers. _IACR Trans. Symm. Cryptol._ , 2020(2):120–145, 2020. 

