---
source_pdf: docs/references/pdf/other-platforms/Efficient Hardware Implementation of Constant Time Sampling for HQC.pdf
converted_at: 2026-05-29 22:40
conversion_time: 2.9s
tool: pymupdf4llm
---

# Efficient Hardware Implementation of Constant Time Sampling for HQC 

## Maximilian Sch¨offel 

_Microelectronic Design Research Group University of Kaiserslautern-Landau_ Kaiserslautern, Germany m.schoeffel@rptu.de 

Johannes Feldmann Norbert Wehn _Microelectronic Design Research Group Microelectronic Design Research Group University of Kaiserslautern-Landau University of Kaiserslautern-Landau_ Kaiserslautern, Germany Kaiserslautern, Germany j.feldmann@rptu.de norbert.wehn@rptu.de 

_**Abstract**_ **—HQC is one of the code-based finalists in the last round of the NIST post quantum cryptography standardization process. In this process, security and implementation efficiency are key metrics for the selection of the candidates. A critical compute kernel with respect to efficient hardware implementations and security in HQC is the sampling method used to derive random numbers. Due to its security criticality, recently an updated sampling algorithm was presented to increase its robustness against side-channel attacks.** 

**In this paper, we pursue a cross layer approach to optimize this new sampling algorithm to enable an efficient hardware implementation without comprising the original algorithmic security and side-channel attack robustness.** 

**We compare our cross layer based implementation to a direct hardware implementation of the original algorithm and to optimized implementations of the previous sampler version. All implementations are evaluated using the Xilinx Artix 7 FPGA. Our results show that our approach reduces the latency by a factor of 24 compared to the original algorithm and by a factor of 28 compared to the previously used sampler with significantly less resources.** 

_**Index Terms**_ **—HQC, PQC, code-based cryptography, KEM, sampling** 

## I. INTRODUCTION 

Quantum computers are expected to revolutionize sectors such as medicine, materials science, and artificial intelligence once they reach maturity with adequate computing power. However, they also pose serious threats on communication security, and it is expected that it is possible to break State of the Art (SoA) public key cryptography by the end of this decade [1]. Therefore, the United States National Institute for Standards and Technology (US NIST) is currently conducting a process to find new, quantum computer resistant cryptographic algorithms (Post-Quantum Cryptography or PQC) [2]. 

Hamming Quasi Cyclic (HQC) [3] is one of the code-based candidates for standardization that has advanced to the final round of the NIST PQC process. Compared to the already standardized lattice-based algorithm KYBER, implementations of code-based algorithms have both a larger computational complexity and larger memory footprint. However, viable alternatives to lattice-based algorithms are already required today in case that the relatively new lattice-based algorithms turn out to be insecure in future (Crypto Agility). As a 

result, the application requirements in environments such as the Industrial Internet of Things (IIoT), which are limited by computing power and available energy but have strict timing constraints, can often only be met by using dedicated hardware accelerators. 

For such applications, several papers on hardware implementations have already been published. The authors of HQC proposed a High-Level Synthesis (HLS)-based design that outperforms the remaining code-based candidates in the final round of the NIST process [4]. A HW/SW co-design of HQC that targets IoT applications was proposed in [5], and the authors found that the memory and the sampling unit are the main contributors to the area requirement. Furthermore, they showed that sampling and polynomial multiplication are the main drivers of the HQC latency. One of these bottlenecks, the polynomial multiplication, was addressed by the LEAP multiplier in [6]. 

Secure and efficient sampling algorithms to derive random numbers are still a subject of research, and a detailed study of different algorithms and protection measures with respect to power side channels was conducted in [7]. While their focus was on algorithms rather than hardware implementations which ensure robustness against power SCAs, the authors also provided a hardware implementation, which, however, requires significant computation time and was designed primarily for BIKE, the other code-based candidate in the NIST process. 

Recently, the authors of HQC introduced an updated, more secure sampling procedure based on Sendrier’s modified Fisher-Yates approach [8] as a response to successful timing SCAs on the HQC sampling procedure [9]. 

In conclusion, the focus of research so far has been mainly on polynomial ring multiplication. But for the other critical factor – the new sampling algorithm – an efficient solution has yet to be explored. Existing implementations are either prone to timing SCAs or have high computation time. 

In this paper, we present to the best of our knowledge the first cross-layer approach for this new sampler. We investigate how the interrelationships between the algorithmic layer, which provides the base for a timing SCA-resistant implementation, and the hardware implementation layer can be exploited to maximize implementation efficiency without comprising security. Our new contributions are: 

We acknowledge that the key idea of this paper (performing the uniqueness check of the polynomials in explicit rather than support representation) was published in _Fast and Efficient Hardware Implementation of HQC_ , Appendix 1.B, by Deshpande et al. during the review process of this paper. Therefore, we do not further pursue a conference publication. 

- 1) A reduction of the computational complexity from _O_ ( _n_[2] ) to _O_ ( _n_ ) through a new approach to represent the polynomials during the sampling procedure. 

- 2) A hardware implementation with a pipelining scheme that is robust against timing side channel attacks. The resource efficiency (latency / number of required FPGA resources) is increased by jointly considering the implementation of the sampling procedure and polynomial ring arithmetic. 

- 3) A detailed comparison of implementation results of a standard implementation, our cross layer approach and optimized implementations of the previous sampler on a Xilinx Artix 7 FPGA. 

Our new algorithm requires an update of the original HQC specification, as the random numbers derived from the same seed are not equal to the original algorithm. However, since standardization is still in progress, we encourage to adopt these changes as they do not add complexity to software implementations nor reduce security. 

This paper is structured as follows. In Section II, a background of HQC and the sampling algorithm will be provided. In Section III, the algorithmic improvements will be explained. In Section IV, the hardware design will be presented. In Section V, the results of the hardware implementation will be provided, evaluated and compared with the SoA. In Section VI, we draw a conclusion. 

## II. BACKGROUND 

HQC [3] is a Key-Encapsulation Mechanism (KEM) and its security is based on the hardness of the syndrome decoding problem. Its design rational bases on concatenated ReedMuller/Reed-Solomon code _C_ and erroneous codewords are generated by adding and multiplying random values on the secret message to hide the same. These arithmetic operations are performed on sparse (low hamming weight) and dense (high hamming weight) polynomials _v_ in the ring _R_ = F2[ _X_ ] _/_ ( _X[n] −_ 1), and _v_ can be represented in two different ways: 

- 1) **Explicit representation:** A bit array _v_ of length _n_ = 17669 where each bit entry _vi_ represents the coefficient _vi_ in _v_ =[�] _[n] i_ =0 _[−]_[1] _[v][i][·][ x][i]_[.][The][explicit][representation][is] used for dense polynomials. 

- 2) **Support representation:** An array _c_ of length _ω ≤_ 75, where each integer entry _ci_ represents the coordinate of a non-zero coefficient in the corresponding _v_ : _v_ = � _iω_ =0 _−_ 1 _[x][c][i]_[. The support representation is used for sparse] polynomials. 

HQC is available in three different parameter sets, in this work we refer to HQC-128. Besides the arithmetic in _R_ , the major contributor to the computational complexity of HQC is the sampling procedure [5], where random error polynomials are generated through the expansion of a secretly, truly random generated seed using the Extendable Output Function (XOF) SHAKE [10]. For HQC to operate securely and correctly, the sampled error polynomials must fulfill two criteria. First, as 

the sampling procedure directly involves the computation of security critical values, a constant execution time (independent from the sampled values) is a crucial countermeasure against SCAs. In addition, the sampled errors must meet strict requirements regarding their Hamming weight _ω_ , since a too low Hamming weight would allow attacks on the KEM, and a too large Hamming weight would mean that the original message could not be decrypted by the communication partners as it would exceed the error correction capability of _C_ . Therefore, Algorithm 1 has been proposed by the HQC authors based on the previous works of Sendrier [8] to meet both requirements. 

The algorithm operates with the error polynomials in their support form and, if required, converts them to explicit representation once the sampling is completed (Line 12). An array with _ω_ random words is generated through the expansion of _seed_ with SHAKE in Line 1. This _randomwords_ array is further processed in the _mod loop_ , which implements the ”sampling with bias” as introduced by Sendrier [8]. In _unique check loop_ , each of the sampled values in _support_ are compared with all previously sampled values. If there is a duplicated value, the _found_ flag is set and _support_ [ _i_ ] receives the loop iterator _i_ as a value instead. Because of the biased sample in Line 3 and the fact that _unique check loop_ iterates backwards, the condition _support_ [ _i_ ] _≥ i_ is always satisfied. These measures guarantee that the hamming weight of the resulting polynomial is exactly _ω_ . 

**Algorithm 1:** Constant weight sampling algorithm based on [8] with modifications by the authors of HQC. Note that _word_ refers to 32-bit values. The ” _←−_ $ ” operator refers to sampling bytes from a random distribution. 

**Data:** _n_ = 17669 _, seed, ω_ 

**Result:** _v ∈R_ = F2[ _X_ ] _/_ ( _X[n] −_ 1) with hamming weight _ω_ $ **1** _randomwords ←− prng_ ( _seed, ω_ ); **2** mod loop: **for** 0 _≤ i ≤ ω −_ 1 **do** 

**3** _support_ [ _i_ ] _← i_ + ( _randomwords_ [ _i_ ] mod ( _n − i_ )); **4 end** 

**==> picture [225 x 72] intentionally omitted <==**

**11 end 12** _v ← transform_ ( _support_ ); 

- **13 return** v 

In general, sampling and ring arithmetic in HQC are used in the following sequences: 

**==> picture [144 x 14] intentionally omitted <==**

**==> picture [155 x 14] intentionally omitted <==**

_z ← h · y_ + _x,_ (3) 

where _h_ is a dense polynomial which is directly sampled through seed expansion by using SHAKE, and _x_ and _y_ are sparse (error) polynomials with hamming weight _ω_ sampled with Algorithm 1. 

## III. ALGORITHMIC OPTIMIZATIONS 

In the following, we explain the algorithmic optimizations in our cross layer approach and evaluate each one in terms of its security impact, compatibility with the original algorithm, effect on hardware implementations, and drawbacks. 

## _A. Reducing computational complexity: Uniqueness Check_ 

**Description:** The uniqueness check during the sampling procedure ensures that each of the sampled values occurs only once, thus guaranteeing the Hamming weight of the result. In the support representation in Algorithm 1, each element of the array holds the coordinate of a ”1” coefficient in the polynomial. To ensure that the same coordinate only occurs once in the array, a comparison with all previously sampled coordinates in the array is required, as all of them could hold the same coordinate. This causes the computational complexity of the algorithm to be _O_ ( _ω_[2] ). 

**Improvement:** We propose to store the sampled values in explicit representation instead. There, a single comparison with the currently stored coefficient bit _vi_ at the sampled coordinate _ci_ is necessary to determine the uniqueness of this value, thus significantly reducing the complexity from _O_ ( _ω_[2] ) to _O_ ( _ω_ ). 

**Security:** On our target platform (FPGA), the polynomials are stored in Block Random Access Memory (BRAM) or Look Up Tables (LUTs) without any intermediate cache, thus guaranteeing a memory address independent access latency. On other platforms, this measure can induce side channel attack possibilities depending on the hardware architecture. For architectures with address dependent memory access latency secret information (in this case the location of the word inside the corresponding array) can be leaked. This is for example the case for software implementations on cache-based computer architectures. 

**Hardware:** The major drawback of this method is that it increases the memory requirement for the polynomial by a factor of 15.7 (17669 bits instead of 1125 bits), thus memory has to be traded-off against runtime. Furthermore, for the subsequent polynomial multiplication in _R_ to be efficient, one of the polynomials ( _y_ , see Equation 3) needs to be available in support representation. 

**Compatibility:** This optimization is bit-true, thus it maintains seed compatibility. 

## _B. Increasing Throughput: Enabling Efficient Pipelining_ 

**Description:** The algorithm can be further improved to enable an efficient pipelining scheme that increases the hardware throughput, i.e. number of coordinates sampled per time. In Algorithm 1, the mod_loop requires the first element, _randomwords_ [0], to calculate _support_ [0], whereas the 

unique_check_loop requires _support_ [ _ω −_ 1] in its first iteration, thus introducing a data dependency between both loops which prohibits efficient pipelining. 

**Improvement:** We suggest an implicit inversion of the _randomwords_ array, where the first word returned by _prng_ is used as _randomwords_ [ _ω −_ 1] instead of _randomwords_ [0]. Using this approach, the mod_loop and unique_check_loop loops can be combined into a single loop, allowing efficient pipelining. Since SHAKE (the prng algorithm) returns random values sequentially, it is possible to operate directly on the returned word in the pipelined loop instead of waiting for the random array to be returned as a whole, as described in our improved Algorithm 2. 

**Security:** Given that SHAKE is a cryptographically secure XOF [10], it holds that _prng_ returns uniformly randomly distributed words. Hence, from a security perspective, the quality of the content in _randomwords_ [ _i_ ] and _randomwords_ [ _i_ + 1] is equivalent _∀i_ in the given context. 

**Hardware:** Pipelining and concurrent execution can significantly reduce the time it takes to sample a polynomial. In addition, including random words and support computation in the same pipeline loop eliminates the BRAM required to store these arrays as a whole. 

**Compatibility:** Seed compatibility is not given since the same seed yield to different sampled polynomials compared to the reference implementation supplied by the authors of HQC. Therefore, it requires an update of the original algorithmic specification, e.g. by replacing _randomwords_ [ _i_ ] in Line 3 in Algorithm 1 with _randomwords_ [ _ω −_ 1 _− i_ ]. 

**Algorithm 2:** Our proposal for the sampling algorithm 

|**1 **<br>**2**<br>**3**<br>**4**<br>**5**|**Data:** _n_= 17669_, seed, ω_<br>**Result:** _v ∈R_=F2[_X_]_/_(_Xn −_1) with hamming<br>weight _ω_<br> **for** (_ω −_1)_≥i ≥_0 **do**<br>_randomwords_[_i_]<br>$_←−prng_(_seed,_1);<br>_support_[_i_]_←i_+ (_randomwords_[_i_] mod (_n −i_));<br>**if** _v_[_support_[_i_]] = 1 **then**<br>_v_[_i_] = 1;|
|---|---|
|**6**|**end**|
|**7**<br>**8**|**else**<br>_v_[_support_[_i_]] = 1;|
|**9**|**end**|
|**10 **|**end**|
|**11 **|**return** v|



_C. Decreasing memory footprint: Joint consideration of the sampling and arithmetic in R_ = F2[ _X_ ] _/_ ( _X[n] −_ 1) 

**Description:** In SoA implementations, sampling and the arithmetic in _R_ are treated as separated functions without considering synergies between both to increase their efficiency (number of hardware resources and latency). Memories are used in the following way for these two functions (e.g. [4] [5]): 

- 1) _h_ is sampled and stored in the Random Access Memory (RAM) ( _RAM_ 0) in explicit representation. 

- 2) _x_ is sampled and stored in _RAM_ 1 in explicit representation. 

- 3) _y_ is sampled and stored in _RAM_ 2 in support representation. 

- 4) _z[′]_ , the product of h and y, is computed and stored in _RAM_ 3. The product of _h_ and _y_ requires twice the storage of the explicit representation. 

- 5) _z_ is calculated by the modular reduction of _z[′]_ and adding _x_ . 

Thus, four RAMs are required to execute this procedure. Notably, memory has been shown to be the major contributor to the area requirement of the HQC implementation [5]. 

- **Improvement:** We propose the following procedure instead: 

- 1) _x_ is sampled and stored in _RAM_ 0 in explicit representation. 

- 2) _y_ is sampled and stored in _RAM_ 1 in explicit representation during the uniqueness check, and concurrently stored in _RAM_ 2 in support representation. The support representation of _y_ is later required for the dense-sparse polynomial multiplication. 

- 3) _h_ is sampled and stored in _RAM_ 1, thus overwriting the no longer required explicit representation of _y_ . 

- 4) _z_ is computed and stored in _RAM_ 0. Each intermediate result of _z_ is reduced modulo _X[n] −_ 1, thereby only requiring storage for single explicit representation. 

**Hardware:** This procedure has four advantages: 

- 1) It eliminates the need for an additional RAM when sampling the sparse polynomial _y_ in explicit representation (see Section III-A), since _RAM_ 1 can be reused for _h_ after sampling _y_ . 

- 2) _x_ can directly be stored inside the result RAM for _z_ , thus removing its requirement for an additional RAM. 

- 3) The required memory size for _z_ is halved. 

- 4) The schoolbook approach in [4] and [5] multiplies _h · y_ wordwise, i.e. each memory word in _h_ is multiplied by each coordinate in _y_ based on a windowing method. The intermediate results are stored in _RAM_ 0 and repeatedly added to the subsequent intermediate results (which corresponds to an XOR operation since the elements of the polynomial are in F2). This procedure can be used to implicitly add x during the multiplication steps by preloading _x_ instead of zeros into _RAM_ 0, thus eliminating the need for an additional computation step. This requires to use the schoolbook approach instead of the optimized LEAP multiplier [6]. 

**Security:** This improvement does not affect the security in the hardware implementation. 

## IV. HARDWARE DESIGN 

In our cross-layer approach described in Section III, we improved the algorithmic layer to enable an efficient hardware implementation with respect to 

- 1) **latency** reduction through the optimizations described in Sections III-A and III-B, and 

- 2) **hardware resources** reduction through the optimizations described in Sections III-B and III-C. 

In this chapter, we present the challenges and solutions of our hardware design which incorporates the above optimizations. 

## _A. Sampler_ 

The major challenge of a pipeline schedule for Algorithm 2 is to ensure that no secret information gets leaked through the execution time. Here, the two critical operations are the modulo operation in Line 3 and the uniqueness check procedure and its measures. 

For fixed modulus, the Barrett Reduction [11] is often used in hardware implementations to ensure constant time calculation and resource efficiency. This replaces the division with two multiplications, subtractions and shifts using a precomputed reduction factor _R_ instead, see Algorithm 3. However, the modulus of the sampling algorithm is not fixed, but is in the range [ _n, n − ω_ ], and therefore requires the storage of _ω_ precomputed 18-bit values of _R_ . For the given range with _ω_ = 75, we observed the following dependency, which drastically reduces the required storage from 18 _· ω bits_ to _ω_ + 18 _bits_ at the cost of one addition and subtraction: 

**==> picture [184 x 11] intentionally omitted <==**

where _LUT_ is a precomputed one-bit array of length _ω_ and _R_ 0 = _n−_ 2( _ω_[32] _−_ 1)[.] 

**Algorithm 3:** Barret reduction algorithm used in the hardware implementation based on [11] 

**Data:** _W, M_ , _R ←⌊_[2] _M_[32] _[⌋]_ **Result:** _X_ = _W_ mod _M_ **1** _X ← W − M ·_ (( _W · R_ ) _>>_ 32); **2 if** _X ≥ M_ **then 3** _X ← X − M_ ; **4 end 5 return** X 

For the uniqueness checking procedure, we ensure a constant time implementation as follows. We assume that the polynomial _v_ is stored in _w_ words of length _mw_ in a BRAM that allows simultaneous reads and writes, and that one word holds multiple coordinates. If a new coordinate is to be written, the currently stored data must be read first to prevent overwriting. In a pipelined architecture, this means that in cycle _i_ , reads belonging to the current iteration are performed, and in cycle _i_ +1, the corresponding bit in the word is set and written to memory. This causes two challenges. First, a readafter-write hazard could occur if the same address is written and read in the same cycle (i.e., by two successive sampled values), which leads to reading obsolete data in the second access. We solve this by detecting and storing the last word 

**==> picture [464 x 150] intentionally omitted <==**

Fig. 1. Sketch of the sampling pipeline. 

written in a register, which is used for the next write if a hazard is detected, instead of the word read from memory. Second, in most cases, if a non-unique value is found, it requires a write to a different memory word than the one previously read. However, stalling the pipeline to perform this required read would reveal secret information due to the nonconstant execution time. Therefore, we locally keep record of the memory words belonging to the first _ω_ coordinates and write them to memory at the end of the sampling procedure. The actual writing to memory is performed independently of the uniqueness of the respective values, so as not to leak information about the power. 

The operation principle of the pipelined sampler is presented in Figure 1. All stages are designed such that they are able to operate in parallel. The first stage of the pipeline implements the PRNG word generation. The words are generated by the SHAKE function, which works by permuting and then squeezing the internal state of the Keccak [10]. Our design uses an Intellectual Property (IP) core from the authors of Keccak to perform the state permutation [12], the squeezing is executed on a 64-bit boundary. Three pipeline stages are used to calculate the Barret Reduction, as we use a Karazuba based approach to efficiently map the multiplication to the DSP slices of our FPGA. The last two stages implement the uniqueness check and memory accesses. 

## _B. Arithmetic in R_ 

The polynomial multiplication in _R_ is implemented using a similar approach as in [4] and [5], with modifications to incorporate our proposed improvements such that addition, multiplication and reduction are executed simultaneously. To reduce the hardware complexity, we do not read and add the intermediate results in the arithmetic module as in the cited works, but instead, we implemented a modify access that XORs the data currently stored in memory with the incoming data in our memory module. This approach ensures that our hardware has similar performance (resource utilization, frequency and clock cycles) like the LEAP multiplier [6]. 

TABLE I 

COMPARISON OF LATENCY, FREQUENCY, TIME IN MICROSECONDS AND FPGA RESOURCES OF DIFFERENT IMPLEMENTATIONS FOR THE SAMPLER FUNCTION. * NOTES THAT THE DESIGN WAS IMPLEMENTED ON A DIFFERENT FPGA. 

||**Impl.**|**Latency**<br>[Cycles] / [us]|**Frequency**<br>[MHz]|**FPGA Resources**<br>LUT<br>FF<br>BRAM|**FPGA Resources**<br>LUT<br>FF<br>BRAM|**FPGA Resources**<br>LUT<br>FF<br>BRAM|
|---|---|---|---|---|---|---|
||HW/SW [5]*|3074 / 30.7|100|925|192|0|
||HLS [4]|3726 / 24.35|153|1472|1021|1|
||Original Alg.|2602 / 20.82|125|469|265|0|
||**New Alg.**|**115 / 0.86**|**133**|**453**|**170**|**0**|



## V. RESULTS 

An objective comparison for hardware implementations in the US NIST PQC process is difficult because the US NIST only specified the Xilinx Artix 7 product family as target platform. However, the devices within this family still differ significantly in terms of available resources and speed level, and comparing results from different devices (as done several times in the SoA) is not objective. Therefore, in our comparison, the same device was used as in the original HQC implementation [4], Xilinx Artix xc7a100tftg256-1 FPGA with the Xilinx Vivado 2020.1 software version. 

## _A. Comparison of sampler implementations_ 

In Table I we compare four different implementations to evaluate the efficiency of optimization III-A and III-B. For all implementations, we considered the hamming weight _ω_ = 66 as required during the key generation procedure of HQC128. _HW/SW_ and _HLS_ refer to implementations of the previously used sampling algorithm that is susceptible to timing SCAs as described in [9]. _Original Alg._ and _New Alg._ present the results of our implementations of the original, new sampling procedure and our optimized one. In all implementations, the hardware of the SHAKE module is not included. However, _HW/SW_ used the same IP block for it as the one employed in our design. 

As shown in the table, the implementation of the new algorithm requires less clock cycles than the two preceding 

TABLE II 

COMPARISON OF LATENCY IN CLOCK CYCLES AND TIME IN MICROSECONDS, FREQUENCY AND FPGA RESOURCES OF DIFFERENT IMPLEMENTATIONS FOR THE HQC-128 KEYGEN FUNCTION. 

|**Impl.**|**Latency**<br>**Freq.**<br>[Cycles] / [us]<br>[MHz]|**Resources**<br>LUT<br>FF<br>BRAM|
|---|---|---|
||||
|HLS [4]<br>_⊢_Poly-Mult.<br>HW/SW [5]<br>**This work**<br>_⊢R_-Module|40427 / 269.5<br>150<br>_⊢_21418 / 142.79<br>150<br>56000 / 560<br>100<br>**6492 / 46**<br>**141**<br>_⊢_4885 / 34.65<br>141|11484<br>8798<br>6<br>_⊢_6175<br>_⊢_3701<br>0<br>8000<br>2400<br>3<br>**13834**<br>**6963**<br>**2.5**<br>_⊢_2956<br>_⊢_862<br>0|
||||
|KYBER [13]|3800 / 23.75<br>160|7412<br>4644<br>3|



versions, while increasing the security via constant time implementation. The reason for this is that the old algorithm requires more random numbers to be sampled with SHAKE due to rejections, and that it operates on a non-optimal 24-bit rather than 32-bit boundary for its random values, which complicates the access pattern for typical 32-bit or 64-bit memories as used in [5]. Furthermore, the results in the table show that more than one order of magnitude (24 _×_ ) of latency decrease is achieved through our optimizations III-B and III-A over _Original Alg._ . 

## _B. Key Generation function_ 

A conclusive evaluation of the optimizations presented in this paper requires a view of the entire HQC cryptosystem, not just the sampler. Therefore, we included the joint design with the _R_ arithmetic module in the implementation of the HQC key generation function by [4]. For the integration, the sampler module has been further modified to support the SHAKE-based seed expansion to sample _h_ . The results of this integration are illustrated in Table II. As presented, our _R_ module provides a comparable resource efficiency (latency / number of resources) like the LEAP multiplier [6]. In addition, optimization III-C leads to a notable reduction in the amount of memory required, which has previously been shown to be the largest area contributor in the Application Specific Integrated Circuit (ASIC) implementation of HQC [5]. When all optimizations are combined, the HQC key generation function is substantially faster than SoA implementations. Most importantly, the results show that our optimizations significantly reduce the performance gap between code-based and lattice-based algorithms, as shown by comparing the KYBER512 hardware implementation [13] to our design. 

## VI. CONCLUSION 

In this work, we presented to the best of our knowledge the first in-depth study on the efficient implementation of the new, more secure HQC sampling procedure. We introduced novel methodologies to implement the sampling algorithm that substantially enhances the efficiency of its hardware implementation and reduces the algorithmic complexity from _O_ ( _n_[2] ) to _O_ ( _n_ ). The changes were carefully evaluated not to induce any new side channel attack possibilities or to comprise the security of the implementation. Our results show that these improvements reduce the latency of the sampling 

algorithm by a factor of 24, while the hardware resources required remain comparable to those of the original sampling algorithm, particularly when implemented jointly with the ring arithmetic in HQC. Based on these changes, and the fact that HQC was already shown to be the most efficient codebased cryptosystem in the NIST process, the performance gap between code-based and lattice-based algorithms substantially decreases - from a factor of 10.5 to a factor of 1.7 in terms of execution time - by integrating our proposals into a SoA hardware design of the HQC-128 key generation function. To conclude, HQC is a very competitive alternative to KYBER in case it turns out to be insecure in the future in terms of resource efficiency. 

## REFERENCES 

- [1] M. Mosca, “Cybersecurity in an Era with Quantum Computers: Will We Be Ready?” _IEEE Security & Privacy_ , vol. 16, no. 5, pp. 38–41, 2018. 

- [2] National Institute for Standards and Technology, U.S. Departement of Commerce, “Post-Quantum Cryptography,” 2023, https://csrc.nist.gov/projects/post-quantum-cryptography, 2023, Retrieved 2023-06-07. 

- [3] C. A. Melchor, N. Aragon, S. Bettaieb, L. Bidoux, O. Blazy, J.C. Deneuville, P. Gaborit, E. Persichetti, G. Z´emor, and I. Bourges, “Hamming Quasi-Cyclic (HQC),” 2021. 

- [4] C. Aguilar-Melchor, J.-C. Deneuville, A. Dion, J. Howe, R. Malmain, V. Migliore, M. Nawan, and K. Nawaz, “Towards Automating Cryptographic Hardware Implementations: A Case Study of HQC,” in _CodeBased Cryptography Workshop_ . Springer, 2022, pp. 62–76. 

- [5] M. Sch¨offel, J. Feldmann, and N. Wehn, “Code-based Cryptography in IoT: A HW/SW Co-Design of HQC,” in _2022 IEEE 8th World Forum on Internet of Things (WF-IoT)_ . IEEE, 2022, pp. 1–7. 

- [6] Y. Tu, P. He, C¸ . K. Koc¸, and J. Xie, “LEAP: Lightweight and Efficient Accelerator for Sparse Polynomial Multiplication of HQC,” _IEEE Transactions on Very Large Scale Integration (VLSI) Systems_ , 2023. 

- [7] M. Krausz, G. Land, J. Richter-Brockmann, and T. G¨uneysu, “A Holistic Approach Towards Side-Channel Secure Fixed-Weight Polynomial Sampling,” in _IACR International Conference on Public-Key Cryptography_ . Springer, 2023, pp. 94–124. 

- [8] N. Sendrier, “Secure Sampling of Constant-Weight Words–Application to BIKE,” _Cryptology ePrint Archive_ , 2021. 

- [9] Q. Guo, C. Hlauschek, T. Johansson, N. Lahr, A. Nilsson, and R. L. Schr¨oder, “Don’t reject this: Key-recovery timing attacks due to rejection-sampling in HQC and BIKE,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pp. 223–263, 2022. 

- [10] National Institute of Standards and Technology, “FIPS PUB 202 -SHA-3 Standard: Permutation-Based Hash and Extendable-Output Functions,” https://csrc.nist.gov/Projects/post-quantum-cryptography, Retrieved 2022-02-17. 

- [11] H. Becker, V. Hwang, M. J. Kannwischer, B.-Y. Yang, and S.-Y. Yang, “Neon NTT: Faster Dilithium, Kyber, and Saber on Cortex-A72 and Apple M1,” _Cryptology ePrint Archive_ , 2021. 

- [12] Bertoni, G. and Daemen, J. and Peeters, M. and Van Assche, G., “Keccak in VHDL,” https://keccak.team/hardware.html, 2022, Retrieved 2023-0607. 

- [13] Y. Xing and S. Li, “A compact hardware implementation of CCAsecure key exchange mechanism CRYSTALS-KYBER on FPGA,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pp. 328–356, 2021. 

