---
source_pdf: docs/references/pdf/riscv/Code-based_Cryptography_in_IoT_A_HW_SW_Co-Design_of_HQC.pdf
converted_at: 2026-05-29 22:41
conversion_time: 3.4s
tool: pymupdf4llm
---

## Code-based Cryptography in IoT: A HW/SW Co-Design of HQC 

## Maximilian Sch¨offel 

_Microelectronic Design Research Group University of Kaiserslautern_ Kaiserslautern, Germany schoeffel@eit.uni-kl.de 

## Johannes Feldmann 

Norbert Wehn 

_Microelectronic Design Research Group Microelectronic Design Research Group University of Kaiserslautern University of Kaiserslautern_ Kaiserslautern, Germany Kaiserslautern, Germany feldmann@eit.uni-kl.de wehn@eit.uni-kl.de 

_**Abstract**_ **—Recent advances in quantum computing pose a serious threat on the security of widely used public-key cryptosystems. Thus, new post-quantum cryptographic algorithms have been proposed as part of the associated US NIST process to enable secure, encrypted communication in the age of quantum computing. Many hardware accelerators for structured latticebased algorithms have already been published to meet the strict power, area and latency requirements of low-power IoT edge devices. However, the security of these algorithms is still uncertain. Currently, many new attacks against the lattice structure are investigated to judge on their security. In contrast, code-based algorithms, which rely on deeply explored security metrics and are appealing candidates in the NIST process, have not yet been investigated to the same depth in the context of IoT due to the computational complexity and memory footprint of state-of-theart software implementations.** 

**In this paper, we present to the best of our knowledge the first HW/SW co-design based implementation of the codebased Hamming Quasi Cyclic Key-Encapsulation Mechanism. We profile and evaluate this algorithm in order to explore the trade-off between software optimizations, tightly coupled hardware acceleration by instruction set extension and modular, loosely coupled accelerators. We provide detailed results on the energy consumption and performance of our design and compare it to existing implementations of lattice- and code-based algorithms. The design was implemented in two technologies: FPGA and ASIC. Our results show that code-based algorithms are valid alternatives in low-power IoT from an implementation perspective.** 

_**Index Terms**_ **—Post Quantum Cryptography; Key Encapsulation Mechanism; IoT; Security; RISC-V; ASIC; Hardware Implementation; HW/SW co-design; HQC** 

## I. INTRODUCTION 

Privacy and data integrity are a key requirement in the Internet of Things (IoT). In many applications such as industrial IoT (IIoT), medical and healthcare, online banking, and even smart homes, highly sensitive data that should not be altered or made available to the public is transmitted over the Internet. In the vast majority of cases, the required security is provided by a combination of symmetric cryptography and Public Key Cryptography (PKC). However, recent advances in quantum computing severely compromise the security of the State-ofthe-Art (SoA) PKC. While they are intractable on conventional computers, the underlying mathematical problems can be solved in polynomial time using Shor’s Algorithms [1] once large scale quantum computers become available. This is 

expected to be the case by the end of this decade [2] and thus, the US NIST is currently conducting a standardization process to find new post-quantum cryptographic (PQC) algorithms. 

The Key Encapsulation Mechanisms (KEMs) in the current, third round of the US NIST PQC standardization process rely on assumptions about the computational hardness of lattice-, code-, or isogeny-based problems. Among these, the structured lattice-based algorithms are considered as most promising candidates for future standardization and for IoT applications due to their low-complexity computations. However, the structure of the lattices used is still the subject of cryptanalysis, and the security claims of the developers remain controversial [3]. 

Due to the novelty of these algorithms, crypto-agility, i.e. the ability to seamlessly replace cryptographic algorithms in case that they are vulnerable, is even more important for PQC than for SoA cryptography. Code-based algorithms are based on different, well studied security assumptions, but have a higher computational complexity and larger memory footprints than lattice-based algorithms in state-of-the-art implementations [4]. To determine if they are a viable alternative in lowpower IoT environments in case that lattice-based algorithms turn out to be vulnerable, hardware implementations are essential for a conclusive evaluation and have also been requested by the US NIST [5]. 

Therefore, in this work we present to the best of our knowledge the first HW/SW co-design based implementation of the code-based Hamming Quasi Cyclic KEM (HQC) [4]. Our design deploys a custom RISC-V processor and was implemented as an application-specific integrated circuit (ASIC) and field programmable gate array (FPGA). In summary, the new contributions of this work are: 

- 1) We provide the first ASIC implementation of a codebased KEM from the US NIST standardization process, which is fully compatible with the NIST C reference implementation. 

- 2) We identify the bottlenecks of the PQC algorithm and investigate for each bottleneck the best implementation method. We develop and implement software optimizations, instruction set extensions, and loosely coupled accelerators and provide detailed information about their individual benefits and overhead. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 10,2026 at 13:32:37 UTC from IEEE Xplore.  Restrictions apply. 

- 3) We compare the energy consumption, hardware requirements, and latency of our design to SoA implementations of lattice- and code-based primitives. 

The results show that our implementation is the most efficient design. Furthermore, we show that HQC can be implemented with a similar resource utilization as lattice-based algorithms while achieving viable performance. 

This paper is structured as follows. In Section II, we briefly introduce the working principle of KEMs in general and HQC. In Section III, we provide an overview of the related work and of the SoA. In Section IV, we identify and evaluate the computational bottlenecks of HQC in software. In Section V, we present the IoT processing system and the hardware implementation of the different accelerators. In Section VI, we compare our results with the SoA. In Section VII, we draw a conclusion. 

## II. BACKGROUND 

KEMs form a public key cryptosystem that is build out of three algorithms, Key-Generation (KeyGen), Encapsulation (Encaps) and Decapsulation (Decaps). Unlike general purpose Public Key Encryption Schemes (PKEs), KEMs are not thought to perform any application data encryption, but are designed to establish a randomly generated shared secret between communication partners in cryptographic protocols like Transport Layer Security (TLS) similar to the state-of-theart Diffie-Hellmann Key-Exchange. Afterwards, this shared secret is used to derive a secret key for de- and encryption of application data with fast symmetric cryptographic algorithms like Advanced Encryption Standard (AES). KEMs are often build out of existing PKEs using transformations like the Fujisaki-Okamoto Transform. 

The first code-based PKE was introduced by McEliece in 1978 and is based on the assumption that the error-correction code used is indistinguishable from random codes [6]. Although the original McEliece cryptosystem, which relied on Goppa codes, remains secure to this day, the method of hiding the generator matrix of the code in the public key carries a potential vulnerability. Attempts to reduce the key size by using more structured codes than the original McEliece approach have shown that this vulnerability can be exploited to crack the cryptosystems in 0.06 seconds [7]. 

Therefore, the authors of HQC proposed a novel approach which combines two different types of codes: 

- 1) A decodable [ _n, k_ ] code _C_ with a fixed, publicly known generator matrix **G** _∈_ F _[k]_ 2 _[×][n]_ and the error correction capability _δ_ based on concatenated Reed-Muller (RM) and Reed-Solomon (RS) codes. 

- 2) A random double-circulant [2 _n, n_ ] code with a publicly known parity check matrix **h** . 

This design rational allows HQC to use significantly smaller keys than the other code-based KEM Classic McEliece (2 KB vs 255 KB public key size) while still achieving the same security metrics. 

Fig. 1 shows how the shared secret _ss_ is established between the communication partners using the HQC KEM. HQC uses 

|**Alice**<br>**KeyGen()**:<br>1. **h**<br>$ _←_<br>_−R_<br>2. _sk_ = (_x, y_)<br>$ _←_<br>_−R_2<br>3. _pk_ = (**h**_, s_ = _x_+**h**_· y_)<br>Send _pk_<br>Send _ct_ = (_c, d_)<br>_Encrypt_(_pk, m, θ_)|**Bob**<br>**Encaps(**_pk_**)**:<br>4. _m_<br>$ _←_<br>_−_F_k_<br>2<br>5. _θ ←G_(_m_)<br>6. _e_<br>$ _←_<br>_−R_<br>7. (_r_1_, r_2)<br>$ _←_<br>_−R_2<br>8. _u_ = _r_1 +**h**_· r_2<br>9. _v_ = _m_**G**+_s · r_2 +_e_<br>10. _c ←_(_u, v_)<br>11. _d ←H_(_m_)<br>12. _ss ←K_(_m, c_)|
|---|---|



**Decaps(sk,ct)** 13. _m[′]_ = _C.Decode_ ( _v − u · y_ ) 14. _θ[′] ←G_ ( _m[′]_ ) 15. _c[′]_ = _Encrypt_ ( _pk, m[′] , θ[′]_ ) 16. If _c_ = _c[′] or d_ = _H_ ( _m[′]_ ) _abort_ 17. _ss ←K_ ( _m[′] , c_ ) 

Fig. 1. HQC KEM as defined in [4] with _R_ = F2[ _X_ ] _/_ ( _X[n] −_ 1), the hash $ functions _G, H, K_ , the sampling operator _←−_ and the KEM’s public key _pk_ , private key _sk_ , ciphertext _ct_ and shared secret _ss_ . _θ_ is the seed for the pseudorandom number generation during the encryption in Encaps() and Decaps(). 

the Keccak-based extendable output function SHAKE as a seedexpander of a random generated seed as the scheme requires a large amount of random bytes ( _n_ = 17669 for the smallest parameter set HQC-128). Furthermore, the Keccakbased Secure Hash Alorithm 3 (SHA3) [8] is used for the _G, H_ and _K_ functions which are required due to the KEM-DEM transformation in HQC to construct an IND-CCA2 secure KEM. 

The procedure of HQC in short is as follows, a detailed description can be found in [4]. First, Alice randomly generates the parity check matrix _h_ and the private key _sk_ , from which the public key _pk_ is constructed. Here, the polynomials _x_ and _y_ which build the secret key are hidden in the public key by multiplying **h** with _y_ and adding _x_ in _R_ . Bob uses _pk_ to encrypt his randomly generated message _m_ , which is the basis for the shared secret _ss_ . During this encryption, the randomly generated vectors _r_ 1, _r_ 2 and _e_ which have a fixed, predefined hamming weight are used to disguise _m_ further. The hamming weights are selected in a way such that they still allow a correct decryption of _m_ by Alice with respect to _δ_ with a very high probability. The ciphertext _ct_ is sent back to Alice, who decrypts the message _m[′]_ and calculates _ss_ based on it. 

The HQC algorithm is available in 3 different parameter sets. This paper is focused on the NIST level 1 parameter set HQC-128. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 10,2026 at 13:32:37 UTC from IEEE Xplore.  Restrictions apply. 

## III. STATE OF THE ART 

Many works have been published which deal with hardware accelerations of new PQC primitives. Among these publications, the vast majority is focused on accelerators for lattice-based algorithms. A cryptographic co-processor was implemented in [9] as an ASIC to support various lattice based NIST schemes. Fritzmann et al. developed a HW/SW based co-design on a RISCV core for the lattice-based scheme NewHope [10]. In [11], FrodoKEM, an algorithm which has a high security confidentiality due to its less structured lattice, was accelerated by using a HW/SW co-design approach. 

In contrast, the code-based KEMs have not yet been investigated to the same depth. For BIKE, another code-based candidate with a comparable key size to HQC, an FPGA implementation has been proposed in [12]. So far, the only hardware implementation for HQC was presented by the original authors of HQC in [4] and is based on FPGA HLS. Therefore, in this work, we present the first HW/SW co-design approach of HQC and implement our design both as ASIC and FPGA. 

## IV. HW/SW CO-DESIGN 

There are three possibilities for implementation: 

1) Software. 

- 2) Custom processor instructions. 

- 3) Loosely coupled accelerators. 

In a first step, the execution of the NIST reference software was profiled to determine the computational bottlenecks and the memory footprint. In a second step, we investigated for each bottleneck the most suitable approach to find the optimum trade-off between the area, latency, memory footprint, and energy consumption. The highest priority was assigned to software optimization, as it offers high flexibility without additional costs. Then, if this is not efficient, custom processor instructions were considered as a second option, since they are still flexible and require little additional hardware. Only when these two approaches were found to be ineffective a looselycoupled accelerator was considered. 

## _A. IoT Processing System (IoT-PS)_ 

Our methodology requires a processing system that allows instruction set extensions and the efficient interfacing of loosely-coupled accelerators. Therefore, we chose an adaptive platform that includes a RISC-V core whose instruction set architecture provides the ability to add custom instructions. Fig. 2 shows the final architecture of the IoT-PS. Our custom, area optimized RISC-V core supports the RV32IC instruction set which features additional compressed instructions and, therefore, significantly reduces the program size. The Direct Memory Access (DMA) controller features a memory copy (memcpy) and memory initialization (memset) function, of which both are able to operate on byte, half-word, and word granularity. The JTAG module provides access to the memories and the register file of the RISC-V core. It also can be used to start, stop, and reset the IoT-PS. Depending on the target platform, the data memory module was either based 

on an SRAM hard macro cell (ASIC) or Block RAM (Xilinx FPGA). Block RAM was also used for the instruction memory in case of an FPGA implementation. However, for the ASIC implementation we used a ROM macro cell, thus the program code is available after reset and does not need to be loaded via JTAG. The IoT-PS features no peripheral units except the I/O controller which is used to communicate via pin toggling. 

**==> picture [221 x 89] intentionally omitted <==**

**----- Start of picture text -----**<br>
JTAG RISC-V HQC Accelerator DMA<br>AXI4-Lite Interconnect<br>20 KB Instruction Memory 32 KB Data Memory I/O Controller<br>**----- End of picture text -----**<br>


Fig. 2. Architecture Overview 

## _B. Profiling of HQC-128_ 

The US NIST C reference implementation was used to identify the bottlenecks of the HQC-128 execution in our setup. The code was compiled with optimization level 2 (O2) and simulated cycle-accurately with the RTL model of our IoT-PS. Compared to Fig. 2, the size of ROM and RAM had to be increased for the analysis due to the large requirements of the reference implementation. 

The simulation results are shown in Table I. The specified clock cycles in the table refer to the processor cycles that the RISC-V core spends within the respective C function and excluding the time spent in sub-functions, e.g., gf mul is called during the computation of RS-Encode, but not included in its reported cycles. For all three KEM-functions, (1) the arithmetic in _R_ , (2) the SHAKE-based hashing and (3) memory operations are the main contributors to the total execution time. On top of that, the sampling operation, the RM-Decoding algorithm (4) and the finite field multiplication (5) are further contributors to the computation time. The unsigned division, which is performed in software, is mostly used during the polynomial multiplication in (1). 

In (1), the largest part is accounted by the multiplication of the large polynomials ( _n_ = 17669 for HQC-128), which are represented as bit vectors. This includes the subsequent reduction by _X[n] −_ 1 of the intermediate result, and is performed, for example, in steps 3., 8. and 9. in Fig. 1. The multiplication complexity is reduced by the fact that one of the vectors is sparse and has a small, known hamming weight _w ≤_ 75, which allows to consider only the non-zero coefficients in the sparse polynomial during processing. The execution of the multiplication consists mostly of XOR operations for adding the binary coefficients of the same degrees and SHIFT / AND operations to determine the degree of the intermediate results. Due to the high degree of the polynomials, a large number of LOAD and STORE instructions is required during the computation. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 10,2026 at 13:32:37 UTC from IEEE Xplore.  Restrictions apply. 

TABLE I 

TOTAL CYCLE COUNT AND SHARE OF IMPORTANT FUNCTIONS OF THE NIST C REFERENCE IMPLEMENTATION ON THE RISC-V, N.A. (NOT APPLICABLE) REFERS TO FUNCTIONS WHICH ARE NOT USED IN THIS STEP. 

|**Function**|||**Keygen Cycles**|**Encaps Cycles**|**Decaps Cycles**|
|---|---|---|---|---|---|
|**Total**|||**5609k**|**13850k**|**19903k**|
|**Arithmetic in**||_R_|**1540k (27.46%)**|**3448k (24.9%)**|**4989k (25.1%)**|
|- Vect<br>Mul|||1528k|3413k|4942k|
|- Vect<br>Add|||12k|35k|47k|
|**SHAKE**|||**1854k (33.05%)**|**5007k (36.15%)**|**5414k (27.2%)**|
|- Keccak<br>State||Permute|1744k|4626k|5005k|
|- Keccak<br>Inc|Squeeze||103k|131k|154k|
|- Keccak<br>Inc|Absorb||7k|250k|255k|
|**RS-RM Code**|||**n.A.**|**26k (0.18%)**|**1440k (7.24%)**|
|- RS-Encode|||n.A.|26k|26k|
|- RS-Decode|||n.A.|n.A.|56k|
|- RM-Decode|||n.A.|n.A.|1358k|
|**Sampling**|||**81k (1.44%)**|**155k (1.1%)**|**236k (1.18%)**|
|**Memory-Operation**|||**2071k (36.92%)**|**5068k (36.59%)**|**7175k (36.05%)**|
|- memcpy|||2045k|5021k|7092k|
|- memset|||26k|47k|83k|
|**Rest**|||**63k (1.12%)**|**146k (2.17%)**|**649k (3.26%)**|
|- unsigned division|||49k|100k|151k|
|- gf<br>mul|||n.A.|20k|162k|



Keccak’s permutation function in (2) is the computational core of the sponge construction in SHA3 and consists of bitwise AND, XOR, and rotate operations on the 25 lanes of 64 bits each. The major bottleneck in this permutation is the interdependence of the intermediate results which causes the contents of the processor registers to be swapped with the main memory multiple times during the execution of one of the 24 rounds. 

The large overhead of the memory operations in (3) is driven by two reasons. First, the RISC-V core supports only one outstanding memory read or write access at a time. It waits for a slave response before continuing the program execution. Second, the reference implementation is not optimized for low memory usage, e.g., it often stores multiple copies of temporary results, initializes a larger number of arrays, or copies parts of arrays to different memory locations. 

TABLE II 

STACK MEMORY AND CODE-SIZE OF THE NIST C REFERENCE IMPLEMENTATION OF HQC-128 ON OUR RISC-V CORE. 

further improved by removing redundant arrays which often get initialized with zeroes or are the target of memcpy operations. The operations are performed with pointers instead. For the remaining memory operations, the time required for memcpy and for array initialization via memset were accelerated by using the DMA controller of the platform. 

## _D. Instruction Set Extension_ 

The bottleneck of RS-Encoding and -Decoding is caused by the multiplication in F28. This operation has only three operands, including the generator polynomial, and one return value with the size of one byte each. A F28-Unit is added to the RISC-V core which is able to perform the operation shown in Equation 1, where _a_ = ( _a_ 15 _, · · · , a_ 0) and _b_ = ( _b_ 7 _, · · · , b_ 0) are the input operands, and _d_ = ( _d_ 14 _, · · · , d_ 0) is the output. This unit is made accessible via both an R-type and an I-type custom instruction, where register rs1 is used as operand _a_ , register rs2 respectively the immediate value imm is used as operand _b_ , and the output _d_ is stored in register rd. 

|**Code **|**Size**|**Keygen**<br>10.798 KB|**Encaps**<br>17.015 KB|**Decaps**<br>22.378 KB|
|---|---|---|---|---|
|**Stack **|**Memory**|53.018 KB|68.714 KB|77.762 KB|



**==> picture [246 x 28] intentionally omitted <==**

Using these custom instructions, a multiplication in F28 is performed within four clock cycles. 

## _C. Software Optimization_ 

In multiple functions, the reference implementation uses non-optimal data-types which increases the number of required memory accesses and processor instructions. An example of this is the comparisons in Step 16 of Fig. 1, which are performed on a byte boundary rather than a processor word boundary. The memory footprint and computation time was 

## _E. Loosely-Coupled Accelerators_ 

Fig. 4 shows the block diagram of the loosely-coupled HQC accelerators. To enable parallel calculations between the processor and the accelerator, the accelerator has both an AXI slave and an AXI master interface and fetches its calculation inputs (e.g. the polynomials) from the processor’s 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 10,2026 at 13:32:37 UTC from IEEE Xplore.  Restrictions apply. 

**==> picture [360 x 150] intentionally omitted <==**

**----- Start of picture text -----**<br>
Dense Polynomial<br>0 word0 63 64 word1 127 . . . 17664wordN 17228<br>coord0 coordword0 0 coord0+63 XOR . . . coordword0 N coord0<br>+ 17664 +17228<br>coord1 word0 . . . wordN<br>coord1 coord1+63 XOR coord1 coord1<br>+ 17664 +17228<br>XOR<br>coordw-1 word0 . . . wordN<br>coordw-1 Coordw-1+63 coordw-1 coordw-1<br>+ 17664 +17228<br>Intermediate Result<br>. . .<br>. . .<br>Sparse Polynomial<br>**----- End of picture text -----**<br>


Fig. 3. Working principle of the polynomial multiplication in _R_ with _n_ = 17669 and 64-bit memory words. 

main memory via the master interface, according to the processor command which was previously received via the slave interface. Due to the data dependencies between the steps in the HQC-KEM, and based on the previous observation that the bottleneck in the HQC is driven by memory accesses, we decided that enabling parallel read/read or read/write accesses is more beneficial than running the dedicated compute units in parallel. Therefore, only two SRAMs are used and shared between the compute units, and only one of the compute units is processing at the same time. The access to the SRAMs and the operation mode of the compute units are managed by one control unit. 

**==> picture [233 x 171] intentionally omitted <==**

**----- Start of picture text -----**<br>
AXI4-Lite Interconnect<br>AXI-Master<br>AXI-Slave<br>SRAM0 SRAM1<br>(288 x HQC Control Unit (566 x<br>64 Bit) 64 Bit)<br>Sampling-Unit R -Unit RM-Decoder<br>Keccak-IP<br>**----- End of picture text -----**<br>


Fig. 4. HQC hardware accelerator. 

The _R_ -Unit implements the addition, multiplication and reduction of the polynomials in _R_ . Fig. 3 shows the working principle of the polynomial multiplication. The values of the sparse polynomial contain the locations of its non-zero coordinates. In our implementation, we iterate through the multiplication by a word-by-word shift of the dense polynomial by the coordinates given in the sparse polynomial. 

After the shift, the interim result is XOR-ed with the word that is currently stored at the respective location in memory and the carry out with respect to the word alignment of the 

memory is calculated. The _R_ -Unit is designed such that only two cycles are necessary for calculating a resulting word. In the first cycle the address of the dense polynomial and the intermediate polynomial are calculated and read based on the coordinate, while in the second cycle the new value and the carry-out are calculated and written to memory. 

The Sampling-Unit combines the sponge functions squeeze and absorb of the incremental version of SHAKE, the permutation function of Keccak and the rejection-based sampling, during which SHAKE functions are used as extendable output functions (XOF). For the permutation function, a highspeed open-source implementation by the original authors of Keccak was used, which executes the permutation in 24 clock cycles [13]. 

As shown in Table I, the vast majority of decoding time is spent on the RM-Codes, which employs a Maximum Likelihood (ML) algorithm based on the Hadamard Transform and a subsequent peak-search for the highest value in the transformed codeword. Because HQC uses duplicated RM codes, the decoding algorithm must be preceded by another transformation function [4]. This transform requires many single-bit operations, and thus, the implementation in software is not efficient. Therefore, we adapted the transform and the subsequent decoding steps to an efficient hardwareimplementation. 

## V. RESULTS AND COMPARISON 

The IoT-PS presented was implemented in a 22 nm FD-SOI technology from GlobalFoundries under worst case Process, Voltage and Temperature (PVT) conditions (125 °C, 0.72 V for timing; 25 °C, 0.8 V for power). Synthesis is performed with the Synopsys DesignCompiler, Place&Route is carried out with the Synopsys IC-Compiler. The SRAMs were generated by the INVECAS Memory Compiler. Power numbers are calculated with back-annotated wiring data. The layout of ASIC IP core presented in this work can be seen in Figure 5 has a size of 0 _._ 12 _mm_[2] with an aspect ratio of 1 _._ 77 and a maximum frequency of 700 _MHz_ . The IoT-PS presented was also implemented on a Xilinx Artix xc7a100tcsg324-3 using Xilinx Vivado for a better comparison to existing work. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 10,2026 at 13:32:37 UTC from IEEE Xplore.  Restrictions apply. 

## TABLE III 

CYCLE COUNT OF THE HQC-KEM IN OUR SETUP WITH THE DIFFERENT HARDWARE MODULES. THE IMPROVEMENT REFERS TO SPEEDUP WITH RESPECT TO THE NIST C REFERENCE IMPLEMENTATION WITHOUT ANY HARDWARE ACCELERATORS. 

|||**Keygen**||**Encaps**|**Decaps**|**Decaps**|
|---|---|---|---|---|---|---|
||Cycles|Improvement|Cycles|Improvement|Cycles|Improvement|
|Reference|5609k|-|13850k||19903k|-|
|DMA + SW<br>OPT|3587k|36.0%|7044k|49.1%|10851k|45.5%|
|+ _R_-Unit|1862k|66.8%|5183k|62.6%|7245k|63.6%|
|+ Sampling-Unit|1623k|71.1%|1955k|85.9%|5176k|74.0%|
|+ RM-Decoder|n.A.|n.A.|n.A.|n.A.|9636k|51.6%|
|+ F28-Instruction|n.A.|n.A.|7028k|49.3%|10722k|46.1%|
|+ All Modules|56k|98.9%|131k|99%|557k|97.2%|
|Code Size|1.5 KB|86.1%|6.6 KB|61.2%|13.362 KB|40.3%|
|Stack Memory|10 KB|81.1%|24 KB|65.7%|31 KB|60.1%|



## _A. Impact of individual optimizations on the overall run time_ 

Table III shows the extent to which the presented hardware modules accelerate the computation time of the three KEM functions. As illustrated, the use of a DMA and the software optimization already provide a significant speed up between 36% and 49% over the reference implementation. This shows that the NIST C reference implementation is not meant to be used in IoT devices without optimizations. The loosely coupled Sampling-Unit is the accelerator that provides the a runtime reduction of at least 50% compared to the optimized software implementation with DMA in all KEM functions. The _R_ -Unit, however, reduces the runtime only between 26 _._ 5% and 48% depending on the KEM function. The RM-Decoder has the least impact on the performance since it is only used in Decaps. Also it is able to achieve a runtime reduction of 11 _._ 2%. The F28-Instructions give only a minor speedup on its own, but shows its potential in combination with all loosely coupled accelerators. 

## _B. Resource distribution of the individual hardware modules_ 

Figure 5 shows a qualitative area distribution of the distinct modules for ASIC, while Table IV shows a quantitative distribution for FPGA. The _R_ -Unit shows the highest area efficiency among all loosely coupled accelerators. Although this unit has a lower runtime reduction compared to the 

**==> picture [227 x 128] intentionally omitted <==**

Fig. 5. Layout; RISC-V - blue; JTAG - cyan; Interconnect - lime; I/O Controller - purple; DMA - pink; Sampling Unit - red; RM-Decoder - orange; _R_ -Unit - yellow; HQC Control Unit, SRAM0, SRAM1 - green; ROM - white, horizontal strips; RAM - white, cross pattern 

Sampling-Unit, it needs less than 10% of its FPGA resources. The RM-Decoder, however, requires fewer resources than the _R_ -Unit, but also offers the least performance gain and is only used in Decaps. Therefore, it is far less efficient compared to both _R_ -Unit and Sampling-Unit. The F28-Unit, which is used by the custom instructions, requires only negligible resources. However, the decoding of these instructions as well as the controlling of the unit requires additional resources which are hidden inside the RISC-V core. 

TABLE IV 

RESOURCE UTILIZATION ON FPGA (ARTIX7) 

|||**LUTs**|**Registers**|**Block RAM**|
|---|---|---|---|---|
||RISC-V|2210|1682|0|
||⌞F28-Unit<br>Interconnect<br>Memories|27<br>2775<br>53|0<br>1919<br>6|0<br>0<br>24|
||HQC Accelerator|7920|2370|3|
||_⊢R_-Unit<br>_⊢_RM-Decoder|565<br>435|117<br>63|0<br>0|
||⌞Sampling Unit<br>⌞Keccak Permute|5610<br>4685|1814<br>1622|0<br>0|
||DMA<br>JTAG|489<br>452|412<br>546|0<br>0|
||I/O Controller|41|68|0|
||IoT-PS|13934|7003|27|



## _C. Comparison to State of the Art_ 

Table V presents the required clock cycles for the different KEM functions of SoA implementations and of our work. We use the number of clock cycles as metric rather than absolute computation time. This is, for our our work, a pessimistic comparison due to the high achievable clock frequency. However, even under this assumption, our implementation requires a comparable number of clock cycles as the low-latency HQC implementation, while it requires less hardware than its low area hardware implementation. Compared to BIKE, the other code-based KEM, our implementation requires about the same amount of clock cycles like the low latency implementation while using significantly less hardware resources. The implementation of FrodoKEM, which would be an alternative if structured lattice-based KEMs like Kyber and NewHope are 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 10,2026 at 13:32:37 UTC from IEEE Xplore.  Restrictions apply. 

TABLE V 

COMPARISON OF CLOCK CYCLES, FREQUNCY AND FPGA RESOURCES FOR DIFFERENT STATE-OF-THE-ART IMPLEMENTATIONS. HW/SW REFERS TO IMPLEMENTATIONS BASED ON HW/SW CO-DESIGN, FULL REFERS TO FULL HARDWARE IMPLEMENTATIONS OF THE RESPECTIVE SCHEME. NEWHOPE AND KYBER ARE STRUCTURED-LATTICE BASED ALGORITHMS, FRODOKEM IS BASED ON LESS-STRUCTURED LATTICES, AND THE REMAINING IMPLEMENTATIONS ARE BASED ON CODES. 

|**Implementation**||**Keygen**|**Encaps**|**Decaps**|**Frequency**|**FPGA Resources**|**FPGA Resources**|**FPGA Resources**|**Target Plattform**|
|---|---|---|---|---|---|---|---|---|---|
|||Cycles|Cycles|Cycles|MHz|LUTs|FFs|BRAMs||
|HQC (low area, HW) [4]||630k|1500k|2100k|132|8.9k|4k|14|FPGA (Xilinx Artix-7)|
|HQC (low latency, HW) [4]||40k|89k|190k|148|20k|16k|12.5|FPGA (Xilinx Artix-7)|
|BIKE (low area, HW) [12]||2671k|153k|1628k|121|13k|5k|17|FPGA (Xilinx Artix-7)|
|BIKE (low latency, HW) [12]||259k|12k|189k|96|53k|7k|49|FPGA (Xilinx Artix-7)|
|NewHope (HW/SW) [10]||357k|590k|167k|n.A.|11k|5k|1|FPGA (Xilinx Zynq-7000)|
|FrodoKEM (HW/SW) [11]||23.4M|25.5M|25.3M|100|5.6k|1.1k|0|FPGA (Xilinx Zynq Ultrascale+)|
|Kyber (HW/SW) [9]||75k|132k|142k|72|n.A.|n.A.|n.A.|ASIC (40nm)|
|HQC on Cortex M4 (SW)||1048k|2436k|4001k|64|n.A.|n.A.|n.A.|nRF52840|
|**This Work HQC (DMA+SW**|**OPT)**|3587k|7044k|10851k|700|n.A.|n.A.|n.A.|ASIC (22nm)|
|**This Work HQC (HW/SW)**||56k|131k|557k|700|n.A.|n.A.|n.A.|ASIC (22nm)|
|**This Work HQC (HW/SW)**||56k|131k|557k|100|8k|2.4k|3|FPGA (Xilinx Artix-7)|



proven to be vulnerable to attacks, is overall 100 times slower than our work. 

Table VI shows the energy consumption of our implementation, of HQC on a Cortex M4 processor and of the structured lattice-based KYBER, also implemented as an ASIC. As can be seen, our implementation requires considerably less energy than the pure software on the Cortex M4 and also less than KYBER’s ASIC implementation, which, however, was implemented on a larger technology node. 

## TABLE VI 

COMPARISON OF ENERGY CONSUMPTION. FOR A TRADE-OFF BETWEEN POWER AND LATENCY, OUR DESIGN WAS IMPLEMENTED AND SIMULATED WITH A 200 MHZ CLOCK. 

|**Implementation**|**Keygen**|**Encaps**|**Decaps**|
|---|---|---|---|
|Kyber (HW/SW) [9]<br>HQC on Cortex M4 (SW)<br>**This Work HQC (HW/SW)**|_µJ_<br>5.97<br>500<br>1.02|_µJ_<br>9.37<br>1184<br>2.41|_µJ_<br>11.25<br>1872<br>7.1|



## VI. CONCLUSION 

In this work, we investigated the performance of the codebased post-quantum KEM HQC in the context of low power IoT system. We presented the first ASIC implementation of a code-based US NIST PQC candidate. With a combination of software optimizations, instruction set extensions, and loosely coupled hardware accelerators, we achieve similar performance to the full SoA hardware implementation of HQC, but require significantly less hardware resources and provide more flexibility. Compared to SoA implementations of lattice-based algorithms, we have shown that code-based algorithms are promising alternatives in IoT based applications in terms of energy efficiency, computation time, and required hardware. 

## ACKNOWLEDGEMENT 

This paper was partly founded by the German Federal Ministry of Education and Research as part of the project “SIKRIN-KRYPTOV” (16KIS1069). 

## REFERENCES 

- [1] P. W. Shor, “Algorithms for quantum computation: Discrete logarithms and factoring,” in _Proceedings of the 35th Annual Symposium on Foundations of Computer Science_ . IEEE Computer Society, 1994, p. 124–134. 

- [2] M. Mosca, “Cybersecurity in an Era with Quantum Computers: Will We Be Ready?” _IEEE Security & Privacy_ , vol. 16, no. 5, pp. 38–41, 2018. 

- [3] Peikert, Christopher J. and Bernstein, D.J., “CRYSTALS-KYBER: Round 3 Official Comments,” https://csrc.nist.gov/CSRC/media/Projects/post-quantumcryptography/documents/round-3/official-comments/CRYSTALSKYBER-round3-official-comment.pdf, 2022, Retrieved 2022-06-07. 

- [4] C. A. Melchor, N. Aragon, S. Bettaieb, L. Bidoux, O. Blazy, J.C. Deneuville, P. Gaborit, E. Persichetti, G. Z´emor, and I. Bourges, “Hamming Quasi-Cyclic (HQC),” 2021. 

- [5] G. Alagic, J. Alperin-Sheriff, D. Apon, D. Cooper, Q. Dang, J. Kelsey, Y.-K. Liu, C. Miller, D. Moody, R. Peralta _et al._ , “Status Report on the Second Round of the NIST Post-Quantum Cryptography Standardization Process,” _NIST, Tech. Rep., July_ , 2020. 

- [6] R. J. McEliece, “A public-key cryptosystem based on algebraic coding theory,” _The Deep Space Network Progress Report_ , vol. 42-44, pp. 114– 116, 1978. 

- [7] J.-C. Faugere, A. Otmani, L. Perret, and J.-P. Tillich, “Algebraic cryptanalysis of McEliece variants with compact keys,” in _Annual International Conference on the Theory and Applications of Cryptographic Techniques_ . Springer, 2010, pp. 279–298. 

- [8] National Institute of Standards and Technology, “FIPS PUB 202 -SHA-3 Standard: Permutation-Based Hash and Extendable-Output Functions,” https://csrc.nist.gov/Projects/post-quantum-cryptography, Retrieved 2022-02-17. 

- [9] U. Banerjee, T. S. Ukyab, and A. P. Chandrakasan, “Sapphire: A Configurable Crypto-Processor for Post-Quantum Lattice-Based Protocols,” _arXiv preprint arXiv:1910.07557_ , 2019. 

- [10] T. Fritzmann, U. Sharif, D. M¨uller-Gritschneder, C. Reinbrecht, U. Schlichtmann, and J. Sepulveda, “Towards Reliable and Secure PostQuantum Co-Processors based on RISC-V,” in _2019 Design, Automation & Test in Europe Conference & Exhibition (DATE)_ , 2019, pp. 1148– 1153. 

- [11] P. Karl, T. Fritzmann, and G. Sigl, “Hardware Accelerated FrodoKEM on RISC-V,” in _2022 25th International Symposium on Design and Diagnostics of Electronic Circuits and Systems (DDECS)_ , 2022, pp. 154–159. 

- [12] J. Richter-Brockmann, J. Mono, and T. Guneysu, “Folding BIKE: Scalable Hardware Implementation for Reconfigurable Devices,” _IEEE Transactions on Computers, vol. 71, no. 5, pp. 1204-1215_ , 2022. 

- [13] Bertoni, G. and Daemen, J. and Peeters, M. and Van Assche, G., “Keccak in VHDL,” https://keccak.team/hardware.html, 2022, Retrieved 2022-0607. 

Authorized licensed use limited to: Aristotle University of Thessaloniki. Downloaded on March 10,2026 at 13:32:37 UTC from IEEE Xplore.  Restrictions apply. 

