---
source_pdf: docs/references/pdf/riscv/!!!secuelec_rennes_phoenix_prez.pdf
converted_at: 2026-05-29 22:41
conversion_time: 7.9s
tool: pymupdf4llm
---

**==> picture [501 x 540] intentionally omitted <==**

**==> picture [84 x 83] intentionally omitted <==**

**==> picture [153 x 151] intentionally omitted <==**

**==> picture [124 x 97] intentionally omitted <==**

**==> picture [81 x 81] intentionally omitted <==**

## PHOENIX Crypto-Agile Hardware Sharing for ML-KEM and HQC 

**Antonio Ras, PhD Candidate** _Laboratoire Sécurité des Composants (LSCO),_ **CEA-Leti** 

## _**Encadrants CEA**_ **:** 

Mikael Carmona, Antoine Loiseau, Simon Pontié, Emanuele Valea 

## _**Directeurs de thèse**_ **:** 

Guénaël Renault, Benjamin Smith 

**==> picture [29 x 28] intentionally omitted <==**

**Séminaire SecuElec, Rennes** | 25 April 2025 

## Introduction 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Quantum-threat 

- ❑ Shor algorithm can easily solve hard problem 

   - ❑ Discrete logarithm (Elliptic Curve Cryptography) 

   - ❑ Integer factorization (RSA) 

**==> picture [394 x 158] intentionally omitted <==**

**----- Start of picture text -----**<br>
Probability to break<br>RSA-1024 in 24h<br>**----- End of picture text -----**<br>


**1** 

## Introduction 

## ➢ Quantum-threat 

- ❑ Shor algorithm can easily solve hard problem 

   - ❑ Discrete logarithm (Elliptic Curve Cryptography) 

   - ❑ Integer factorization (RSA) 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Post-Quantum Cryptography 

- ❑ New matematical hard problem 

   - _-_ 

   - ❑ _Lattice based_ and _Code based_ cryptography 

   - ❑ ... 

- ❑ **Key Encapsulation Mechanism (KEM)** 

- ❑ Digital Signature (DS) 

- ❑ End of PQC NIST Process (2017 → 2025) 

Probability to break RSA-1024 in 24h 

**==> picture [353 x 86] intentionally omitted <==**

**1** 

## Introduction 

## ➢ Quantum-threat 

- ❑ Shor algorithm can easily solve hard problem 

   - ❑ Discrete logarithm (Elliptic Curve Cryptography) 

   - ❑ Integer factorization (RSA) 

**==> picture [394 x 158] intentionally omitted <==**

**----- Start of picture text -----**<br>
Probability to break<br>RSA-1024 in 24h<br>**----- End of picture text -----**<br>


**==> picture [172 x 50] intentionally omitted <==**

## ➢ Post-Quantum Cryptography 

- ❑ New matematical hard problem 

   - _-_ 

   - ❑ _Lattice based_ and _Code based_ cryptography 

   - ❑ ... 

- ❑ **Key Encapsulation Mechanism (KEM)** 

- ❑ Digital Signature (DS) 

- ❑ End of PQC NIST Process (2017 → 2025) 

**==> picture [353 x 86] intentionally omitted <==**

## ➢ Quantum-safe transition 

- 

- ❑ **Hybridization :** _Post quantum + pre-quantum cryptography_ 

- ❑ **Crypto-Agility :** Ability to switch between different PQC solutions 

**==> picture [310 x 115] intentionally omitted <==**

**1** 

## Introduction 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Quantum-threat 

- ❑ Shor algorithm can easily solve hard problem 

   - ❑ Discrete logarithm (Elliptic Curve Cryptography) 

   - ❑ Integer factorization (RSA) 

**==> picture [394 x 158] intentionally omitted <==**

**----- Start of picture text -----**<br>
Probability to break<br>RSA-1024 in 24h<br>**----- End of picture text -----**<br>


## ➢ Post-Quantum Cryptography 

- ❑ New matematical hard problem 

   - _-_ 

   - ❑ _Lattice based_ and _Code based_ cryptography ❑ ... 

- ❑ **Key Encapsulation Mechanism (KEM)** 

- ❑ Digital Signature (DS) 

- ❑ End of PQC NIST Process (2017 → 2025) 

**==> picture [353 x 86] intentionally omitted <==**

## ➢ Quantum-safe transition 

- 

- ❑ **Hybridization :** _Post quantum + pre-quantum cryptography_ 

- ❑ **Crypto-Agility :** Ability to switch between different PQC solutions 

**==> picture [310 x 115] intentionally omitted <==**

## ➢ Crypto-Agility 

- ❑ **Purpose** : **Maintain security along PQC families** 

- ❑ : **Our targeted agility + Hardware** 

   - ❑ ML-KEM (lattice-based) + HQC (code-based) 

||**ML-KEM**|**HQC**|**Lattice-code agility**|
|---|---|---|---|
|Hardware<br>implementation|~40|3|2|



## **Lattice-Code Agility State of the Art** 

**[ZZO+24]** Zhu et al, “16.2 A 28nm 69.4kOPS 4.4μJ/Op Versatile Post-Quantum Crypto-Processor Across Multiple Mathematical Problems”, 2024 

**[ZZL+22]** Zhu et al, “A 28nm 48KOPS 3.4µJ/Op Agile Crypto-Processor for Post-Quantum Cryptography on Multi-Mathematical Problems”, 2022 

**1** 

## Agenda 

**1. Crypto-Agility on NIST standards** 

**2. Number-Theoretic Transform (NTT) 3. HQC using alternative multiplication 4. Proposed sharing strategy 5. Integration results 6. Conclusion** 

**==> picture [960 x 44] intentionally omitted <==**

# 1 Crypto-Agility on NIST standards A case study for ML-KEM and HQC 

## Targeted Crypto-agility 

**ML-KEM :** _Module-Learning with Error,_ lattice problem 

**==> picture [378 x 124] intentionally omitted <==**

**----- Start of picture text -----**<br>
public  𝑨 , uniform  secret  𝒔 ,  𝒆 binomial<br>𝑡0 𝑎00 ⋯ 𝑎0(𝑘−1) 𝑠0 𝑒0<br>⋮ ⋮ ⋱ ⋮ ⋮ ⋮<br>𝑡𝑘−1 𝑎(𝑘−1)0 ⋯ 𝑎(𝑘−1)(𝑘−1) 𝑠𝑘−1 𝑒𝑘−1<br>Knowing  𝐭= 𝑨𝒔+ 𝒆 and  𝑨 , it is difficult to find  𝒔<br>**----- End of picture text -----**<br>


**==> picture [172 x 50] intentionally omitted <==**

**Hamming Quasi-Cyclic (HQC):** _Quasi-Cyclic Syndrome Decoding,_ code-corrector problem 

**==> picture [331 x 91] intentionally omitted <==**

**Knowing** 𝒔= 𝒆𝑯[𝒕] **and** 𝑯 _**,**_ **it is difficult to find the small** 𝒆 

**2** 

## Targeted Crypto-agility 

**==> picture [172 x 50] intentionally omitted <==**

**ML-KEM :** _Module-Learning with Error,_ lattice problem 

**==> picture [378 x 124] intentionally omitted <==**

**----- Start of picture text -----**<br>
public  𝑨 , uniform  secret  𝒔 ,  𝒆 binomial<br>𝑡0 𝑎00 ⋯ 𝑎0(𝑘−1) 𝑠0 𝑒0<br>⋮ ⋮ ⋱ ⋮ ⋮ ⋮<br>𝑡𝑘−1 𝑎(𝑘−1)0 ⋯ 𝑎(𝑘−1)(𝑘−1) 𝑠𝑘−1 𝑒𝑘−1<br>Knowing  𝐭= 𝑨𝒔+ 𝒆 and  𝑨 , it is difficult to find  𝒔<br>**----- End of picture text -----**<br>


**Hamming Quasi-Cyclic (HQC):** _Quasi-Cyclic Syndrome Decoding,_ code-corrector problem 

**==> picture [331 x 91] intentionally omitted <==**

**Knowing** 𝒔= 𝒆𝑯[𝒕] **and** 𝑯 _**,**_ **it is difficult to find the small** 𝒆 

Frameworks seem close, but... 

**2** 

## Targeted Crypto-agility 

**==> picture [172 x 50] intentionally omitted <==**

**ML-KEM :** _Module-Learning with Error,_ lattice problem 

**==> picture [378 x 124] intentionally omitted <==**

**----- Start of picture text -----**<br>
public  𝑨 , uniform  secret  𝒔 ,  𝒆 binomial<br>𝑡0 𝑎00 ⋯ 𝑎0(𝑘−1) 𝑠0 𝑒0<br>⋮ ⋮ ⋱ ⋮ ⋮ ⋮<br>𝑡𝑘−1 𝑎(𝑘−1)0 ⋯ 𝑎(𝑘−1)(𝑘−1) 𝑠𝑘−1 𝑒𝑘−1<br>Knowing  𝐭= 𝑨𝒔+ 𝒆 and  𝑨 , it is difficult to find  𝒔<br>**----- End of picture text -----**<br>


**Hamming Quasi-Cyclic (HQC):** _Quasi-Cyclic Syndrome Decoding,_ code-corrector problem 

**==> picture [331 x 91] intentionally omitted <==**

**Knowing** 𝒔= 𝒆𝑯[𝒕] **and** 𝑯 _**,**_ **it is difficult to find the small** 𝒆 

Frameworks seem close, but... 

**==> picture [677 x 188] intentionally omitted <==**

**----- Start of picture text -----**<br>
vs<br>ℤ𝑞 ℤ2<br>𝑅 = ℛ =<br>𝑞 𝑋 [𝑛] +1 2 𝑋 [𝑛] +1<br>**----- End of picture text -----**<br>


**2** 

## Targeted Crypto-agility 

**==> picture [172 x 50] intentionally omitted <==**

**ML-KEM :** _Module-Learning with Error,_ lattice problem 

**==> picture [378 x 124] intentionally omitted <==**

**----- Start of picture text -----**<br>
public  𝑨 , uniform  secret  𝒔 ,  𝒆 binomial<br>𝑡0 𝑎00 ⋯ 𝑎0(𝑘−1) 𝑠0 𝑒0<br>⋮ ⋮ ⋱ ⋮ ⋮ ⋮<br>𝑡𝑘−1 𝑎(𝑘−1)0 ⋯ 𝑎(𝑘−1)(𝑘−1) 𝑠𝑘−1 𝑒𝑘−1<br>Knowing  𝐭= 𝑨𝒔+ 𝒆 and  𝑨 , it is difficult to find  𝒔<br>**----- End of picture text -----**<br>


**Hamming Quasi-Cyclic (HQC):** _Quasi-Cyclic Syndrome Decoding,_ code-corrector problem 

**==> picture [331 x 91] intentionally omitted <==**

**Knowing** 𝒔= 𝒆𝑯[𝒕] **and** 𝑯 _**,**_ **it is difficult to find the small** 𝒆 

**==> picture [677 x 216] intentionally omitted <==**

**----- Start of picture text -----**<br>
Frameworks seem close, but...<br>vs<br>ℤ𝑞 ℤ2<br>𝑅 = ℛ =<br>𝑞 𝑋 [𝑛] +1 2 𝑋 [𝑛] +1<br>**----- End of picture text -----**<br>


**How to implement Crypto-Agility efficiently ?** 

**2** 

## Sharing strategy 

## ➢ Software profiling 

**==> picture [327 x 196] intentionally omitted <==**

**----- Start of picture text -----**<br>
ML-KEM HQC<br>1%<br>5%<br>4%<br>35%<br>60%<br>95%<br>**----- End of picture text -----**<br>


**==> picture [172 x 50] intentionally omitted <==**

**==> picture [158 x 40] intentionally omitted <==**

**----- Start of picture text -----**<br>
Hash functions Others<br>Polynomial Multiplication<br>**----- End of picture text -----**<br>


KEM Operations Profiling 

## ➢ Sharing strategy 

**Purpose :** Identify common / similar operations 

Possible sharing strategies : 

- ❑ **Hash function** : _**straightforward** approach,_ FIPS 202 

- ❑ : **Polynomial multiplication** _approach_ 

**3** 

## Sharing strategy 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Software profiling 

**==> picture [327 x 196] intentionally omitted <==**

**----- Start of picture text -----**<br>
ML-KEM HQC<br>1%<br>5%<br>4%<br>35%<br>60%<br>95%<br>**----- End of picture text -----**<br>


**==> picture [158 x 40] intentionally omitted <==**

**----- Start of picture text -----**<br>
Hash functions Others<br>Polynomial Multiplication<br>**----- End of picture text -----**<br>


KEM Operations Profiling 

## ➢ Sharing strategy 

**Purpose :** Identify common / similar operations 

Possible sharing strategies : 

- ❑ **Hash function** : _**straightforward** approach,_ FIPS 202 ❑ : **Polynomial multiplication** _approach_ 

## Which multiplication strategy to mutualize 

## **HQC** 

**ML-KEM HQC** _Sparse - Dense :_ Not constant time _Number-Theoretic Transform_ **&** _2-way Karatsuba :_ New bottleneck _Frobenius Additive FFT :_ _**Our proposal**_ 

**3** 

## Sharing strategy 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Software profiling 

**==> picture [327 x 196] intentionally omitted <==**

**----- Start of picture text -----**<br>
ML-KEM HQC<br>1%<br>5%<br>4%<br>35%<br>60%<br>95%<br>**----- End of picture text -----**<br>


Hash functions Others Polynomial Multiplication 

KEM Operations Profiling 

## ➢ Sharing strategy 

**Purpose :** Identify common / similar operations 

Possible sharing strategies : 

- ❑ **Hash function** : _**straightforward** approach,_ FIPS 202 ❑ : **Polynomial multiplication** _approach_ 

## Which multiplication strategy to mutualize 

**ML-KEM HQC** _Sparse - Dense :_ Not constant time _Number-Theoretic Transform_ **&** _2-way Karatsuba :_ New bottleneck _Frobenius Additive FFT :_ _**Our proposal**_ 

**What about hardware Crypto-Agility ?** 

**3** 

## System on Chip and hardware agility 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ System-on-Chip 

**==> picture [523 x 297] intentionally omitted <==**

**----- Start of picture text -----**<br>
Microprocessor  Memories<br>(CPU)<br>Interconnect<br>(system bus)<br>**----- End of picture text -----**<br>


**4** 

**[FBR+22]** Tim Fritzmann et al, _“_ Masked Accelerators and Instruction Set Extensions for Post-Quantum Cryptography _“, 2022_ 

## System on Chip and hardware agility 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ System-on-Chip 

- ❑ **Application-specific accelerators** 

   - ❖ **Tightly-coupled :** No flexibility, low data exchange latency 

   - ❖ **Loosely-coupled :** High flexibility, high data exchange latency 

**==> picture [544 x 337] intentionally omitted <==**

**----- Start of picture text -----**<br>
Microprocessor  Memories<br>(CPU)<br>Tightly-coupled<br>Interconnect<br>(system bus)<br>Loosely-coupled<br>[FBR+22]  Tim Fritzmann et al,  “ Masked Accelerators and Instruction Set Extensions for Post-Quantum Cryptography “, 2022<br>**----- End of picture text -----**<br>


**4** 

## System on Chip and hardware agility 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ System-on-Chip 

## ➢ Hardware resource-sharing 

- ❑ **Application-specific accelerators** 

   - ❖ **Tightly-coupled :** No flexibility, low data exchange latency 

   - ❖ **Loosely-coupled :** High flexibility, high data exchange latency 

**==> picture [544 x 337] intentionally omitted <==**

**----- Start of picture text -----**<br>
Microprocessor  Memories<br>(CPU)<br>Tightly-coupled<br>Interconnect<br>(system bus)<br>Loosely-coupled<br>[FBR+22]  Tim Fritzmann et al,  “ Masked Accelerators and Instruction Set Extensions for Post-Quantum Cryptography “, 2022<br>**----- End of picture text -----**<br>


**==> picture [285 x 381] intentionally omitted <==**

**4** 

**==> picture [960 x 44] intentionally omitted <==**

# 2 Number-Theoretic Transform The polynomial multiplication strategy for ML-KEM 

## FFT-based polynomial multiplication 

**==> picture [172 x 50] intentionally omitted <==**

## **How to perform multiplication** 

- ❑ Evaluating input polynomial in a different domain using an evaluation points set → **FFT step** 

- ❑ Perform multiplication between evaluated points → **PWM step** 

- ❑ Interpolate back to get final result → **Inverse FFT (IFFT) step** 

**IMPORTANT** : FFT and IFFT are performed using different **processing elements,** and 

**==> picture [754 x 314] intentionally omitted <==**

**5** 

## Polynomial multiplication in ML-KEM 

**==> picture [172 x 50] intentionally omitted <==**

ℤ 𝑞 ➢ Number-Theoretic-Transform : FFT-like for polynomials in 𝑅𝑞 = 𝑋[𝑛] +1[, where ][𝑞= 3329][ and ][n = 256][.] 

INTT 

**6** 

**[XL21]** Y. Xing and S. Li, _“_ A Compact Hardware Implementation of CCA-Secure Key Exchange Mechanism CRYSTALS-KYBER on FPGA _“, 2021_ 

## Polynomial multiplication in ML-KEM 

**==> picture [172 x 50] intentionally omitted <==**

ℤ 𝑞 ➢ Number-Theoretic-Transform : FFT-like for polynomials in 𝑅𝑞 = 𝑋[𝑛] +1[, where ][𝑞= 3329][ and ][n = 256][.] 

INTT 

## **Which operation we compute in practice ?** 

❑ ℤ𝑞 where 𝑞= 3329 (12-bits coefficient) 

## **Modular addition** 

ℎ= 𝑓+ 𝑔𝑚𝑜𝑑𝑞 

## **Modular subtraction** 

ℎ= 𝑓−𝑔𝑚𝑜𝑑𝑞 

## **Modular integer multiplication** 

**==> picture [173 x 34] intentionally omitted <==**

**----- Start of picture text -----**<br>
ℎ= 𝑓∗𝑔𝑚𝑜𝑑𝑞<br>**----- End of picture text -----**<br>


**Barrett or Montgomery reduction** 

**[XL21]** Y. Xing and S. Li, _“_ A Compact Hardware Implementation of CCA-Secure Key Exchange Mechanism CRYSTALS-KYBER on FPGA _“, 2021_ 

**21** 

## Polynomial multiplication in ML-KEM 

**==> picture [172 x 50] intentionally omitted <==**

## 𝑛 ➢ Incomplete NTT : Factorize modulo 𝑋[𝑛] + 1 into 2[polynomials of ][𝑑𝑒𝑔𝑟𝑒𝑒1][.] 

**==> picture [270 x 189] intentionally omitted <==**

**==> picture [592 x 222] intentionally omitted <==**

**----- Start of picture text -----**<br>
𝑋<br>(  𝑓0 + 𝑓1 )<br>Point-wise<br>Multiplication<br>2-way Karatsuba : ℎ0 = 𝑓0𝑔0 + 𝑓1𝑔1𝐾 ; ℎ1 = (𝑓0+𝑓1)(𝑔0+𝑔1) −(𝑓0𝑔0 + 𝑓1𝑔1)<br>**----- End of picture text -----**<br>


**7** 

## Polynomial multiplication in ML-KEM 

**==> picture [172 x 50] intentionally omitted <==**

## 𝑛 ➢ Incomplete NTT : Factorize modulo 𝑋[𝑛] + 1 into 2[polynomials of ][𝑑𝑒𝑔𝑟𝑒𝑒1][.] 

**==> picture [270 x 189] intentionally omitted <==**

**==> picture [548 x 222] intentionally omitted <==**

**----- Start of picture text -----**<br>
𝑋<br>1 )<br>Point-wise<br>Multiplication<br>2-way Karatsuba : ℎ0 = 𝑓0𝑔0 + 𝑓1𝑔1𝐾 ; ℎ1 = (𝑓0+𝑓1)(𝑔0+𝑔1) −(𝑓0𝑔0 + 𝑓1𝑔1)<br>**----- End of picture text -----**<br>


𝑋 ( 𝑓0 + 𝑓1 ) 

## ➢ Hardware State-of-the-Art 

- ❑ Example of fully configurable hardware design 

- ❑ Include CT, GS and PWM butterflies 

- ❑ Same polynomial ring → **easy to design** 

**==> picture [322 x 153] intentionally omitted <==**

**7** 

**==> picture [960 x 44] intentionally omitted <==**

# Frobenius Additive 3 FFT The alternative polynomial multiplication strategy for HQC 

## Frobenius Additive FFT (FAFFT) 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FFT-like Binary power-of-two polynomial multiplication 

❑ New polynomial basis using **Cantor basis** 

- ❑ Encode and Decode : **Frobenius map** reduce evaluation points 

**==> picture [757 x 218] intentionally omitted <==**

**----- Start of picture text -----**<br>
ℛ →ℛ 𝑚 ℛ 𝑚 →ℛ<br>2 2 2 2<br>**----- End of picture text -----**<br>


**8** 

**[CCK+18]** Chen, Cheng, Li et al. «Multiplying boolean Polynomials with Frobenius Partitions in Additive Fast Fourier Transform», 2018 

## Frobenius Additive FFT (FAFFT) 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FFT-like Binary power-of-two polynomial multiplication 

❑ New polynomial basis using **Cantor basis** 

- ❑ Encode and Decode : **Frobenius map** reduce evaluation points 

**==> picture [71 x 15] intentionally omitted <==**

**----- Start of picture text -----**<br>
ℛ →ℛ 𝑚<br>2 2<br>**----- End of picture text -----**<br>


**==> picture [71 x 15] intentionally omitted <==**

**----- Start of picture text -----**<br>
ℛ 𝑚 →ℛ<br>2 2<br>**----- End of picture text -----**<br>


## **Which operation we compute in practice ?** 

❑ ℛ 𝑚: = ℤ 2 2 𝑥/ 𝑔(𝑥) 

❑ 𝑚= 32 and 𝑥= 𝑥[32] + 𝑥[22] + 𝑥[2] + 𝑥+ 1 𝑔 

## **Carryless addition** 

ℎ= 𝑓⊕𝑔 

## **Modular carryless multiplication** 

- ℎ= 𝑓∗𝑔𝑚𝑜𝑑𝑔(𝑥) 

**==> picture [173 x 16] intentionally omitted <==**

**----- Start of picture text -----**<br>
Shift-and-Add strategy<br>**----- End of picture text -----**<br>


**8** 

**[CCK+18]** Chen, Cheng, Li et al. «Multiplying boolean Polynomials with Frobenius Partitions in Additive Fast Fourier Transform», 2018 

## HQC using FAFFT in software 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FAFFT profiling 

- ❑ Implementation in C, without ASM optimization 

- ❑ **Improved version** of FAFFT in BIKE **[CCK21]** 

- ❑ Adapt for HQC polynomial size 

   - ❑ HQC-128 : 𝟑𝟐𝟕𝟔𝟖bits 

   - ❑ HQC-192/256 : 𝟔𝟓𝟓𝟑𝟔bits 

## **FAFFT PROFILING CORTEX-A9 @125 MHZ** 

**==> picture [340 x 153] intentionally omitted <==**

**----- Start of picture text -----**<br>
47,9<br>23,9<br>11,9<br>9<br>4<br>1,7 1,6<br>2X BC 2X  2X FFT PWM IFFT DECODE IBC<br>ENCODE<br>CONTRIBUTION (%)<br>**----- End of picture text -----**<br>


**9** 

**[CCK21]** Chen et al, “Optimizing BIKE for the Intel Haswell and ARM Cortex-M4”, 2021 

## HQC using FAFFT in software 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FAFFT profiling 

- ❑ Implementation in C, without ASM optimization 

- ❑ **Improved version** of FAFFT in BIKE **[CCK21]** 

- ❑ Adapt for HQC polynomial size 

   - ❑ HQC-128 : 𝟑𝟐𝟕𝟔𝟖bits 

   - ❑ HQC-192/256 : 𝟔𝟓𝟓𝟑𝟔bits 

## ➢ HQC using FAFFT profiling 

## **FAFFT PROFILING CORTEX-A9 @125 MHZ** 

**==> picture [340 x 153] intentionally omitted <==**

**----- Start of picture text -----**<br>
47,9<br>23,9<br>11,9<br>9<br>4<br>1,7 1,6<br>2X BC 2X  2X FFT PWM IFFT DECODE IBC<br>ENCODE<br>CONTRIBUTION (%)<br>**----- End of picture text -----**<br>


- ❑ **First FAFFT integration in HQC** 

- ❑ Speed up **x3.7 / x5 / x8** for respective HQC-X 

## **Benchmark HQC-X ( Mcycles )** 

- ❑ **Baseline :** 2-way Karatsuba 

**==> picture [548 x 199] intentionally omitted <==**

**----- Start of picture text -----**<br>
KEM.KeyGen KEM.Encaps KEM.Decaps<br>600<br>483,4<br>500<br>400<br>314,6<br>300 262,4<br>200 171,9 155,8<br>100 58,9 91,9 85,1 54,4 69,1<br>28,9 7,3 15,5 27 15,8 33,3 17,7 38,4<br>0<br>Baseline Our proposal Baseline Our proposal Baseline Our proposal<br>HQC-128 HQC-192 HQC-256<br>**----- End of picture text -----**<br>


- ❑ **Our proposal :** FAFFT 

**9** 

**[CCK21]** Chen et al, “Optimizing BIKE for the Intel Haswell and ARM Cortex-M4”, 2021 

**==> picture [960 x 44] intentionally omitted <==**

# 4 Proposed sharing strategy The solution to manage different butterfly structures with different mathematical foundations 

## Super-Butterfly 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Challenges 

||**NTT in ML-KEM**|**FAFFT in HQC**|
|---|---|---|
|_Structure_|ℤ3329|ℛ232|
|_Coefficient size_|12-bits|32-bits|
|_Addition_|||
|_Subtraction_|Modulo q = 3329|Carryless (XOR)|
|_Multiplication_|Integer|Carryless|
|_└ Reduction_|Barrett|Shift-and-Add|



- ❑ **How to combine different butterfly structures ?** 

   - ❖ Different coefficient size 

- ❑ **How to combine different mathematical foundation ?** 

   - ❖ Integer vs Carryless 

   - ❖ Different reduction method 

## ➢ Solution 

**==> picture [244 x 218] intentionally omitted <==**

**==> picture [300 x 143] intentionally omitted <==**

**10** 

## Super-Butterfly 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Challenges 

|||**NTT in ML-KEM**|**FAFFT in HQC**|
|---|---|---|---|
||_Structure_|ℤ3329|ℛ232|
||_Coefficient size_|12-bits|32-bits|
||_Addition_<br>_Subtraction_|Modulo q = 3329|Carryless (XOR)|
||_Multiplication_|Integer|Carryless|
||_└ Reduction_|Barrett|Shift-and-Add|



- ❑ **How to combine different butterfly structures ?** 

   - ❖ Different coefficient size 

- ❑ **How to combine different mathematical foundation ?** 

   - ❖ Integer vs Carryless 

   - ❖ Different reduction method 

## ➢ Solution 

**==> picture [244 x 218] intentionally omitted <==**

❑ Data parallelism = 32 

**==> picture [356 x 164] intentionally omitted <==**

**==> picture [300 x 143] intentionally omitted <==**

## **Super-Butterfly** 

**2x NTT butterfly instances** 

**1x FAFFT butterfly instances** 

**10** 

## Agility on mathematical foundation 

## ➢ Agile Modular Arithmetics 

➢ Agile Modular Multiplier 

**==> picture [172 x 50] intentionally omitted <==**

**11** 

## Agility on mathematical foundation 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Agile Modular Arithmetics 

## ❑ **Carryless addition** → **XOR operation** 

## ❑ **Modular addtion and subtraction** 

- ❖ **Two’s complement to have only additions** 

**==> picture [459 x 97] intentionally omitted <==**

Result smaller than modulo q Result bigger than modulo q 

**11** 

## Agility on mathematical foundation 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Agile Modular Arithmetics 

## ➢ Agile Modular Multiplier 

## ❑ **Carryless addition** → **XOR operation** 

## ❑ **Modular addtion and subtraction** 

## ❑ **Hybrid 2-way Karatsuba** 

## ❑ _Schoolbook-based_ 𝑀𝑥 multiplier 

## ❖ **Two’s complement to have only additions** 

**==> picture [459 x 97] intentionally omitted <==**

**==> picture [407 x 146] intentionally omitted <==**

**==> picture [400 x 193] intentionally omitted <==**

**----- Start of picture text -----**<br>
Result smaller than modulo q<br>Result bigger than modulo q<br>**----- End of picture text -----**<br>


**==> picture [148 x 196] intentionally omitted <==**

**11** 

## PHOENIX 

**==> picture [172 x 50] intentionally omitted <==**

## _**Features**_ 

## ❑ **Loosely-coupled accelerator** 

- ❑ **Process Element :** Super-Butterfly valorisation 

- ❑ **Coefficient Generation :** Generate coefficient pairs to be processed 

- ❑ **Polynomial Memory :** Conflict-free memory **Constant Memory :** Different constant values 

- ❑ **Control Unit :** Orchestrate everything 

**==> picture [449 x 371] intentionally omitted <==**

**12** 

## PHOENIX 

**==> picture [172 x 50] intentionally omitted <==**

## _**Features**_ 

## ❑ **Loosely-coupled accelerator** 

- ❑ **Process Element :** Super-Butterfly valorisation 

- ❑ **Coefficient Generation :** Generate coefficient pairs to be processed 

- ❑ **Polynomial Memory :** Conflict-free memory **Constant Memory :** Different constant values 

- ❑ **Control Unit :** Orchestrate everything 

## **Further optimization for ML-KEM** 

- ❑ Vector-like polynomial multiplication 

- ❑ Addition of polynomial error 

**==> picture [361 x 68] intentionally omitted <==**

**----- Start of picture text -----**<br>
𝑡0 𝑎00 ⋯ 𝑎0(𝑘−1) 𝑠0 𝑒0<br>⋮ ⋮ ⋱ ⋮ ⋮ ⋮<br>𝑡𝑘−1 𝑎(𝑘−1)0 ⋯ 𝑎(𝑘−1)(𝑘−1) 𝑠𝑘−1 𝑒𝑘−1<br>**----- End of picture text -----**<br>


## → **Increase performance** 

## → **reducing communication overhead** 

**==> picture [449 x 371] intentionally omitted <==**

**12** 

**==> picture [960 x 44] intentionally omitted <==**

5 Results Crypto-Agility using PHOENIX for all NIST security levels 

## Resource utilization on FPGA 

**==> picture [172 x 50] intentionally omitted <==**

- ➢ System-on-Chip integration 

   - ❑ **Zybo-Z7 @125 MHz, Artix-7 FPGA** 

   - ❑ **AXI4-Lite system bus** 

   - ❑ **All NIST security levels** 

**==> picture [360 x 216] intentionally omitted <==**

**13** 

## Resource utilization on FPGA 

## ➢ System-on-Chip integration 

- ❑ **Zybo-Z7 @125 MHz, Artix-7 FPGA** 

- ❑ **AXI4-Lite system bus** 

- ❑ **All NIST security levels** 

**==> picture [172 x 50] intentionally omitted <==**

**==> picture [317 x 190] intentionally omitted <==**

## ➢ Resource comparison 

## **Observation** 

   - ❑ Absence of FAFFT HW implem 

   - ❑ NTT cycles aligned to state-of-the-art 

   - ❑ High-Speed vs Lightweight design 

   - ❑ Agility bring resource overhead 

- **[YMOS21]** Bisheh-Niasar et al, “High-Speed NTT-based Polynomial Multiplication Accelerator for CRYSTALS-Kyber Post-Quantum Cryptography”, 2021 

- **[IUH22]** Itabashi et al, “Efficient modular poly-nomial multiplier for NTT accelerator of Crystals-Kyber”, 2022 

- **[LTHW22]** Li et al, “Reconfigurable andhigh-efficiency polynomial multiplication accelerator for Crystals-Kyber.”, 2022 

- **[BNAMK21]** Bisheh-Niasa et al, “High-speed NTT-based polynomial multiplication accelerator for post-quantum cryptography”, 2021 

## NTT in Hardware 

**==> picture [357 x 185] intentionally omitted <==**

**----- Start of picture text -----**<br>
4000<br>x1.2<br>3000<br>x2.8 x2.1 x3.2<br>2000<br>1000<br>236<br>0<br>PHOENIX [YMOS21] [IUH22] [LTHW22] [BNAMK21]<br>NTT Cycles Slice Equivalent<br>**----- End of picture text -----**<br>


**13** 

## Performance using PHOENIX 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ ML-KEM 

- 𝑺𝑾 

- ❑ **Speed-up results** ~~**(**~~ 𝑺𝑾+𝑯𝑾 **[) ]**[due to different platforms] 

- ❑ [FSS20] uses tightly-coupled strategy for NTT 

- ❑ Comparing [WZZ+24] 

   - ❖ Loosely-coupled NTT 

   - ❖ Assembly optimization for FIPS202 

- ❑ **Promising results** → **system bus overhead** 

## Comparison for ML-KEM 768 ( speed-up ) 

**==> picture [390 x 180] intentionally omitted <==**

**----- Start of picture text -----**<br>
3<br>KEM.KeyGen KEM.Encaps KEM.Decaps<br>2,32<br>1,98<br>1,92<br>2<br>1,25 1,33 1,19 1,23 1,36<br>1,15<br>1<br>0<br>This Work [FSS20] [WZZ+24]<br>Cortex-A9 RISC-V<br>**----- End of picture text -----**<br>


**[FSS20]** Fritzmann et al, “RISQ-V: Tightly Coupled RISC-V Accelerators for Post-Quantum Cryptography”, 2020 **[WZZ+24]** Wang et al, “Optimized Hardware-Software Co-Design for Kyber and Dilithium on RISC-V SoC FPGA”, 2024 

**14** 

## Performance using PHOENIX 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ ML-KEM 

- 𝑺𝑾 

- ❑ **Speed-up results** ~~**(**~~ 𝑺𝑾+𝑯𝑾 **[) ]**[due to different platforms] 

- ❑ [FSS20] uses tightly-coupled strategy for NTT 

- ❑ Comparing [WZZ+24] 

   - ❖ Loosely-coupled NTT 

   - ❖ Assembly optimization for FIPS202 

- ❑ **Promising results** → **system bus overhead** 

## ➢ HQC 

- ❑ PHOENIX _accelerate_ **x2.3 / x2.4 / x2.0** baseline KEM FAFFT-based 

## **Further optimization for HQC (Optimized HQC)** 

- ❑ Same approach conducted in ML-KEM for NTT 

- ❑ Save some FFT but doubling public key size 

- ❑ Case scenario with static key 

- ❑ Speed up **x1.15** for Encaps / Decaps HQC levels 

## Comparison for ML-KEM 768 ( speed-up ) 

**==> picture [390 x 403] intentionally omitted <==**

**----- Start of picture text -----**<br>
3<br>KEM.KeyGen KEM.Encaps KEM.Decaps<br>2,32<br>1,98<br>1,92<br>2<br>1,25 1,33 1,19 1,23 1,36<br>1,15<br>1<br>0<br>This Work [FSS20] [WZZ+24]<br>Cortex-A9 RISC-V<br>PHOENIX in HQC-192 ( Mcycles )<br>75<br>KEM.KeyGen KEM.Encaps KEM.Decaps<br>54,4<br>50<br>33,3<br>25,2<br>25 23,7<br>15,8<br>13,7<br>10,9<br>6<br>0<br>0<br>SW FAFFT SW + PHOENIX Optimized HQC<br>**----- End of picture text -----**<br>


> **[FSS20]** Fritzmann et al, “RISQ-V: Tightly Coupled RISC-V Accelerators for Post-Quantum Cryptography”, 2020 **[WZZ+24]** Wang et al, “Optimized Hardware-Software Co-Design for Kyber and Dilithium on RISC-V SoC FPGA”, 2024 

**14** 

## Conclusion 

**==> picture [172 x 50] intentionally omitted <==**

## Crypto-Agility 

- ❑ The key to maintain PQC-based security 

- ❑ Need of sharing strategy for efficient implementation 

## Polynomial Multiplication 

- ❑ Alternative Frobenius AFFT improve current HQC bottleneck 

- ❑ Polynomial multiplication FFT-based for ML-KEM and HQC 

- ❑ **Challenge 1** : Combine different butterfly structures 

- ❑ **Challenge 2** : Combine different mathematical foundations 

- ❑ **PHOENIX valorizes Super-Butterfly design as challenges solution** 

**This work proves the existence of efficient sharing strategy on the new NIST KEM standards** 

## Ongoing Improvements 

- ❑ **PHOENIX < NTT + FAFFT (?)** 

- ❑ ML-KEM result suffers due to system bus overhead 

**15** 

## Resource utilization on FPGA 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Resource comparison with Hardware NTT 

**==> picture [521 x 127] intentionally omitted <==**

LUT 𝐹𝐹 SEC = + 4 8[+ 𝐵𝑅𝐴𝑀× 200 + 𝐷𝑆𝑃× 100] 

## FAFFT Background 

**==> picture [172 x 50] intentionally omitted <==**

Another possible way, found in the state-of-the-art, to perform polynomial multiplication in HQC is the AFFT, which is an FFT-based variant adapted to be used in the context of binary field. 

Before explaining this technique we have to introduce few mathematical concepts: 

- 2 

- **Cantor basis** : They are a set of (𝛽𝑖) satisfies 𝛽0 = 1, 𝛽𝑖 + 𝛽𝑖 = 𝛽𝑖−1 𝑓𝑜𝑟𝑖> 0. In pratice, it is a new polynomial basis for constructing a finite field as well as an FFT over the field 

- 𝑚−1 

- **Vanishing polynomials** : Given a basis (𝛽𝑖)𝑖=0 in the base field, its sequence of subspaces is 𝑉𝑖 ≔𝑠𝑝𝑎𝑛{𝛽0, 𝛽0, … , 𝛽𝑖−1} **.** Its subspace vanishing polynomials (𝑠𝑖) are Properties : 

**==> picture [121 x 42] intentionally omitted <==**

- (linearity) 𝑠𝑖 𝑥 contains only monomials in the form 𝑥[2][𝑘] 

- (minimal two terms) 𝑠𝑖 𝑥= 𝑥[2][𝑖] + x iff i is a power of 2 

- (recursivity) 𝑠𝑖 𝑥= 𝑠𝑖−12 𝑥+ 𝑠𝑖−1(𝑥) 

M. Chen, W. Li et al, “Faster Multiplication for Long Binary Polynomials”, 2017 

## Resources utilization of PHOENIX 

**==> picture [172 x 50] intentionally omitted <==**

**==> picture [505 x 299] intentionally omitted <==**

## Performance using PHOENIX 

**==> picture [172 x 50] intentionally omitted <==**

## ML-KEM 

**==> picture [578 x 175] intentionally omitted <==**

**==> picture [472 x 186] intentionally omitted <==**

HQC 

## HQC : Standard vs Optimized 

**==> picture [172 x 50] intentionally omitted <==**

**==> picture [631 x 153] intentionally omitted <==**

**==> picture [631 x 261] intentionally omitted <==**

