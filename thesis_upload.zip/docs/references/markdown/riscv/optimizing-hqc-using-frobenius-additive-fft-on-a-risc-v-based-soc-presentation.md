---
source_pdf: docs/references/pdf/riscv/!Optimizing HQC using Frobenius Additive FFT on a RISC-V-based SoC - Presentation.pdf
converted_at: 2026-05-29 22:41
conversion_time: 4.4s
tool: pymupdf4llm
---

**==> picture [152 x 151] intentionally omitted <==**

**==> picture [173 x 84] intentionally omitted <==**

**==> picture [124 x 97] intentionally omitted <==**

**==> picture [81 x 81] intentionally omitted <==**

## Optimizing HQC using Frobenius Additive FFT on a RISC-V-based System-on-Chip 

Antonio Ras, Mikael Carmona, Antoine Loiseau, Simon Pontié, Emanuele Valea, Guénaël Renault, Benjamin Smith 

**==> picture [355 x 170] intentionally omitted <==**

**----- Start of picture text -----**<br>
Antonio<br>RAS<br>PhD Candidate,  CEA-LETI<br>Security of Components Laboratory<br>(LSCO)<br>**----- End of picture text -----**<br>


**==> picture [80 x 31] intentionally omitted <==**

**Sixth PQC Standardization Conference** 25 September 2025 

## Agenda 

**1. HQC: a quantum-safe cryptosystem** 

**2. Improving multiplication operation 3. ANDROMEDA hardware solution 4. Experimental results 5. Conclusion** 

**2** 

## Agenda 

**1. HQC: a quantum-safe cryptosystem** 

**2. Improving multiplication operation** 

**3. ANDROMEDA hardware solution** 

**4. Experimental results** 

**5. Conclusion** 

**2** 

## HQC cryptosystem 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Hamming Quasi-Cyclic (HQC) 

- _Quasi-Cyclic Syndrome Decoding_ hard problem (NP-complete) 

- Based on error correcting code theory 

- Decode function has fixed correction bits capability 

**==> picture [564 x 124] intentionally omitted <==**

**----- Start of picture text -----**<br>
public key secret key<br>message message<br>codeword Add random ciphertext codeword<br>Encode Reduce Error Decode<br>Error<br>Encrypt (Alice) Noisy channel Decrypt (Bob)<br>**----- End of picture text -----**<br>


- Three different security levels 

**==> picture [264 x 65] intentionally omitted <==**

**3** 

## HQC cryptosystem 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Hamming Quasi-Cyclic (HQC) 

- _Quasi-Cyclic Syndrome Decoding_ hard problem (NP-complete) 

- Based on error correcting code theory 

- Decode function has fixed correction bits capability 

**==> picture [564 x 124] intentionally omitted <==**

**----- Start of picture text -----**<br>
public key secret key<br>message message<br>codeword Add random ciphertext codeword<br>Encode Reduce Error Decode<br>Error<br>Encrypt (Alice) Noisy channel Decrypt (Bob)<br>**----- End of picture text -----**<br>


- Three different security levels 

**==> picture [264 x 65] intentionally omitted <==**

## ➢ HQC software profiling 

- Identify operation’s bottleneck over HQC execution time 

- Profiling on RISC-V based platform 

**==> picture [338 x 139] intentionally omitted <==**

**----- Start of picture text -----**<br>
5%<br>Polynomial Multiplication<br>(Karatsuba algorithm)<br>Other<br>95%<br>**----- End of picture text -----**<br>


**3** 

## HQC cryptosystem 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ Hamming Quasi-Cyclic (HQC) 

- _Quasi-Cyclic Syndrome Decoding_ hard problem (NP-complete) 

- Based on error correcting code theory 

- Decode function has fixed correction bits capability 

**==> picture [564 x 124] intentionally omitted <==**

**----- Start of picture text -----**<br>
public key secret key<br>message message<br>codeword Add random ciphertext codeword<br>Encode Reduce Error Decode<br>Error<br>Encrypt (Alice) Noisy channel Decrypt (Bob)<br>**----- End of picture text -----**<br>


## ▪ Three different security levels 

**==> picture [264 x 65] intentionally omitted <==**

## ➢ HQC software profiling 

- Identify operation’s bottleneck over HQC execution time 

- Profiling on RISC-V based platform 

**==> picture [338 x 139] intentionally omitted <==**

**----- Start of picture text -----**<br>
5%<br>Polynomial Multiplication<br>(Karatsuba algorithm)<br>Other<br>95%<br>**----- End of picture text -----**<br>


**Our contribution** The alternative **Frobenius Additive FFT** for HQC polynomial multiplication and its first state-of-the-art **hardware implementation** ! 

**3** 

## Agenda 

**1. HQC: a quantum-safe cryptosystem** 

**2. Improving multiplication operation** 

**3. ANDROMEDA hardware solution** 

**4. Experimental results** 

**5. Conclusion** 

**4** 

## FFT-based polynomial multiplication 

**==> picture [172 x 50] intentionally omitted <==**

## **How to perform multiplication** 

- Evaluating input polynomials in a different domain using an evaluation points set → **FFT step** 

- Perform multiplication between evaluated points → **PWM step** 

- Interpolate back to get final result → **Inverse FFT (IFFT) step** 

**==> picture [272 x 140] intentionally omitted <==**

**==> picture [88 x 235] intentionally omitted <==**

**==> picture [43 x 36] intentionally omitted <==**

**==> picture [124 x 62] intentionally omitted <==**

**----- Start of picture text -----**<br>
Point-wise<br>Multiplication<br>**----- End of picture text -----**<br>


**==> picture [272 x 140] intentionally omitted <==**

**==> picture [43 x 34] intentionally omitted <==**

**==> picture [282 x 143] intentionally omitted <==**

**5** 

## FFT-based polynomial multiplication 

**==> picture [172 x 50] intentionally omitted <==**

## **How to perform multiplication** 

- Evaluating input polynomials in a different domain using an evaluation points set → **FFT step** 

- Perform multiplication between evaluated points → **PWM step** 

- Interpolate back to get final result → **Inverse FFT (IFFT) step** 

**==> picture [741 x 364] intentionally omitted <==**

**----- Start of picture text -----**<br>
Point-wise<br>Multiplication<br>FFT and IFFT are performed using different  processing elements,      and<br>**----- End of picture text -----**<br>


**5** 

## Frobenius Additive FFT (FAFFT) 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FFT-like Binary power-of-two polynomial multiplication 

- Alternative to Karatsuba approach to improve HQC performance 

- New polynomial basis using **Cantor basis** 

- Encode and Decode : **Frobenius map** reduce evaluation points 

**==> picture [757 x 218] intentionally omitted <==**

**----- Start of picture text -----**<br>
ℛ →ℛ 𝑚 ℛ →ℛ<br>2 2 2 [𝑚] 2<br>**----- End of picture text -----**<br>


**6** 

**[CCK+18]** Chen, Cheng, Li et al. «Multiplying boolean Polynomials with Frobenius Partitions in Additive Fast Fourier Transform», 2018 

## Frobenius Additive FFT (FAFFT) 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FFT-like Binary power-of-two polynomial multiplication 

- Alternative to Karatsuba approach to improve HQC performance 

- New polynomial basis using **Cantor basis** 

- Encode and Decode : **Frobenius map** reduce evaluation points 

ℛ →ℛ 𝑚 2 2 

## **Which operation we compute in practice ?** 

- ℛ2𝑚: = ℤ2 𝑥/ 𝑔(𝑥) 

- 𝑚= 32 and 𝑔 𝑥= 𝑥[32] + 𝑥[22] + 𝑥[2] + 𝑥+ 1 

## **Carryless addition** 

ℎ= 𝑓⊕𝑔 

**==> picture [71 x 15] intentionally omitted <==**

**----- Start of picture text -----**<br>
ℛ →ℛ<br>2 [𝑚] 2<br>**----- End of picture text -----**<br>


## **Modular carryless multiplication** 

ℎ= 𝑓∗𝑔𝑚𝑜𝑑𝑔(𝑥) 

**==> picture [173 x 16] intentionally omitted <==**

**----- Start of picture text -----**<br>
Shift-and-Add strategy<br>**----- End of picture text -----**<br>


**6** 

**[CCK+18]** Chen, Cheng, Li et al. «Multiplying boolean Polynomials with Frobenius Partitions in Additive Fast Fourier Transform», 2018 

## HQC using FAFFT in software 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FAFFT implementation 

## ➢ HQC using FAFFT in software 

- Implementation in C, without ASM optimization 

- ▪ Inspired by state-of-the-art solution **[CCK+18] [CCK21]** 

- ▪ **First state-of-the art FAFFT integration in HQC** 

- RISC-V based embedded platform 

- Result in number of clock cycles 

- **[AMAB+24]** as C baseline implementation on RISC-V platform 

- ▪ Speed up **3.52x / 4.98x / 8.08x** for respective HQC-X 

**==> picture [586 x 200] intentionally omitted <==**

> **[AMAB+24]** C. Aguilar, N. Aragon et al. «HQC (Hamming Quasi-Cyclic),», 2024 

> **[CCK+18]** Chen, Cheng, Li et al. «Multiplying boolean Polynomials with Frobenius Partitions in Additive Fast Fourier Transform», 2018 **[CCK21]** Chen et al, “Optimizing BIKE for the Intel Haswell and ARM Cortex-M4”, 2021 

**7** 

## Agenda 

**1. HQC: a quantum-safe cryptosystem** 

**2. Improving multiplication operation** 

**3. ANDROMEDA hardware solution** 

**4. Experimental results** 

**5. Conclusion** 

**8** 

## Accelerating FAFFT in hardware 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FAFFT profiling 

- Result in number of clock cycles 

- FFT-like and PWM steps around 75% of execution time 

- **Hardware-based acceleration strategy** 

**==> picture [322 x 159] intentionally omitted <==**

**9** 

## Accelerating FAFFT in hardware 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FAFFT profiling 

- Result in number of clock cycles 

- FFT-like and PWM steps around 75% of execution time 

- **Hardware-based acceleration strategy** 

**==> picture [322 x 159] intentionally omitted <==**

## ➢ Carry-Free Butterfly (CFB) 

- Configurable hardware design 

- Manage FFT, PWM and IFFT butterfly 

- Two carryless operations 

- Karatsuba-based multiplier approach 

**==> picture [271 x 173] intentionally omitted <==**

**9** 

## Accelerating FAFFT in hardware 

**==> picture [172 x 50] intentionally omitted <==**

## ➢ FAFFT profiling 

- Result in number of clock cycles 

- FFT-like and PWM steps around 75% of execution time 

- **Hardware-based acceleration strategy** 

**==> picture [322 x 159] intentionally omitted <==**

## ➢ Carry-Free Butterfly (CFB) 

- Configurable hardware design 

- Manage FFT, PWM and IFFT butterfly 

- Two carryless operations 

- Karatsuba-based multiplier approach 

   - 𝑎= (𝑎1, 𝑎0) 𝑏= (𝑏1, 𝑏0) 

   - 𝑧0 = 𝑎0 ×𝑀0 𝑏0 𝑧1 = 𝑎1 ×𝑀1 𝑏1 

   - 𝑧2 = [ 𝑎1 ⊕𝑎0 ×𝑀2 𝑏1 ⊕𝑏0 ] ⊕𝑧0 ⊕𝑧1 

- Schoolbook-based 𝑀 𝑥 multiplier 

**==> picture [346 x 207] intentionally omitted <==**

**----- Start of picture text -----**<br>
Reduction  𝑔 𝑥<br>**----- End of picture text -----**<br>


**9** 

**==> picture [172 x 50] intentionally omitted <==**

## ANDROMEDA hardware design 

**==> picture [340 x 236] intentionally omitted <==**

## ➢ Design Rationale 

- **Loosely-coupled accelerator** 

- **Four main components** 

   - **Butterfly elements :** CFBs valorisation 

   - **Address generation :** Coefficient pairs selection 

   - **Memories:** Polynomial and Constants 

   - **Control Unit :** Orchestrate everything 

- Maximum frequency of **125 MHz, Artix-7 FPGA** 

**10** 

**==> picture [172 x 50] intentionally omitted <==**

## ANDROMEDA hardware design 

**==> picture [340 x 236] intentionally omitted <==**

## ➢ Design Rationale 

- **Loosely-coupled accelerator** 

- **Four main components** 

   - **Butterfly elements :** CFBs valorisation 

   - **Address generation :** Coefficient pairs selection 

   - **Memories:** Polynomial and Constants 

   - **Control Unit :** Orchestrate everything 

- Maximum frequency of **125 MHz, Artix-7 FPGA** 

## ➢ System-on-Chip integration 

- **RISC-V based system on chip on Kintex-7 FPGA** 

- 256 KB data and instruction memory 

- OBI system bus 

- All NIST security levels 

**==> picture [304 x 179] intentionally omitted <==**

**10** 

## Agenda 

**1. HQC: a quantum-safe cryptosystem** 

**2. Improving multiplication operation** 

**3. ANDROMEDA hardware solution** 

**4. Experimental results** 

**5. Conclusion** 

**11** 

## Experimental results 

**==> picture [172 x 50] intentionally omitted <==**

## **Absence of existing hardware FAFFT implementation in state-of-the-art** 

## ➢ HQC Performance 

- Result in number of clock cycles 

- ▪ **[AMAB+24]** as C baseline implementation on RISC-V platform 

- ▪ Speed up **2.74x / 2.79x / 2.38x** over alternative HQC + FAFFT, in software, respective HQC-X 

- ▪ Overall acceleration of **9.64x / 13.87x / 19.22x** over baseline HQC 

**==> picture [449 x 194] intentionally omitted <==**

**12** 

**[AMAB+24]** C. Aguilar, N. Aragon et al. «HQC (Hamming Quasi-Cyclic),», 2024 

## Experimental results 

**==> picture [172 x 50] intentionally omitted <==**

## **Absence of existing hardware FAFFT implementation in state-of-the-art** 

## ➢ HQC Performance 

- Result in number of clock cycles 

- **[AMAB+24]** as C baseline implementation on RISC-V platform 

- Speed up **2.74x / 2.79x / 2.38x** over alternative HQC + FAFFT, in software, respective HQC-X 

- Overall acceleration of **9.64x / 13.87x / 19.22x** over baseline HQC 

**==> picture [449 x 194] intentionally omitted <==**

## ➢ ANDROMEDA hardware resources 

- Our two configurable CFB design only accounts for 14% of total resource utilization 

**==> picture [361 x 72] intentionally omitted <==**

**12** 

**[AMAB+24]** C. Aguilar, N. Aragon et al. «HQC (Hamming Quasi-Cyclic),», 2024 

## Agenda 

**1. HQC: a quantum-safe cryptosystem 2. Improving multiplication operation** 

**3. ANDROMEDA hardware solution** 

**4. Experimental results** 

**5. Conclusion** 

**13** 

## Conclusion 

**==> picture [172 x 50] intentionally omitted <==**

## Quantum-safe transition 

- Current public-key cryptography weak against quantum computer 

- Future NIST standard scheme : **Hamming Quasi-Cyclic (HQC)** 

- Alternative method for the main HQC’s bottleneck : **Polynomial Multiplication** 

## Our contribution 

- Implementation and integration of **Frobenius Additive FFT (FAFFT) in HQC** 

- Dedicated hardware design, **ANDROMEDA** , targeting main FAFFT’s bottleneck 

- Performance improvements for software-only and hardware-software co-design scenario in RISC-V based System-on-Chip 

- This work has been published in the Digital System Design (DSD) 2025 conference 

**14** 

## Conclusion 

**==> picture [172 x 50] intentionally omitted <==**

## Quantum-safe transition 

- Current public-key cryptography weak against quantum computer 

- Future NIST standard scheme : **Hamming Quasi-Cyclic (HQC)** 

- Alternative method for the main HQC’s bottleneck : **Polynomial Multiplication** 

## Our contribution 

- Implementation and integration of **Frobenius Additive FFT (FAFFT) in HQC** 

- Dedicated hardware design, **ANDROMEDA** , targeting main FAFFT’s bottleneck 

- Performance improvements for software-only and hardware-software co-design scenario in RISC-V based System-on-Chip 

- This work has been published in the Digital System Design (DSD) 2025 conference 

## Ongoing work 

- Hardware-resources sharing on crypto-agility application between **HQC** and **ML-KEM** 

**14** 

## Crypto-agility: ML-KEM & HQC 

**==> picture [172 x 50] intentionally omitted <==**

## Sharing strategy 

Polynomial multiplication operations: 

- _**Frobenius Additive FFT**_ **(FAFFT) for HQC** 

- ▪ _**Number-Theoretic-Transform**_ **(NTT) for ML-KEM** 

**==> picture [406 x 148] intentionally omitted <==**

**15** 

## Crypto-agility: ML-KEM & HQC 

**==> picture [172 x 50] intentionally omitted <==**

## Sharing strategy 

Polynomial multiplication operations: 

- _**Frobenius Additive FFT**_ **(FAFFT) for HQC** 

- _**Number-Theoretic-Transform**_ **(NTT) for ML-KEM** 

## Hardware proposal 

**==> picture [406 x 148] intentionally omitted <==**

## **Super-Butterfly:** 

- Configurable hardware design for butterfly elements execution 

- Carry-Free Butterfly (HQC) and NTT-based design (ML-KEM) 

- **Goal:** Hardware-resource saving respect to standardalone designs 

**15** 

## Crypto-agility: ML-KEM & HQC 

**==> picture [172 x 50] intentionally omitted <==**

## Sharing strategy 

Polynomial multiplication operations: 

- _**Frobenius Additive FFT**_ **(FAFFT) for HQC** 

- _**Number-Theoretic-Transform**_ **(NTT) for ML-KEM** 

## Hardware proposal 

**==> picture [406 x 148] intentionally omitted <==**

## **Super-Butterfly:** 

- Configurable hardware design for butterfly elements execution 

- Carry-Free Butterfly (HQC) and NTT-based design (ML-KEM) 

- **Goal:** Hardware-resource saving respect to standardalone designs 

## **PHOENIX:** 

- Loosely-coupled accelerator for FAFFT and NTT operation 

- Super-butterfly valorisation 

**==> picture [71 x 71] intentionally omitted <==**

**Ras et al** , «PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC» 

**==> picture [332 x 266] intentionally omitted <==**

**15** 

## Crypto-agility: ML-KEM & HQC 

**==> picture [172 x 50] intentionally omitted <==**

## Sharing strategy 

Polynomial multiplication operations: 

- _**Frobenius Additive FFT**_ **(FAFFT) for HQC** 

- _**Number-Theoretic-Transform**_ **(NTT) for ML-KEM** 

## Hardware proposal 

**==> picture [406 x 148] intentionally omitted <==**

## **Super-Butterfly:** 

- Configurable hardware design for butterfly elements execution 

- Carry-Free Butterfly (HQC) and NTT-based design (ML-KEM) 

- **Goal:** Hardware-resource saving respect to standardalone designs 

## **PHOENIX:** 

- Loosely-coupled accelerator for FAFFT and NTT operation 

- Super-butterfly valorisation 

**==> picture [71 x 71] intentionally omitted <==**

**Ras et al** , «PHOENIX: Crypto-Agile Hardware Sharing for ML-KEM and HQC» 

▪ **New result will be available soon!** 

**==> picture [332 x 266] intentionally omitted <==**

**15** 

