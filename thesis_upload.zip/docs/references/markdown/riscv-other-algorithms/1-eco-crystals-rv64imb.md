---
source_pdf: docs/references/pdf/riscv-other-algorithms/1_ECO-CRYSTALS - RV64IMB.pdf
converted_at: 2026-05-31 10:01
conversion_time: 11.3s
tool: pymupdf4llm
---

## ECO-CRYSTALS: Efficient Cryptography CRYSTALS on Standard RISC-V ISA 

Xinyi Ji _[∗]_ , Jiankuo Dong _[∗]_ , Junhao Huang _[†‡]_ , Zhijian Yuan _[∗]_ , Wangchen Dai _[§]_ , Fu Xiao _[∗]_ , Jingqiang Lin _[¶]_ 

> _∗_ School of Computer Science, Nanjing University of Posts and Telecommunications, Nanjing, China 

> _†_ Department of Computer Science, BNU-HKBU United International College, Zhuhai, China 

> _‡_ Department of Computer Science, Hong Kong Baptist University, Hong Kong, China 

> _§_ School of Cyber Science and Technology, SUN YAT-SEN University, Hangzhou, China. 

> _¶_ School of Cyber Security, University of Science and Technology of China, Hefei, China. 

_**Abstract**_ **—The field of post-quantum cryptography (PQC) is continuously evolving. Many researchers are exploring efficient PQC implementation on various platforms, including x86, ARM, FPGA, GPU, etc. In this paper, we present an Efficient CryptOgraphy CRYSTALS (ECO-CRYSTALS) implementation on standard 64-bit RISC-V Instruction Set Architecture (ISA). The target schemes are two winners of the National Institute of Standards and Technology (NIST) PQC competition: CRYSTALSKyber and CRYSTALS-Dilithium, where the two most timeconsuming operations are Keccak and polynomial multiplication. Notably, this paper is the first highly-optimized assembly software implementation to deploy Kyber and Dilithium on the 64-bit RISC-V ISA. Firstly, we propose a better scheduling strategy for Keccak, which is specifically tailored for the 64-bit dualissue RISC-V architecture. Our 24-round Keccak permutation (Keccak-** _p_ **[1600,24]) achieves a 59.18% speed-up compared to the reference implementation. Secondly, we apply two modular arithmetic (Montgomery arithmetic and Plantard arithmetic) in the polynomial multiplication of Kyber and Dilithium to get a better lazy reduction. Then, we propose a flexible dual-instructionissue scheme of Number Theoretic Transform (NTT). As for the matrix-vector multiplication, we introduce a row-to-column processing methodology to minimize the expensive memory access operations. Compared to the reference implementation, we obtain a speedup of 53.85%** ∼ **85.57% for NTT, matrix-vector multiplication, and INTT in our ECO-CRYSTALS. Finally, our ECOCRYSTALS implementation for key generation, encapsulation, and decapsulation in Kyber achieves 399k, 448k, and 479k cycles respectively, achieving speedups of 60.82%, 63.93%, and 65.56% compared to the NIST reference implementation. Similarly, our ECO-CRYSTALS implementation for key generation, sign, and verify in Dilithium reaches 1 364k, 3 191k, and 1 369k cycles, showcasing speedups of 54.84%, 64.98%, and 57.20%, respectively.** 

_**Index Terms**_ **—PQC, Kyber, Dilithium, RISC-V, Keccak, Matrix-vector multiplication** 

This work was supported in part by Major Science and Technology Demonstration Project of Jiangsu Provincial Key R & D Program under Grant No. BE2022798, in part by the National Natural Science Foundation of China under Grant No. 62302238, in part by the Natural Science Foundation of Jiangsu Province under Grant No. BK20220388, in part by the Natural Science Research Project of Colleges and Universities in Jiangsu Province under Grant No. 22KJB520004, in part by the China Postdoctoral Science Foundation under Grant No. 2022M711689, in part by the Postgraduate Research and Practice Innovation Program of Jiangsu Province under Grant No. KYCX23 1079. _Corresponding author: Fu Xiao._ 

## I. INTRODUCTION 

The rapid advancement of quantum computers presents a significant threat to modern cryptography due to their formidable attack capabilities. Shor’s algorithm [1] based on quantum computers provided an exponential speedup in cracking the discrete logarithmic and large integer factorization problems in polynomial time. Consequently, the security of public-key cryptographic algorithms, reliant on the protection of private keys, is compromised. To guarantee the secure implementation of public-key cryptography, there is an urgent demand for novel algorithms capable of withstanding both quantum and classical attacks. The post-quantum cryptography (PQC) is investigated to supersede the current public-key cryptosystems to cope with the quantum challenge. The National Institute of Standards and Technology (NIST) has launched a competition to standardize post-quantum cryptosystems. This competition is now in its fourth round, with three algorithms (CRYSTALS-DILITHIUM [2], FALCON [3], SPHINCS+ [4]) being selected to be standardized for digital signature algorithms and one algorithm (CRYSTALS-KYBER [5]) being standardized for the key encapsulation mechanism. Kyber and Dilithium are a cryptographic suite for algebraic lattices. 

The performance of Kyber and Dilithium has garnered significant attention during the NIST PQC Standardization Process. Researchers have explored various optimization strategies to enhance the efficiency of computationally intensive operations in lattice-based cryptography on ARM [6] [7] [8] [9] [10] [11] [12], AVX2 [13] [14], and GPU [15] [16], etc. Sanal et al. [17] was the first optimized implementation of Kyber on 64-bit ARM processors, optimizing vectorized operations and accelerating symmetric functions through cryptography extension. Becker et al. [7] shortened the canonical implementation by eliminating explicit rotations to implement the Keccak permutation on the A-profile of the ARM architecture. Abdulrahman et al. [18] implemented NTT instances on the ARMv8.1-M+Helium and AArch64+Neon architectures. Ye et al. [19] designed novel Single-Instruction-Multiple-Data (SIMD) instructions and utilized dual-issue techniques on CV32E40P to optimize the polynomial operations in 256-bit mode. 

**Our Contribution.** RISC-V, an open-source Instruction Set 

Architecture (ISA), is gaining attention from academia and industry due to its modular design and flexibility. While the existing platforms mainly concentrate on the ARM architecture [7] [18] and the efficient SIMD RISC-V processor [19], the implementation of CRYSTALS lacks support for 64-bit RISCV platforms. Moreover, while most research in PQC focuses on polynomial multiplication, Keccak has received comparatively less attention. Faced with these problems, we propose the first efficient PQC software implementations (Kyber1024 and Dilithium5) targeting the RV64IMB ISA on VisionFive 2 with an in-order dual-issue CPU. The contributions of the paper are summarized as follows. 

- Firstly, we present a better scheduling strategy for Keccak, specifically tailored for the RV64 dual-issue architecture. In addition to leveraging the efficient manipulation instructions **rori** and **andn** in RV64IMB to speed up Keccak, we refactor Keccak instruction sequences to eliminate data hazards in a dual-issue mode, thereby maximizing Keccak throughput and improving its performance. Notably, our approach ensures no memory accesses during the Keccak round. Our Keccak implementation achieves a 59.18% speed-up compared to the reference implementation. For other 64-bit platforms lacking **rori** and **andn** instruction, we also provide an efficient generic implementation that minimizes the number of **not** operations based on the lane complementing transform technique proposed in [20]. This alternative implementation results in a 51.51% speed-up compared to the reference. 

- Then, two optimized modular arithmetic (Montgomery arithmetic and Plantard arithmetic) are applied to CRYSTALS considering both instruction and memory efficiency. For polynomial arithmetic, we propose a flexible dual-instruction-issue scheme for NTT with careful register allocation and module planning. The shuffled data and interleaved instructions are designed to avoid data hazards. By introducing Montgomery arithmetic and Plantard arithmetic, we can achieve a more effective lazy reduction. After a more advanced range analysis based on Montgomery multiplication proposed in [14], there is no reduction required after NTT in CRYSTALS either using Montgomery arithmetic or Plantard arithmetic. We achieve speedups of 76.76% and 85.57% for NTT and INTT in Kyber, respectively, compared to the reference implementation. The performance improvements are 75.65% and 78.96% for NTT and INTT in Dilithium. 

- Thirdly, for the matrix-vector multiplication, we present a row-to-column processing methodology to minimize expensive memory access operations by transforming the row-based approach to a column-based approach. In our matrix-vector multiplication, the number of loading _sk_ is reduced from _k × l × n_ times to _l × n_ times. We also eliminate the memory consumption for the precomputed values _sk_ 2 _t_ +1 _ζ_[2] _[br]_[7][(] _[t]_[)+1] (0 _≤_ t _<_ 128) and the precomputed values _sk_ 2 _t_ +1 _ζ_[2] _[br]_[7][(] _[t]_[)+1] is multiplied at 

once by all related computations rather than duplicate loading them following by the redundant loading _sk_ . In the _k_ -th polynomial multiplication, compared to the reference implementation, we obtain speedups of 78.71% and 53.85% for matrix-vector multiplication in Kyber and Dilithium, respectively. 

This paper is the first highly-optimized assembly software implementation to deploy Kyber and Dilithium on the 64-bit RISC-V ISA. By integrating optimizations across core operations (Keccak, NTT and matrix-vector multiplication), our ECO-CRYSTALS of key generation, encapsulation, and decapsulation in Kyber with Plantard arithmetic outperform the NIST reference implementation with a speedup of 60.82%∼65.56%. Our ECO-CRYSTALS of key generation, sign, and verify in Dilithium with Plantard arithmetic outperform the NIST reference implementation with a speedup of 54.84%∼64.98%. Due to the lack of experiments with 64-bit RISC-V ISA implementations, we also compare our ECO-CRYSTALS with the existing implementations on 32-bit or 64-bit microprocessors. Overall, our ECO-CRYSTALS outperform the implementation on 32-bit RISC-V [10] by 8.44 _×_ ∼9.90 _×_ and the implementation on 32-bit ARM Cortex-M4 [11] by 2.18 _×_ ∼2.98 _×_ . However, compared to the implementations on the 64-bit triple-issue out-of-order architecture Cortex-A75 [17] and the state-ofthe-art hardware/software implementations on 32-bit platforms CV32E40P [19], our ECO-CRYSTALS are 1.65 _×_ ∼1.77 _×_ and 1.96 _×_ ∼2.92 _×_ slower than the work in [17] and [19], respectively. However, we believe it is normal for our implementation to be slower than theirs because their platforms have more powerful SIMD instruction set than ours. 

The remainder of the paper is structured as follows. Section 2 introduces fundamental preparatory knowledge. Section 3 describes the efficient Keccak implementation designed on the RV64 dual-issue architecture. Section 4 outlines our dedicated optimization implementation scheme of Kyber and Dilithium on RISC-V ISA. Section 5 presents the experimental results. 

## II. PRELIMINARY KNOWLEDGE 

In this section, the Cryptographic Suite for Algebraic Lattices (Kyber and Dilithium) is briefly described. Then, the related time-consuming operations are given. Finally, we introduce the basic knowledge of the RISC-V architecture. 

## _A. The Cryptographic Suite for Algebraic Lattices_ 

Two cryptographic primitives make up the cryptographic suite for algebraic lattices, Kyber and Dilithium, respectively. _1) Kyber:_ Kyber is an IND-CCA2-secure keyencapsulation mechanism (Kyber.CCAKEM) from an INDCPA-secure public-key encryption scheme (Kyber.CPAPKE). It is equipped with 3 parameter sets, namely Kyber512, Kyber768, and Kyber1024, to provide different levels of security. The length of plaintext _n_ is set to 256 and parameter _k_ is the degree of the polynomial matrix or vector. We usually change _k_ to scale security to different levels, where _k_ equals 2, 3, and 4 respectively. All of the symmetric primitives 

with functions are instantiated from the FIPS 202 standard. Kyber.CCAKEM consists of three parts: key generation, encapsulation, and decapsulation. 

_2) Dilithium:_ Dilithium is an EUF-CMA-secure digital signature algorithm which is based on Fiat-Shamir with Aborts [21] approach. Dilithium uses 3 parameter sets, Dilithium2, Dilithium3, and Dilithium5. The only way to scale the security of Dilithium is by changing the values of ( _k, l_ ), where ( _k, l_ ) equals (4,4), (6,5), and (8,7) respectively. All of the symmetric primitives with functions are instantiated from the FIPS 202 standard. All algebraic operations are assumed to be over the polynomial ring _Rq_ . The general framework of Dilithium consists of three parts: key generation, signing, and verification. 

## _B. Keccak_ 

Keccak is the new standard for hash functions, having won the SHA-3 competition [20] of NIST in 2012. It is a big family consisting of four cryptographic hash functions (SHA3-224, SHA3-256, SHA3-384, and SHA3-512) and two extendable output functions (SHAKE-128 and SHAKE-256). Its main structure is the sponge structure with innovative Keccak- _f_ permutation as the underlying function and multi-rate padding as the padding rule. The width of the permutation _b_ and the number of iterations _nr_ is denoted by Keccak- _p_ [ _b_ , _nr_ ], where _b ∈{_ 25 _,_ 50 _,_ 100 _,_ 200 _,_ 400 _,_ 800 _,_ 1600 _}_ comprise the state and _nr_ is a positive integer. Input and output states of the step mappings are represented as arrays of bits with dimensions 5- by-5-by- _w_ , where _w_ is _b/_ 25. The six hash functions of Keccak can be conceptually understood as different ways or modes in which the Keccak- _p_ [1600,24] permutation is used. 

A Keccak- _f_ round consists of five step mappings called _θ_ , _ρ_ , _ψ_ , _χ_ and _ι_ . The pseudocode of five step mappings in a round of Keccak- _f_ [1600] is shown in Algorithm 1. _A_ [ _x, y_ ] represents a specific lane in the permutation state. _C_ [ _x_ ], _D_ [ _x_ ] and _B_ [ _x, y_ ] are intermediate variables. The symbols **xor** , **not** and **and** denote the bitwise exclusive, the bitwise complement and the bitwise AND operation, respectively. The goal of ROL( _a_ , _offset_ ) is to move bit _a_ from native position _i_ to position _i_ + _offset_ . The constants _r_ [ _x, y_ ] are specified in a table and RC is a round constant with a different value in each round. 

## _C. Modular Arithmetic_ 

The goal of modular arithmetic is to limit the magnitude of the coefficients. The symbol [ _x_ ] _l′_ in Algorithm 2 and Algorithm 3 denotes _x >> l[′]_ , while [ _x_ ] _[l][′]_ denotes _x_ mod 2 _[l][′]_ , where _l[′]_ denotes machine word size 16 _,_ 32 or 64. It is commonly applied following arithmetic operations, such as multiplication or addition. Kyber and Dilithium employ the Montgomery algorithm [22] after multiplying with a precomputed root of unity. The Barrett reduction [23] is utilized to mitigate overflow after the adding operation. To ensure the accuracy of the reduced values as representatives, the precomputed roots incorporate the Montgomery factor. 

Compared to the state-of-the-art signed Montgomery arithmetic, Huang et al. [9] and Aoki et al. [12] proposed two 

**Algorithm 1:** A Keccak- _f_ round 

**==> picture [217 x 290] intentionally omitted <==**

variants of Plantard arithmetic [24] for LBC schemes. [12] used rounding operations for which there were no corresponding integer instructions on RISC-V. [10] enlarged the input range of Plantard arithmetic which enables more effective lazy reduction strategies in NTT/INTT. 

**Algorithm 2:** Signed Montgomery multiplication [13] 

**Input:** Two signed integers _a_ , _b_ , and _ab ∈_ [- _q_ 2 _[l][′][−]_[1] , _q_ 2 _[l][′][−]_[1] ), _q <_ 2 _[l][′][−]_[1] . **Output:** _r ≡ ab_ 2 _[−][l][′]_ mod _q_ , _r ∈_ (- _q_ , _q_ ). 1: _c_ = _ab_ = _c_ 12 _[l][′]_ + _c_ 0 2: _m_ = [ _c_ 0 _q[−]_[1] ]2 _l′_ 3: _t_ 1 = [ _mq_ ] _[l][′]_ 4: _r_ = _c_ 1 _− t_ 1 

## **Algorithm 3:** Plantard multiplication [10] 

|**Input:** Two signed integers _a_, _b_, and _ab ∈_(_q_2_l′ −q_2_l′_+_α_,<br>22_l′ −q_2_l′_+_α_), _q <_2_l′−α−_1, _q′_ =_q−_1 mod_±_ 22_l′_.<br>**Output:** _r_ = _ab_(_−_2_−_2_l′_) mod_± q_, _r ∈_[- _q_+1<br>2 , _q_<br>2).<br>1: _r_ = [([[_abq′_]2_l′_]_l′_ + 2_α_)_q_]_l′_|
|---|



The primary distinction between [13] and [10] lies in the varying ranges of inputs and outputs. The input range of Plantard multiplication is at least 2 _[l][′]_[+] _[α] −_ 2 times bigger than Montgomery multiplication where _α_ = 3 for the modulus _q_ = 

TABLE I 

2[12] _−_ 2[10] + 2[8] + 1 in Kyber, _α_ = 8 for _q_ = 2[23] _−_ 2[13] + 1 in Dilithium, and _l[′]_ is equal to 16 and 32 in Kyber and Dilithium as shown in Algorithm 2 and Algorithm 3, respectively. 

## _D. Number Theoretic Transform_ 

NTT is a specialized version of the Fast Fourier Transform (FFT) that operates over finite fields or rings. The sequence of elements **f** = [ _f_ 0 _, f_ 1 _, ..., fn−_ 1] can be transformed into another sequence by formula **Fi** =[�] _[n] j_ =0 _[−]_[1] _[f][j][·][ ζ][ij]_[,][where] _[ζ]_ is the primitive _n_ -th roots of unity. It can be restored to the original sequence by formula _fj_ = _n[−]_[1][ �] _[n] i_ =0 _[−]_[1] **[F][i]** _[·]_[ (] _[ζ][ij]_[)] _[−]_[1][,] called INTT. The Cooley-Tukey algorithm (CT) [25] is a widely used algorithm for efficiently computing the Discrete Fourier Transform (DFT) and its variants NTT. The Chinese Remainder Theorem (CRT) [26] provides a way to reconstruct an integer from its residues modulo several pairwise coprime moduli. The Gentleman-Sande Algorithm (GS) [27] is used in INTT to restore the sequence. Using NTT and INTT, the product of two polynomial _f_ , _g_ is efficiently computed as _f ·g_ =NTT _[−]_[1] (NTT( _f_ ) _◦_ NTT( _g_ )), where _◦_ denotes the efficient pointwise multiplication. 

For Kyber, the polynomial ring is _Rq_ =[�] _i_[Z] _[q]_[[] _[X]_[]] _[/]_[(] _[X][n]_[+1)] where _q_ = 13 _·_ 2[8] +1 and _n_ = 256. The polynomial _X_[256] +1 of _R_ factors into 128 polynomials of degree 2 modulo _q_ where NTT domain representation exists primitive 256-th roots of unity _ζ_ = 17 modulo _q_ . The cyclotomic polynomial _X_[256] + 1 splits into _X_[2] _− ζ[i]_ modulo _q_ with _i_ = 1 _,_ 3 _,_ 5 _, ...,_ 255. The NTT of Kyber which has log _n −_ 1 layers is an incomplete implementation for 16-bit signed integers. 

For Dilithium, the polynomial ring is _Rq_ = � _i_[Z] _[q]_[[] _[X]_[]] _[/]_[(] _[X][n]_[+][1)][where] _[q]_ = 2[23] _−_ 2[13] + 1 and _N_ = 256. The polynomial _X_[256] + 1 of _R_ factors into 256 polynomials of degree 1 modulo _q_ where NTT domain representation exists primitive 512-th roots of unity _r_ = 1753 modulo _q_ . The cyclotomic polynomial _X_[256] + 1 splits into linear factors _X − r[i]_ modulo _q_ with _i_ = 1 _,_ 3 _,_ 5 _, ...,_ 511. The NTT of Dilithium with log _n_ layers is a complete implementation for 32-bit signed integers. 

## _E. RV64IMB ISA on VisionFive 2_ 

RV64IMB denotes a RISC-V processor architecture that embraces 64-bit functionalities (RV64). It encompasses fundamental integer operations (I), facilitates integer multiplication and division (M), and employs bit manipulation instructions (B) for fine-tuned bit-level operations. In Table I, we present a comprehensive demonstration of the fundamental integer operations in RV64IMB architecture, where sext stands for sign-extend, and S and U represent arithmetic shift right and logical shift right, respectively. 

Apart from the above instructions, load and store instructions are fundamental in transferring data between memory and registers, such as **lw** (Load Word) and **ld** (Load Double Word), **sw** (Store Word) and **sd** (Store Double Word). In particular, the **mulh** instruction is part of the integer multiplication extension. This instruction performs a signed 

RV64IMB ISA INSTRUCTION EXPLANATION 

||Instructions|Meanings|
|---|---|---|
|Basic operations|**add**rd,rs1,rs2<br>**mul**rd,rs1,rs2<br>**addw**rd,rs1,rs2<br>**mulw**rd,rs1,rs2|x[rd]=x[rs1] + x[rs2]<br>x[rd]=x[rs1]_×_x[rs2]<br>x[rd]=sext((x[rs1] + x[rs2])[31:0])<br>x[rd]=sext((x[rs1]_×_x[rs2])[31:0])|
|Shift operations|**sll**rd,rs1,rs2<br>**sra**rd,rs1,rs2<br>**srl**rd,rs1,rs2<br>**slliw**rd,rs1,shamt<br>**sraiw**rd,rs1,shamt<br>**srliw**rd,rs1,rs2|x[rd]=x[rs1]_<<_x[rs2]<br>x[rd]=x[rs1]_>>s_ x[rs2]<br>x[rd]=x[rs1]_>>u_ x[rs2]<br>x[rd]=sext((x[rs1]_<<_shamt)[31:0])<br>x[rd]=sext(x[rs1][31:0]_>>s_ shamt)<br>x[rd]=sext(x[rs1][31:0]_>>u_ shamt)|
|Logical operations|**and**rd,rs1,rs2<br>**or**rd,rs1,rs2<br>**xor**rd,rs1,rs2|x[rd]=x[rs1]&x[rs2]<br>x[rd]=x[rs1] — x[rs2]<br>x[rd]=x[rs1]_⊕_x[rs2]|
|Bit manipulation operations|**andn**rd,rs1,rs2<br>**orn**rd,rs1,rs2<br>**xnor**rd,rs1,rs2|x[rd]=x[rs1]& ˜x[rs2]<br>x[rd]=x[rs1]_|_ ˜x[rs2]<br>x[rd]=x[rs1]_⊕_˜x[rs2]|
|Bit permutation operations|**ror**rd,rs1,rs2<br>**rori**rd,rs1,shamt|x[rd]=(x[rs1]_<<_(64-x[rs2]))_|_(x[rs1]_>>_x[rs2])<br>x[rd]=(x[rs1]_<<_ (64-shamt)) _|_ (x[rs1]_>>_shamt)|



multiplication of two 64-bit integers and returns the upper 64 bits of the 128-bit result. 

Our target platform VisionFive 2 is an in-order dual-issue CPU with a non-trivial pipeline that is capable of executing up to two instructions per clock cycle. If no data hazards exist between a pair of instructions, they can be issued simultaneously in the same cycle. The execution unit is fully bypassed, allowing most instructions to have a one-cycle result latency. In particular, the load instructions and multiplication instructions generally take around 3 cycles. 

## III. OPTIMIZED KECCAK ON THE RV64IMB ARCHITECTURE 

Bertoni et al. [20], the Keccak team members, proposed a lane complementing transform to reduce the number of **not** operations from 25 to 5 in a round of Keccak- _f_ [1600]. They also optimized the addressing in the plane-by-plane processing to minimize the required memory for computing Keccak- _f_ . Nevertheless, reducing the number of **not** operations is not a primary concern on the RV64IMB architecture, as it includes the **andn** instruction. In this paper, we proposed two versions of Keccak implementation. The first version is based on the open-source Keccak implementation targeting the RV64 [28] with **rori** and **andn** . The second version is also based on the Keccak implementation in [28], but we managed to reduce the **not** instructions, and we believe it could be adapted to other 64-bit platforms without **rori** and **andn** instructions. 

In our experimental platform, a total of 29 registers within the 32 general-purpose registers can be programmable, excluding the hard-wired zero, the return address, and the stack point. While the stack pointer is programmable, we refrain from arbitrary changes to x2 due to program execution and memory management concerns. For the 25 fixed input and output states in Keccak- _p_ [1600,24], we employ 25 fixed registers (64-bit wide in RV64IMB) to represent each state. Among the remaining four registers (r0, r1, r2, r3) whose values can be changed arbitrarily, they are used to store the values of intermediate variables during each round ( _C_ 0- _C_ 3 in [28]). 

## _A. Implementation of Keccak on RV64IMB architecture_ 

**Better scheduling of Keccak on RV64IMB architecture** . We refactor the instruction execution order of 24 Keccak 

**==> picture [259 x 160] intentionally omitted <==**

**----- Start of picture text -----**<br>
// STEP // and STEP<br>... ...<br>1 2 3 4 5 6 7 8 9 10 11 12 13 14<br>// STEP<br>...<br>15 16 17 18 19 20 21 22 23 24 25 26 27<br>**----- End of picture text -----**<br>


Fig. 1. Refactor Keccak instruction execution order in a dual-issue mode 

rounds in a dual-issue mode. Fig. 1 shows the instruction flow in round _i_ where indexes represent array offsets and _i_ 0- _i_ 5 are immediate values. Each calculation is presented as a column. Gray dotted boxes are utilized to denote the dual-issue instructions. In our platform, **xor** can be dual-issued with other **xor** instructions. The instructions **rori** and **andn** are as well. All these instructions used in Keccak can operate in dual-issue mode when there are no data conflicts. Hence, the specifics of the logical operations are omitted. 

Firstly, we can fix _x_ as a constant and keep _y_ as a variable in the _θ_ step of Algorithm 1. When _C_ [0] = _A_ [0 _,_ 0] _⊕ A_ [0 _,_ 1] _⊕_ ... _⊕ A_ [0 _,_ 4] is computed, _A_ [0 _, y_ ] will be changed in the first **xor** operations with the parties of two columns where _y ∈{_ 0 _,_ 1 _,_ 2 _,_ 3 _,_ 4 _}_ , as demonstrated in [28]. The computations of r0, r1 and r2 are interlaced rather than executed sequentially in the _θ_ step, as the manual implementation is to perform line 1, line 4, and line 7 in that order. 

Then, the core we are studying supports the bit manipulation extension which comes with the **rori** and **andn** instructions that are very useful when implementing Keccak. By reducing the number of instructions needed in the implementation, the **rori** and **andn** offer substantial improvements in performance, code size, and energy efficiency, particularly for Keccak requiring intensive bitwise manipulation. For the _ρ_ and _ψ_ step in Fig. 1, the computation result _A_ [0 _,_ 1] in line 8 does not influence the source data _A_ [3 _,_ 3] in line 9. It shows that there is no direct data dependency between two instructions which can be scheduled and executed in parallel. 

Thirdly, for the _χ_ step, the four available registers can store four intermediate values making multiple **andn** instructions free from resource conflicts which can maximize processor throughput and performance according to the instruction scheduling. Hence, our refactored instructions reduce the waiting time from the last computation result and avoid data hazards, ensuring the program runs in dual-issue mode. And to be sure, there are no memory accesses during the keccak round (except RC in _ι_ step, it is inevitably), and all the interactive computation of data is performed in registers. 

## _B. Implementation of Keccak on other 64-bit platforms_ 

For other 64-bit platforms that do not support **rori** and **andn** instructions, the **rori** instruction can be split into one **slli** , one **srli** , and one **or** instruction, while the **andn** instruction can be split into one **not** and one **and** instruction. Notably, Bertoni et al. [20] provided the 64-bit C code implementation of the lane complementing transform without targeting the RV64IMB ISA. In particular, we apply the lane complementing transform proposed in [20] to the Keccak implementation for 64-bit RISC-V in [28]. It replaces 2 or 3 **and** operations with **or** operations and retains 5 **xor** operations where the number of **not** operations can be reduced from 600 to 120 in 24 rounds. When applying the mapping _χ_ to the 5 lanes in a plane _y_ , the **not** operations for each 5 lanes of the state in round _i_ are delineated in the subsequent five equations. 

**==> picture [223 x 11] intentionally omitted <==**

**==> picture [223 x 11] intentionally omitted <==**

**==> picture [226 x 26] intentionally omitted <==**

**==> picture [224 x 26] intentionally omitted <==**

**==> picture [226 x 26] intentionally omitted <==**

**Better scheduling of Keccak on other 64-bit platforms** . For one thing, the **rori** instruction is split into three instructions in the _ρ_ and _ψ_ step. We can interlace the **slli** , **srli** , and **or** instructions to avoid data hazards similar to the _θ_ step in Fig. 1. For another thing, we use Equation 1 as an example to demonstrate the calculation processes across every 5 lanes in the _χ_ step. As shown in Fig. 2, the **andn** instruction is broken down into two instructions in lines 6 and 8, separated by a single instruction to avoid stalls. Compared to the implementation of RV64IMB architecture, we use one more instruction on 64-bit platforms based on the lane complementing transform. Our process remains in a dual-issue mode to accommodate platforms that execute it out-of-order. Finally, our refactored instructions on other 64-bit platforms also eliminate memory accesses during 24 Keccak rounds. 

## IV. OPTIMIZED KYBER AND DILITHIUM ON THE RV64IMB ARCHITECTURE 

This section discusses the detailed optimization strategies for the polynomial and matrix-vector multiplication with Montgomery and Plantard arithmetic in Kyber1024 and Dilithium5. 

**==> picture [259 x 74] intentionally omitted <==**

**----- Start of picture text -----**<br>
the input of mapping<br>Equation (1)<br>1 2 3 4 5 6 7 8 9 10 11<br>**----- End of picture text -----**<br>


Fig. 2. Refactor Keccak instruction execution order on other 64-bit platforms 

**Algorithm 5:** Plantard multiplication by a constant implementation for Kyber 

|mplementation for Kyber|mplementation for Kyber|mplementation for Kyber|
|---|---|---|
|**Input:** A 16-bit integer _a ∈_[-215, 215), a 32-bit|||
|precomputed twiddle factor _ζ_.|||
|**Output:** _r_ = _aζ_(_−_2_−_2_l′_) mod_± q_, _r ∈_[- _q_+1<br>2 , _q_<br>2).|||
|1: **mulw** _r_, _a_, _ζ_|||
|2: **sraiw** _r_, _r_, 16|||
|3: **addiw** _r_, _r_, 8|||
|4: **mulw** _r_, _r_, _q_|||
|5: **sraiw** _r_, _r_, 16|||



## _A. Montgomery and Plantard arithmetic in Kyber and Dilithium_ 

For the choice of the Plantard algorithm, we compare two existing Plantard arithmetic in [10] and [12]. Since our target platform does not support the rounding operations required in [12], the Plantard arithmetic in [12] uses one more addition than [10]. Hence, we opt for [10]. We conduct a thorough comparison of the Montgomery arithmetic [13] and Plantard arithmetic [10], discussing from both instruction and memory perspectives. The detailed ISA is outlined in Algorithms 4, 5, 6, and 7. 

_1) An analysis of two arithmetic implementations in Kyber:_ The Montgomery arithmetic shown in [13] requires to compute a signed low product. For Kyber, this would need to fetch the low 16-bit result from a 32-bit register. Given the absence of explicit instruction for fetching the low 16 bits of 32-bit registers in the RISC-V ISA, we choose to multiply _q[−]_[1] by 2[16] to eliminate the high 16 bits of 32-bit registers after the **mulw** instruction rather than manually performing a 16-bit left shift followed by a 16-bit right shift. For the Plantard arithmetic, our 64-bit RISC-V platform does not support the 32-bit **mulh** instruction to multiply two 32-bit values and extract the high 32 bits of the product, and we can only implement the Plantard arithmetic in 5 instructions which is one instruction fewer than the Montgomery Multiplication. Compared to Algorithm 5, Algorithm 4 needs an extra temporary variable _t_ to store intermediate values and an extra 32-bit register to store _q[−]_[1] 2[16] . 

## **Algorithm 4:** Montgomery multiplication implementation for Kyber 

**Input:** Two 16-bit integers _a_ , _ζ_ and _aζ ∈_ [- _q_ 2[15] , _q_ 2[15] ). **Output:** _r_ = _aζ_ 2 _[−][l][′]_ mod _q_ , _r ∈_ (- _q_ , _q_ ). 1: **mulw** _r_ , _a_ , _ζ_ 2: **mulw** _t_ , _r_ , _q[−]_[1] 2[16] 3: **sraiw** _t_ , _t_ , 16 4: **mulw** _t_ , _t_ , _q_ 5: **subw** _r_ , _r_ , _t_ 6: **sraiw** _r_ , _r_ , 16 

_2) An analysis of two arithmetic implementations in Dilithium:_ Unlike Algorithm 4, the signed-low-product for 32-bit modulus can be directly implemented with **mulw** as shown in Algorithm 6, which saves the 64-bit product _t_ as a 32-bit word. As for the 32-bit Plantard arithmetic 

in Dilithium, similar to [10], we can multiply _q_ by _q_[32] to obtain the effective high 32-bit result with **mulh** instruction. Hence, we obtain a 4-instruction Plantard multiplication by a constant (Algorithm 7) for 32-bit modulus on the 64-bit RISCV platform which is one instruction fewer than Algorithm 6. Furthermore, compared to Algorithm 7, Algorithm 6 needs an extra temporary variable _t_ to store intermediate values and an extra register to store _q[−]_[1] . 

**Algorithm 6:** Montgomery multiplication implementation for Dilithium 

|ation for Dilithium|||
|---|---|---|
|**Input:** _r_ = _aζ_2_−l′_ mod _q_, _r ∈_(-_q_,_q_).|||
|**Output:** _r_ = _aζ_(_−_2_−_2_l′_) mod_± q_, _r ∈_[- <br>1: **mul** _r_, _a_, _ζ_<br>2: **mulw** _t_, _r_, _q−_1|_q_+1<br>2 , _q_<br>2).||
|3: **mul** _t_, _t_, _q_|||
|4: **sub** _r_, _r_, _t_|||
|5: **srai** _r_, _r_, 32|||



**Algorithm 7:** Plantard multiplication by a constant implementation for Dilithium 

|**Input:** A 32-bit integer _a ∈_[-231, 231), a 64-bit<br>precomputed twiddle factor _ζ_.|
|---|
|**Output:** _r_ = _aζ_(_−_2_−_2_l′_) mod_± q_, _r ∈_[- _q_+1<br>2 , _q_<br>2).|
|1: **mul** _r_, _a_, _ζ_|
|2: **srai** _r_, _r_, 32|
|3: **addi** _r_, _r_, 256<br>4: **mulh** _r_, _r_, _q_232|



_3) Montgomery multiplication VS Plantard multiplication:_ Table II shows the number of instructions and registers used in Montgomery and Plantard multiplication on RV64 ISA in Kyber and Dilithium. Regarding the number of instructions, Plantard multiplication requires 5 instructions in Kyber and 4 instructions in Dilithium, respectively, which are all one multiplication instruction fewer than Montgomery multiplication. Regarding the number of registers, excluding the input and output parameters and the twiddle factor, Montgomery multiplication uses two more registers than Plantard multiplication in Kyber and Dilithium, in which one is fixed to store 

a constant and another is used to store an intermediate value in Montgomery arithmetic. 

This extra register to store the intermediate value would ~~increase the re~~ gister pressure, especially in dual-issue mode. ~~Specifcally, w~~ hen the pre-allocation of registers is completed, ~~the fxed consta~~ nt in Montgomery multiplication can be reused. ~~However, the in~~ termediate value cannot be reused within a pair ~~of input param~~ eters ( _a_ 0 and _a_ 1) that are expected to execute ~~in dual-issue m~~ ode. To distinguish the results between _a_ 0 _ζ_ ~~and~~ ~~_a_ 1~~ ~~_ζ_ , we n~~ eed to use two different registers _t_ 0 and _t_ 1. Specifcally, it would require _i_ registers ( _t_ 0- _ti_ ) to compute _i_ Montgomery multiplications in dual-issue mode. In contrast, the Plantard multiplication does not need any additional registers to compute _i_ Plantard multiplications in dual-issue mode, which significantly reduces the register pressure. 

TABLE II 

~~C~~ OMPARISON OF NUMBER OF INSTRUCTIONS AND REGISTERS BETWEEN ~~MONTGOME~~ RY AND PLANTARD MULTIPLICATION ON RV64 ISA 

||Kyber|Montgomery multiplication|Plantard multiplication|
|---|---|---|---|
||MUL (*)|3|2|
||ADD (+/-)|1|1|
||SHIFT (_>>_)|2|2|
|#|of instructions<br># of registers|6<br>3|5<br>1|
||Dilithium|Montgomery multiplication|Plantard multiplication|
||MUL (*)<br>ADD (+/-)<br>SHIFT (_>>_)|3<br>1<br>1|2<br>1<br>1|
|#|of instructions<br># of registers|5<br>3|4<br>1|



## _B. NTT_ 

For the dimension-256 NTT, there are 128 pairs of butterfly operations in each layer ( _f_ = _f_ + ( _gζ_ ) _q_ , _g_ = _f −_ ( _gζ_ ) _q_ ). 

**Register allocation** . We adopt the 3+4 layer merging scheme for the 7-layer dimension-256 NTT in Kyber and the 4+4 layer merging strategy for the 8-layer dimension256 NT ~~T~~ in ~~D~~ ilithium. The redundant registers available in RISC-V ~~e~~ na ~~bl~~ e us to load 8 pairs of coefficients and the corresponding twiddle factors at once. For the given layers with a substantial quantity of twiddle factors, address entries of the twiddle factor array which also need to be placed in registers are utilized to differentiate the butterfly operations across layers. Our foundational principle lies in substituting ~~a~~ s many high-frequency occurrences of variables into registers ~~a~~ s possible, such as _q_ and _q[−]_[1] . 

**Module planning** . The butterfly operation can be split into three parts: the multiplication module _gζ_ , the reduction ~~m~~ odule ( _gζ_ ) _q_ (Algorithms in IV-A except the first line), and ~~t~~ he addition and subtraction (additive) module _f_ = _f_ +( _gζ_ ) _q_ , _g_ = _f −_ ( _gζ_ ) _q_ . For 8 pairs of coefficients, there are eight multiplication modules, eight reduction modules, and sixteen additive ~~m~~ od ~~ul~~ es. It can be seen that multiplication instructions have a t ~~hr~~ ou ~~gh~~ put of 1 and a 3-cycle latency [29], and multiplications cannot be dual-issued with other multiplications. It makes instruction scheduling an essential part of high-speed implementations. 

**==> picture [259 x 246] intentionally omitted <==**

**----- Start of picture text -----**<br>
layer 1 layer 2 layer 3<br>0 0 0<br>1 1 1<br>2 2 0<br>0 0<br>3 3 1<br>1 0<br>4 0 2<br>0 0<br>5 1 3<br>1 0<br>6 2 2<br>2 1 2 1<br>7 3 3<br>3 1 3 1<br>0 0 0 4 4<br>1 0 1 5 5<br>2 1 2 6 4<br>4 2<br>3 1 3 7 5<br>5 2<br>4 2 4 4 6<br>4 2<br>5 2 5 5 7<br>5 2<br>6 3 6 6 6<br>6 3 6 3<br>7 3 7 7 7<br>7 3 7 3<br>**----- End of picture text -----**<br>


Fig. 3. A flexible dual-instruction-issue scheme of NTT 

We present a flexible dual-instruction-issue scheme of NTT to avoid stalls as shown in Fig. 3 where the red, green, and blue boxes represent the multiplication module, the reduction module, and the additive module, respectively. The presence of two identical values with the same color in each column indicates that the two modules are dual-issue. The numbers represent the module operations of coefficients in each layer. Take the first three layers in NTT as an example, the group set _{fi_ +0 _, fi_ +16 _, ..., fi_ +240 _}_ , 0 _≤ i <_ 16, will be loaded into register r0-r15 in order. Once two of the multiplication modules in each layer have been completed, it is possible to advance to the reduction modules, without waiting for all the other multiplication modules in that layer to be completed. 

Note that all of this is predicated on the absence of data hazards. After the reduction module, a pair of additive modules with the same number need to perform _f_ = _f_ + ( _gζ_ ) _q_ , _g_ = _f −_ ( _gζ_ ) _q_ . It can be seen that _f_ will be changed in the first instruction which influences the source data of the second instruction. Hence, we shuffle the data for the 8 pairs of coefficients by using a temporary register to save a coefficient. For example, in layer 1, we can use r16 to pre-save the value of r7. Then, the register r7 can take the place of r0, thus making this formula (r7 = r0 + r8, r8 = r0 - r8) free of data conflicts. Data shuffling is performed in the additive module at each layer to ensure dual-issue capability. Ultimately, the coefficients in the registers are saved to the corresponding NTT array memory. 

Moreover, a continuous sequence of multiplication instructions would be ineffective. By interleaving the order of instructions, the multiplication module of the next layer (layer 2) can be alternated with the additive module of the former 

layer (layer 1) under the reasonable register allocation. When the multiplication module and the additive module appear simultaneously where there are no data hazards, they can be issued simultaneously by the processor and executed in dualissue mode. For example in layer 1, after the fourth pair of coefficients in the additive module is calculated, the number 0 in the multiplication module can be dual-issued with the number 5 in the additive module. Suppose the twiddle factors are not pre-loaded in the registers which are ready to multiply by the coefficients of number 0 in the multiplication module, in that case, we can load them before number 4 of the additive module rather than number 0 of the multiplication module to avoid data hazards. 

## _C. Matrix-vector Multiplication_ 

Many optimization techniques known as asymmetric multiplication [30] and accumulation technique [8] are used to speed up pointwise multiplication and matrix-vector multiplication. The asymmetric multiplication is only applicable to Kyber. It caches the _sk_ 2 _t_ +1 _ζ_[2] _[br]_[7][(] _[t]_[)+1] (0 _≤_ t _<_ 128) with a 16-bit array. The accumulation technique accumulates _k_ pointwise multiplication, reducing the number of modular multiplications. Finally, the _k_ -th pointwise algorithm performs modular multiplication by the sum of the products which can reduce ( _k −_ 1) _× n_ modular arithmetic. 

For the matrix-vector multiplication of Kyber and Dilithium, we can express it in a unified formula: 

## _pk_ [ _i_ ][ _t_ ] = _a_ [ _i_ ][ _j_ ][ _t_ ] _◦ sk_ [ _j_ ][ _t_ ] _, i ∈_ [0 _, k_ ) _, j ∈_ [0 _, l_ ) _, t ∈_ [0 _, n_ ) 

where _k_ is 4 and 8, _l_ is 4 and 7, in Kyber and Dilithium respectively. Note that we exclude the NTT and INTT computation in this process. The former implementations [10], [30] based on optimized techniques cache the _sk_ 2 _t_ +1 _ζ_[2] _[br]_[7][(] _[t]_[)+1] (0 _≤ t <_ 128) in memory when the first matrix-vector multiplication _pk_ [0][ _t_ ] (0 _≤ t <_ 256) is computed. The computation mode in the row ( _pk_ [0][ _t_ ], _pk_ [1][ _t_ ], ..., _pk_ [ _k−_ 1][ _t_ ]) would cause the _sk_ to be reloaded _k_ times despite saving the computation of _sk_ 2 _t_ +1 _ζ_[2] _[br]_[7][(] _[t]_[)+1] . Similarly, the cached memory _sk_ 2 _t_ +1 _ζ_[2] _[br]_[7][(] _[t]_[)+1] is reloaded _k −_ 1 times. 

We propose a row-to-column processing methodology of matrix-vector multiplication without duplicate loading and memory consumption. Fig. 4 shows the transformation from a row-based approach to a column-based approach. When the partial coefficients of _sk_ [ _j_ ][ _t_ ], such as 0 _≤ j < l_ , 0 _≤ t <_ 2, are loaded into the registers, we can compute the _sk_ [ _j_ ][1] _ζ_[2] _[br]_[7][(0)+1] (0 _≤ j < l_ ) and execute the matrix-vector multiplication with matrix _a_ [0][ _j_ ][ _t_ ] (0 _≤ j < l_ , 0 _≤ t <_ 256) to get the result of _pk_ [0][ _t_ ]. Note that we can not load too many coefficients at once since the limited register resources. Then, reuse the _sk_ [ _j_ ][1] _ζ_[2] _[br]_[7][(0)+1] to continue computing with the left coefficients of _a_ [ _i_ ][ _j_ ][ _t_ ] in matrix _A_ which is marked with a green arrow in Fig. 4. When all related computations with _sk_ [ _j_ ][1] _ζ_[2] _[br]_[7][(0)+1] are finished, the precomputed 

**==> picture [259 x 195] intentionally omitted <==**

**----- Start of picture text -----**<br>
No duplicate loading<br>Load coefficients in batches<br>...<br>pointwise multiplication<br>Save in columns<br>...<br>**----- End of picture text -----**<br>


Fig. 4. A row-to-column processing methodology of matrix-vector multiplication 

_sk_ [ _j_ ][1] _ζ_[2] _[br]_[7][(0)+1] will no longer be accessed and will be released. Finally, the results are saved to _pk_ like a column. 

In our processing methodology, each coefficient of _sk_ , _a_ , and _pk_ is only loaded once and the precomputed _sk_ [ _j_ ][2 _t_ + 1] _ζ_[2] _[br]_[7][(] _[t]_[)+1] do not consume memory, much less subsequently duplicate loading them following by duplicate loading _sk_ . Compared with the former implementations [10], [30], We reduce the number of loading _sk_ from _k × l × n_ to _l × n_ and there is no memory consumption for _sk_ [ _j_ ][2 _t_ + 1] _ζ_[2] _[br]_[7][(] _[t]_[)+1] . Note that there is no asymmetric multiplication in Dilithium in that we use a grey arrow to express it in Fig. 4. And, some dual-issue instructions are also possible in polynomial multiplication if the left registers are rich. 

## _D. Lazy Reduction_ 

In lazy reduction, instead of performing modular reduction after each basic operation, the reduction operation is postponed until it is necessary. To start, it is crucial to determine the specific contexts where reduction arithmetic is essential. Secondly, we have to specify the specific input and output ranges of two arithmetic. When employing Plantard multiplication by a constant whose value can be limited to [0, _q_ ), the input range of the coefficients can be extended to [2 _[l][′] −_ 2 _[l][′]_[+] _[α]_ ,2[2] _[l][′] /q−_ 2 _[l][′]_[+] _[α]_ ) which is [-137 _q_ ,230 _q_ ] in Kyber and [-130687 _q_ ,131456 _q_ ] in Dilithium. Notably, the Montgomery algorithm does not support this operation because even with a fixed constant, the coefficients remain within the 16-bit range, equivalent to the parameter type range. Table III shows the maximum boundary value of the modular arithmetic. 

_1) NTT:_ We introduce a more advanced range analysis for Montgomery multiplication [14]. The output coefficients of NTT are bounded by 16540 if the inputs are less than 3329 and the output coefficients of NTT are bounded by 42082400 if the inputs are less than 8380417. Two bounds are smaller than 4 _._ 97 _q_ and 5 _._ 03 _q_ in Kyber and Dilithium respectively. For 

## TABLE III 

THE MAXIMUM BOUNDARY VALUE OF THE MODULAR ARITHMETIC IN THE SPEED VERSION 

||Output of NTT|Output of matrix-vector multiplication|Input of INTT|
|---|---|---|---|
|Kyber|4_._97_q_ / 4_._5_q_|_q_ / 0_._5_q_|_q_ / 0_._5_q_|
|Dilithium|5_._03_q_ / 5_q_|_q_ / 0_._5_q_|_q_ / 0_._5_q_|



Kyber, the coefficients after NTT are increased to 4 _._ 97 _q_ and 4 _._ 5 _q_ for Montgomery and Plantard arithmetic. We disregarded the minor increase of 0.5 in the negative range of Plantard arithmetic as it was deemed negligible. For Dilithium, one variable is sampled uniformly in [0, _q_ ) by performing rejection sampling on an array of random bytes, and the other variable is obtained from NTT. The maximum values 5 _._ 03 _q_[2] and 5 _q_[2] are within the input range of Montgomery and Plantard multiplication, respectively. Hence, neither algorithms in Kyber and Dilithium need to be reduced. 

_2) Matrix-vector Multiplication:_ Our matrix-vector multiplication is based on [6] which ensured that the output range of the matrix-vector multiplication matches that of the multiˆ ˆ plication algorithm ( _h_[ˆ] 2 _i_ +1 = ( _f_[ˆ] 2 _ig_ 2 _i_ +1 + _f_[ˆ] 2 _i_ +1 _g_ 2 _i_ ) _q_ ). Notably, Dilithium has the polynomial of degree 1, which is unsuitable for the method in [6]. The _k_ -th pointwise multiplication with accumulation technique [8] performs modular multiplication by the sum of the products, thereby confining the output range of the pointwise algorithm to the same range as modular arithmetic which is discussed in IV-C. This technique has been used in Kyber in [10], [30]. For Dilithium, it can be seen that _q ×_ 5 _._ 03 _q × l_ and _q ×_ 5 _q × l_ are within the input range of Montgomery arithmetic (256 _q_[2] _<_ 2[31] _q <_ 257 _q_[2] ) and Plantard arithmetic (130687 _q_[2] _<_ 2[32] _q −_ 2[40] _q <_ 130688 _q_[2] ) in pointwise multiplication, respectively. We can accumulate the coefficients first and delay the modular reduction to the final pointwise multiplication using either Montgomery arithmetic or Plantard arithmetic. Even though the accumulation method produces a difference of _lq_ , it all reverts to the normal domain after the INTT operation. 

_3) INTT:_ For Kyber, the input coefficients of INTT are _q_ with Montgomery arithmetic which will increase to 16 _q_ in the fourth layer. The mind of [31] is not appliable to Montgomery arithmetic where [31] computed the Fermat number transformation modulo 257 while loading the coefficients to 32-bit registers in that the input range of Montgomery arithmetic is less than 2[15] _−_ 1. Not all coefficients in the fourth layer require performing modular reduction. Hence, we need to find the coefficients of 16 _q_ and some coefficients of 8 _q_ or 4 _q_ that may increase to 16 _q_ in the latter layer. Finally, the coefficients ( _fi_ +0, _fi_ +32, _fi_ +64, _fi_ +96, _fi_ +128, _fi_ +160, _fi_ +192, and _fi_ +224, 0 _≤ i <_ 16) are required to be reduced. When implementing Kyber with Plantard arithmetic, it is sufficient that the values would not exceed the input range of Plantard multiplication by a constant ([-137 _q_ ,230 _q_ ]) in INTT. The coefficients are unrestricted by input ranges and parameter types. Note that the limit of parameter type 16-bit is less than the limit of the input range. Even if coefficients exceed the parameter type, they can be loaded into 64-bit registers for more efficient lazy reduction. 

Hence, there is no reduction required with Plantard arithmetic in Kyber. For Dilithium, there is no reduction in INTT using either Montgomery arithmetic or Plantard arithmetic. 

Note that there are three reduction operations before checking the infinity norm of polynomials (chknorm function) to avoid revealing secret information in the signature of Dilithium, the coefficients require to be reduced to [- 6283009,6283007]. When using the Plantard arithmetic, the maximum values are _[q]_[which][are][within][the][range][of] 2[+ 2][19] [-6283009,6283007]. Hence, three reduction operations can be saved in the signature procedure. 

## V. PERFORMANCE EVALUATION 

Based on our optimized RISC-V software implementation as outlined in III and IV, the experimental results for Kyber and Dilithium are presented. 

## _A. Experimental platforms_ 

**SiFive U74 4-core.** Our CPU hardware environment comprises a CPU SiFive U74, featuring a 4-core 64-bit RV64GC architecture running at 1.5GHz, with 4 GB LPDDR4 memory. The Debian GNU/Linux bookworm/sid operating system facilitates the software ecosystem, alongside GCC version 11.3.0 (Debian 11.3.0-3) as the toolchain. The power consumption is approximately 15W. 

**Comparative platforms.** The 64-bit platforms currently available for comparison optimized for software implementation are Cortex-A55, a dual-issue out-of-order architecture and Cortex-A75, a triple-issue out-of-order architecture. Becker et al. [7] implemented Keccak while Abdulrahman et al. [18] implemented NTT. Sanal et al. [17] implemented NTT and Kyber. Due to the lack of experiments with 64-bit RISC-V ISA implementation, we also introduce the current best-performing experiment [11] based on ARMv7-M ISA implementation (Cortex-M4) and a hardware SIMD architecture [19] that supports RV32IMC ISA to compare the performance of Kyber and Dilithium. SiFive Freedom E310 is a 32-bit single-issue processor where Huang et al. [10] implemented the entire Kyber. 

## _B. Performance of Keccak_ 

**==> picture [230 x 133] intentionally omitted <==**

**----- Start of picture text -----**<br>
CYCLE COUNTS AND THROUGHPUT OF<br>KECCAK-P[1600,24]<br>Cycle counts Throughput<br>5713<br>6000 700000<br>643225<br>5000 600000<br>541516<br>500000<br>4000<br>2770 400000<br>3000 2332<br>300000<br>262559<br>2000<br>200000<br>1000 100000<br>0 0<br>Reference impl. RV64IMB impl. Generalized impl.<br>**----- End of picture text -----**<br>


Fig. 5. Performance of Keccak- _p_ [1600,24] on SiFive U74 

**==> picture [487 x 118] intentionally omitted <==**

**----- Start of picture text -----**<br>
CYCLE COUNTS OF KYBER CYCLE COUNTS OF DILITHIUM<br>Reference implementation Opt based on  Montgomery arithmetic Opt based on  Plantard arithmetic Reference implementation Opt based on  Montgomery arithmetic Opt based on  Plantard arithmetic<br>3019820<br>KeyGen 439860 1017671 KeyGen 13639021408693<br>398705<br>1241006 9111368<br>Encapsulation 497831 Sign 3832573<br>447619 3191169<br>1389276 3197740<br>Decapsulation 551950 Verify 1450846<br>478526 1368514<br>0 200000 400000 600000 800000 1000000 1200000 1400000 1600000 0 2000000 4000000 6000000 8000000 10000000<br>**----- End of picture text -----**<br>


Fig. 6. Performance of Kyber and Dilithium on SiFive U74 

Fig. 5 shows the cycle counts of Keccak- _p_ [1600,24] on SiFive U74. We implement Keccak on RV64IMB ISA for Better scheduling of Keccak rounds. Except for using the **rori** and **andn** instructions, we also refactor the instruction execution order in a dual-issue path. Compared to the NIST reference implementation [32], our optimized scheduling of Keccak based on RV64IMB implementation achieves a speedup of 59.18%. For the generalized implementation, which does not utilize the **rori** and **andn** instructions, we achieve a speed-up of 51.51%. The maximum throughput of Keccak can achieve up to 643k operations per second. However, our best performance of Keccak consumes more 914 cycle counts than [7]. The distinction between our work and [7] lies in CortexA55 supports substituting explicit rotations with extensive use of the Barrel shifter operation, resulting in a significant performance improvement. 

## _C. Performance of polynomial and matrix-vector multiplication_ 

Table IV presents the performance of NTT, matrix-vector multiplication, and INTT. For all implementations, we provide the NIST reference implementation of Kyber [5] and Dilithium [2] on 64-bit RISC-V ISA for better comparison. By introducing two arithmetic, NTT is designed in a flexible dual-instruction-issue way. Matrix-vector multiplication is transformed from a row-based approach to a column-based approach. INTT is also in a flexible dual-instruction-issue way. Compared to Montgomery arithmetic, Plantard arithmetic used 2 fewer variables which leads more flexible dual-issue. 

## TABLE IV 

CYCLE COUNTS OF POLYNOMIAL AND MATRIX-VECTOR MULTIPLICATION 

|Implementation of Kyber|NTT|Matrix-vector Multiplication|INTT|
|---|---|---|---|
|Cortex-A55 (AArch64+NEON [18])|891|-|-|
|Cortex-A75 (AArch64+SIMD [17])|2332|-|3209|
|This work (C-ref [5])|24 525|214 995|38 920|
|This work (optimized based<br>on Montgomery arithmetic)|8 845<br>63.93%|50 797<br>76.37%|10 262<br>73.63%|
|This work (optimized based<br>on Plantard arithmetic)|5 700<br>76.76%|45 774<br>78.71%|5 618<br>85.57%|
|Implementation of Dilithium|NTT|Matrix-vector Multiplication|INTT|
|Cortex-A55 (AArch64+Neon [18])|1728|-|-|
|This work (C-ref [2])|24 202|310 898|27 258|
|This work (optimized based<br>on Montgomery arithmetic)|9 131<br>62.27%|141 385<br>54.52%|9 255<br>66.05%|
|This work (optimized based<br>on Plantard arithmetic)|5 893<br>75.65%|143 488<br>53.85%|5 736<br>78.96%|



Multiplication instructions have a throughput of 1 and a 3-cycle latency. Because our target platform is a dual-issue platform, we can estimate a lower bound for the number of cycles for an NTT using the number of multiplications and additions. The butterfly of Kyber and Dilithium requires 2 multiplications and 5 additions with plantard multiplication which in total should require (2 _×_ 3 + 5) _/_ 2 = 5 _._ 5 cycles on the dual-issue platform. We expect the NTT with Plantard arithmetic would require 128 _×_ 7 _×_ 5.5 = 4928 cycles and 128 _×_ 8 _×_ 5.5 = 5632 cycles for the 7-layer and 8- layer NTT in Kyber and Dilithium, respectively. The current implementations take 5700 cycles and 5893 cycles which are very close to the lower bounds. Only a small fraction of the cycles would be spent on load, store, and other overhead. 

Compared to the reference implementation, our proposed NTT obtains speedups of 63.93% and 76.76% in Kyber and 62.27% and 75.65% in Dilithium. Our matrixvector multiplication achieves speedups of 76.37%/78.71% and 54.52%/53.85% for Kyber and Dilithium, respectively. In Dilithium, the matrix-vector multiplication does not need to precompute _sk_ 2 _t_ +1 _ζ_[2] _[br]_[7][(] _[t]_[)+1] , resulting in a minimal difference between using Montgomery arithmetic and Plantard arithmetic. INTT achieves speedups of 73.63%/85.57% and 66.05%/78.96% in Kyber and Dilithium, respectively. Our NTT implementations in Kyber and Dilithium are 6.40 _×_ and 3.41 _×_ slower than [18] as they reserved the Neon units for the core arithmetic. For the optimized vectorized implementation [17] of NTT/INTT in Kyber on triple-issue architecture, our implementations are 2.44 _×_ /1.75 _×_ slower than them. However, we believe it is normal for our implementation to be slower than theirs because their platforms have more powerful SIMD instruction set than ours. 

## _D. Performance of Kyber and Dilithium_ 

Fig. 6 shows the performance of our ECO-CRYSTALS on the 64-bit processor. We apply various optimizations focused on Keccak, polynomial and matrix-vector multiplication to the cryptographic suite. The overall reference implementation of Kyber [5] and Dilithium [2] are listed. Compared with Montgomery arithmetic, Plantard arithmetic consumes fewer numbers of instructions and performs fewer modular reductions. Hence, Plantard arithmetic demonstrates superior 

performance compared to Montgomery arithmetic when employed in both Kyber and Dilithium. Finally, the cycle counts of key generation, encapsulation, and decapsulation in Kyber with Plantard arithmetic are faster by 60.82%, 63.93%, and 65.56% respectively compared to the reference implementation. And, the cycle counts of key generation, sign, and verify in Dilithium are faster by 54.84%, 64.98%, and 57.20% respectively compared to the reference implementation. 

## _E. Comparison with Related Work_ 

Since this paper is the first software implementation that deploys Kyber and Dilithium on a 64-bit RISC-V platform, we are unable to conduct comparisons with other implementations on the same platform. Therefore, we compare the performance of ECO-CRYSTALS with the leading performance achieved on 32-bit RISC-V [10], [19], 32-bit ARM [11] or 64-bit ARM platforms [17]. 

As shown in Table V, our key generation, encapsulation, and decapsulation in Kyber are 1.75 _×_ , 1.65 _×_ , and 1.77 _×_ slower than that of Cortex-A75 [17], respectively. The slow-downs mainly come from the advantage of SIMD operations on polynomial multiplication and triple-issue architecture which are not applicable to our target platform. The performance of key generation, encapsulation, and decapsulation in Kyber are 2.05 _×_ , 2.26 _×_ , and 1.96 _×_ slower than that of CV32E40P, respectively. Additionally, the performance of key generation, sign, and verify in Dilithium are 2.92 _×_ , 2.72 _×_ , and 2.55 _×_ slower than that of [19] respectively. The slow-downs are reasonable because their work is a hardware-software codesign that introduced 256-bit SIMD operations to improve the PQC performance, while our ECO-CRYSTALS is merely a software implementation, and the target platform does not support vector extension. 

TABLE V 

COMPARISON OF CYCLE COUNTS WITH THE STATE-OF-THE-ART WORKS 

|Platform|Kyber1024|KeyGen|Encapsulation|Decapsulation|
|---|---|---|---|---|
|Cortex-M4|Huang et al. [11]|962k|1 119k|1 043k|
|Cortex-A75|Sanal et al. [17]|228k|272k|271k|
|CV32E40P|Ye et al. [19]|195k|198k|244k|
|SiFive Freedom E310|Huang et al. [10]|3 794k|4 435k|4 045k|
|SiFive U74|This work|**399k**|**448k**|**479k**|
|Platform|Dilithium5|KeyGen|Sign|Verify|
|Cortex-M4|Huang et al. [11]|4 069k|7 730k|3 998k|
|CV32E40P|Ye et al. [19]|467k|1 173k|537k|
|SiFive U74|This work|**1 364k**|**3 191k**|**1 369k**|



To the best of our knowledge, the most high-performing 32bit RISC-V ISA implementation of Kyber currently available is provided by [10]. Compared to the implementation in [10], our key generation, encapsulation, and decapsulation in our Kyber implementation are 9.51 _×_ , 9.90 _×_ , and 8.44 _×_ faster than that of the 32-bit RISC-V ISA implementation [10], respectively. The large speed-ups mainly come from the fact that their platform is a 32-bit single-issue RISC-V platform, which are very different and incomparable from our 64-bit dual-issue platform. Compared to the best-performing implementation on the 32-bit ARM Cortex-M4 in [11], the key generation, encapsulation, and decapsulation in Kyber 

are 2.41 _×_ , 2.50 _×_ , and 2.18 _×_ faster than that of Cortex-M4, respectively. Additionally, the key generation, sign, and verify in Dilithium are 2.98 _×_ , 2.42 _×_ , and 2.92 _×_ faster than that of the 32-bit single-issued Cortex-M4. 

## VI. CONCLUSION 

In this paper, we optimize the instruction execution order in a dual-issue mode for better scheduling of Keccak and employ two modular arithmetic with various optimizations to enhance polynomial multiplication. For NTT, we propose a flexible dual-instruction-issue scheme. For the matrix-vector multiplication, we introduce a row-to-column processing methodology to minimize the expensive memory access operations. Finally, the cycle counts of key generation, encapsulation, and decapsulation in Kyber are 60.82%, 63.93%, and 65.56% faster than that of NIST reference implementation, respectively. And, the cycle counts of key generation, sign, and verify in Dilithium are 54.84%, 64.98%, and 57.20% faster than that of the NIST reference implementation. 

## REFERENCES 

- [1] P. W. Shor, “Polynomial-time algorithms for prime factorization and discrete logarithms on a quantum computer,” _SIAM review_ , vol. 41, no. 2, pp. 303–332, 1999. 

- [2] L. Ducas, E. Kiltz, T. Lepoint, V. Lyubashevsky, P. Schwabe, G. Seiler, and D. Stehl´e, “Crystals-dilithium: A lattice-based digital signature scheme,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pp. 238–268, 2018. 

- [3] T. Prest, P.-A. Fouque, J. Hoffstein, P. Kirchner, V. Lyubashevsky, T. Pornin, T. Ricosset, G. Seiler, W. Whyte, and Z. Zhang, “Falcon,” _Post-Quantum Cryptography Project of NIST_ , 2020. 

- [4] D. J. Bernstein, A. H¨ulsing, S. K¨olbl, R. Niederhagen, J. Rijneveld, and P. Schwabe, “The sphincs+ signature framework,” in _Proceedings of the 2019 ACM SIGSAC conference on computer and communications security_ , 2019, pp. 2129–2146. 

- [5] J. Bos, L. Ducas, E. Kiltz, T. Lepoint, V. Lyubashevsky, J. M. Schanck, P. Schwabe, G. Seiler, and D. Stehl´e, “Crystals-kyber: a cca-secure module-lattice-based kem,” in _2018 IEEE European Symposium on Security and Privacy (EuroS&P)_ . IEEE, 2018, pp. 353–367. 

- [6] E. Alkim, Y. A. Bilgin, M. Cenk, and F. G´erard, “Cortex-m4 optimizations for _{_ R, M _}_ LWE schemes,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , vol. 2020, pp. 336–357, 2020. 

- [7] H. Becker and M. J. Kannwischer, “Hybrid scalar/vector implementations of keccak and sphincs+ on aarch64,” in _International Conference on Cryptology in India_ . Springer, 2022, pp. 272–293. 

- [8] A. Abdulrahman, J.-P. Chen, Y.-J. Chen, V. Hwang, M. J. Kannwischer, and B.-Y. Yang, “Multi-moduli ntts for saber on cortex-m3 and cortexm4,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pp. 127–151, 2022. 

- [9] J. Huang, J. Zhang, H. Zhao, Z. Liu, R. C. Cheung, C¸ . K. Koc¸, and D. Chen, “Improved plantard arithmetic for lattice-based cryptography,” _Cryptology ePrint Archive_ , 2022. 

- [10] J. Huang, H. Zhao, J. Zhang, W. Dai, L. Zhou, R. C. Cheung, C¸ . K. Koc¸, and D. Chen, “Yet another improvement of plantard arithmetic for faster kyber on low-end 32-bit iot devices,” _IEEE Transactions on Information Forensics and Security_ , 2024. 

- [11] J. Huang, A. Adomnic˘ai, J. Zhang, W. Dai, Y. Liu, R. C. Cheung, C¸ . K. Koc¸, and D. Chen, “Revisiting keccak and dilithium implementations on armv7-m,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , vol. 2024, no. 2, pp. 1–24, 2024. 

- [12] D. Aoki, K. Minematsu, T. Okamura, and T. Takagi, “Efficient word size modular multiplication over signed integers,” in _2022 IEEE 29th Symposium on Computer Arithmetic (ARITH)_ . IEEE, 2022, pp. 94– 101. 

- [13] G. Seiler, “Faster avx2 optimized ntt multiplication for ring-lwe lattice cryptography,” _Cryptology ePrint Archive_ , 2018. 

- [14] C.-M. M. Chung, V. Hwang, M. J. Kannwischer, G. Seiler, C.-J. Shih, and B.-Y. Yang, “NTT multiplication for NTT-unfriendly rings: New speed records for Saber and NTRU on Cortex-M4 and AVX2,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pp. 159–188, 2021. 

- [15] N. Gupta, A. Jati, A. K. Chauhan, and A. Chattopadhyay, “Pqc acceleration using gpus: Frodokem, newhope, and kyber,” _IEEE Transactions on Parallel and Distributed Systems_ , vol. 32, no. 3, pp. 575–586, 2020. 

- [16] X. Ji, J. Dong, T. Deng, P. Zhang, J. Hua, and F. Xiao, “Hi-kyber: A novel high-performance implementation scheme of kyber based on gpu,” _IEEE Transactions on Parallel and Distributed Systems_ , 2024. 

- [17] P. Sanal, E. Karagoz, H. Seo, R. Azarderakhsh, and M. MozaffariKermani, “Kyber on arm64: Compact implementations of kyber on 64bit arm cortex-a processors,” in _International Conference on Security and Privacy in Communication Systems_ . Springer, 2021, pp. 424–440. 

- [18] A. Abdulrahman, H. Becker, M. J. Kannwischer, and F. Klein, “Fast and clean: Auditable high-performance assembly via constraint solving,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , vol. 2024, no. 1, pp. 87–132, 2024. 

- [19] Z. Ye, R. Song, H. Zhang, D. Chen, R. C.-C. Cheung, and K. Huang, “A highly-efficient lattice-based post-quantum cryptography processor for iot applications,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , vol. 2024, no. 2, pp. 130–153, 2024. 

- [20] G. Bertoni, J. Daemen, M. Peeters, G. Van Assche, and R. Van Keer, “KECCAK implementation overview (May 2012),” http://keccak. noekeon.org/. 

- [21] V. Lyubashevsky, “Lattice signatures without trapdoors,” in _Annual International Conference on the Theory and Applications of Cryptographic Techniques_ . Springer, 2012, pp. 738–755. 

- [22] P. L. Montgomery, “Modular multiplication without trial division,” _Mathematics of computation_ , vol. 44, no. 170, pp. 519–521, 1985. 

- [23] P. Barrett, “Implementing the rivest shamir and adleman public key encryption algorithm on a standard digital signal processor,” in _Conference on the Theory and Application of Cryptographic Techniques_ . Springer, 1986, pp. 311–323. 

- [24] T. Plantard, “Efficient word size modular arithmetic,” _IEEE Transactions on Emerging Topics in Computing_ , vol. 9, no. 3, pp. 1506–1518, 2021. 

- [25] J. W. Cooley and J. W. Tukey, “An algorithm for the machine calculation of complex fourier series,” _Mathematics of computation_ , vol. 19, no. 90, pp. 297–301, 1965. 

- [26] D. Pei, A. Salomaa, and C. Ding, _Chinese remainder theorem: applications in computing, coding, cryptography_ . World Scientific, 1996. 

- [27] W. M. Gentleman and G. Sande, “Fast fourier transforms: for fun and profit,” in _Proceedings of the November 7-10, 1966, fall joint computer conference_ , 1966, pp. 563–578. 

- [28] Mjosaarinen, “RISC-V Cryptography Extension,” https://github.com/ riscv/riscv-crypto/blob/main/benchmarks/sha3/zscrypto rv64/Keccak.c, 2024. 

- [29] SiFive. (2024) Vf2 software documentation. [Online]. Available: https://www.sifive.com/documentation 

- [30] H. Becker, V. Hwang, M. J. Kannwischer, B.-Y. Yang, and S.-Y. Yang, “Neon ntt: Faster dilithium, kyber, and saber on cortex-a72 and apple m1,” _IACR Transactions on Cryptographic Hardware and Embedded Systems_ , pp. 221–244, 2022. 

- [31] A. Abdulrahman, V. Hwang, M. J. Kannwischer, and A. Sprenkels, “Faster Kyber and Dilithium on the Cortex-M4,” in _Applied Cryptography and Network Security: 20th International Conference, ACNS 2022, Rome, Italy, June 20–23, 2022, Proceedings_ . Springer, 2022, pp. 853– 871. 

- [32] G. Bertoni, J. Daemen, M. Peeters, and G. Van Assche, “Keccak,” in _Annual international conference on the theory and applications of cryptographic techniques_ . Springer, 2013, pp. 313–314. 

**==> picture [62 x 86] intentionally omitted <==**

**==> picture [62 x 86] intentionally omitted <==**

**==> picture [66 x 91] intentionally omitted <==**

**==> picture [66 x 91] intentionally omitted <==**

**==> picture [64 x 91] intentionally omitted <==**

**==> picture [62 x 91] intentionally omitted <==**

**Xinyi Ji** received her B.E. degree from Nanjing University of Posts and Telecommunications in 2022, and currently pursuing a Ph.D. degree in the School of Computer Science and Technology, Nanjing University of Posts and Telecommunications. Her research interests include cryptographic engineering, lattice-based cryptography, post-quantum cryptography, and high-performance computing. 

**Jiankuo Dong** received the B.E. degree from the Xi’an Jiaotong University, and the Ph.D. degree from the University of Chinese Academy of Sciences in 2014 and 2019, respectively. He is currently an Assistant Professor with School of Computer Science, Nanjing University of Posts and Telecommunications. His research interests include cryptographic engineering, public key cryptography and applied cryptography. 

**Junhao Huang** received his Bachelor and Master degrees from Nanjing University of Aeronautics and Astronautics in 2018, and 2021, respectively. He is currently a PhD student at BNU-HKBU United International College and Hong Kong Baptist University. His research interests are public-key cryptography, post-quantum cryptography and cryptographic engineering. 

**Zhijian Yuan** received his B.E. degree from Nanjing University of Information Science and Technology in 2022, and currently pursuing an MS. degree in the School of Computer Science and Technology, Nanjing University of Posts and Telecommunications. His research interests include cryptographic engineering, post-quantum cryptography, and highperformance computing. 

**Wangchen Dai** received the Ph.D. degree in electronic engineering from the City University of Hong Kong in 2018. After that, he had appointments at Hardware Security Lab, Huawei Technologies Company Ltd., and the Department of CSSE, Shenzhen University. He is currently working as a Senior Researcher with Zhejiang Lab, Hangzhou, China. His research interests include cryptographic hardware and embedded systems, fully homomorphic encryption, and reconfigurable computing. 

**Fu Xiao** received the Ph.D. degree in computer science and technology from the Nanjing University of Science and Technology, Nanjing, China, in 2007. He is currently a Professor and a Ph.D. Supervisor with the School of Computer Science and Technology, Nanjing University of Posts and Telecommunications. His research interest includes wireless sensor networks. Prof. Xiao is a member of the IEEE Computer Society and the Association for Computing Machinery. 

**==> picture [64 x 91] intentionally omitted <==**

**Jingqiang Lin** School of Cyber Security, University of Science and Technology of China, Hefei, China. Jingqiang Lin (Senior Member, IEEE) received the M.S. and Ph.D. degrees from the University of Chinese Academy of Sciences, in 2004 and 2009, respectively. He is a Full Professor with the School of Cyber Security, University of Science and Technology of China. His research interests include applied cryptography and system security. 

